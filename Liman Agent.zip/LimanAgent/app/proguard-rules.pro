# Keep Rhino script engine classes (used by the run_js agent tool)
-keep class org.mozilla.javascript.** { *; }
-dontwarn org.mozilla.javascript.**

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.liman.agent.**$$serializer { *; }
-keepclassmembers class com.liman.agent.** { *** Companion; }
-keepclasseswithmembers class com.liman.agent.** { kotlinx.serialization.KSerializer serializer(...); }
