package com.liman.agent.agent

import java.io.File
import java.security.MessageDigest

/**
 * v2.21.0 — THE STORAGE DOCTOR (intelligent investigator + cleanup with undo).
 *
 * Not "find largest file" — the phone's AI system administrator:
 *  - triage everything in the user's granted folders into
 *    SAFE TO DELETE / REVIEW FIRST / DO NOT TOUCH, with reasons and
 *    reclaimable bytes;
 *  - cleanup NEVER deletes: it QUARANTINES (copies into the workspace vault
 *    + manifest with original path + sha256) and only then removes the
 *    original — every cleanup is undoable with one command.
 *
 * Triage logic is pure (unit-tested); SAF walking lives in the tool layer.
 */
object StorageDoctor {

    data class FileFacts(
        val relPath: String,
        val name: String,
        val size: Long,
        val modified: Long,
        val mime: String
    ) {
        val ext: String = name.substringAfterLast('.', "").lowercase()
        val isDir: Boolean = mime == "vnd.android.document/directory" || mime == "dir"
    }

    data class Group(
        val label: String,
        val reason: String,
        val files: List<FileFacts>,
        val bytes: Long
    )

    data class Report(
        val safe: List<Group>,
        val review: List<Group>,
        val keep: Group,
        val totalFiles: Int,
        val totalBytes: Long,
        val reclaimableSafe: Long,
        val reclaimableWithReview: Long
    )

    private val TEMP_EXTS = setOf("tmp", "temp", "log", "bak", "old", "part", "crdownload", "partial", "swp")
    private val ARCHIVE_EXTS = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz")
    private val VIDEO_EXTS = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv")
    private val DOC_EXTS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv", "json", "epub")
    private val IMAGE_EXTS = setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "bmp")

    fun triage(files: List<FileFacts>, nowMs: Long = System.currentTimeMillis()): Report {
        val real = files.filter { !it.isDir }
        // exact duplicates: identical name AND size in different folders
        val byNameSize = real.filter { it.size > 0 }.groupBy { it.name.lowercase() to it.size }
        val dupPaths = byNameSize.values.filter { it.size > 1 }
            .flatten().map { it.relPath }.toHashSet()
        // likely duplicates: identical large size, different names (REVIEW)
        val bySize = real.filter { it.size > 1_000_000 }.groupBy { it.size }
        val likelyDupPaths = bySize.values.filter { it.size > 1 }
            .flatten().map { it.relPath }.toHashSet()

        val safe = mutableListOf<Group>()
        val review = mutableListOf<Group>()

        val temp = real.filter { it.ext in TEMP_EXTS || it.name.endsWith("~") || it.name.startsWith(".") && it.ext != "" }
        if (temp.isNotEmpty()) safe += Group("Temporary & log files", "temp/log/bak/part files — safe to remove", temp, temp.sumOf { it.size })

        val dups = real.filter { it.relPath in dupPaths }
        if (dups.isNotEmpty()) safe += Group("Exact duplicates", "same name + same size in different folders", dups, dups.sumOf { it.size })

        val apks = real.filter { it.ext == "apk" }
        if (apks.isNotEmpty()) review += Group("Installed-package leftovers (.apk)", "installers you probably already installed", apks, apks.sumOf { it.size })

        val archives = real.filter { it.ext in ARCHIVE_EXTS }
        if (archives.isNotEmpty()) review += Group("Archives", "zip/rar/7z — check content before removing", archives, archives.sumOf { it.size })

        val oldVideos = real.filter { it.ext in VIDEO_EXTS && nowMs - it.modified > 90L * 24 * 3600 * 1000 }
        if (oldVideos.isNotEmpty()) review += Group("Videos older than 90 days", "not touched in 3+ months", oldVideos, oldVideos.sumOf { it.size })

        val huge = real.filter { it.size > 50_000_000L }
        if (huge.isNotEmpty()) review += Group("Files over 50 MB", "worth a conscious decision", huge, huge.sumOf { it.size })

        val likely = real.filter { it.relPath in likelyDupPaths && it.relPath !in dupPaths }
        if (likely.isNotEmpty()) review += Group("Likely duplicates (same size)", "identical size >1MB, different names — verify before removing", likely, likely.sumOf { it.size })

        val flagged = safe.flatMap { it.files } + review.flatMap { it.files }
        val keepFiles = real.filter { f -> flagged.none { it.relPath == f.relPath } }
        val keep = Group(
            "KEEP (do not touch)",
            "documents, recent media, projects, everything else",
            keepFiles,
            keepFiles.sumOf { it.size }
        )
        val safeBytes = safe.sumOf { it.bytes }
        val reviewBytes = review.sumOf { it.bytes }
        return Report(
            safe = safe, review = review, keep = keep,
            totalFiles = real.size, totalBytes = real.sumOf { it.size },
            reclaimableSafe = safeBytes, reclaimableWithReview = safeBytes + reviewBytes
        )
    }

    fun fmtBytes(b: Long): String = when {
        b >= 1_000_000_000L -> String.format("%.1f GB", b / 1e9)
        b >= 1_000_000L -> String.format("%.0f MB", b / 1e6)
        b >= 1_000L -> String.format("%.0f KB", b / 1e3)
        else -> "$b B"
    }

    fun renderReport(r: Report, rootLabel: String, maxPerGroup: Int = 12): String = buildString {
        appendLine("STORAGE DOCTOR — $rootLabel: ${r.totalFiles} files, ${fmtBytes(r.totalBytes)}")
        appendLine("Reclaimable: ${fmtBytes(r.reclaimableSafe)} SAFE + ${fmtBytes(r.reclaimableWithReview - r.reclaimableSafe)} after review.")
        appendLine()
        if (r.safe.isEmpty() && r.review.isEmpty()) {
            appendLine("Nothing suspicious found — this folder is already clean.")
        }
        if (r.safe.isNotEmpty()) {
            appendLine("## SAFE TO DELETE (${fmtBytes(r.reclaimableSafe)})")
            r.safe.forEach { g ->
                appendLine("- ${g.label} · ${g.files.size} file(s) · ${fmtBytes(g.bytes)} — ${g.reason}")
                g.files.take(maxPerGroup).forEach { appendLine("    ${it.relPath} (${fmtBytes(it.size)})") }
            }
        }
        if (r.review.isNotEmpty()) {
            appendLine()
            appendLine("## REVIEW FIRST")
            r.review.forEach { g ->
                appendLine("- ${g.label} · ${g.files.size} file(s) · ${fmtBytes(g.bytes)} — ${g.reason}")
                g.files.take(maxPerGroup).forEach { appendLine("    ${it.relPath} (${fmtBytes(it.size)})") }
            }
        }
        appendLine()
        appendLine("## KEEP — ${r.keep.files.size} file(s), ${fmtBytes(r.keep.bytes)} (documents, recent media, projects…)")
        appendLine()
        appendLine("Cleanup is UNDOABLE: files are quarantined to the workspace vault (manifest + originals) before removal. Show this plan to the user, get approval, then storage_clean {action:\"quarantine\", paths:[…]} — or \"undo\" to restore the last batch.")
    }
}

/**
 * The quarantine vault: manifests with original locations + sha256 so every
 * cleanup is reversible. Pure file logic (unit-tested).
 */
object Quarantine {

    @kotlinx.serialization.Serializable
    data class Entry(
        val rootLabel: String,
        val relPath: String,
        val name: String,
        val size: Long,
        val sha256: String,
        val quarantinedAt: Long
    )

    @kotlinx.serialization.Serializable
    data class Manifest(val batch: String, val entries: List<Entry>)

    fun vaultDir(workspace: File): File = File(workspace, "quarantine")

    fun newBatchDir(workspace: File): File {
        val dir = File(vaultDir(workspace), "batch-" + System.currentTimeMillis())
        dir.mkdirs()
        return dir
    }

    fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    fun writeManifest(batchDir: File, entries: List<Entry>) {
        val m = Manifest(batchDir.name, entries)
        File(batchDir, "manifest.json").writeText(
            com.liman.agent.util.JSON.encodeToString(Manifest.serializer(), m)
        )
    }

    /** Latest batch manifest (by dir name timestamp), or null. */
    fun latest(workspace: File): Pair<File, Manifest>? {
        val root = vaultDir(workspace)
        val dirs = root.listFiles { f -> f.isDirectory && f.name.startsWith("batch-") }
            .orEmpty().sortedByDescending { it.name }
        for (d in dirs) {
            val f = File(d, "manifest.json")
            if (f.exists()) {
                runCatching {
                    return d to com.liman.agent.util.JSON.decodeFromString(Manifest.serializer(), f.readText())
                }
            }
        }
        return null
    }
}
