package com.liman.agent.agent

/**
 * v2.28.0 — TERMUX DEPENDENCY SELF-HEAL.
 *
 * The user's complaint: "it doesn't use termux easily to install any
 * dependencies". Instead of failing with `command not found` and leaving the
 * model to improvise, the bridge now recognizes the missing-dependency
 * fingerprint in the output, auto-installs the right package ONCE, and
 * retries the command.
 *
 * Pure logic — unit-tested; execTermuxRun applies it.
 */
object TermuxHeal {

    /** common binaries → the Termux pkg that provides them */
    private val BIN_TO_PKG = mapOf(
        "python3" to "python", "python" to "python",
        "pip3" to "python-pip", "pip" to "python-pip",
        "node" to "nodejs", "npm" to "nodejs", "npx" to "nodejs",
        "git" to "git", "ffmpeg" to "ffmpeg",
        "curl" to "curl", "wget" to "wget", "jq" to "jq",
        "zip" to "zip", "unzip" to "unzip", "tar" to "tar",
        "clang" to "clang", "gcc" to "clang", "make" to "make",
        "cargo" to "rust", "rustc" to "rust",
        "ssh" to "openssh", "scp" to "openssh",
        "tmux" to "tmux", "vim" to "vim", "nano" to "nano",
        "termux-api" to "termux-api"
    )

    data class Fix(
        val kind: String,          // "missing-binary" | "missing-python-module"
        val missing: String,       // binary or module name
        val installCommand: String // what we auto-run ONCE
    )

    // "bash: jq: command not found" (prefixed) · "npm: command not found" (bare) ·
    // "zsh:1: command not found: jq" (zsh, name at the end)
    private val CMD_NOT_FOUND = Regex("""(?m)^(?:[^\s:]+:\s*)?((?!command\b)\S+):\s*(?:command not found|not found)\b""")
    private val CMD_NOT_FOUND_ZSH = Regex("""(?i)command not found:\s*(\S+)""")
    private val NO_MODULE = Regex("""(?i)module named\s+'?([A-Za-z0-9_.-]+)'?""")

    /**
     * Recognize a missing-dependency fingerprint in command output.
     * Returns the fix to apply, or null when the output looks healthy
     * (or unhealable — those get no false hope).
     */
    fun diagnose(output: String): Fix? {
        // 1) python module missing → pip install
        NO_MODULE.find(output)?.let { m ->
            val mod = m.groupValues[1].substringBefore('.')
            if (mod.isNotBlank() && mod !in setOf("os", "sys", "json", "re", "math", "time", "datetime"))
                return Fix("missing-python-module", mod, "pip install -q $mod || pip3 install -q $mod")
        }
        // 2) binary missing → pkg install (only ones we know a package for)
        CMD_NOT_FOUND.findAll(output).forEach { m ->
            val bin = m.groupValues[1].substringAfterLast('/')
            BIN_TO_PKG[bin]?.let { pkg -> return Fix("missing-binary", bin, "pkg install -y $pkg") }
        }
        CMD_NOT_FOUND_ZSH.find(output)?.let { m ->
            val bin = m.groupValues[1].substringAfterLast('/').trim(':', '\r', '\n')
            BIN_TO_PKG[bin]?.let { pkg -> return Fix("missing-binary", bin, "pkg install -y $pkg") }
        }
        return null
    }

    /** The teaching text appended after an auto-heal, so the model learns the pattern. */
    fun healReport(fix: Fix, retryOutput: String): String = buildString {
        appendLine("🔧 SELF-HEAL: your command failed because '${fix.missing}' is not installed (${fix.kind}).")
        appendLine("I auto-ran: ${fix.installCommand}")
        appendLine("Then retried your command. Result:")
        appendLine(retryOutput.take(18_000))
        appendLine("(Remember: Termux installs packages with 'pkg install <name>' — you can also run that yourself before commands that need a tool.)")
    }
}
