package com.liman.agent.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import com.liman.agent.LimanApplication
import com.liman.agent.R
import com.liman.agent.agent.Scheduler
import com.liman.agent.data.PipelineDef
import com.liman.agent.data.ScheduledTask
import com.liman.agent.util.fmtTime

/**
 * v2.21.0 — THE ＋ NEW AUTOMATION screen.
 *
 * The "#1 wow feature": describe what should run on its own → Liman builds
 * the pipeline (trigger + AI transform steps + outputs) and it runs unattended
 * via the scheduler. Existing automations show live state; run-now and
 * pause/resume work from here.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutomationsScreen(
    onBack: () -> Unit,
    onOpenChat: (String) -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as LimanApplication
    val stores = app.container.stores
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var refresh by remember { mutableStateOf(0) }
    // read fresh every recomposition (refresh ticks after mutations)
    val pipelines = stores.pipelines.state.value

    var idea by remember { mutableStateOf("") }
    var runningNow by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Automations") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .padding(horizontal = 16.dp)
        ) {
            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        "＋ New automation",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Describe it once — Liman builds the pipeline (sources → AI transform → outputs) and runs it on schedule, even closed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = idea,
                        onValueChange = { idea = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = {
                            Text("Every day at 8, check these Telegram channels, summarize the best engineering news in Persian and post it to my channel…")
                        },
                        minLines = 3
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        enabled = idea.isNotBlank(),
                        onClick = {
                            val conv = stores.conversations.newConversation()
                            conv.title = "⚙ " + idea.take(34)
                            app.container.pendingDrafts[conv.id] =
                                "Build me an automation that: $idea\n\n" +
                                    "Use the automation tool to create it (choose a sensible trigger — ask me only if it genuinely matters; " +
                                    "use activeHours so it never runs while I sleep). Show me the pipeline you built and run it once now to prove it works."
                            scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                runCatching { stores.conversations.save(conv) }
                            }
                            idea = ""
                            onOpenChat(conv.id)
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) { Text("Build with Liman") }
                }
            }

            Spacer(Modifier.height(12.dp))
            if (pipelines.isEmpty()) {
                Text(
                    "No automations yet — describe your first one above.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(pipelines, key = { it.id }) { p ->
                        Card(
                            Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (p.enabled) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                            )
                        ) {
                            Column(Modifier.padding(13.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            p.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            PipelineDef.triggerText(p) +
                                                (if (p.lastRunAt > 0) " · last run ${p.lastRunAt.fmtTime()}" else " · never run"),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        if (p.enabled) "🟢" else "⏸",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                }
                                if (p.description.isNotBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        p.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Row {
                                    TextButton(
                                        enabled = runningNow == null,
                                        onClick = {
                                            runningNow = p.id
                                            Thread {
                                                runCatching {
                                                    stores.pipelines.touch(p.id)
                                                    Scheduler.runTask(
                                                        context,
                                                        ScheduledTask(
                                                            id = "pipe-run",
                                                            title = "⚙ " + p.name.take(40),
                                                            prompt = PipelineDef.runPrompt(p),
                                                            enabled = true
                                                        )
                                                    )
                                                    Scheduler.notify(context, "⚙ Automation finished", p.name)
                                                }
                                                runningNow = null
                                            }.start()
                                        }
                                    ) { Text(if (runningNow == p.id) "Running…" else "Run now") }
                                    TextButton(onClick = {
                                        stores.pipelines.upsert(p.copy(enabled = !p.enabled))
                                        Scheduler.syncPipelines(context)
                                        refresh += 1
                                    }) { Text(if (p.enabled) "Pause" else "Resume") }
                                    Spacer(Modifier.weight(1f))
                                    TextButton(onClick = {
                                        stores.pipelines.delete(p.id)
                                        Scheduler.syncPipelines(context)
                                        refresh += 1
                                    }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
