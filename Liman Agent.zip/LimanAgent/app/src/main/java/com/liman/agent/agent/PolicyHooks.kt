package com.liman.agent.agent

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * v2.29.0 — THE HARDENED HARNESS (from the SUPER AGENT blueprints).
 *
 * Deterministic guardrails that don't depend on the model behaving:
 *  • DangerousCommands — PreToolUse denial of destructive shell patterns
 *    ("make autonomy safe by making actions observable and reversible — the
 *    rest is a bomb", blueprint §14).
 *  • Untrusted — provenance tagging of all external content so prompt
 *    injection can't hijack the agent (blueprint §14.5: "your #1 security
 *    risk").
 *  • SecretRedactor — keys never land in logs (blueprint §20).
 *  • OutputShaper — head+tail truncation, full output spilled to a workspace
 *    file the model can read_file back (blueprint §5 principle 4 / tip 11).
 *  • RateGuard — circuit breaker against runaway loops (blueprint §4 stop
 *    conditions / architecture §11).
 *
 * Pure logic — unit-tested; Tools wires it into the dispatch.
 */
object PolicyHooks {

    // ------------------------------------------------ dangerous shell patterns

    private val DANGEROUS = listOf(
        // rm -rf on a whole root — /, /*, ~, ~/*, $HOME (project folders are fine)
        Regex("""(?i)\brm\s+(-[a-z]*r[a-z]*f[a-z]*|-[a-z]*f[a-z]*r[a-z]*)\s+(/|/\*|~(?:/\*|/)?|\${'$'}HOME)(\s|$)"""),
        // raw disk / filesystem nukes
        Regex("""(?i)\bdd\b[^|]*\bof=/dev/"""),
        Regex("""(?i)\bmkfs(\.\w+)?\b"""),
        // fork bomb
        Regex("""\s*:\(\)\s*\{.*\}\s*;\s*:"""),
        // pipe-to-shell remote code execution
        Regex("""(?i)\b(curl|wget)\b[^|;]*\|\s*(ba|z|da)?sh\b"""),
        // permission nukes on root
        Regex("""(?i)\bchmod\s+-R\s+777\s+/(\s|$)"""),
        // power actions
        Regex("""(?i)\b(reboot|shutdown)\b""")
    )

    /**
     * Returns a denial reason (with the safer path forward) or null when the
     * command is allowed. Errors are prompts — every denial says what to do.
     */
    fun checkCommand(cmd: String): String? {
        DANGEROUS.forEach { re ->
            if (re.containsMatchIn(cmd)) {
                return "BLOCKED by the safety harness: this shell pattern is destructive/irreversible " +
                    "('$cmd' matched a hard red line). Safer path: target the exact project path instead of a " +
                    "whole root, download-then-inspect instead of piping curl into sh, or ask the user to run it " +
                    "manually if it genuinely must happen."
            }
        }
        return null
    }

    // ------------------------------------------------ untrusted-content tagging

    /**
     * Wrap external content (web pages, search results, API bodies) so the
     * agent treats it as DATA. Injection defense, blueprint §14.5.
     */
    fun untrusted(source: String, body: String): String {
        val stamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'", Locale.US).format(Date())
        return "<untrusted source=\"$source\" fetched=\"$stamp\">\n$body\n</untrusted>"
    }

    // ------------------------------------------------ secret redaction (logs)

    private val SECRETS = listOf(
        Regex("""\bsk-[A-Za-z0-9_-]{16,}"""),
        Regex("""\bsk-ant-[A-Za-z0-9_-]{16,}"""),
        Regex("""\bgh[pousr]_[A-Za-z0-9]{20,}"""),
        Regex("""\bxox[baprs]-[A-Za-z0-9-]{10,}"""),
        Regex("""\bAKIA[0-9A-Z]{16}\b"""),
        Regex("""\bAIza[0-9A-Za-z_-]{30,}"""),
        Regex("""(?i)\bbearer\s+[A-Za-z0-9._-]{24,}""")
    )

    /** Mask credential-shaped strings before anything is logged. */
    fun redact(s: String): String {
        var out = s
        SECRETS.forEach { re -> out = out.replace(re) { m -> m.value.take(6) + "…REDACTED" } }
        return out
    }

    // ------------------------------------------------ output shaping + spill

    const val MAX_RESULT_CHARS = 8_192
    private const val HEAD = 3_000
    private const val TAIL = 2_000

    /**
     * Head+tail truncation with a spill notice. [spill] receives the FULL text
     * and returns the workspace-relative path it saved it to (or null).
     * The model can read the full output back with read_file.
     */
    fun shape(text: String, spill: (String) -> String?): String {
        if (text.length <= MAX_RESULT_CHARS) return text
        val overflow = text.length - HEAD - TAIL
        val path = runCatching { spill(text) }.getOrNull()
        val middle = if (path != null)
            "\n[… $overflow chars truncated — FULL OUTPUT saved to workspace file: $path — read it with read_file if you need the middle part …]\n\n"
        else
            "\n[… $overflow chars truncated — head and tail only …]\n\n"
        return text.take(HEAD) + middle + text.takeLast(TAIL)
    }

    // ------------------------------------------------ rate guard (circuit breaker)

    private val window = ArrayDeque<Long>()
    private const val MAX_PER_MINUTE = 90

    /** Sliding 60 s window across ALL tool calls. */
    fun allow(nowMs: Long = System.currentTimeMillis()): Boolean {
        synchronized(window) {
            while (window.isNotEmpty() && nowMs - window.first() > 60_000) window.removeFirst()
            if (window.size >= MAX_PER_MINUTE) return false
            window.addLast(nowMs)
            return true
        }
    }

    fun resetForTest() = synchronized(window) { window.clear() }
}
