package com.liman.agent.agent

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.liman.agent.data.Stores
import java.io.File

/**
 * Android file access over SAF (Storage Access Framework).
 *
 * The user grants folder tree roots in Settings → Storage access. Every
 * grant is persisted (DocumentsContract takes URI permission grants that
 * survive reboots). The storage_* tools list/read/write inside those roots
 * only — never outside.
 */
object Saf {

    fun roots(stores: Stores): List<Uri> =
        stores.settings.state.value.storageRoots.mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }

    fun addRoot(stores: Stores, uri: Uri) {
        val cur = stores.settings.state.value.storageRoots.toMutableList()
        if (uri.toString() !in cur) {
            cur.add(uri.toString())
            stores.settings.update { it.copy(storageRoots = cur) }
        }
    }

    fun removeRoot(stores: Stores, uri: Uri) {
        val cur = stores.settings.state.value.storageRoots.toMutableList()
        cur.remove(uri.toString())
        stores.settings.update { it.copy(storageRoots = cur) }
    }

    // ------------------------------------------------ listing

    fun list(context: Context, stores: Stores, rootUri: Uri, path: String): List<Entry> {
        val rootDoc = rootDocId(rootUri) ?: return emptyList()
        val docId = if (path.isBlank() || path == ".") rootDoc
        else "$rootDoc/$path".replace("//", "/")
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(
            rootUri, docId
        )
        val out = ArrayList<Entry>()
        context.contentResolver.query(
            children,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
            ), null, null, null
        )?.use { c ->
            while (c.moveToNext() && out.size < 800) {
                val id = c.getString(0) ?: continue
                out.add(
                    Entry(
                        name = c.getString(1) ?: "?",
                        isDir = (c.getString(2) ?: "") == DocumentsContract.Document.MIME_TYPE_DIR,
                        mime = c.getString(2) ?: "",
                        size = c.getLong(3),
                        modified = c.getLong(4),
                        relPath = id.removePrefix(rootDoc).removePrefix("/")
                    )
                )
            }
        }
        return out.sortedWith(compareByDescending<Entry> { it.isDir }.thenBy { it.name.lowercase() })
    }

    data class Entry(
        val name: String,
        val isDir: Boolean,
        val mime: String,
        val size: Long,
        val modified: Long,
        val relPath: String
    )

    // ------------------------------------------------ read / write

    fun readText(context: Context, rootUri: Uri, path: String, maxBytes: Long = 2_000_000): String {
        val uri = docUri(rootUri, path) ?: throw IllegalStateException("bad path: $path")
        return when (val ins = context.contentResolver.openInputStream(uri)) {
            null -> throw IllegalStateException("cannot open $path (not found or no permission)")
            else -> ins.use { stream ->
                val head = ByteArray(maxBytes.coerceAtMost(stream.available().toLong()).toInt().coerceAtLeast(1))
                val n = stream.read(head)
                String(head, 0, n, Charsets.UTF_8)
            }
        }
    }

    fun readBytes(context: Context, rootUri: Uri, path: String, maxBytes: Long = 20_000_000): ByteArray {
        val uri = docUri(rootUri, path) ?: throw IllegalStateException("bad path: $path")
        return context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalStateException("cannot open $path")
    }

    fun writeText(context: Context, rootUri: Uri, path: String, content: String, append: Boolean = false) {
        val dir = path.substringBeforeLast('/', "")
        val name = path.substringAfterLast('/')
        if (name.isBlank()) throw IllegalStateException("bad path: $path")
        val existing = runCatching { docUri(rootUri, path) }.getOrNull()
        val target: Uri = if (existing != null) {
            if (!append) {
                // rewrite: delete then recreate keeps semantics simple
                runCatching { DocumentsContract.deleteDocument(context.contentResolver, existing) }
                createDoc(context, rootUri, dir, name, "text/plain")
            } else existing
        } else createDoc(context, rootUri, dir, name, "text/plain")

        val mode = if (append && existing != null) "wa" else "w"
        context.contentResolver.openOutputStream(target, mode)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
            ?: throw IllegalStateException("cannot write $path")
    }

    private fun createDoc(context: android.content.Context, rootUri: Uri, dir: String, name: String, mime: String): Uri {
        val parent = if (dir.isBlank()) {
            DocumentsContract.buildDocumentUriUsingTree(rootUri, rootDocId(rootUri)!!)
        } else DocumentsContract.buildDocumentUriUsingTree(rootUri, "${rootDocId(rootUri)}/$dir")
        return DocumentsContract.createDocument(context.contentResolver, parent, mime, name)
            ?: throw IllegalStateException("cannot create $name in $dir")
    }

    // ------------------------------------------------ helpers

    private fun rootDocId(rootUri: Uri): String? =
        DocumentsContract.getTreeDocumentId(rootUri) // e.g. "primary:Download"

    private fun docUri(rootUri: Uri, path: String): Uri? {
        val docId = "${rootDocId(rootUri)}/$path".replace("//", "/")
        return DocumentsContract.buildDocumentUriUsingTree(rootUri, docId)
    }

    /** Pretty name for a root, e.g. "Downloads" or "My Files". */
    fun rootLabel(context: Context, uri: Uri): String = try {
        val doc = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
        context.contentResolver.query(
            doc, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
            null, null, null
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: uri.lastPathSegment ?: "folder"
    } catch (e: Exception) {
        uri.lastPathSegment ?: "folder"
    }

    /** Root display list for tools/UI: uri + label. */
    fun describeRoots(context: Context, stores: Stores): List<Pair<Uri, String>> =
        roots(stores).map { it to rootLabel(context, it) }

    /** v2.21 — write raw bytes (quarantine restore, binary outputs). */
    fun writeBytes(context: Context, rootUri: Uri, path: String, bytes: ByteArray) {
        val dir = path.substringBeforeLast('/', "")
        val name = path.substringAfterLast('/')
        if (name.isBlank()) throw IllegalStateException("bad path: $path")
        val mime = android.webkit.MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"
        val target = createDoc(context, rootUri, dir, name, mime)
        context.contentResolver.openOutputStream(target, "w")?.use { it.write(bytes) }
            ?: throw IllegalStateException("cannot write $path")
    }

    /** v2.21 — delete a document in a granted tree (storage cleanup). */
    fun deleteDoc(context: Context, rootUri: Uri, path: String): Boolean {
        val uri = runCatching { docUri(rootUri, path) }.getOrNull() ?: return false
        return runCatching {
            DocumentsContract.deleteDocument(context.contentResolver, uri)
        }.getOrDefault(false)
    }

    /** Downloads a root's file into workspace (for tool use / preview). */
    fun copyToWorkspace(context: Context, rootUri: Uri, path: String, destDir: File): File {
        val bytes = readBytes(context, rootUri, path)
        val name = path.substringAfterLast('/').ifBlank { "file.bin" }
        destDir.mkdirs()
        val f = File(destDir, name)
        f.writeBytes(bytes)
        return f
    }
}
