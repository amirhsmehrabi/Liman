package com.liman.agent.agent

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

/**
 * npm-lite: lets the on-device JS sandbox `require()` real npm packages.
 *
 * Flow (all host-side; sandboxed JS never gets Java/network access):
 *  1. GET  https://registry.npmjs.org/<pkg>/latest   → version, main, dist.tarball
 *  2. GET  tarball (≤ 8 MB) → gunzip → untar into workspace/.liman/npm/<pkg>@<ver>/
 *  3. resolve the entry (package.json main / browser, fallback index.js) and
 *     return its source for evaluation in a fresh module scope.
 *
 * Disk-cached per version, so a package is downloaded once per workspace.
 * Pure-JVM (unit tested): OkHttp + a hand-written ustar/pax/GNU tar reader.
 */
object NpmLite {

    private const val REGISTRY = "https://registry.npmjs.org"
    private const val MAX_TARBALL = 8L * 1024 * 1024
    private const val MAX_FILE = 4L * 1024 * 1024
    private const val MAX_TOTAL = 40L * 1024 * 1024
    private const val MAX_FILES = 4000

    private val json = Json { ignoreUnknownKeys = true }

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    class NpmException(message: String) : Exception(message)

    /** Everything the sandbox needs to evaluate one module. */
    class Resolved(
        val source: String,
        /** stable identity for the require() cache, e.g. "left-pad@1.3.0/index.js" */
        val canonical: String,
        /** package root dir on disk (for relative imports) */
        val pkgDir: File,
        /** dir of this entry inside the package ("" or "lib/…") */
        val dirInPkg: String
    )

    /** Root of the on-disk package cache. */
    fun cacheRoot(workspace: File): File = File(workspace, ".liman/npm")

    /**
     * Resolves a require() argument to module source + metadata.
     * Accepts: "pkg", "pkg/file.js", "@scope/pkg", "@scope/pkg/file.js".
     * @throws NpmException with a human-readable, agent-actionable message.
     */
    fun readModule(workspace: File, name: String): Resolved {
        val clean = name.trim().trimStart('/')
        if (clean.isEmpty()) throw NpmException("empty module name")
        val slash = clean.indexOf('/')
        val (pkgName, subPath) = if (clean.startsWith("@")) {
            // @scope/pkg[/path...]
            val second = clean.indexOf('/', 1)
            if (second < 0) Pair(clean, null)
            else Pair(clean.substring(0, second), clean.substring(second + 1).takeIf { it.isNotEmpty() })
        } else if (slash >= 0) {
            Pair(clean.substring(0, slash), clean.substring(slash + 1).takeIf { it.isNotEmpty() })
        } else {
            Pair(clean, null)
        }

        val pkgDir = ensurePackage(workspace, pkgName)
        val version = pkgDir.parentFile?.name?.substringAfter('@') ?: ""
        val relEntry: String = if (subPath != null) {
            val ef = resolveAsFile(File(pkgDir, subPath)) ?: resolveAsDirectory(File(pkgDir, subPath))
                ?: throw NpmException("'$name': file not found inside package '$pkgName'")
            ef.relativeTo(pkgDir).path.replace('\\', '/')
        } else {
            packageEntry(pkgDir)
                ?: throw NpmException(
                    "package '$pkgName' has no usable entry (no package.json main, no index.js)"
                )
        }
        val f = File(pkgDir, relEntry)
        if (!f.isFile) throw NpmException("'$name': resolved entry missing ($relEntry)")
        return Resolved(
            source = f.readText(Charsets.UTF_8),
            canonical = "$pkgName@$version/$relEntry",
            pkgDir = pkgDir,
            dirInPkg = relEntry.substringBeforeLast('/', "")
        )
    }

    /** require('./relative') from a module that lives inside [pkgDir]. */
    fun readRelative(pkgDir: File, path: String, curDir: String): Resolved {
        val joined = if (curDir.isEmpty()) path else "$curDir/$path"
        val resolved = File(pkgDir, joined).normalize()
        val f = resolveAsFile(resolved) ?: resolveAsDirectory(resolved)
        ?: throw NpmException("cannot resolve relative import '$path'")
        if (!f.path.startsWith(pkgDir.normalize().path + File.separator) && f.path != pkgDir.normalize().path)
            throw NpmException("relative import '$path' escapes the package")
        val rel = f.relativeTo(pkgDir).path.replace('\\', '/')
        return Resolved(
            source = f.readText(Charsets.UTF_8),
            canonical = "${pkgDir.name}/$rel",
            pkgDir = pkgDir,
            dirInPkg = rel.substringBeforeLast('/', "")
        )
    }

    // ---------------- package fetch & cache ----------------

    private fun ensurePackage(workspace: File, pkgName: String): File {
        if (!pkgName.matches(Regex("^@[a-zA-Z0-9._-]+/[a-zA-Z0-9._-]+$|^[a-zA-Z0-9._-]+$")))
            throw NpmException("invalid package name '$pkgName'")

        val dirName = pkgName.replace('/', '+')
        val root = cacheRoot(workspace)
        // cached: any "<name>@<version>" dir for this package
        val cached = root.listFiles { d -> d.name.startsWith("$dirName@") }?.firstOrNull()
        if (cached != null && File(cached, "package").isDirectory) return File(cached, "package")

        // fetch metadata
        val metaUrl = "$REGISTRY/${urlEncode(pkgName)}/latest"
        val meta = try {
            val body = http.newCall(Request.Builder().url(metaUrl).build()).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                r.body?.bytes() ?: throw IOException("empty body")
            }
            json.parseToJsonElement(String(body, Charsets.UTF_8)).jsonObject
        } catch (e: Exception) {
            throw NpmException(
                "could not fetch npm metadata for '$pkgName' (${e.message}). " +
                    "Check the name, or the internet connection."
            )
        }
        val version = meta["version"]?.jsonPrimitive?.content
            ?: throw NpmException("package '$pkgName' metadata has no version")
        val tarball = meta["dist"]?.jsonObject?.get("tarball")?.jsonPrimitive?.content
            ?: "$REGISTRY/${urlEncode(pkgName)}/-/${pkgName.substringAfterLast('/')}-$version.tgz"

        val pkgDir = File(root, "$dirName@$version")
        val marker = File(pkgDir, ".complete")
        if (marker.isFile && File(pkgDir, "package").isDirectory) return File(pkgDir, "package")

        // download + extract
        val tgz = try {
            val body = http.newCall(Request.Builder().url(tarball).build()).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                r.body?.bytes() ?: throw IOException("empty body")
            }
            if (body.size > MAX_TARBALL) throw IOException("tarball too large (${body.size} bytes)")
            body
        } catch (e: Exception) {
            throw NpmException("could not download $pkgName@$version tarball (${e.message})")
        }

        pkgDir.deleteRecursively()
        val total = longArrayOf(0)
        TarReader.extract(
            gzip = tgz,
            outDir = File(pkgDir, "package"),
            stripPrefix = "package/",
            maxFileBytes = MAX_FILE,
            maxTotalBytes = MAX_TOTAL,
            maxFiles = MAX_FILES
        ) { extracted, totalBytes -> total[0] = totalBytes; extracted }
        if (!File(pkgDir, "package").isDirectory || total[0] == 0L)
            throw NpmException("tarball of $pkgName@$version contained no usable files")
        marker.writeText("ok")
        return File(pkgDir, "package")
    }

    private fun packageEntry(pkgDir: File): String? {
        val pj = File(pkgDir, "package.json")
        if (pj.isFile) {
            try {
                val obj = json.parseToJsonElement(pj.readText(Charsets.UTF_8)).jsonObject
                val main = (obj["browser"]?.jsonPrimitive?.content)
                    ?: obj["main"]?.jsonPrimitive?.content
                    ?: "index.js"
                val asFile = resolveAsFile(File(pkgDir, main))
                if (asFile != null) return asFile.relativeTo(pkgDir).path
                val asDir = resolveAsDirectory(File(pkgDir, main))
                if (asDir != null) return asDir.relativeTo(pkgDir).path
            } catch (_: Exception) {
            }
        }
        return resolveAsFile(File(pkgDir, "index.js"))?.relativeTo(pkgDir)?.path
    }

    /** tries f, f.js, f.json, f.mjs, f.cjs */
    private fun resolveAsFile(f: File): File? {
        if (f.isFile) return f
        for (ext in listOf(".js", ".json", ".mjs", ".cjs")) {
            val c = File(f.path + ext)
            if (c.isFile) return c
        }
        return null
    }

    /** tries f/index.js, f/index.json */
    private fun resolveAsDirectory(f: File): File? {
        for (idx in listOf("index.js", "index.json", "index.mjs")) {
            val c = File(f, idx)
            if (c.isFile) return c
        }
        return null
    }

    private fun urlEncode(s: String): String =
        java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    // ---------------- tar (ustar + pax + GNU longname) ----------------

    object TarReader {

        /**
         * Extracts a .tgz byte array into outDir. Handles pax extended headers
         * ("x" with path=) and GNU long names ("L"), which modern npm tarballs
         * use for long paths. Skips non-regular entries and binary blobs that
         * can never be evaluated (.node/.dll/.exe/.so).
         */
        fun extract(
            gzip: ByteArray,
            outDir: File,
            stripPrefix: String = "package/",
            maxFileBytes: Long,
            maxTotalBytes: Long,
            maxFiles: Int,
            onFile: (String, Long) -> Unit = { _, _ -> }
        ) {
            val input = GZIPInputStream(ByteArrayInputStream(gzip))
            val tar = input.readBytes()
            outDir.mkdirs()

            var off = 0
            var pendingPath: String? = null   // from 'L' or 'x' blocks
            var total = 0L
            var count = 0
            val skipExt = setOf("node", "dll", "exe", "so", "dylib", "class", "jar", "wasm")

            while (off + 512 <= tar.size) {
                val block = tar.copyOfRange(off, off + 512)
                if (block.all { it == 0.toByte() }) break // end of archive
                val name = str(block, 0, 100)
                val size = oct(block, 124, 12)
                val type = block[156].toInt() and 0xFF
                val dataStart = off + 512

                if (type == 'L'.code) {           // GNU long name
                    pendingPath = str(tar, dataStart, size.toInt()).trimEnd('\u0000', '\n')
                } else if (type == 'x'.code || type == 'g'.code) { // pax header
                    val pax = str(tar, dataStart, size.toInt())
                    pendingPath = Regex("(?m)^\\d+ path=(.+)$").find(pax)?.groupValues?.get(1)?.trim()
                        ?: pendingPath
                } else if (type == '0'.code || type == 0 || type == '7'.code) { // regular file
                    var path = (pendingPath ?: name).replace('\\', '/')
                    pendingPath = null
                    if (path.startsWith("./")) path = path.substring(2)
                    if (stripPrefix.isNotEmpty()) {
                        if (!path.startsWith(stripPrefix)) {
                            if (path == stripPrefix.trimEnd('/')) path = ""
                            else path = "" // entries outside package/ are skipped
                        } else {
                            path = path.substring(stripPrefix.length)
                        }
                    }
                    if (path.isNotEmpty() && !path.contains("..") &&
                        !skipExt.contains(path.substringAfterLast('.').lowercase())
                    ) {
                        if (count >= maxFiles) error("too many files in tarball")
                        if (size > maxFileBytes) error("file too large: $path")
                        if (total + size > maxTotalBytes) error("tarball total too large")
                        val outFile = File(outDir, path)
                        outFile.parentFile?.mkdirs()
                        outFile.writeBytes(tar.copyOfRange(dataStart, dataStart + size.toInt()))
                        total += size
                        count++
                        onFile(path, size)
                    }
                }
                // directories ('5'), symlinks, devices: skipped
                off = dataStart + (((size + 511) / 512) * 512).toInt()
            }
        }

        private fun str(b: ByteArray, off: Int, len: Int): String {
            val end = minOf(off + len, b.size)
            var stop = off
            while (stop < end && b[stop] != 0.toByte()) stop++
            return String(b, off, stop - off, Charsets.UTF_8)
        }

        private fun oct(b: ByteArray, off: Int, len: Int): Long {
            val s = str(b, off, len).trim()
            return if (s.isEmpty()) 0L else s.toLong(8)
        }
    }
}
