package com.liman.agent.agent

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/**
 * Free, key-less online code execution for the run_code tool.
 *
 * Providers (tried in order, both verified live, no signup, no API key):
 *  1. paiza.io  — REST: POST /runners/create (form) → poll /runners/get_details.
 *                 Live-verified languages: python3, bash, c, cpp, java, go,
 *                 rust, ruby, php, perl, typescript, coffeescript, kotlin,
 *                 swift, scala, r, haskell. Supports stdin. No node.js.
 *  2. wandbox.org — POST /api/compile.json (JSON). 175 compilers; used as
 *                 fallback (and for nodejs-20).
 *
 * If a provider is down or rate-limits, the next one is tried; the last error
 * is surfaced to the agent with an actionable hint.
 */
object OnlineRunner {

    class RunException(message: String) : Exception(message)

    data class Result(
        val stdout: String,
        val stderr: String,
        val exitCode: Int,
        val provider: String,
        val compileOutput: String = "",
        val note: String = ""
    )

    /** alias → (paiza slug, wandbox slug) */
    val languages: Map<String, Pair<String?, String?>> = mapOf(
        "python" to ("python3" to "cpython-3.12.7"),
        "python3" to ("python3" to "cpython-3.12.7"),
        "py" to ("python3" to "cpython-3.12.7"),
        "bash" to ("bash" to "bash"),
        "sh" to ("bash" to "bash"),
        "shell" to ("bash" to "bash"),
        "node" to (null to "nodejs-20.17.0"),
        "nodejs" to (null to "nodejs-20.17.0"),
        "c" to ("c" to "gcc-13.2.0-c"),
        "cpp" to ("cpp" to "gcc-13.2.0"),
        "c++" to ("cpp" to "gcc-13.2.0"),
        "java" to ("java" to null),
        "go" to ("go" to "go-1.23.2"),
        "golang" to ("go" to "go-1.23.2"),
        "rust" to ("rust" to "rust-1.82.0"),
        "rs" to ("rust" to "rust-1.82.0"),
        "ruby" to ("ruby" to "ruby-3.4.9"),
        "rb" to ("ruby" to "ruby-3.4.9"),
        "php" to ("php" to "php-8.3.12"),
        "perl" to ("perl" to "perl-5.42.0"),
        "typescript" to ("typescript" to null),
        "ts" to ("typescript" to null),
        "coffeescript" to ("coffeescript" to null),
        "kotlin" to ("kotlin" to null),
        "swift" to ("swift" to null),
        "scala" to ("scala" to null),
        "r" to ("r" to null),
        "haskell" to ("haskell" to null),
        "hs" to ("haskell" to null)
    )

    val supportedList: String =
        "python, bash, node/javascript, c, c++, java, go, rust, ruby, php, perl, " +
            "typescript, coffeescript, kotlin, swift, scala, r, haskell"

    private val json = Json { ignoreUnknownKeys = true }

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    fun supports(language: String): Boolean = languages.containsKey(language)

    /**
     * @param code the program source
     * @param stdin optional standard input
     * @param timeoutSeconds wall-clock budget (the providers cap CPU themselves)
     */
    fun run(language: String, code: String, stdin: String, timeoutSeconds: Int): Result {
        val (paizaLang, wandboxCompiler) = languages[language]
            ?: throw RunException("unsupported language '$language'. Supported: $supportedList")

        val errors = ArrayList<String>()

        if (paizaLang != null) {
            try {
                return runPaiza(paizaLang, code, stdin, timeoutSeconds)
            } catch (e: Exception) {
                errors.add("paiza.io (${e.message})")
            }
        }
        if (wandboxCompiler != null) {
            try {
                return runWandbox(wandboxCompiler, code, stdin)
            } catch (e: Exception) {
                errors.add("wandbox.org (${e.message})")
            }
        }
        throw RunException(
            "all online runners failed: ${errors.joinToString("; ")}. " +
                "The internet connection may be down, or the free services are " +
                "temporarily unavailable — retry, or (for js) use the on-device engine."
        )
    }

    // ---------------- paiza.io ----------------

    private fun runPaiza(lang: String, code: String, stdin: String, timeoutSeconds: Int): Result {
        val deadline = System.currentTimeMillis() + timeoutSeconds * 1000L
        val createBody = FormBody.Builder()
            .add("source_code", code)
            .add("language", lang)
            .add("input", stdin)
            .add("longpoll", "true")
            .add("api_key", "guest")
            .build()

        val createResp = post("https://api.paiza.io/runners/create", createBody)
        val createJson = parse(createResp)
        val id = createJson["id"]?.jsonPrimitive?.content
            ?: throw RunException("paiza create failed: ${createResp.take(200)}")

        var details: JsonObject? = null
        while (System.currentTimeMillis() < deadline) {
            val detResp = get("https://api.paiza.io/runners/get_details?id=$id&api_key=guest")
            val det = parse(detResp)
            if (det["status"]?.jsonPrimitive?.content == "completed") {
                details = det
                break
            }
            Thread.sleep(1000)
        }
        val det = details
            ?: throw RunException("paiza run did not finish in ${timeoutSeconds}s")

        val buildExit = det["build_exit_code"]?.jsonPrimitive?.content?.toIntOrNull()
        if (buildExit != null && buildExit != 0) {
            return Result(
                stdout = det["build_stdout"]?.jsonPrimitive?.content ?: "",
                stderr = det["build_stderr"]?.jsonPrimitive?.content ?: "",
                exitCode = buildExit,
                provider = "paiza.io",
                compileOutput = "COMPILE ERROR",
                note = "the program failed to compile"
            )
        }
        return Result(
            stdout = det["stdout"]?.jsonPrimitive?.content ?: "",
            stderr = det["stderr"]?.jsonPrimitive?.content ?: "",
            exitCode = det["exit_code"]?.jsonPrimitive?.content?.toIntOrNull() ?: -1,
            provider = "paiza.io"
        )
    }

    // ---------------- wandbox.org ----------------

    private fun runWandbox(compiler: String, code: String, stdin: String): Result {
        val payload = buildJsonObject {
            put("code", code)
            put("compiler", compiler)
            put("stdin", stdin)
            put("save", false)
        }.toString()
        val resp = postRaw("https://wandbox.org/api/compile.json", "application/json; charset=utf-8", payload)
        val obj = parse(resp)

        if (resp.contains("\"Error\"") && obj["status"]?.jsonPrimitive?.content == null)
            throw RunException("wandbox error: ${resp.take(200)}")

        val status = obj["status"]?.jsonPrimitive?.content ?: "error"
        if (status != "0" && obj.isEmpty())
            throw RunException("wandbox status $status")

        val compileErr = obj["compiler_error"]?.jsonPrimitive?.content ?: ""
        val programErr = obj["program_error"]?.jsonPrimitive?.content ?: ""
        return Result(
            stdout = obj["program_output"]?.jsonPrimitive?.content ?: "",
            stderr = listOf(programErr, if (compileErr.isNotEmpty()) "\n[compile error]\n$compileErr" else "")
                .filter { it.isNotEmpty() }.joinToString("\n"),
            exitCode = if (compileErr.isNotEmpty()) 1 else if (status == "0") 0 else -1,
            provider = "wandbox.org"
        )
    }

    // ---------------- http helpers ----------------

    private fun post(url: String, body: okhttp3.FormBody): String =
        withRetry {
            http.newCall(Request.Builder().url(url).post(body).build()).execute().use { r ->
                if (r.code == 429) throw IOException429()
                if (!r.isSuccessful) throw RunException("HTTP ${r.code}")
                r.body?.string() ?: throw RunException("empty body")
            }
        }

    private fun postRaw(url: String, contentType: String, payload: String): String =
        withRetry {
            val body = payload.toRequestBody(contentType.toMediaType())
            http.newCall(Request.Builder().url(url).post(body).build()).execute().use { r ->
                if (r.code == 429) throw IOException429()
                if (!r.isSuccessful) throw RunException("HTTP ${r.code}")
                r.body?.string() ?: throw RunException("empty body")
            }
        }

    private fun get(url: String): String =
        http.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) throw RunException("HTTP ${r.code}")
            r.body?.string() ?: throw RunException("empty body")
        }

    private class IOException429 : Exception("rate limited (429)")

    private inline fun <T> withRetry(block: () -> T): T {
        var last: Exception? = null
        repeat(3) { attempt ->
            try {
                return block()
            } catch (e: IOException429) {
                last = e
                Thread.sleep((1200L * (attempt + 1)).coerceAtMost(4000L))
            } catch (e: RunException) {
                throw e
            } catch (e: Exception) {
                last = e
                Thread.sleep(800L)
            }
        }
        throw last ?: RunException("request failed")
    }

    private fun parse(s: String): JsonObject =
        try {
            json.parseToJsonElement(s).jsonObject
        } catch (e: Exception) {
            throw RunException("bad JSON from provider: ${s.take(120)}")
        }
}
