package com.liman.agent.agent

import org.mozilla.javascript.BaseFunction
import org.mozilla.javascript.ClassShutter
import org.mozilla.javascript.Context
import org.mozilla.javascript.ContextFactory
import org.mozilla.javascript.NativeFunction
import org.mozilla.javascript.Scriptable
import org.mozilla.javascript.ScriptableObject
import java.io.File

/**
 * Sandboxed JavaScript engine (Mozilla Rhino, interpreter mode) used by the
 * `run_js` and `run_code` agent tools.
 *
 * Security model:
 *  - ClassShutter denies ALL access to Java classes (no I/O, no reflection)
 *  - interpreter-only mode so instruction counting works
 *  - wall-clock deadline enforced from the instruction observer
 *  - module code from npm runs under the same shutter — packages are
 *    downloaded host-side (NpmLite), only their SOURCE enters the sandbox
 *
 * v2.13 additions:
 *  - require('npm-package') with live download + disk cache (pure-JS packages)
 *  - CommonJS module wrapper (module/exports/require/__filename)
 *  - mini event loop: setTimeout/setInterval queue drained after the main script
 *  - process/globalThis stubs so common npm packages load
 */
object JsSandbox {

    private class ExitSentinel(val code: Int) : RuntimeException("process.exit($code)")

    fun run(code: String, timeoutMs: Long = 15_000L, workspace: File? = null): String {
        val timeout = timeoutMs.coerceIn(1_000L, 120_000L)
        val deadline = System.currentTimeMillis() + timeout
        val out = StringBuilder()

        val factory = object : ContextFactory() {
            override fun observeInstructionCount(cx: Context, instructionCount: Int) {
                if (System.currentTimeMillis() > deadline) {
                    throw RuntimeException("script timed out after ${timeout}ms")
                }
            }
        }

        return try {
            factory.call { cx ->
                cx.setOptimizationLevel(-1) // interpreter mode → instruction observer works
                cx.instructionObserverThreshold = 2_000
                cx.setClassShutter(ClassShutter { false })

                val scope = cx.initStandardObjects() as ScriptableObject
                installOutput(cx, scope, out)
                installRequire(cx, scope, workspace, out)
                installTimers(cx, scope)
                installStubs(cx, scope)
                cx.evaluateString(scope, "var globalThis = this;", "globalThis", 1, null)

                val result = cx.evaluateString(scope, code, "liman", 1, null)
                drainTimers(cx, scope, deadline)

                val resStr = if (result === Context.getUndefinedValue()) "undefined" else Context.toString(result)
                out.append("→ ").append(resStr)
                out.toString()
            }
        } catch (t: Throwable) {
            val exit = exitCodeOf(t)
            val msg = if (exit != null) "process.exit($exit) called" else (t.message ?: t.javaClass.simpleName)
            "JS error: $msg${if (out.isNotEmpty()) "\noutput so far:\n$out" else ""}"
        }
    }

    // ---------------- output ----------------

    private fun installOutput(cx: Context, scope: ScriptableObject, out: StringBuilder) {
        val print = object : BaseFunction() {
            override fun call(
                cx: Context, scope: Scriptable, thisObj: Scriptable, args: Array<Any?>
            ): Any {
                out.append(args.joinToString(" ") { Context.toString(it) }).append('\n')
                return Context.getUndefinedValue()
            }
        }
        scope.put("print", scope, print)
        cx.evaluateString(
            scope,
            """
            var console = {
              log: function(){ print.apply(null, arguments) },
              info: function(){ print.apply(null, arguments) },
              debug: function(){ print.apply(null, arguments) },
              warn: function(){ print.apply(null, arguments) },
              error: function(){ print.apply(null, arguments) },
              trace: function(){ print.apply(null, arguments) }
            };
            """.trimIndent(),
            "console", 1, null
        )
    }

    // ---------------- require / npm-lite ----------------

    private fun installRequire(
        cx: Context,
        scope: ScriptableObject,
        workspace: File?,
        out: StringBuilder
    ) {
        val moduleCache = HashMap<String, Scriptable>() // canonical path → exports
        val moduleDirs = ArrayDeque<String>()            // stack of current module dirs (in-pkg rel dir)
        val modulePkgs = ArrayDeque<File>()              // package dir for relative resolution

        val require = object : BaseFunction() {
            override fun call(
                cx: Context, scope: Scriptable, thisObj: Scriptable, args: Array<Any?>
            ): Any {
                val name = Context.toString(args.getOrNull(0) ?: "undefined")
                if (name == "undefined") throw RuntimeException("require() needs a module name")

                // builtin-ish shims
                if (name == "path") return pathShim(cx, scope)
                if (name == "events") return eventsShim(cx, scope)

                if (workspace == null)
                    throw RuntimeException("require() is unavailable (no workspace)")

                val resolved = if (name.startsWith("./") || name.startsWith("../")) {
                    val curDir = moduleDirs.lastOrNull() ?: ""
                    val pkg = modulePkgs.lastOrNull()
                        ?: throw RuntimeException("relative require outside a module")
                    NpmLite.readRelative(pkg, name, curDir)
                } else {
                    NpmLite.readModule(workspace, name)
                }

                // same file required twice → cached exports
                moduleCache[resolved.canonical]?.let { return it }

                val moduleScope = cx.newObject(scope) as ScriptableObject
                val moduleObj = cx.newObject(scope)
                val exports = cx.newObject(scope)
                moduleObj.put("exports", moduleObj, exports)
                moduleScope.put("module", moduleScope, moduleObj)
                moduleScope.put("exports", moduleScope, exports)
                moduleScope.put("require", moduleScope, this)
                moduleScope.put("__filename", moduleScope, resolved.canonical)

                moduleDirs.addLast(resolved.dirInPkg)
                modulePkgs.addLast(resolved.pkgDir)
                try {
                    val wrapper = cx.evaluateString(
                        scope,
                        "(function(module, exports, require, __filename){\n${resolved.source}\n})",
                        resolved.canonical, 1, null
                    ) as NativeFunction
                    wrapper.call(cx, moduleScope, moduleScope, arrayOf(moduleObj, exports, this, resolved.canonical))
                } catch (e: Throwable) {
                    val exit = exitCodeOf(e)
                    if (exit != null) throw e
                    throw RuntimeException("module '$name' failed: ${e.message}")
                } finally {
                    moduleDirs.removeLast()
                    modulePkgs.removeLast()
                }
                val exp = moduleObj.get("exports", moduleObj)
                    ?.let { if (it === Scriptable.NOT_FOUND) exports else it } ?: exports
                moduleCache[resolved.canonical] = (exp as? Scriptable) ?: exports
                return exp
            }
        }
        scope.put("require", scope, require)
    }

    private fun pathShim(cx: Context, scope: Scriptable): Scriptable {
        val obj = cx.newObject(scope)
        val js = """
            (function(){
              function norm(p){ var parts=p.split('/'), out=[];
                for (var i=0;i<parts.length;i++){ var s=parts[i];
                  if (s===''||s==='.') continue;
                  if (s==='..') out.pop(); else out.push(s); }
                return out.join('/'); }
              function dirname(p){ var i=p.lastIndexOf('/'); return i<0?'.':p.substring(0,i)||'/'; }
              function basename(p){ var i=p.lastIndexOf('/'); return i<0?p:p.substring(i+1); }
              function extname(p){ var b=basename(p), i=b.lastIndexOf('.'); return i<0?'':b.substring(i); }
              function join(){ var segs=Array.prototype.slice.call(arguments); return norm(segs.join('/')); }
              return { normalize: norm, dirname: dirname, basename: basename,
                       extname: extname, join: join, resolve: join,
                       sep: '/', posix: null };
            })()
        """.trimIndent()
        return cx.evaluateString(scope, js, "path-shim", 1, null) as Scriptable
    }

    private fun eventsShim(cx: Context, scope: Scriptable): Scriptable {
        val js = """
            (function(){
              function EventEmitter(){ this._l = {}; }
              EventEmitter.prototype.on = function(ev, fn){
                (this._l[ev] = this._l[ev] || []).push(fn); return this; };
              EventEmitter.prototype.addListener = EventEmitter.prototype.on;
              EventEmitter.prototype.once = function(ev, fn){
                var self=this; var g=function(){ self.removeListener(ev,g); fn.apply(null,arguments); };
                return this.on(ev,g); };
              EventEmitter.prototype.removeListener = function(ev, fn){
                var a=this._l[ev]||[]; var i=a.indexOf(fn); if(i>=0) a.splice(i,1); return this; };
              EventEmitter.prototype.emit = function(ev){
                var a=this._l[ev]||[]; var args=Array.prototype.slice.call(arguments,1);
                for (var i=0;i<a.length;i++) a[i].apply(null,args);
                return a.length>0; };
              var ee = new EventEmitter();
              ee.EventEmitter = EventEmitter;
              return ee;
            })()
        """.trimIndent()
        return cx.evaluateString(scope, js, "events-shim", 1, null) as Scriptable
    }

    // ---------------- timers (mini event loop) ----------------

    private fun installTimers(cx: Context, scope: ScriptableObject) {
        val js = """
            var __timers = { next: [], seq: 0, now: function(){ return Date.now(); } };
            function setTimeout(fn, ms){ var id = ++__timers.seq;
              __timers.next.push({ id: id, at: __timers.now() + (Number(ms)||0), fn: fn, interval: 0 });
              return id; }
            function setInterval(fn, ms){ var id = ++__timers.seq;
              __timers.next.push({ id: id, at: __timers.now() + (Number(ms)||0), fn: fn, interval: Math.max(1, Number(ms)||1) });
              return id; }
            function clearTimeout(id){ __cancel(id); }
            function clearInterval(id){ __cancel(id); }
        """.trimIndent()
        cx.evaluateString(scope, js, "timers", 1, null)
        val cancel = object : BaseFunction() {
            override fun call(
                cx: Context, scope: Scriptable, thisObj: Scriptable, args: Array<Any?>
            ): Any {
                val id = (args.getOrNull(0) as? Double)?.toInt() ?: -1
                cx.evaluateString(
                    scope,
                    "__timers.next = __timers.next.filter(function(t){ return t.id !== $id; });",
                    "cancel", 1, null
                )
                return Context.getUndefinedValue()
            }
        }
        ScriptableObject.defineProperty(scope, "__cancel", cancel, ScriptableObject.DONTENUM)
    }

    private fun drainTimers(cx: Context, scope: Scriptable, deadline: Long) {
        var drained = 0
        while (drained < 500) {
            if (System.currentTimeMillis() > deadline)
                throw RuntimeException("event loop timed out")
            val next = cx.evaluateString(
                scope,
                """(function(){
                    var due = null, earliest = null;
                    for (var i=0;i<__timers.next.length;i++){
                      var t = __timers.next[i];
                      if (earliest===null || t.at < earliest) earliest = t.at;
                      if (t.at <= __timers.now() && (due===null || t.at < due.at)) due = t;
                    }
                    if (due === null){
                      if (earliest === null) return "EMPTY";
                      return "WAIT:" + Math.max(0, earliest - __timers.now());
                    }
                    return due;
                   })()""",
                "pick-timer", 1, null
            )
            if (next === Context.getUndefinedValue() || next === null) break
            // nothing due yet but timers pending → wait for the nearest one
            if (next is String) {
                if (next == "EMPTY") break
                val waitMs = next.removePrefix("WAIT:").toLongOrNull() ?: break
                Thread.sleep(waitMs.coerceIn(1L, 500L))
                continue
            }
            val t = next as Scriptable
            val id = (t.get("id", t) as Double).toInt()
            val interval = (t.get("interval", t) as Double).toInt()
            val fn = t.get("fn", t) as BaseFunction
            if (interval <= 0) {
                cx.evaluateString(scope, "__cancel($id);", "rm", 1, null)
            } else {
                cx.evaluateString(
                    scope,
                    "__timers.next = __timers.next.map(function(x){ if (x.id===$id) x.at = __timers.now() + $interval; return x; });",
                    "resched", 1, null
                )
            }
            fn.call(cx, scope, scope, emptyArray())
            drained++
        }
    }

    // ---------------- process & misc stubs ----------------

    private fun installStubs(cx: Context, scope: ScriptableObject) {
        val js = """
            var process = {
              platform: 'linux', arch: 'arm64',
              version: 'v20.12.0 (liman-sandbox)',
              argv: ['node', 'liman'],
              env: { NODE_ENV: 'production' },
              cwd: function(){ return '/'; },
              nextTick: function(fn){ fn(); },
              exit: function(code){ __processExit(code || 0); },
              stdout: { write: function(s){ print(String(s).replace(/\n$/, '')); } },
              stderr: { write: function(s){ print(String(s).replace(/\n$/, '')); } },
              on: function(){}, binding: function(){ return {}; }
            };
            var Buffer = {
              from: function(s){ if (typeof s === 'string') return { data: s, toString: function(){ return s; }, length: s.length }; return { length: 0 }; },
              isBuffer: function(){ return false; },
              alloc: function(n){ return { length: n, toString: function(){ return ''; } }; }
            };
        """.trimIndent()
        cx.evaluateString(scope, js, "stubs", 1, null)
        val exitFn = object : BaseFunction() {
            override fun call(
                cx: Context, scope: Scriptable, thisObj: Scriptable, args: Array<Any?>
            ): Any {
                val code = (args.getOrNull(0) as? Double)?.toInt() ?: 0
                throw ExitSentinel(code)
            }
        }
        ScriptableObject.defineProperty(scope, "__processExit", exitFn, ScriptableObject.DONTENUM)
    }

    private fun exitCodeOf(t: Throwable): Int? {
        var cur: Throwable? = t
        var depth = 0
        while (cur != null && depth < 12) {
            if (cur is ExitSentinel) return cur.code
            cur = cur.cause
            depth++
        }
        return null
    }
}
