package com.liman.agent.agent

import java.util.Base64

/**
 * v2.23.0 — ON-DEVICE OCR (Termux tesseract).
 *
 * The zero-APK-growth route: tesseract runs IN TERMUX (pkg install
 * tesseract), so no ML Kit dependency and no model bloat inside Liman.
 * The image travels to Termux base64-encoded over the bridge — the same
 * proven transfer as the native APK factory — and the recognized text
 * comes back. Free, offline, ~40 languages.
 */
object OcrBridge {

    fun setupScript(): String = """
        set -e
        pkg install -y tesseract
        tesseract --version 2>&1 | head -1
        echo 'LIMAN_OCR_SETUP_OK'
    """.trimIndent()

    /**
     * Decode the image, run tesseract, print the text. Langs: eng, fas,
     * ara, deu, … (tesseract-ocr-<lang> packages; eng ships with base).
     */
    fun runScript(b64: String, lang: String): String {
        val safeLang = Regex("^[a-z]{2,3}(-[a-zA-Z0-9]+)?$").find(lang.trim().lowercase())?.value ?: "eng"
        return buildString {
            appendLine("set -e")
            appendLine("mkdir -p ~/liman-ocr && cd ~/liman-ocr")
            appendLine("printf %s '${b64}' | base64 -d > in.png")
            appendLine("tesseract in.png out -l $safeLang 2>/dev/null")
            appendLine("cat out.txt")
            appendLine("echo 'LIMAN_OCR_DONE'")
        }
    }

    /** true when the OCR result text carries recognized content. */
    fun hasText(out: String): Boolean =
        out.contains("LIMAN_OCR_DONE") &&
                out.substringBefore("LIMAN_OCR_DONE").replace(Regex("\\s"), "").length > 8

    fun encode(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)
}
