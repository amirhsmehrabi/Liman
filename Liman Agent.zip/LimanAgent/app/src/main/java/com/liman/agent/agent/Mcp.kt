package com.liman.agent.agent

import com.liman.agent.llm.Http
import com.liman.agent.llm.LPart
import com.liman.agent.util.toJsonObject
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * MCP (Model Context Protocol) client over Streamable HTTP.
 *
 * Connects to any MCP server that exposes an HTTP endpoint:
 *   initialize → notifications/initialized → tools/list → tools/call
 * Responses may be plain JSON or SSE-framed; both are handled.
 * Remote tools become first-class Liman tools named mcp_<server>_<tool>.
 */
class McpClient(
    private val endpoint: String,
    private val bearerToken: String = "",
    private val timeoutSec: Long = 60
) {
    private var sessionId: String? = null
    private var nextId = 1

    data class McpToolInfo(
        val name: String,
        val description: String,
        val inputSchemaJson: String,
        val readOnly: Boolean
    )

    data class McpCallResult(
        val text: String,
        val media: List<LPart.Media>,
        val isError: Boolean
    )

    fun initialize() {
        rpc(
            "initialize",
            buildJsonObject {
                put("protocolVersion", "2025-03-26")
                putJsonObject("capabilities") {}
                putJsonObject("clientInfo") {
                    put("name", "LimanAgent")
                    put("version", "1.0.0")
                }
            }
        )
        // notification — servers usually answer 202 with an empty body
        runCatching { notify("notifications/initialized") }
    }

    fun listTools(): List<McpToolInfo> {
        val result = rpc("tools/list", null)
        val tools = result["tools"] as? kotlinx.serialization.json.JsonArray ?: return emptyList()
        return tools.mapNotNull { t ->
            val obj = t as? JsonObject ?: return@mapNotNull null
            val name = (obj["name"] as? JsonPrimitive)?.content ?: return@mapNotNull null
            val description = (obj["description"] as? JsonPrimitive)?.content ?: ""
            val schema = obj["inputSchema"]?.toString()
                ?: """{"type":"object","properties":{}}"""
            val annotations = obj["annotations"] as? JsonObject
            val readOnly = (annotations?.get("readOnlyHint") as? JsonPrimitive)?.content == "true"
            McpToolInfo(name, description, schema, readOnly)
        }
    }

    fun callTool(name: String, args: JsonObject): McpCallResult {
        val result = rpc(
            "tools/call",
            buildJsonObject {
                put("name", name)
                put("arguments", args)
            }
        )
        val isError = (result["isError"] as? JsonPrimitive)?.content == "true"
        val content = result["content"] as? kotlinx.serialization.json.JsonArray
        val texts = ArrayList<String>()
        val media = ArrayList<LPart.Media>()
        var imgIdx = 0
        content?.forEach { c ->
            val obj = c as? JsonObject ?: return@forEach
            when ((obj["type"] as? JsonPrimitive)?.content) {
                "text" -> (obj["text"] as? JsonPrimitive)?.content?.let { texts.add(it) }
                "image" -> {
                    val b64 = (obj["data"] as? JsonPrimitive)?.content ?: return@forEach
                    val mime = (obj["mimeType"] as? JsonPrimitive)?.content ?: "image/png"
                    val ext = if (mime.contains("jpeg")) "jpg" else "png"
                    media.add(LPart.Media(mime, b64, "mcp_img_${imgIdx++}.$ext"))
                }
                "resource" -> {
                    val res = obj["resource"] as? JsonObject
                    val text = (res?.get("text") as? JsonPrimitive)?.content
                        ?: (res?.get("uri") as? JsonPrimitive)?.content ?: "resource"
                    texts.add(text)
                }
            }
        }
        val text = if (texts.isEmpty() && media.isEmpty()) {
            "(MCP tool returned no content)"
        } else texts.joinToString("\n").ifBlank { "(image content attached)" }
        return McpCallResult(text, media, isError)
    }

    // ---------------- transport ----------------

    private fun rpc(method: String, params: JsonObject?): JsonObject {
        val id = nextId++
        val body = buildJsonObject {
            put("jsonrpc", "2.0")
            put("id", id)
            put("method", method)
            params?.let { put("params", it) }
        }
        val payload = post(body)
        val obj = payload.toJsonObject()
            ?: throw IOException("MCP: non-JSON response: ${payload.take(200)}")
        (obj["error"] as? JsonObject)?.let { err ->
            val msg = (err["message"] as? JsonPrimitive)?.content ?: err.toString()
            throw IOException("MCP error: $msg")
        }
        return obj["result"] as? JsonObject ?: JsonObject(emptyMap())
    }

    private fun notify(method: String) {
        post(
            buildJsonObject {
                put("jsonrpc", "2.0")
                put("method", method)
            }
        )
    }

    private fun post(body: JsonObject): String {
        val req = Request.Builder()
            .url(endpoint)
            .header("Content-Type", "application/json")
            .header("Accept", "application/json, text/event-stream")
            .apply {
                sessionId?.let { header("Mcp-Session-Id", it) }
                if (bearerToken.isNotBlank()) header("Authorization", "Bearer $bearerToken")
            }
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        Http.toolClient(timeoutSec).newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IOException("MCP HTTP ${resp.code}: ${resp.body?.string()?.take(200)}")
            }
            if (sessionId == null) resp.header("mcp-session-id")?.let { sessionId = it }
            val ct = resp.header("Content-Type") ?: ""
            val raw = resp.body?.string() ?: ""
            return if (ct.contains("text/event-stream")) parseSseData(raw) else raw
        }
    }

    /** Extracts the last non-empty data: payload from an SSE-framed response. */
    private fun parseSseData(sse: String): String {
        val data = StringBuilder()
        var lastComplete = ""
        sse.lines().forEach { line ->
            when {
                line.startsWith("data:") -> data.append(line.removePrefix("data:").trim())
                line.isBlank() && data.isNotEmpty() -> {
                    lastComplete = data.toString()
                    data.setLength(0)
                }
            }
        }
        if (data.isNotEmpty()) lastComplete = data.toString()
        return lastComplete
    }
}
