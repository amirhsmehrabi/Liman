package com.liman.agent.agent

/**
 * v2.36.0 — AI TASK NAMING.
 *
 * The user's rule: a conversation's title must NEVER be the first prompt —
 * the agent names its own tasks with a short, creative 2-3 word title.
 *
 * [heuristic] is the zero-cost fallback (and the instant placeholder shown
 * in the list while the run is still going); the AI title replaces it right
 * after the first run completes. [clean] sanitizes whatever the model
 * replies with into a legal 1-3 word title.
 *
 * Pure Kotlin — unit-tested (TaskTitlesTest).
 */
object TaskTitles {

    private val STRIP = Regex("[\"'`*#\\[\\](){}<>:;,.!?…«»“”‘’—–\\n\\r\\t|/\\\\]")

    private val STOP = setOf(
        "the", "a", "an", "to", "for", "of", "in", "on", "at", "with", "and", "or",
        "my", "me", "i", "please", "can", "you", "could", "would", "should", "is",
        "are", "do", "does", "did", "will", "be", "this", "that", "it", "hey",
        "hi", "hello", "dear", "liman", "agent", "task", "about", "from", "into",
        "some", "give", "want", "need", "using", "use", "make", "help"
    )

    /** Instant placeholder from the first message — 2-3 significant words. */
    fun heuristic(text: String): String {
        val words = STRIP.replace(text, " ")
            .trim()
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() && it.length > 1 && it.lowercase() !in STOP }
        if (words.isEmpty()) return ""
        return titleCase(words.take(3)).take(28)
    }

    /** Sanitize the model's title reply into 1-3 clean words. */
    fun clean(raw: String): String {
        val words = STRIP.replace(raw, " ")
            .trim()
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
        if (words.isEmpty()) return ""
        // drop an accidental "Title:" prefix
        val dropped = if (words.size > 1 && words[0].lowercase().endsWith("title")) words.drop(1) else words
        if (dropped.isEmpty()) return ""
        return titleCase(dropped.take(3)).take(28)
    }

    private fun titleCase(words: List<String>): String =
        words.joinToString(" ") { w -> w.lowercase().replaceFirstChar { it.uppercase() } }

    const val SYSTEM =
        "You name conversations. Reply with ONLY a short, creative 2-3 word title for the task described. " +
            "No quotes, no punctuation, no emoji, no explanation — just the title words, in the language of the task."

    fun userPrompt(goal: String): String = "Task: ${goal.take(600)}\n\nTitle (2-3 words):"
}
