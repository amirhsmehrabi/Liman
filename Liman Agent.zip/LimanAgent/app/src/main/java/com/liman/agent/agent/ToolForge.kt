package com.liman.agent.agent

import android.content.Context
import com.liman.agent.data.Stores
import com.liman.agent.llm.RouterServer
import com.liman.agent.llm.ToolSpec
import com.liman.agent.util.JSON
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import java.io.File
import java.util.Base64

/**
 * v2.21.0 — TOOL FORGE: the agent programs itself.
 *
 * "I keep getting these PDF reports — make a tool that extracts the important
 * numbers." The agent writes the tool body, registers it, and from then on
 * calls it like any built-in. Two engines:
 *
 *  - **js** — runs in the sealed Rhino sandbox (JsSandbox: no Java classes,
 *    no I/O, instruction-counted, time-boxed). Always available, zero risk →
 *    SAFE tool. Perfect for parsing / transforming / computing.
 *  - **python** — a real python3 script in the user's Termux (full power:
 *    pip packages, files, network) → WRITE-risk, approval-gated, needs the
 *    Termux bridge.
 *
 * Contract:
 *  - js body = the body of a function receiving `input` (the parsed args
 *    object); its return value becomes the tool result (print() also works).
 *  - python body = a script reading ONE JSON object from stdin and printing
 *    its result (ideally JSON) to stdout.
 *
 * Stored as workspace/tools/<name>.json — auditable, deletable, versionable.
 */
object ToolForge {

    @Serializable
    data class ForgedSpec(
        val name: String,
        val description: String,
        val engine: String,        // js | python
        val params: String,        // JSON schema for the input object
        val code: String,
        val createdAt: Long = 0L
    )

    fun validName(name: String): Boolean = Regex("^[a-z][a-z0-9_]{2,30}$").matches(name)

    fun dir(workspace: File): File = File(workspace, "tools").apply { mkdirs() }

    fun save(workspace: File, spec: ForgedSpec): Boolean {
        if (!validName(spec.name)) return false
        runCatching {
            dir(workspace)
            File(dir(workspace), spec.name + ".json")
                .writeText(JSON.encodeToString(ForgedSpec.serializer(), spec))
        }.onFailure { return false }
        return true
    }

    fun loadAll(workspace: File): List<ForgedSpec> =
        dir(workspace).listFiles { f -> f.isFile && f.name.endsWith(".json") }.orEmpty()
            .mapNotNull { f ->
                runCatching { JSON.decodeFromString(ForgedSpec.serializer(), f.readText()) }.getOrNull()
            }
            .filter { validName(it.name) }

    fun delete(workspace: File, name: String): Boolean {
        if (!validName(name)) return false
        val f = File(dir(workspace), "$name.json")
        return f.exists() && f.delete()
    }

    // ---------------- execution ----------------

    /** JS: wrap the body in a function receiving `input`; its return = result. */
    fun jsWrapper(spec: ForgedSpec, argsJson: String): String {
        val input = argsJson.trim().ifBlank { "{}" }
        return "var input = $input;\n" +
            "var result = (function(){\n" + spec.code + "\n})();\nresult"
    }

    fun runJs(spec: ForgedSpec, argsJson: String, workspace: File): String =
        runCatching { JsSandbox.run(jsWrapper(spec, argsJson), 30_000L, workspace) }
            .getOrElse { "JS error: ${it.message ?: it.toString()}" }

    /** Python: base64-embed code + input into a bash script for the bridge. */
    fun pythonScript(spec: ForgedSpec, argsJson: String): String {
        val b64 = Base64.getEncoder().encodeToString(spec.code.toByteArray(Charsets.UTF_8))
        val inB64 = Base64.getEncoder().encodeToString(argsJson.trim().ifBlank { "{}" }.toByteArray(Charsets.UTF_8))
        return "mkdir -p ~/.liman-tools\n" +
            "printf %s '$b64' | base64 -d > ~/.liman-tools/${spec.name}.py\n" +
            "printf %s '$inB64' | base64 -d | python3 ~/.liman-tools/${spec.name}.py"
    }

    /** Run a python tool in Termux via the local-router bridge. */
    suspend fun runPython(context: Context, stores: Stores, spec: ForgedSpec, argsJson: String, timeoutS: Int = 180): String {
        val port = RouterServer.runningPort()
            ?: runCatching {
                val s = stores.settings.state.value
                if (RouterServer.start(stores, s.routerPort, s.routerLan)) s.routerPort else null
            }.getOrNull()
            ?: return "The Termux bridge is not reachable (local router not running). " +
                "Recreate this tool with engine 'js', or enable the router + Termux bridge."
        return TermuxBridge.run(context, port, pythonScript(spec, argsJson), timeoutS * 1000L)
    }

    fun isJsResultError(out: String): Boolean = out.startsWith("JS error:")

    /** Build the DynamicTool registration for a forged spec. */
    fun dynamicTool(
        spec: ForgedSpec,
        takenNames: Set<String>,
        context: Context,
        stores: Stores,
        workspace: File
    ): com.liman.agent.agent.DynamicTool? {
        if (spec.name in takenNames) return null
        val safeParams = runCatching {
            com.liman.agent.util.JSON.parseToJsonElement(spec.params)
            spec.params
        }.getOrDefault("""{"type":"object","properties":{}}""")
        return if (spec.engine == "python") {
            DynamicTool(
                ToolSpec(spec.name, "[forged·python] " + spec.description.take(800), safeParams),
                ToolRisk.WRITE
            ) { args -> runTool(spec, args, context, stores, workspace) }
        } else {
            DynamicTool(
                ToolSpec(spec.name, "[forged·js] " + spec.description.take(800), safeParams),
                ToolRisk.SAFE
            ) { args -> runTool(spec, args, context, stores, workspace) }
        }
    }

    private suspend fun runTool(
        spec: ForgedSpec,
        args: JsonObject,
        context: Context,
        stores: Stores,
        workspace: File
    ): ToolOutcome {
        val raw = args.toString()
        return if (spec.engine == "python") {
            val out = runPython(context, stores, spec, raw)
            val ok = !out.startsWith("Termux is not installed") && !out.startsWith("The Termux bridge") &&
                !out.startsWith("No response from Termux") && !out.startsWith("Could not send") &&
                !out.contains("Traceback (most recent call last)")
            ToolOutcome(out.take(20_000), ok)
        } else {
            val out = runJs(spec, raw, workspace)
            ToolOutcome(out.take(20_000), !isJsResultError(out))
        }
    }
}
