package com.liman.agent.data

import android.content.Context
import com.liman.agent.util.JSON
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import java.io.File

// ============================================================
// Individual stores
// ============================================================

class ProviderStore(private val file: File) {
    private val _state = MutableStateFlow<List<ProviderConfig>>(emptyList())
    val state: StateFlow<List<ProviderConfig>> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(ListSerializer(ProviderConfig.serializer()), file.readText())
        }.getOrDefault(emptyList())
    }

    fun get(id: String): ProviderConfig? = _state.value.firstOrNull { it.id == id }

    fun upsert(p: ProviderConfig) {
        val list = _state.value.toMutableList()
        val idx = list.indexOfFirst { it.id == p.id }
        if (idx >= 0) list[idx] = p else list.add(p)
        _state.value = list
        save()
    }

    fun delete(id: String) {
        _state.value = _state.value.filter { it.id != id }
        save()
    }

    private fun save() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(ListSerializer(ProviderConfig.serializer()), _state.value))
        }
    }
}

class SettingsStore(private val file: File) {
    private val _state = MutableStateFlow(AgentSettings())
    val state: StateFlow<AgentSettings> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(AgentSettings.serializer(), file.readText())
        }.getOrDefault(AgentSettings())
    }

    fun update(block: (AgentSettings) -> Unit) {
        val s = _state.value.copy()
        block(s)
        _state.value = s
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(AgentSettings.serializer(), s))
        }
    }
}

class ComboStore(private val file: File) {
    private val _state = MutableStateFlow(ComboConfig())
    val state: StateFlow<ComboConfig> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(ComboConfig.serializer(), file.readText())
        }.getOrDefault(ComboConfig())
    }

    fun update(block: (ComboConfig) -> ComboConfig) {
        val c = block(_state.value.copy())
        _state.value = c
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(ComboConfig.serializer(), c))
        }
    }
}

class MemoryStore(private val file: File) {
    private val _state = MutableStateFlow<Map<String, MemoryItem>>(emptyMap())
    val state: StateFlow<Map<String, MemoryItem>> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(
                MapSerializer(String.serializer(), MemoryItem.serializer()),
                file.readText()
            )
        }.getOrDefault(emptyMap())
    }

    fun save(key: String, value: String) {
        _state.value = _state.value + (key to MemoryItem(value))
        persist()
    }

    fun keys(): List<String> = _state.value.keys.sorted()

    fun recall(query: String? = null): List<Pair<String, String>> {
        val all = _state.value.map { it.key to it.value.value }
        if (query.isNullOrBlank()) return all
        val q = query.lowercase()
        return all.filter { it.first.lowercase().contains(q) || it.second.lowercase().contains(q) }
            .ifEmpty { all }
    }

    private fun persist() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(
                JSON.encodeToString(MapSerializer(String.serializer(), MemoryItem.serializer()), _state.value)
            )
        }
    }
}

class ConversationStore(private val dir: File) {
    private val _state = MutableStateFlow<List<ConversationMeta>>(emptyList())
    val state: StateFlow<List<ConversationMeta>> = _state

    init {
        dir.mkdirs()
        refresh()
    }

    fun refresh() {
        _state.value = dir.listFiles { f -> f.isFile && f.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() }
            ?.mapNotNull { f ->
                runCatching {
                    val c = JSON.decodeFromString(Conversation.serializer(), f.readText())
                    val preview = c.entries.firstOrNull { it is Entry.UserEntry }
                        ?.let { (it as Entry.UserEntry).text } ?: ""
                    ConversationMeta(c.id, c.title, c.updatedAt, preview.ellipsizeMax(), c.entries.size)
                }.getOrNull()
            } ?: emptyList()
    }

    private fun String.ellipsizeMax(n: Int = 90): String =
        if (length <= n) this else take(n) + "…"

    fun newConversation(): Conversation {
        val c = Conversation(id = com.liman.agent.util.genId("task"), ownWorkspace = true)
        write(c)
        refresh()
        return c
    }

    fun load(id: String): Conversation? = runCatching {
        val f = File(dir, "$id.json")
        if (f.exists()) JSON.decodeFromString(Conversation.serializer(), f.readText()) else null
    }.getOrNull()

    private fun write(c: Conversation) {
        runCatching {
            dir.mkdirs()
            File(dir, "${c.id}.json").writeText(JSON.encodeToString(Conversation.serializer(), c))
        }
    }

    suspend fun save(c: Conversation) {
        withContext(Dispatchers.IO) { write(c) }
        refresh()
    }

    fun delete(id: String) {
        File(dir, "$id.json").delete()
        refresh()
    }
}

// ============================================================
// Root container for all persistence + folders
// ============================================================

class Stores(context: Context) {
    private val dir = context.filesDir

    val workspace: File = File(dir, "workspace").apply { mkdirs() }
    val uploads: File = File(workspace, "uploads").apply { mkdirs() }
    val generated: File = File(workspace, "generated").apply { mkdirs() }
    val downloads: File = File(workspace, "downloads").apply { mkdirs() }

    /**
     * v2.31 — PER-CHAT WORKSPACES: each new conversation gets its own folder
     * under workspace/chats/<id>/, so one task's files never clutter another.
     * The root workspace stays the shared/legacy area (old chats, scheduled
     * missions that must keep state across runs, subagents inherit parent).
     */
    fun chatWorkspace(convId: String): File =
        File(workspace, "chats/$convId").apply { mkdirs() }
    val conversationsDir: File = File(dir, "conversations").apply { mkdirs() }

    val providers = ProviderStore(File(dir, "providers.json"))
    val settings = SettingsStore(File(dir, "settings.json"))
    val combo = ComboStore(File(dir, "combo.json"))
    val memory = MemoryStore(File(dir, "memory.json"))
    val conversations = ConversationStore(conversationsDir)
    val skills = SkillStore(File(dir, "skills"))
    val mcp = McpStore(File(dir, "mcp.json"))
    val telegram = TelegramStore(File(dir, "telegram.json"))
    val usage = UsageStore(File(dir, "usage.json"))
    val schedule = ScheduledStore(File(dir, "schedule.json"))
    // v2.20.0 — SYNTHESIS stores
    val knowledge = KnowledgeStore(File(dir, "knowledge"))
    // v2.21.0 — AUTOMATION LAYER stores
    val pipelines = PipelineStore(File(dir, "pipelines.json"))
    val runstate: File = File(dir, "runstate").apply { mkdirs() }
    // v2.23.0 — SUPER AGENT stores (watchers, triggers, digest, secret tokens)
    val watchers = WatcherStore(File(dir, "watchers.json"))
    val triggers = TriggerStore(File(dir, "triggers.json"))
    val digest = DigestStore(File(dir, "digest.json"))
    val tokens = TokenStore(File(dir, "tokens.json"))
}
