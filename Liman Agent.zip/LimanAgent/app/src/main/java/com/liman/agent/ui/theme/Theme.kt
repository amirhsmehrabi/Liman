package com.liman.agent.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * "Signal" — v2.9 design language (2026 evolved minimalism), v2.26.0 tuned
 * to a BLUE tone (user request: blue instead of green).
 *
 * Deep blue-graphite canvas, one signature azure→cyan gradient doing all
 * the brand work, soft tonal bubbles for the assistant, gradient-filled
 * bubbles for the user, and a threaded rail that links consecutive answers
 * with a traveling pulse of light. Minimal chrome, generous whitespace,
 * motion only where it means something.
 */

// ---------- v2.34.0 FLUID CANVAS palette (the accepted HTML design) ----------
// Deep navy canvas #060B16 · sky #38BDF8 → indigo #818CF8 signature gradient ·
// blue-tinted glass surfaces · emerald semantic success · amber steer.
private val Canvas = Color(0xFF060B16)        // S0 — deepest navy (from the mockup)
private val Surface = Color(0xFF0A1120)        // S1 — tonal glass layer
private val SurfaceHi = Color(0xFF0E1730)      // S2 — chat/agent layer
private val Surface3 = Color(0xFF13203C)       // S3 — tool/chain layer
private val Surface4 = Color(0xFF182948)       // S4 — elevated
private val Sky = Color(0xFF38BDF8)            // signature sky (primary)
private val Indigo = Color(0xFF818CF8)         // signature indigo (secondary)
private val OnSignal = Color(0xFF041020)
private val SkyContainer = Color(0xFF10273F)
private val OnSkyContainer = Color(0xFFCDEAFF)
private val Emerald = Color(0xFF34D399)        // semantic success + steer
private val OnEmerald = Color(0xFF03251A)
private val EmeraldContainer = Color(0xFF0D3A2C)
private val OnEmeraldContainer = Color(0xFFA7F3D0)
private val Ink = Color(0xFFE6EDFB)            // primary text
private val InkDim = Color(0xFF8B9CC4)         // secondary text

val DarkColors = darkColorScheme(
    primary = Sky,
    onPrimary = OnSignal,
    primaryContainer = SkyContainer,
    onPrimaryContainer = OnSkyContainer,
    secondary = Indigo,
    onSecondary = Color(0xFF0B1030),
    secondaryContainer = Color(0xFF232B54),
    onSecondaryContainer = Color(0xFFDDE1FF),
    tertiary = Emerald,
    onTertiary = OnEmerald,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = OnEmeraldContainer,
    background = Canvas,
    onBackground = Ink,
    surface = Surface,
    onSurface = Ink,
    surfaceVariant = SurfaceHi,
    onSurfaceVariant = InkDim,
    surfaceTint = Sky,
    inverseSurface = Ink,
    inverseOnSurface = Canvas,
    outline = Color(0xFF3A4A70),
    outlineVariant = Color(0xFF1B2740),
    error = Color(0xFFF87171),
    errorContainer = Color(0xFF5C1A1E),
    onError = Color(0xFF2A0507),
    onErrorContainer = Color(0xFFFFDAD6),
    scrim = Color(0xFF000000)
)

// ---------- light palette (Fluid Canvas daylight) ----------
val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBE9FF),
    onPrimaryContainer = Color(0xFF0B1F45),
    secondary = Color(0xFF6366F1),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE3E5FF),
    onSecondaryContainer = Color(0xFF1A1F56),
    tertiary = Color(0xFF0D9488),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFC8F5EC),
    onTertiaryContainer = Color(0xFF04302A),
    background = Color(0xFFF2F5FC),
    onBackground = Color(0xFF101828),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF101828),
    surfaceVariant = Color(0xFFE7ECF8),
    onSurfaceVariant = Color(0xFF4A5878),
    outline = Color(0xFF6B7A9C),
    outlineVariant = Color(0xFFC6CEDC),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6)
)

/** The signature gradient + semantic extras. */
object LimanExtras {
    // SIGNAL HUES ARE LOCKED: they convey state and must never be re-themed.
    val Success = Color(0xFF34D399)
    val Warn = Color(0xFFFBBF24)
    val Error = Color(0xFFF87171)
    val Free = Color(0xFF38BDF8)
    val Vision = Color(0xFFFBBF24)
    val Apricot = Color(0xFFFBBF24)
    // chat bubble pairs — quiet translucent indigo (user) on navy glass
    val ChatUserBgDark = Color(0xFF1B2344)
    val ChatUserFgDark = Color(0xFFCBD5F5)
    val ChatUserBgLight = Color(0xFFDBE7FF)
    val ChatUserFgLight = Color(0xFF0D1F45)
    /** the traveling rail pulse — sky → indigo (the Fluid Canvas gradient) */
    val RailA = Color(0xFF38BDF8)
    val RailB = Color(0xFF818CF8)
    /** dark ink for text/icons sitting ON the gradient */
    val OnSignalFallback = Color(0xFF041020)

    /** the send affordance follows the tonal user-bubble pair */
    @androidx.compose.runtime.Composable
    fun sendTint(): Color =
        if (androidx.compose.foundation.isSystemInDarkTheme()) ChatUserBgDark else ChatUserBgLight

    @androidx.compose.runtime.Composable
    fun sendInk(): Color =
        if (androidx.compose.foundation.isSystemInDarkTheme()) ChatUserFgDark else ChatUserFgLight
}

@Composable
fun LimanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = LimanTypography,
        content = content
    )
}
