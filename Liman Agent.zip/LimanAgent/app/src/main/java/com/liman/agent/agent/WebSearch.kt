package com.liman.agent.agent

import com.liman.agent.llm.Http
import com.liman.agent.util.ellipsize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.IOException
import java.net.URLDecoder
import java.net.URLEncoder

/**
 * Agent web search with a resilient engine chain:
 * DuckDuckGo HTML → Bing → Wikipedia API.
 * No API key needed.
 */
object WebSearch {

    data class SearchResult(val title: String, val url: String, val snippet: String)

    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

    suspend fun search(query: String, maxResults: Int = 6): String = withContext(Dispatchers.IO) {
        val res = searchResults(query, maxResults)
        if (res.isEmpty()) {
            "Web search failed on all engines (DuckDuckGo, Bing, Wikipedia). " +
                "You can still try http_request directly on a known URL."
        } else {
            buildString {
                appendLine("Web results for \"$query\":")
                res.forEachIndexed { i, r ->
                    appendLine()
                    appendLine("${i + 1}. ${r.title}")
                    appendLine("   ${r.url}")
                    if (r.snippet.isNotBlank()) appendLine("   ${r.snippet.ellipsize(240)}")
                }
            }
        }
    }

    /** Structured search used by the skill finder and the free-API radar. */
    suspend fun searchResults(query: String, maxResults: Int = 8): List<SearchResult> =
        withContext(Dispatchers.IO) {
            val engines = listOf<() -> List<SearchResult>>(
                { duckDuckGo(query) },
                { bing(query) },
                { wikipedia(query) }
            )
            for (engine in engines) {
                val res = runCatching { engine() }.getOrDefault(emptyList())
                if (res.isNotEmpty()) return@withContext res.take(maxResults)
            }
            emptyList()
        }

    private fun httpGet(url: String, timeoutSec: Long = 25): String {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", UA)
            .header("Accept-Language", "en-US,en;q=0.9")
            .get()
            .build()
        Http.toolClient(timeoutSec).newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            return r.body?.string() ?: ""
        }
    }

    private fun stripTags(s: String) = s.replace(Regex("<[^>]*>"), "")

    private fun clean(s: String) = stripTags(OfficeExtractors.decodeEntities(s))
        .replace(Regex("\\s+"), " ")
        .trim()

    // ---------------- DuckDuckGo HTML ----------------

    private fun duckDuckGo(query: String): List<SearchResult> {
        val html = httpGet("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(query, "UTF-8"))
        if (!html.contains("result__a")) throw IOException("no result block (possibly rate-limited)")
        val out = ArrayList<SearchResult>()
        val linkRe = Regex(
            """<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""",
            RegexOption.DOT_MATCHES_ALL
        )
        for (m in linkRe.findAll(html)) {
            val href = OfficeExtractors.decodeEntities(m.groupValues[1])
            val url = ddgRealUrl(href) ?: continue
            val title = clean(m.groupValues[2])
            if (title.isEmpty() || url.startsWith("http://duckduckgo.com")) continue
            out.add(SearchResult(title, url, ""))
        }
        val snipRe = Regex(
            """class="result__snippet"[^>]*>(.*?)</(?:a|div|span|td)>""",
            RegexOption.DOT_MATCHES_ALL
        )
        val snippets = snipRe.findAll(html).map { clean(it.groupValues[1]) }.toList()
        return out.mapIndexed { i, r ->
            if (i < snippets.size) r.copy(snippet = snippets[i]) else r
        }.filter { it.title.isNotBlank() }
    }

    private fun ddgRealUrl(href: String): String? {
        if (href.startsWith("//") || href.contains("duckduckgo.com/l/")) {
            val m = Regex("""[?&]uddg=([^&]+)""").find(href) ?: return null
            return URLDecoder.decode(m.groupValues[1], "UTF-8")
        }
        return href
    }

    // ---------------- Bing ----------------

    private fun bing(query: String): List<SearchResult> {
        val html = httpGet("https://www.bing.com/search?q=" + URLEncoder.encode(query, "UTF-8") + "&count=12")
        val unescaped = OfficeExtractors.decodeEntities(html)
        val chunks = unescaped.split("<li class=\"b_algo\"").drop(1)
        if (chunks.isEmpty()) throw IOException("no b_algo results")
        val out = ArrayList<SearchResult>()
        for (chunk in chunks) {
            val m = Regex("""<h2[^>]*><a[^>]*href="([^"]+)"[^>]*>(.*?)</a>""").find(chunk) ?: continue
            var url = m.groupValues[1]
            val b64 = Regex("""[?&]u=a1([A-Za-z0-9_\-=]+)""").find(url)?.groupValues?.get(1)
            if (b64 != null) {
                url = try {
                    val padded = b64 + "=".repeat((-b64.length) % 4)
                    String(java.util.Base64.getUrlDecoder().decode(padded), Charsets.UTF_8)
                } catch (t: Throwable) {
                    url
                }
            }
            val title = clean(m.groupValues[2])
            if (title.isEmpty() || !url.startsWith("http")) continue
            val snip = Regex("""<p[^>]*>(.*?)</p>""", RegexOption.DOT_MATCHES_ALL)
                .find(chunk)?.let { clean(it.groupValues[1]) } ?: ""
            out.add(SearchResult(title, url, snip))
            if (out.size >= 8) break
        }
        return out
    }

    // ---------------- Wikipedia ----------------

    private fun wikipedia(query: String): List<SearchResult> {
        val json = httpGet(
            "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=" +
                URLEncoder.encode(query, "UTF-8") + "&format=json&srlimit=5"
        )
        val out = ArrayList<SearchResult>()
        val titles = Regex(""""title"\s*:\s*"((?:[^"\\]|\\.)*)"""").findAll(json)
            .map { it.groupValues[1].replace("\\\"", "\"").replace("\\\\", "\\") }
            .toList()
        for (t in titles) {
            val url = "https://en.wikipedia.org/wiki/" + URLEncoder.encode(t.replace(' ', '_'), "UTF-8")
            out.add(SearchResult(t, url, ""))
        }
        // snippets
        val snips = Regex(""""snippet"\s*:\s*"((?:[^"\\]|\\.)*)"""").findAll(json)
            .map { clean(it.groupValues[1]) }
            .toList()
        val withSnips = out.mapIndexed { i, r -> if (i < snips.size) r.copy(snippet = snips[i]) else r }
        if (withSnips.isEmpty()) throw IOException("no wikipedia hits")
        return withSnips
    }
}
