package com.liman.agent.agent

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.abs

/**
 * Safe, precise math expression evaluator (recursive descent).
 * No eval, no host access. Used by the `calculator` agent tool.
 */
object Calculator {

    fun evaluate(raw: String): String = try {
        if (raw.isBlank()) throw IllegalArgumentException("empty expression")
        val p = Parser(raw)
        val v = p.parseExpr()
        p.skipWs()
        if (!p.atEnd()) throw IllegalArgumentException("unexpected '${p.peekChar()}' at position ${p.i + 1}")
        fmt(v)
    } catch (t: Throwable) {
        "Error: ${t.message ?: "invalid expression"}"
    }

    private fun fmt(v: Double): String = when {
        v.isNaN() || v.isInfinite() -> "Error: result is not finite"
        abs(v - v.toLong().toDouble()) < 1e-9 && abs(v) < 1e15 -> v.toLong().toString()
        else -> BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
    }

    private class Parser(val s: String) {
        var i = 0

        fun skipWs() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        fun atEnd() = i >= s.length
        fun peekChar() = s[i]

        fun parseExpr(): Double {
            var v = parseTerm()
            while (true) {
                skipWs()
                if (i < s.length && (s[i] == '+' || s[i] == '-')) {
                    val op = s[i]; i++
                    val r = parseTerm()
                    v = if (op == '+') v + r else v - r
                } else return v
            }
        }

        private fun parseTerm(): Double {
            var v = parseFactor()
            while (true) {
                skipWs()
                if (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
                    val op = s[i]; i++
                    val r = parseFactor()
                    v = when (op) {
                        '*' -> v * r
                        '/' -> v / r
                        else -> v % r
                    }
                } else return v
            }
        }

        private fun parseFactor(): Double {
            skipWs()
            var neg = false
            while (i < s.length && (s[i] == '-' || s[i] == '+')) {
                if (s[i] == '-') neg = !neg
                i++
                skipWs()
            }
            var v = parsePrimary()
            skipWs()
            if (i < s.length && s[i] == '^') {
                i++
                val r = parseFactor() // right-associative
                v = Math.pow(v, r)
            }
            return if (neg) -v else v
        }

        private fun parsePrimary(): Double {
            skipWs()
            if (i >= s.length) throw IllegalArgumentException("unexpected end of expression")
            val c = s[i]
            if (c == '(') {
                i++
                val v = parseExpr()
                skipWs()
                if (i >= s.length || s[i] != ')') throw IllegalArgumentException("missing ')'")
                i++
                return v
            }
            if (c.isDigit() || c == '.') return parseNumber()
            if (c.isLetter() || c == '_') return parseName()
            throw IllegalArgumentException("unexpected character '$c'")
        }

        private fun parseNumber(): Double {
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
                i++
                if (i < s.length && (s[i] == '+' || s[i] == '-')) i++
                while (i < s.length && s[i].isDigit()) i++
            }
            val tok = s.substring(start, i)
            return tok.toDoubleOrNull() ?: throw IllegalArgumentException("bad number '$tok'")
        }

        private fun parseName(): Double {
            val start = i
            while (i < s.length && (s[i].isLetterOrDigit() || s[i] == '_')) i++
            val name = s.substring(start, i).lowercase()
            skipWs()
            if (i < s.length && s[i] == '(') {
                i++
                val args = ArrayList<Double>()
                skipWs()
                if (i < s.length && s[i] == ')') {
                    i++
                } else {
                    while (true) {
                        args.add(parseExpr())
                        skipWs()
                        if (i < s.length && s[i] == ',') {
                            i++
                            continue
                        }
                        if (i < s.length && s[i] == ')') {
                            i++
                            break
                        }
                        throw IllegalArgumentException("expected ',' or ')' in arguments of $name")
                    }
                }
                return applyFunction(name, args)
            }
            return constant(name)
        }

        private fun applyFunction(name: String, args: List<Double>): Double {
            fun need(n: Int) {
                if (args.size != n) throw IllegalArgumentException("$name expects $n argument(s), got ${args.size}")
            }
            return when (name) {
                "sqrt" -> { need(1); Math.sqrt(args[0]) }
                "cbrt" -> { need(1); Math.cbrt(args[0]) }
                "abs" -> { need(1); Math.abs(args[0]) }
                "sin" -> { need(1); Math.sin(args[0]) }
                "cos" -> { need(1); Math.cos(args[0]) }
                "tan" -> { need(1); Math.tan(args[0]) }
                "asin" -> { need(1); Math.asin(args[0]) }
                "acos" -> { need(1); Math.acos(args[0]) }
                "atan" -> { need(1); Math.atan(args[0]) }
                "atan2" -> { need(2); Math.atan2(args[0], args[1]) }
                "sinh" -> { need(1); Math.sinh(args[0]) }
                "cosh" -> { need(1); Math.cosh(args[0]) }
                "tanh" -> { need(1); Math.tanh(args[0]) }
                "ln" -> { need(1); Math.log(args[0]) }
                "log" -> { need(1); Math.log10(args[0]) }
                "log2" -> { need(1); Math.log(args[0]) / Math.log(2.0) }
                "exp" -> { need(1); Math.exp(args[0]) }
                "round" -> { need(1); Math.round(args[0]).toDouble() }
                "floor" -> { need(1); Math.floor(args[0]) }
                "ceil" -> { need(1); Math.ceil(args[0]) }
                "sign", "signum" -> { need(1); Math.signum(args[0]) }
                "deg" -> { need(1); Math.toDegrees(args[0]) }
                "rad" -> { need(1); Math.toRadians(args[0]) }
                "min" -> { if (args.isEmpty()) throw IllegalArgumentException("min needs arguments"); args.min() }
                "max" -> { if (args.isEmpty()) throw IllegalArgumentException("max needs arguments"); args.max() }
                "pow" -> { need(2); Math.pow(args[0], args[1]) }
                "hypot" -> { need(2); Math.hypot(args[0], args[1]) }
                else -> throw IllegalArgumentException("unknown function '$name'")
            }
        }

        private fun constant(name: String): Double = when (name) {
            "pi" -> Math.PI
            "e" -> Math.E
            "tau" -> 2.0 * Math.PI
            else -> throw IllegalArgumentException("unknown name '$name'")
        }
    }
}
