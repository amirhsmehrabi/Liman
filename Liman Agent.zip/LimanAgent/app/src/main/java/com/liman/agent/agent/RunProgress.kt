package com.liman.agent.agent

import com.liman.agent.llm.ToolCallData

/**
 * v2.34.0 — THE PROGRESS AUDITOR.
 *
 * The user's complaint, verbatim: "the agent just does multiple cycles
 * without any progress — it writes and writes and writes without doing the
 * tasks, and it must ask the user for help whenever that would make the
 * way faster."
 *
 * This class watches every cycle of a run and detects the three failure
 * shapes of a "spinning" agent:
 *  1. REPEAT  — the same tool calls (name + args) executing again, changing
 *               nothing. Repeating an identical call is not progress.
 *  2. STALL   — cycles passing with zero MUTATING tool calls (reads and
 *               searches only — the agent is "researching" forever).
 *  3. CHATTER — long prose produced between/below tool calls ("write and
 *               write"): big text with barely any action.
 *
 * When any shape persists, [directive] produces the exact instruction that
 * gets injected into the conversation: ACT differently, or ASK THE USER for
 * the one missing piece — asking is faster than guessing.
 *
 * Pure Kotlin — unit-tested (RunProgressTest).
 */
class RunProgress {

    data class CycleReport(
        val cycle: Int,
        val repeatedAll: Boolean,   // every call this cycle was already seen verbatim
        val mutating: Int,          // mutating tool calls this cycle
        val newDistinct: Int,       // first-time call signatures this cycle
        val textChars: Int          // prose the model emitted alongside
    )

    /** Tools that change state — reads/searches don't count as progress. */
    val mutatingTools = setOf(
        "write_file", "append_file", "edit_file", "delete_file", "patch",
        "http_request", "termux_run", "run_js", "run_code", "render_html",
        "native_apk", "build_apk", "snapshot", "mission", "schedule",
        "automation", "tool_forge", "skill_create", "memory_save", "knowledge_add",
        "device", "ui", "image_generate", "motion", "storage_write", "storage_clean",
        "mcp_connect", "github", "watch", "trigger", "evolve", "pack", "install_skill",
        "team_run", "spawn_subagent",
        "finish"
    )

    private val seen = HashSet<String>()
    private var consecutiveRepeats = 0
    private var cyclesWithoutMutation = 0
    private var chattyCycles = 0
    var cycles = 0
        private set
    var directivesUsed = 0
        private set

    val isRepeating get() = consecutiveRepeats >= 2
    val isStalled get() = cyclesWithoutMutation >= 3
    val isChatty get() = chattyCycles >= 2

    /** Record one cycle; returns the report for logging. */
    fun record(cycle: Int, calls: List<ToolCallData>, text: String): CycleReport {
        cycles = cycle
        val fingerprints = calls.map { it.name + "::" + it.argsJson.take(300) }
        val newDistinct = fingerprints.count { it !in seen }
        fingerprints.forEach { seen.add(it) }
        val mutating = calls.count { it.name in mutatingTools }
        val repeatedAll = calls.isNotEmpty() && newDistinct == 0

        consecutiveRepeats = if (repeatedAll) consecutiveRepeats + 1 else 0
        cyclesWithoutMutation = if (mutating == 0) cyclesWithoutMutation + 1 else 0
        chattyCycles = if (text.length > 900 && calls.size < 2) chattyCycles + 1 else 0

        return CycleReport(cycle, repeatedAll, mutating, newDistinct, text.length)
    }

    /** True when the auditor should inject a directive after this cycle. */
    fun needsDirective(maxCycles: Int, cycle: Int): Boolean =
        (isRepeating || isStalled || isChatty) && directivesUsed < 3 ||
            (maxCycles > 4 && cycle >= (maxCycles * 0.7).toInt() && cyclesWithoutMutation >= 2 && directivesUsed < 3)

    /**
     * The injected instruction. Deliberately blunt — politeness already
     * failed by the time this fires.
     */
    fun directive(maxCycles: Int, cycle: Int): String {
        directivesUsed++
        val budget = if (maxCycles > 4 && cycle >= (maxCycles * 0.7).toInt())
            " CYCLE BUDGET: you are on cycle $cycle of $maxCycles — converge NOW." else ""
        val shape = when {
            isRepeating -> "You are REPEATING identical tool calls — nothing changed the first time, nothing will change now."
            isStalled -> "You have spent $cyclesWithoutMutation cycles without a single state-changing action — research is done, execution is overdue."
            isChatty -> "You are writing long prose instead of acting."
            else -> "You are running out of cycles without delivering."
        }
        return "[PROGRESS AUDIT — $shape$budget\n" +
            "STOP writing. STOP re-planning. Do exactly one of these NOW:\n" +
            "(a) take ONE DIFFERENT concrete action (a mutating tool call you have not made yet), or\n" +
            "(b) call ask_user with the single question whose answer unblocks you — if the user's answer would save you " +
            "two or more cycles of guessing, asking is the FAST path, not a failure.\n" +
            "Intermediate text between tool calls is capped at two short sentences. The final answer is the only place for prose.]"
    }
}
