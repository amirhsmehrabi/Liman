package com.liman.agent.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liman.agent.LimanApplication
import com.liman.agent.R
import com.liman.agent.agent.FileIngestor
import com.liman.agent.data.ConversationMeta
import com.liman.agent.util.fmtTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationsScreen(
    onOpen: (String) -> Unit,
    onSettings: () -> Unit,
    onSkills: () -> Unit = {},
    onCredits: () -> Unit = {},
    onAutomations: () -> Unit = {}
) {
    val context = LocalContext.current
    val app = remember { LimanApplication.get(context) }
    val stores = app.container.stores
    val conversations by stores.conversations.state.collectAsState()
    val providers by stores.providers.state.collectAsState()
    val scope = rememberCoroutineScope()
    var deleteTarget by remember { mutableStateOf<ConversationMeta?>(null) }
    // v2.36 — rename tasks right from the landing view
    var renameTarget by remember { mutableStateOf<ConversationMeta?>(null) }
    var renameText by remember { mutableStateOf("") }


    // consume a share-intent handoff (files/text shared from other apps)
    LaunchedEffect(Unit) {
        val share = app.container.pendingShare ?: return@LaunchedEffect
        app.container.pendingShare = null
        val conv = withContext(Dispatchers.IO) { stores.conversations.newConversation() }
        val rels = ArrayList<String>()
        withContext(Dispatchers.IO) {
            val ingestor = FileIngestor(context)
            share.uris.forEach { uri ->
                ingestor.importUri(uri, stores.workspace)?.let { f ->
                    rels.add(f.relativeTo(stores.workspace).toString().replace('\\', '/'))
                }
            }
        }
        if (rels.isNotEmpty()) app.container.pendingImports[conv.id] = rels
        if (share.text.isNotBlank()) app.container.pendingDrafts[conv.id] = share.text
        onOpen(conv.id)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            LimanIcon(R.drawable.ic_anchor, MaterialTheme.colorScheme.primary, size = 20)
                            Spacer(Modifier.width(8.dp))
                            Text("Liman Agent", style = MaterialTheme.typography.titleLarge)
                        }
                        Text(
                            "Your pocket AI agent",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onAutomations) {
                        LimanIcon(R.drawable.ic_bolt, MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = onSkills) {
                        LimanIcon(R.drawable.ic_search_skills, MaterialTheme.colorScheme.onSurface)
                    }
                    IconButton(onClick = onCredits) {
                        Text("💳", fontSize = 18.sp)
                    }
                    IconButton(onClick = onSettings) {
                        LimanIcon(R.drawable.ic_settings, MaterialTheme.colorScheme.onSurface)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    scope.launch(Dispatchers.IO) {
                        val conv = stores.conversations.newConversation()
                        withContext(Dispatchers.Main) { onOpen(conv.id) }
                    }
                },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("New task") }
            )
        }
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
        ) {
            if (providers.none { it.enabled }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            "No provider yet",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            "Add one to give Liman a brain. Gemini connects with just a free API key.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(Modifier.size(8.dp))
                        TextButton(onClick = onSettings) { Text("Open Settings →") }
                    }
                }
            }
            if (conversations.isEmpty() && providers.any { it.enabled }) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        Modifier
                            .size(64.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, androidx.compose.foundation.shape.RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center
                    ) { LimanIcon(R.drawable.ic_anchor, MaterialTheme.colorScheme.onPrimaryContainer, size = 34) }
                    Text(
                        "No tasks yet.\nTap “New task” and give Liman a goal.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 12.dp, vertical = 8.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(conversations, key = { it.id }) { meta ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpen(meta.id) },
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                        ) {
                            Row(
                                Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        meta.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (meta.preview.isNotBlank()) {
                                        Text(
                                            meta.preview,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(
                                        "${meta.entryCount} entries · ${meta.updatedAt.fmtTime()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { renameTarget = meta; renameText = meta.title }) {
                                    Icon(
                                        Icons.Filled.Edit, "Rename",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { deleteTarget = meta }) {
                                    Icon(
                                        Icons.Filled.Delete, "Delete",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    deleteTarget?.let { meta ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete task?") },
            text = { Text("“${meta.title}” and its history will be removed.") },
            confirmButton = {
                TextButton(onClick = {
                    stores.conversations.delete(meta.id)
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }

    // v2.36 — rename a task from the landing view
    renameTarget?.let { meta ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename task") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val newTitle = renameText.trim()
                    if (newTitle.isNotEmpty()) {
                        scope.launch {
                            stores.conversations.load(meta.id)?.let { c ->
                                c.title = newTitle
                                stores.conversations.save(c)
                            }
                        }
                    }
                    renameTarget = null
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }
}
