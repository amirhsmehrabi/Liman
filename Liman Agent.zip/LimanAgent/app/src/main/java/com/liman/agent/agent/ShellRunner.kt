package com.liman.agent.agent

import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * On-device shell: runs real shell scripts inside Liman using an embedded
 * static busybox (sh/ash + ~380 applets: awk, sed, grep, tar, wget, find,
 * xargs, sort, bc, …) shipped as lib*.so in the APK's native library dir —
 * the only app-owned location Android 10+ still allows exec() from.
 *
 * The script runs with the app's own uid: full access to the Liman workspace,
 * no root, no access to other apps. If busybox is missing (exotic ABI), it
 * falls back to /system/bin/sh (mksh + toybox).
 */
object ShellRunner {

    data class Result(
        val stdout: String,
        val stderr: String,
        val exitCode: Int,
        val timedOut: Boolean,
        val shell: String
    )

    private const val MAX_STREAM = 128 * 1024
    private const val KEEP_HEAD = 96 * 1024
    private const val KEEP_TAIL = 24 * 1024

    /**
     * @param busybox explicit busybox binary (tests pass the x86_64 build from
     *                jniLibs); null → try nativeLibraryDir, then /system/bin/sh
     */
    fun run(
        script: String,
        cwd: File,
        timeoutMs: Long,
        stdin: String? = null,
        busybox: File? = null,
        nativeLibraryDir: File? = null,
        workspace: File? = null
    ): Result {
        val timeout = timeoutMs.coerceIn(1_000L, 120_000L)

        val bb = busybox
            ?: nativeLibraryDir?.let { File(it, "libbusybox.so") }?.takeIf { it.canExecute() }

        var shellDesc: String
        var cmd: List<String>
        var extraPath: File?

        if (bb != null && bb.canExecute()) {
            // This busybox build only dispatches when argv[0] names an applet —
            // so we always run it through a symlink called "busybox" (pointing
            // into nativeLibraryDir, so no exec-from-data-dir problem) and
            // symlink-farm all applets into PATH via `busybox --install -s`.
            val binDir = workspace?.let { File(it, ".liman/bin") } ?: File(cwd, ".liman/bin")
            try {
                binDir.mkdirs()
                val bbLink = File(binDir, "busybox")
                if (!bbLink.exists()) {
                    try {
                        java.nio.file.Files.createSymbolicLink(bbLink.toPath(), bb.absoluteFile.toPath())
                    } catch (e: Exception) {
                        // no symlink support → plain copy (works on older Androids)
                        bb.copyTo(bbLink, overwrite = true)
                        bbLink.setExecutable(true, false)
                    }
                }
                if (!File(binDir, "sh").exists()) {
                    ProcessBuilder(bbLink.absolutePath, "--install", "-s", binDir.absolutePath)
                        .start().waitFor(10, TimeUnit.SECONDS)
                }
                // ssl_helper for wget https:// (busybox looks for it in PATH)
                val src = nativeLibraryDir?.let { File(it, "libsslhelper.so") }
                if (src != null && src.isFile) {
                    val staged = File(binDir, "ssl_helper")
                    if (!staged.isFile || staged.length() != src.length()) {
                        src.copyTo(staged, overwrite = true)
                        staged.setExecutable(true, false)
                    }
                }
                cmd = listOf(bbLink.absolutePath, "sh", "-c", script)
                shellDesc = "busybox ash (on-device)"
                extraPath = binDir
            } catch (e: Exception) {
                cmd = listOf(bb.absolutePath, "sh", "-c", script)
                shellDesc = "busybox ash (on-device, no applet links)"
                extraPath = null
            }
        } else {
            extraPath = null
            cmd = listOf("/system/bin/sh", "-c", script)
            shellDesc = "/system/bin/sh (system)"
        }

        val tmp = File(cwd, ".liman/tmp").apply { mkdirs() }
        val pb = ProcessBuilder(cmd).apply {
            directory(cwd)
            val pathDirs = buildList {
                extraPath?.let { add(it.absolutePath) }
                nativeLibraryDir?.let { add(it.absolutePath) }
                add("/system/bin"); add("/system/xbin"); add("/sbin"); add("/vendor/bin")
                add("/system/sbin")
            }
            environment()["PATH"] = pathDirs.joinToString(":")
            environment()["HOME"] = cwd.absolutePath
            environment()["TMPDIR"] = tmp.absolutePath
            environment()["TERM"] = "dumb"
            environment()["LANG"] = "C.UTF-8"
            redirectErrorStream(false)
        }

        val proc = pb.start()
        val stdoutBuf = StringBuilder()
        val stderrBuf = StringBuilder()

        val outThread = Thread { readInto(proc.inputStream, stdoutBuf, MAX_STREAM) }
        val errThread = Thread { readInto(proc.errorStream, stderrBuf, MAX_STREAM) }
        outThread.isDaemon = true
        errThread.isDaemon = true
        outThread.start()
        errThread.start()

        try {
            proc.outputStream.use { os ->
                if (stdin != null) os.write(stdin.toByteArray(Charsets.UTF_8))
            }
        } catch (_: Exception) {
            // process may have exited already
        }

        val finished = proc.waitFor(timeout, TimeUnit.MILLISECONDS)
        val timedOut = !finished
        if (timedOut) {
            proc.destroyForcibly()
        }
        outThread.join(1500)
        errThread.join(1500)

        return Result(
            stdout = cap(stdoutBuf.toString()),
            stderr = cap(stderrBuf.toString()),
            exitCode = if (timedOut) -1 else proc.exitValue(),
            timedOut = timedOut,
            shell = shellDesc
        )
    }


    private fun readInto(stream: java.io.InputStream, sb: StringBuilder, max: Int) {
        try {
            val buf = ByteArray(8 * 1024)
            var total = 0
            while (true) {
                val n = stream.read(buf)
                if (n < 0) break
                if (total < max) {
                    val take = minOf(n, max - total)
                    sb.append(String(buf, 0, take, Charsets.UTF_8))
                    total += take
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun cap(s: String): String {
        if (s.length <= KEEP_HEAD) return s
        return s.take(KEEP_HEAD) + "\n…[${s.length - KEEP_HEAD - KEEP_TAIL} bytes truncated]…\n" +
            s.takeLast(KEEP_TAIL)
    }
}
