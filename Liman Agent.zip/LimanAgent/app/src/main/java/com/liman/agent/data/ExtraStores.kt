package com.liman.agent.data

import com.liman.agent.util.JSON
import com.liman.agent.util.genId
import com.liman.agent.util.now
import com.liman.agent.util.sanitizeFileName
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import java.io.File

// ============================================================
// Skills
// ============================================================

@Serializable
data class SkillMeta(
    val id: String,
    var name: String,
    var description: String = "",
    var sourceUrl: String = "",
    var enabled: Boolean = true,
    var installedAt: Long = now(),
    var uses: Int = 0
)

/**
 * Skills live as folders under files/skills/<id>/SKILL.md (+ meta.json),
 * compatible with the SKILL.md + YAML frontmatter format used by
 * Claude Code / Hermes style skill packs.
 */
class SkillStore(private val dir: File) {

    private val _state = MutableStateFlow<List<SkillMeta>>(emptyList())
    val state: StateFlow<List<SkillMeta>> = _state

    init {
        dir.mkdirs()
        refresh()
    }

    fun refresh() {
        val folders = dir.listFiles { f -> f.isDirectory } ?: emptyArray()
        val metas = folders.mapNotNull { folder ->
            val md = File(folder, "SKILL.md")
            if (!md.exists()) return@mapNotNull null
            val meta = runCatching {
                JSON.decodeFromString(
                    SkillMeta.serializer(),
                    File(folder, "meta.json").readText()
                )
            }.getOrNull() ?: SkillMeta(id = folder.name, name = folder.name)
            meta
        }.sortedBy { it.name.lowercase() }
        _state.value = metas
    }

    fun get(id: String): SkillMeta? = _state.value.firstOrNull { it.id == id }

    fun instructions(id: String): String? {
        val f = File(dir, "$id/SKILL.md")
        return if (f.exists()) f.readText() else null
    }

    fun upsert(meta: SkillMeta, markdown: String) {
        val id = meta.id.ifBlank { genId("skill") }.sanitizeFileName().replace(' ', '_')
        val folder = File(dir, id)
        folder.mkdirs()
        File(folder, "SKILL.md").writeText(markdown)
        File(folder, "meta.json").writeText(
            JSON.encodeToString(SkillMeta.serializer(), meta.copy(id = id))
        )
        refresh()
    }

    fun setEnabled(id: String, enabled: Boolean) {
        get(id)?.let { upsert(it.copy(enabled = enabled), instructions(id) ?: "") }
    }

    fun markUsed(ids: List<String>) {
        var changed = false
        _state.value.forEach { m ->
            if (m.id in ids) {
                File(dir, "${m.id}/meta.json").writeText(
                    JSON.encodeToString(SkillMeta.serializer(), m.copy(uses = m.uses + 1))
                )
                changed = true
            }
        }
        if (changed) refresh()
    }

    fun delete(id: String) {
        File(dir, id).deleteRecursively()
        refresh()
    }
}

// ============================================================
// MCP servers
// ============================================================

@Serializable
data class McpServerConfig(
    val id: String,
    var name: String = "MCP server",
    var url: String = "",
    var bearerToken: String = "",
    var enabled: Boolean = true
)

class McpStore(private val file: File) {
    private val _state = MutableStateFlow<List<McpServerConfig>>(emptyList())
    val state: StateFlow<List<McpServerConfig>> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(ListSerializer(McpServerConfig.serializer()), file.readText())
        }.getOrDefault(emptyList())
    }

    fun upsert(s: McpServerConfig) {
        val list = _state.value.toMutableList()
        val idx = list.indexOfFirst { it.id == s.id }
        if (idx >= 0) list[idx] = s else list.add(s)
        _state.value = list
        save()
    }

    fun delete(id: String) {
        _state.value = _state.value.filter { it.id != id }
        save()
    }

    private fun save() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(ListSerializer(McpServerConfig.serializer()), _state.value))
        }
    }
}

// ============================================================
// Telegram gateway
// ============================================================

@Serializable
data class TelegramConfig(
    var botToken: String = "",
    var enabled: Boolean = false,
    var pairingCode: String = "",
    var allowedChatIds: List<String> = emptyList(),
    var chatToConv: Map<String, String> = emptyMap(),
    var autoApproveRemote: Boolean = false,
    var lastUpdateId: Long = 0L
)

class TelegramStore(private val file: File) {
    private val _state = MutableStateFlow(TelegramConfig())
    val state: StateFlow<TelegramConfig> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(TelegramConfig.serializer(), file.readText())
        }.getOrDefault(TelegramConfig().also { it.pairingCode = genPairing() })
        if (_state.value.pairingCode.isBlank()) {
            update { it.pairingCode = genPairing() }
        }
    }

    fun update(block: (TelegramConfig) -> Unit) {
        val c = _state.value.copy()
        block(c)
        _state.value = c
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(TelegramConfig.serializer(), c))
        }
    }

    private fun genPairing(): String =
        List(6) { "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".random() }.joinToString("")
}

// ============================================================
// Scheduled missions (the cron engine store)
// ============================================================

@Serializable
data class ScheduledTask(
    val id: String,
    var title: String = "Scheduled mission",
    var prompt: String = "",
    /** "HH:MM" daily time (used when everyHours == 0) */
    var dailyAt: String = "08:00",
    /** >0 → run every N hours instead of daily */
    var everyHours: Int = 0,
    /** v2.21 — >0 → run every N MINUTES (15..1380); takes precedence over everyHours (watchtowers, pipelines) */
    var everyMinutes: Int = 0,
    var enabled: Boolean = true,
    var lastRunAt: Long = 0L,
    /** v2.20 (OpenClaw heartbeat): "HH:MM-HH:MM" window when this task may run (overnight OK). null = always. */
    var activeHours: String? = null
)

class ScheduledStore(private val file: File) {
    private val _state = MutableStateFlow<List<ScheduledTask>>(emptyList())
    val state: StateFlow<List<ScheduledTask>> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(ListSerializer(ScheduledTask.serializer()), file.readText())
        }.getOrDefault(emptyList())
    }

    fun upsert(t: ScheduledTask) {
        val list = _state.value.toMutableList()
        val i = list.indexOfFirst { it.id == t.id }
        if (i >= 0) list[i] = t else list.add(t)
        _state.value = list
        persist()
    }

    fun delete(id: String) {
        _state.value = _state.value.filter { it.id != id }
        persist()
    }

    fun markRan(id: String) {
        val list = _state.value.map { if (it.id == id) it.copy(lastRunAt = now()) else it }
        _state.value = list
        persist()
    }

    private fun persist() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(ListSerializer(ScheduledTask.serializer()), _state.value))
        }
    }
}
