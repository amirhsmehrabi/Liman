package com.liman.agent.llm

import com.liman.agent.data.ProviderConfig
import com.liman.agent.data.ProviderKind
import com.liman.agent.data.Stores
import com.liman.agent.util.genId
import com.liman.agent.util.now
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.IOException

/**
 * 🔁 The self-updating FREE catalog (v2.11).
 *
 * Mission: free models that need NO API key must (a) work out of the box and
 * (b) keep themselves fresh — new free models appear in Liman automatically,
 * dead ones get flagged.
 *
 * Sources (both public, no key):
 *  • https://opencode.ai/zen/v1/models — the live truth for the anonymous
 *    OpenCode Zen free pool ("-free" models, the Muse family). This is the
 *    same channel 9Router syncs from.
 *  • https://models.dev/api.json — the community catalog 9Router syncs its
 *    whole model list from (213 providers, refreshed continuously). Used
 *    here for free-model INTEL (what's free where) and to spot brand-new
 *    anonymous free pools as they appear.
 *
 * What a sync does:
 *  1. pulls the live OpenCode free list and writes it into the OpenCode Free
 *     provider's freeModels → the model picker, the mini-router "free" route
 *     and the combo free-pool all pick the new models up instantly.
 *  2. counts free models across the models.dev catalog and files anything
 *     newsworthy into the Free Radar.
 *  3. health-probes the default free model with one tiny request so the UI
 *     can show a live ✓/✗ status.
 *
 * Fair-use note: the anonymous pool is shared with everyone on the internet;
 * it is rate-limited and can be busy. Liman retries with backoff and reports
 * honestly instead of pretending it's unlimited.
 */
object FreeCatalog {

    const val MODELS_DEV_URL = "https://models.dev/api.json"
    const val DEFAULT_FREE_MODEL = "muse-spark-1.3-contributor-free"

    /** models that should always be offered even before the first sync */
    val SEED_FREE_MODELS = listOf(
        "muse-spark-1.3-contributor-free",
        "muse-spark-1.2-contributor-free"
    )

    data class SyncReport(
        val freeModels: List<String>,
        val newOnes: List<String>,
        val channelAlive: Boolean?,
        val catalogProviders: Int,
        val catalogFreeModels: Int,
        val error: String?
    )

    // ---------------- public API ----------------

    /** Makes sure the OpenCode Free provider exists (once) — zero setup. */
    fun ensureProvider(stores: Stores): ProviderConfig {
        val existing = stores.providers.state.value.firstOrNull { it.kind == ProviderKind.OPENCODE_FREE }
        if (existing != null) return existing
        val cfg = ProviderConfig(
            id = genId("prov"),
            name = "OpenCode Free (no key)",
            kind = ProviderKind.OPENCODE_FREE,
            baseUrl = OpenCodeFreeProvider.BASE,
            apiKey = "",
            model = DEFAULT_FREE_MODEL,
            enabled = true,
            presetId = "opencode-free",
            freeModels = SEED_FREE_MODELS,
            useFreePool = true
        )
        stores.providers.upsert(cfg)
        return cfg
    }

    /** One full sync. Safe to call any time; returns what changed. */
    suspend fun sync(stores: Stores, probe: Boolean = true, onProgress: (String) -> Unit = {}): SyncReport =
        withContext(Dispatchers.IO) {
            var freeModels = emptyList<String>()
            var newOnes = emptyList<String>()
            var alive: Boolean? = null
            var catProviders = 0
            var catFree = 0
            var error: String? = null

            // 1) live OpenCode Zen free pool
            onProgress("Checking OpenCode's live free models…")
            runCatching { OpenCodeFreeProvider.fetchFreeModels() }.onSuccess { live ->
                freeModels = live
                val cfg = ensureProvider(stores)
                val old = cfg.freeModels.toSet()
                newOnes = live.filter { it !in old }
                if (live.isNotEmpty()) {
                    cfg.freeModels = live
                    // if the current default model vanished, move to the first live one
                    if (cfg.model !in live && live.isNotEmpty()) cfg.model = live.first()
                    stores.providers.upsert(cfg)
                }
            }.onFailure { e ->
                error = "opencode: ${e.message?.take(120)}"
            }

            // 2) models.dev catalog intel (the catalog 9Router syncs from)
            onProgress("Scanning the models.dev catalog…")
            runCatching { scanModelsDev() }.onSuccess { (p, f) ->
                catProviders = p
                catFree = f
            }

            // 3) health probe of the default free model (one tiny request)
            if (probe && freeModels.isNotEmpty()) {
                onProgress("Health-checking the free channel…")
                alive = probeChannel(stores)
            }

            // (new models land straight in the picker — the radar screen is gone)

            stores.settings.update { it.freeCatalogSyncAt = now() }
            SyncReport(freeModels, newOnes, alive, catProviders, catFree, error)
        }

    /** Runs at most once every 24h (called on app open, next to the Radar). */
    suspend fun dailySync(stores: Stores) {
        val s = stores.settings.state.value
        if (now() - s.freeCatalogSyncAt < 24L * 3600 * 1000) return
        ensureProvider(stores)
        runCatching { sync(stores, probe = true) }
    }

    /**
     * Sends one tiny request through the anonymous channel so the UI can
     * show a live ✓/✗ instead of guessing.
     */
    suspend fun probeChannel(stores: Stores): Boolean = withContext(Dispatchers.IO) {
        val cfg = ensureProvider(stores)
        val model = cfg.freeModels.firstOrNull { it == cfg.model } ?: cfg.model
        val runner = OpenCodeFreeProvider(cfg.copy(model = model))
        runCatching {
            val r = runner.complete(
                LlmRequest(
                    messages = listOf(LlmMessage(Role.USER, listOf(LPart.Text("ping")))),
                    tools = emptyList(),
                    gen = GenSettings(maxTokens = 640, stream = false)
                ),
                null
            )
            r.text.isNotBlank() || r.toolCalls.isNotEmpty()
        }.getOrDefault(false)
    }

    // ---------------- models.dev ----------------

    /**
     * Counts providers + currently-free models in the community catalog.
     * Free = zero input AND zero output cost. (Most still need a key — this
     * is intel for the Radar, not a promise of no-key access.)
     */
    private fun scanModelsDev(): Pair<Int, Int> {
        val req = Request.Builder().url(MODELS_DEV_URL)
            .header("User-Agent", "LimanAgent/2.11 (free catalog sync)")
            .get()
            .build()
        Http.toolClient(45).newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val raw = resp.body?.string() ?: throw IOException("empty")
            val obj = raw.toJsonObject() ?: throw IOException("bad JSON")
            var providers = 0
            var free = 0
            for ((_, pv) in obj) {
                val p = pv as? kotlinx.serialization.json.JsonObject ?: continue
                providers++
                val models = p["models"] as? kotlinx.serialization.json.JsonObject ?: continue
                for ((_, mv) in models) {
                    val m = mv as? kotlinx.serialization.json.JsonObject ?: continue
                    val cost = m["cost"] as? kotlinx.serialization.json.JsonObject ?: continue
                    val cin = (cost["input"] as? kotlinx.serialization.json.JsonPrimitive)?.content?.toDoubleOrNull()
                    val cout = (cost["output"] as? kotlinx.serialization.json.JsonPrimitive)?.content?.toDoubleOrNull()
                    if (cin == 0.0 && cout == 0.0) free++
                }
            }
            return providers to free
        }
    }
}
