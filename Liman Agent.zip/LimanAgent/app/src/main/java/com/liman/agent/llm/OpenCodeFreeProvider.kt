package com.liman.agent.llm

import com.liman.agent.data.ProviderConfig
import com.liman.agent.util.arr
import com.liman.agent.util.genId
import com.liman.agent.util.int
import com.liman.agent.util.obj
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.SecureRandom

/**
 * OpenCode Zen FREE tier — anonymous, no API key, no account, no setup.
 *
 * Protocol reverse-verified against opencode.ai (Sept 2026, same channel the
 * 9Router "OpenCode Free" provider and the OpenCode desktop client use):
 *
 *   POST https://opencode.ai/zen/v1/responses
 *     Authorization:      Bearer public          ← literal "public"
 *     User-Agent:         opencode
 *     x-opencode-client:  desktop
 *     x-opencode-session: ses_<32 hex>           ← sticky per install
 *     x-opencode-request: msg_<32 hex>           ← fresh per request
 *     x-opencode-project: global
 *     Accept:             text/event-stream (stream) or application/json
 *
 * Body speaks the OpenAI **Responses API** format (input items + flat
 * function tools). Models whose id ends in "-free" (currently the
 * muse-spark-*-contributor-free family) are the anonymous free pool; the
 * live list is https://opencode.ai/zen/v1/models (no key needed either).
 *
 * The free pool is shared with everyone, so requests occasionally come back
 * with rate_limit_exceeded — that is retried with backoff automatically.
 *
 * NOTE: temperature is intentionally never sent (Liman standing rule).
 */
class OpenCodeFreeProvider(private val config: ProviderConfig) : ProviderRunner {

    companion object {
        const val BASE = "https://opencode.ai"
        const val RESPONSES_URL = "$BASE/zen/v1/responses"
        const val MODELS_URL = "$BASE/zen/v1/models"

        /** 9Router's exclusion list — known-broken free ids upstream. */
        private val KNOWN_BROKEN = setOf("deepseek-v4-flash-free")

        /** The free-pool filter: exactly the rule 9Router uses. */
        fun isFreePoolModel(id: String): Boolean =
            (id.endsWith("-free") || id == "big-pickle") && id !in KNOWN_BROKEN

        // sticky anonymous session — same shape the desktop client uses
        @Volatile
        private var session: String? = null

        fun sessionId(): String {
            session?.let { return it }
            synchronized(this) {
                session?.let { return it }
                val rnd = ByteArray(16)
                SecureRandom().nextBytes(rnd)
                val hex = buildString { rnd.forEach { append("%02x".format(it)) } }
                val s = "ses_$hex"
                session = s
                return s
            }
        }

        fun newRequestId(): String {
            val rnd = ByteArray(16)
            SecureRandom().nextBytes(rnd)
            val hex = buildString { rnd.forEach { append("%02x".format(it)) } }
            return "msg_$hex"
        }

        /**
         * Live anonymous model list (no key). Returns only the free-pool ids
         * so pickers and the self-updating catalog show what actually works.
         */
        fun fetchFreeModels(): List<String> {
            val req = Request.Builder().url(MODELS_URL)
                .header("x-opencode-client", "desktop")
                .header("User-Agent", "opencode")
                .get()
                .build()
            Http.toolClient(30).newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw java.io.IOException("HTTP ${resp.code}")
                val obj = resp.body?.string()?.toJsonObject() ?: throw java.io.IOException("bad JSON")
                val data = obj.arr("data") ?: return emptyList()
                return data.mapNotNull { d ->
                    (d as? JsonObject)?.str("id")
                }.filter { isFreePoolModel(it) }.distinct().sorted()
            }
        }
    }

    override suspend fun complete(
        req: LlmRequest,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?
    ): LlmResult {
        var attempt = 0
        while (true) {
            val streamed = booleanArrayOf(false)
            try {
                return withContext(Dispatchers.IO) { executeOnce(req, onDelta, streamed) }
            } catch (e: Throwable) {
                val msg = (e.message ?: "").lowercase()
                val rateLimited = "rate_limit" in msg || "rate busy" in msg ||
                    (e is HttpProvException && e.code == 429) ||
                    // stream-mode errors come as a plain JSON body (no SSE lines),
                    // which surfaces as "no content" — that's usually the busy pool
                    (e is EmptyResponseException && attempt < 3)
                // only retry when nothing was streamed yet and it looks transient
                if (rateLimited && !streamed[0] && attempt < 3) {
                    val backoffMs = 1200L * 3L * attempt // 0s, 3.6s, 10.8s
                    if (backoffMs > 0) kotlinx.coroutines.delay(backoffMs)
                    attempt++
                    continue
                }
                if (streamed[0] && rateLimited) {
                    throw HttpProvException(429, "OpenCode free pool is busy (rate limit) — ask again in a moment.")
                }
                throw e
            }
        }
    }

    private suspend fun executeOnce(
        req: LlmRequest,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?,
        streamedFlag: BooleanArray
    ): LlmResult {
        val body = buildRequest(req)
        val call: Call = Http.client.newCall(
            Request.Builder()
                .url(RESPONSES_URL)
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer public")
                .header("User-Agent", "opencode")
                .header("x-opencode-client", "desktop")
                .header("x-opencode-session", sessionId())
                .header("x-opencode-request", newRequestId())
                .header("x-opencode-project", "global")
                .header("Accept", if (req.gen.stream) "text/event-stream" else "*/*")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()
        )
        val response = Http.await(call)
        return Http.withCancelClose(response) {
            if (!response.isSuccessful) {
                val errText = response.body?.string()?.take(1200) ?: ""
                throw mapHttpError(response.code, errText)
            }
            parseResponse(response, req.gen.stream, onDelta, streamedFlag)
        }
    }

    private fun mapHttpError(code: Int, body: String): Exception {
        val m = body.lowercase()
        return when {
            "rate_limit" in m -> HttpProvException(429, body)
            "not supported" in m || "unsupported model" in m ->
                InvalidModelException("OpenCode free: $body")
            else -> HttpProvException(code, body)
        }
    }

    // ---------------- request building (Responses API) ----------------

    private fun buildRequest(req: LlmRequest): JsonObject = buildJsonObject {
        put("model", config.model.ifBlank { "muse-spark-1.3-contributor-free" })
        put("stream", req.gen.stream)
        put("input", JsonArray(toInputItems(req.messages)))
        if (req.tools.isNotEmpty()) {
            put("tools", JsonArray(req.tools.map { t ->
                buildJsonObject {
                    put("type", "function")
                    put("name", t.name)
                    put("description", t.description)
                    put("parameters", safeSchema(t.parametersJson))
                }
            }))
            put("tool_choice", "auto")
        }
        put("max_output_tokens", req.gen.maxTokens)
        // temperature intentionally never sent — standing Liman rule
    }

    private fun toInputItems(messages: List<LlmMessage>): List<JsonObject> {
        val out = ArrayList<JsonObject>()
        for (m in messages) {
            when (m.role) {
                Role.SYSTEM -> {
                    val text = m.textOnly()
                    if (text.isNotBlank()) out.add(buildJsonObject {
                        put("role", "system")
                        put("content", JsonArray(listOf(buildJsonObject {
                            put("type", "input_text")
                            put("text", text)
                        })))
                    })
                }

                Role.USER -> {
                    val texts = m.parts.filterIsInstance<LPart.Text>().joinToString("") { it.text }
                    val media = m.parts.filterIsInstance<LPart.Media>()
                    val content = ArrayList<JsonObject>()
                    if (texts.isNotBlank()) content.add(buildJsonObject {
                        put("type", "input_text")
                        put("text", texts)
                    })
                    media.forEach { p ->
                        if (p.mime.startsWith("image/")) {
                            content.add(buildJsonObject {
                                put("type", "input_image")
                                put("image_url", "data:${p.mime};base64,${p.b64}")
                            })
                        }
                    }
                    if (content.isNotEmpty()) out.add(buildJsonObject {
                        put("role", "user")
                        put("content", JsonArray(content))
                    })
                }

                Role.ASSISTANT -> {
                    val text = m.parts.filterIsInstance<LPart.Text>().joinToString("") { it.text }
                    val calls = m.parts.filterIsInstance<LPart.ToolCallPart>()
                    if (text.isNotBlank()) out.add(buildJsonObject {
                        put("role", "assistant")
                        put("content", JsonArray(listOf(buildJsonObject {
                            put("type", "output_text")
                            put("text", text)
                        })))
                    })
                    calls.forEach { c ->
                        out.add(buildJsonObject {
                            put("type", "function_call")
                            put("call_id", c.id)
                            put("name", c.name)
                            put("arguments", c.argsJson.ifBlank { "{}" })
                        })
                    }
                }

                Role.TOOL -> {
                    m.parts.filterIsInstance<LPart.ToolResultPart>().forEach { r ->
                        out.add(buildJsonObject {
                            put("type", "function_call_output")
                            put("call_id", r.toolCallId)
                            put("output", r.text)
                        })
                    }
                }
            }
        }
        return out
    }

    // ---------------- response parsing ----------------

    private class CallBuilder {
        var callId: String = ""
        var name: String = ""
        val args = StringBuilder()
    }

    private suspend fun parseResponse(
        response: okhttp3.Response,
        stream: Boolean,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?,
        streamedFlag: BooleanArray
    ): LlmResult {
        val text = StringBuilder()
        val calls = LinkedHashMap<String, CallBuilder>()
        var usage: Usage? = null

        fun errFrom(obj: JsonObject): Exception {
            val e = obj.obj("error")
            val msg = e?.str("message") ?: obj.str("message") ?: obj.toString().take(300)
            val code = e?.str("code") ?: ""
            val m = msg.lowercase()
            return when {
                "rate_limit" in m || "rate_limit" in code -> HttpProvException(429, msg)
                "not supported" in m || "unsupported model" in m -> InvalidModelException("OpenCode free: $msg")
                else -> HttpProvException(502, msg)
            }
        }

        fun consumeEvent(obj: JsonObject): Boolean {
            when (obj.str("type") ?: "") {
                "response.output_text.delta" -> {
                    (obj.str("delta") ?: "").let { text.append(it) }
                    return true
                }
                // visible thinking: reasoning summaries stream as deltas too
                "response.reasoning_text.delta", "response.reasoning_summary_text.delta" -> {
                    (obj.str("delta") ?: "").let { text.append(it) }
                    return true
                }
                "response.function_call_arguments.delta" -> {
                    val key = obj.str("item_id") ?: obj.int("output_index")?.toString() ?: "c${calls.size}"
                    val b = calls.getOrPut(key) { CallBuilder() }
                    b.args.append(obj.str("delta") ?: "")
                    return true
                }
                "response.output_item.added" -> {
                    val item = obj.obj("item")
                    if (item?.str("type") == "function_call") {
                        val key = item.str("id") ?: "c${calls.size}"
                        val b = calls.getOrPut(key) { CallBuilder() }
                        item.str("call_id")?.let { b.callId = it }
                        item.str("name")?.let { b.name = it }
                    }
                    return true
                }
                "response.output_item.done" -> {
                    val item = obj.obj("item") ?: return true
                    if (item.str("type") == "function_call") {
                        val key = item.str("id") ?: "c${calls.size}"
                        val b = calls.getOrPut(key) { CallBuilder() }
                        item.str("call_id")?.let { b.callId = it }
                        item.str("name")?.let { b.name = it }
                        item.str("arguments")?.let {
                            b.args.clear()
                            b.args.append(it)
                        }
                    }
                    return true
                }
                "response.completed" -> {
                    val r = obj.obj("response")
                    r?.obj("usage")?.let { u ->
                        usage = Usage(u.int("input_tokens") ?: 0, u.int("output_tokens") ?: 0)
                    }
                    return false
                }
                "response.failed" -> throw errFrom(obj)
                else -> return true // ignore the rest
            }
        }

        if (stream) {
            Http.readLines(response) { line ->
                if (!line.startsWith("data:")) return@readLines
                val data = line.removePrefix("data:").trim()
                if (data.isEmpty() || data == "[DONE]") return@readLines
                val obj = data.toJsonObject() ?: return@readLines
                // NOTE: successful payloads carry "error": null — only a real
                // error OBJECT (or a type:"error" event) is a failure
                if (obj.obj("error") != null) throw errFrom(obj)
                if (obj.str("type") == "error") throw errFrom(obj)
                val keepGoing = consumeEvent(obj)
                streamedFlag[0] = true
                onDelta?.invoke("opencode-free", text.toString())
                if (!keepGoing) return@readLines
            }
        } else {
            val raw = response.body?.string() ?: ""
            val obj = raw.toJsonObject() ?: throw EmptyResponseException()
            if (obj.obj("error") != null) throw errFrom(obj)
            if (obj.str("type") == "error") throw errFrom(obj)
            val output = obj.arr("output") ?: emptyList()
            for (el in output) {
                val item = el as? JsonObject ?: continue
                when (item.str("type")) {
                    "message" -> {
                        item.arr("content")?.forEach { c ->
                            val co = c as? JsonObject ?: return@forEach
                            if (co.str("type") == "output_text" || co.containsKey("text")) {
                                (co.str("text") ?: "").let { if (it.isNotEmpty()) text.append(it) }
                            }
                        }
                    }
                    "function_call" -> {
                        val b = CallBuilder()
                        b.callId = item.str("call_id") ?: ""
                        b.name = item.str("name") ?: ""
                        b.args.append(item.str("arguments") ?: "")
                        calls["done_${calls.size}"] = b
                    }
                    "reasoning" -> { /* encrypted content — nothing to show */ }
                }
            }
            obj.obj("usage")?.let { u ->
                usage = Usage(u.int("input_tokens") ?: 0, u.int("output_tokens") ?: 0)
            }
        }

        val toolCalls = calls.values.filter { it.name.isNotBlank() }.map { b ->
            ToolCallData(
                id = b.callId.ifBlank { genId("ocf") },
                name = b.name,
                argsJson = b.args.toString().ifBlank { "{}" }
            )
        }
        if (text.isBlank() && toolCalls.isEmpty()) {
            throw EmptyResponseException("OpenCode free returned no content (pool may be busy — try again)")
        }
        return LlmResult(
            text = text.toString(),
            toolCalls = toolCalls,
            finishReason = if (toolCalls.isNotEmpty()) "tool_calls" else "stop",
            usage = usage,
            providerName = config.name.ifBlank { "OpenCode Free" },
            modelName = config.model
        )
    }
}
