package com.liman.agent.ui

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * v2.23.0 — Quick Settings tile: one swipe down → tap Liman → the agent
 * is in front of you. No configuration, no state — pure reachability.
 */
class LimanTileService : TileService() {
    override fun onStartListening() {
        qsTile?.let {
            it.state = Tile.STATE_ACTIVE
            it.subtitle = "Super agent"
            it.updateTile()
        }
    }

    override fun onClick() {
        super.onClick()
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivityAndCollapse(intent)
        }
    }
}
