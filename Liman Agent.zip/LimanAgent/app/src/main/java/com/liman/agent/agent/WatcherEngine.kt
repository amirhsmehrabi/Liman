package com.liman.agent.agent

import com.liman.agent.data.Watcher
import com.liman.agent.llm.Http
import com.liman.agent.util.ellipsize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request

/**
 * v2.23.0 — WEB WATCHERS: the agent that waits for you.
 *
 * Price drops, exam results, visa slots, releases, stock — a watcher
 * fetches a URL on a schedule, extracts the interesting part (plain text
 * or regex with an optional capture group), and reports only CHANGES.
 * Pure logic here is unit-tested; fetching is one okhttp call.
 */
object WatcherEngine {

    data class CheckResult(val changed: Boolean, val firstCheck: Boolean, val extraction: String, val note: String)

    // ---------------- pure extraction + diff (tested) ----------------

    /** Extract the watched value from a fetched body. null = extraction failed. */
    fun extract(body: String, mode: String, pattern: String): String? {
        return when (mode) {
            "regex" -> {
                if (pattern.isBlank()) return null
                val re = runCatching { Regex(pattern, RegexOption.DOT_MATCHES_ALL) }.getOrNull() ?: return null
                val m = re.find(body) ?: return null
                (if (m.groupValues.size > 1) m.groupValues[1] else m.value)
                    .replace(Regex("\\s+"), " ").trim().ifEmpty { null }
            }
            else -> {
            // "text": the first meaningful block of the page, whitespace-normalized
            val cleaned = body.replace(Regex("(?s)<script.*?</script>"), " ")
                .replace(Regex("(?s)<style.*?</style>"), " ")
                .replace(Regex("<[^>]+>"), " ")
                .replace(Regex("&[a-z#0-9]+;"), " ")
            val norm = cleaned.replace(Regex("\\s+"), " ").trim()
            if (norm.isEmpty()) null else norm.take(400)
            }
        }
    }

    fun isChanged(old: String, new: String): Boolean = old.isNotBlank() && old != new

    fun isDue(w: Watcher, now: Long): Boolean =
        w.enabled && w.everyMinutes >= 5 && (now - w.lastCheckedAt) >= w.everyMinutes * 60_000L

    fun formatResult(w: Watcher, r: CheckResult): String = buildString {
        appendLine("Watcher '${w.name}' (${w.url}):")
        when {
            r.firstCheck -> appendLine("BASELINE SET — first check. Value: ${r.extraction.ellipsize(300)}")
            r.changed -> appendLine("🔔 CHANGED! Old: ${w.lastValue.ellipsize(200)} → New: ${r.extraction.ellipsize(300)}")
            else -> appendLine("unchanged (${r.extraction.ellipsize(120)})")
        }
        if (r.note.isNotBlank()) appendLine("note: ${r.note}")
    }

    // ---------------- network ----------------

    private fun fetch(url: String): Pair<Int, String> {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Android) LimanAgent/2.23")
            .build()
        Http.toolClient(30).newCall(req).execute().use { resp ->
            val body = runCatching {
                val sb = StringBuilder()
                resp.body?.byteStream()?.let { ins ->
                    val buf = ByteArray(16_384)
                    var total = 0
                    while (total < 1_000_000) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        sb.append(String(buf, 0, n, Charsets.UTF_8))
                    }
                }
                sb.toString()
            }.getOrDefault("")
            return resp.code to body
        }
    }

    /** Check one watcher (network). The caller persists the new value. */
    suspend fun check(w: Watcher): CheckResult = withContext(Dispatchers.IO) {
        val (code, body) = runCatching { fetch(w.url) }
            .getOrElse { return@withContext CheckResult(false, false, "", "fetch failed: ${it.message}") }
        if (code != 200) return@withContext CheckResult(false, false, "", "HTTP $code — not checked")
        val value = extract(body, w.extract, w.pattern)
            ?: return@withContext CheckResult(false, false, "", "extraction failed (${w.extract}${if (w.pattern.isNotBlank()) " /${w.pattern}/" else ""}) — page may have changed structure")
        val first = w.lastValue.isBlank()
        val changed = isChanged(w.lastValue, value)
        CheckResult(changed, first, value, "")
    }
}
