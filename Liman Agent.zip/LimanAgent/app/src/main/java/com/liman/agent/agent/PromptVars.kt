package com.liman.agent.agent

import android.os.Build
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v2.27.0 — PROMPT VARIABLES (knotwork logic).
 *
 * knotwork renders pipeline prompt variables ($DATE, $TIME, $TOOLS, $MODEL,
 * $MEMORY_SUMMARY, $LANG, $LOCATION, $USER, $DEVICE) fresh on EVERY run so
 * scheduled/automated prompts never go stale ("good morning" at 2am, Monday's
 * date on Friday…). Liman applies the same to scheduled tasks, triggers and
 * anywhere a stored prompt is replayed.
 *
 * Pure function — unit-tested (the device-dependent bits are injected).
 */
object PromptVars {

    private fun d(name: String) = "$" + name // literal $NAME — never a Kotlin template

    val NAMES = listOf("DATE", "TIME", "WEEKDAY", "LANG", "DEVICE", "MODEL", "BATTERY", "USER")
        .map { d(it) }

    /**
     * @param prompt the stored prompt with optional variables
     * @param model the model id that will run it ("" → unknown)
     * @param batteryPct 0..100 or null when unknown
     * @param language the effective language ("en", "fa", …)
     * @param userName the user's profile name ("" → "the user")
     */
    fun expand(
        prompt: String,
        model: String = "",
        batteryPct: Int? = null,
        language: String = Locale.getDefault().language,
        userName: String = "",
        nowMs: Long = System.currentTimeMillis()
    ): String {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = nowMs }
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(nowMs))
        val time = SimpleDateFormat("HH:mm", Locale.US).format(Date(nowMs))
        val weekday = cal.getDisplayName(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.LONG, Locale.US) ?: ""
        // Build fields are null under JVM unit tests — stay null-safe
        val manufacturer = (Build.MANUFACTURER ?: "").take(12).ifBlank { "Android" }
        val device = (manufacturer + " " + (Build.MODEL ?: "").take(16)).trim()
        return prompt
            .replace(d("DATE"), date)
            .replace(d("TIME"), time)
            .replace(d("WEEKDAY"), weekday)
            .replace(d("LANG"), language.ifBlank { "en" })
            .replace(d("DEVICE"), device)
            .replace(d("MODEL"), model.ifBlank { "(current combo)" })
            .replace(d("BATTERY"), batteryPct?.let { "$it%" } ?: "unknown")
            .replace(d("USER"), userName.ifBlank { "the user" })
    }
}
