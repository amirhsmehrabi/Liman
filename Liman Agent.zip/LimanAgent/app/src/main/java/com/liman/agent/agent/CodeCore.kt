package com.liman.agent.agent

import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * v2.32.0 — THE CODING AGENT CORE.
 *
 * Ports the abstractions that make the 2026 terminal agents strong:
 *  - AIDER'S REPO MAP: a compact, ranked map of a whole codebase (symbols +
 *    reference counts) so the model navigates big projects without reading
 *    every file — "the single biggest reason it stays cheap on large repos".
 *  - RIPGREP-LITE: regex content search with context lines.
 *  - GIT-NATIVE SAFETY: snapshot / diff / restore (a mini-VCS in pure Kotlin —
 *    every risky multi-file edit is reversible).
 *  - SURGICAL PATCHES: multi-file find/replace batches with atomic reporting.
 *  - WEB SESSIONS: a persistent cookie jar for http_request — login once,
 *    keep acting (the API-first route for site tasks).
 *
 * Pure Kotlin — unit-tested (CodeCoreTest).
 */
object CodeCore {

    // ============================================================
    // 1. RIPGREP-LITE — search_code
    // ============================================================

    data class SearchHit(val file: String, val line: Int, val text: String, val context: List<String>)

    private val SKIP_DIRS = setOf(
        "node_modules", ".git", "build", "dist", ".gradle", ".liman-snapshots",
        ".liman-overflow", "__pycache__", ".idea", "out", "target", "venv", ".venv"
    )
    private val TEXT_EXT = setOf(
        "kt", "java", "js", "mjs", "cjs", "ts", "tsx", "jsx", "py", "rb", "go", "rs", "c", "h", "cpp",
        "hpp", "cs", "swift", "php", "sh", "bash", "zsh", "html", "htm", "css", "scss", "xml", "json",
        "yml", "yaml", "toml", "md", "txt", "csv", "sql", "gradle", "kts", "properties", "env", "svg"
    )

    fun isSearchable(f: File): Boolean {
        if (f.extension.lowercase() in TEXT_EXT) return true
        if (f.extension.isBlank()) {
            // extensionless: shebang or dotfiles like Dockerfile
            return f.name == "Dockerfile" || f.name == "Makefile" || f.name.startsWith(".env")
        }
        return false
    }

    fun search(
        root: File, pattern: String, glob: String? = null,
        contextLines: Int = 1, maxHits: Int = 60
    ): List<SearchHit> {
        val regex = runCatching { Regex(pattern) }.getOrNull() ?: return emptyList()
        val globRe = glob?.let { g ->
            runCatching {
                Regex("^" + g.map { c ->
                    when (c) {
                        '*' -> ".*"
                        '?' -> "."
                        else -> Regex.escape(c.toString())
                    }
                }.joinToString("") + "$")
            }.getOrNull()
        }
        val hits = ArrayList<SearchHit>()
        walk(root) { f ->
            if (globRe != null && !globRe.matches(f.name)) return@walk
            val lines = runCatching { f.readText().lines() }.getOrNull() ?: return@walk
            lines.forEachIndexed { i, line ->
                if (regex.containsMatchIn(line) && hits.size < maxHits) {
                    val ctx = if (contextLines > 0)
                        lines.subList((i - contextLines).coerceAtLeast(0), (i + contextLines + 1).coerceAtMost(lines.size))
                    else emptyList()
                    hits.add(SearchHit(f.relativeToOrNull(root)?.toString()?.replace('\\', '/') ?: f.name, i + 1, line.trimEnd(), ctx))
                }
            }
        }
        return hits
    }

    private fun walk(dir: File, visit: (File) -> Unit) {
        dir.listFiles()?.sortedBy { it.name }?.forEach { f ->
            when {
                f.isDirectory -> if (f.name !in SKIP_DIRS && !f.name.startsWith(".")) walk(f, visit)
                f.isFile && f.length() < 2_000_000 && isSearchable(f) -> visit(f)
            }
        }
    }

    fun searchReport(root: File, hits: List<SearchHit>, pattern: String): String = buildString {
        if (hits.isEmpty()) {
            appendLine("No matches for /$pattern/ under ${root.name}.")
            append("Widen the pattern, drop the glob, or search the parent folder.")
        } else {
            appendLine("${hits.size} match(es) for /$pattern/ (cap 60):")
            hits.take(40).forEach { h ->
                appendLine("${h.file}:${h.line}: ${h.text.take(160)}")
            }
            if (hits.size > 40) append("… ${hits.size - 40} more (refine the pattern).")
        }
    }.trim()

    // ============================================================
    // 2. AIDER-STYLE REPO MAP — symbol index + reference ranking
    // ============================================================

    data class Symbol(val kind: String, val name: String, val line: Int)
    data class FileMap(val path: String, val lang: String, val symbols: List<Symbol>, val refs: Int, val loc: Int)

    private data class LangRules(
        val lang: String,
        val defs: List<Regex>,          // capture group 1 = name
        val imports: Regex
    )

    private val LANGS = listOf(
        LangRules("kotlin", listOf(
            Regex("""^\s*(?:public\s+|private\s+|internal\s+)?(?:open\s+|abstract\s+|sealed\s+|data\s+|enum\s+)*(?:class|interface|object)\s+([A-Za-z_]\w*)"""),
            Regex("""^\s*(?:suspend\s+)?fun\s+([A-Za-z_]\w*)""")
        ), Regex("""^\s*import\s+([\w.]+)""")),
        LangRules("java", listOf(
            Regex("""^\s*(?:public\s+|private\s+|protected\s+)?(?:final\s+|abstract\s+)*(?:class|interface|enum)\s+([A-Za-z_]\w*)"""),
            Regex("""^\s*(?:public|private|protected)\s+(?:static\s+)?[\w<>\[\],\s]+\s+([A-Za-z_]\w*)\s*\(""")
        ), Regex("""^\s*import\s+([\w.]+)""")),
        LangRules("js", listOf(
            Regex("""^\s*(?:export\s+)?(?:async\s+)?function\s*\*?\s*([A-Za-z_$][\w$]*)"""),
            Regex("""^\s*(?:export\s+)?(?:default\s+)?class\s+([A-Za-z_$][\w$]*)"""),
            Regex("""^\s*(?:export\s+)?const\s+([A-Za-z_$][\w$]*)\s*=\s*(?:\(|async|function)""")
        ), Regex("""^\s*import\s+.+?from\s+['"]([^'"]+)['"]""")),
        LangRules("ts", listOf(
            Regex("""^\s*(?:export\s+)?(?:abstract\s+)?class\s+([A-Za-z_$][\w$]*)"""),
            Regex("""^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)"""),
            Regex("""^\s*(?:export\s+)?(?:interface|type|enum)\s+([A-Za-z_$][\w$]*)""")
        ), Regex("""^\s*import\s+.+?from\s+['"]([^'"]+)['"]""")),
        LangRules("python", listOf(
            Regex("""^\s*class\s+([A-Za-z_]\w*)"""),
            Regex("""^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)""")
        ), Regex("""^\s*(?:from\s+([\w.]+)\s+import|import\s+([\w.]+))""")),
        LangRules("html", listOf(Regex("""<(?:script|style)\b""")), Regex("""(?:src|href)\s*=\s*["']([^"']+)["']""")),
        LangRules("css", listOf(Regex("""\.([A-Za-z_][\w-]*)\s*\{""")), Regex("""@import\s+["']([^"']+)["']"""))
    )

    private fun langFor(f: File): LangRules? {
        val ext = f.extension.lowercase()
        return when (ext) {
            "kt", "kts" -> LANGS[0]
            "java" -> LANGS[1]
            "js", "mjs", "cjs", "jsx" -> LANGS[2]
            "ts", "tsx" -> LANGS[3]
            "py" -> LANGS[4]
            "html", "htm" -> LANGS[5]
            "css", "scss" -> LANGS[6]
            else -> null
        }
    }

    /**
     * Builds the compact map: per file — language, LOC, definition symbols,
     * and a reference score (how often OTHER files import/mention it). Files
     * are ranked by references × recency so the model knows where to look
     * first. Output is a tree + symbol digest ≤ ~4 KB.
     */
    fun repoMap(root: File, maxFiles: Int = 200): String {
        val maps = ArrayList<FileMap>()
        val allNames = HashMap<String, Int>()   // symbol/keyword -> mentions across repo
        walk(root) { f ->
            val rules = langFor(f) ?: return@walk
            val text = runCatching { f.readText() }.getOrNull() ?: return@walk
            val lines = text.lines()
            val syms = ArrayList<Symbol>()
            val myImports = HashSet<String>()
            lines.forEachIndexed { i, line ->
                rules.defs.forEach { re ->
                    re.find(line)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }?.let {
                        syms.add(Symbol(defKind(re), it, i + 1)); allNames[it] = (allNames[it] ?: 0) + 1
                    }
                }
                rules.imports.find(line)?.groupValues?.drop(1)?.filter { it.isNotBlank() }?.forEach { myImports.add(it) }
            }
            val path = f.relativeToOrNull(root)?.toString()?.replace('\\', '/') ?: f.name
            maps.add(FileMap(path, rules.lang, syms, myImports.size, lines.size))
        }
        if (maps.isEmpty()) return "(no source files found under ${root.name})"
        // rank: files whose symbols are most referenced elsewhere + import hubs
        val ranked = maps.sortedByDescending { m ->
            m.symbols.sumOf { allNames[it.name] ?: 1 }.toLong() * 2 + m.refs
        }.take(maxFiles)
        return buildString {
            appendLine("REPO MAP — ${root.name} · ${maps.size} source file(s), top ${ranked.size} by importance:")
            appendLine("(navigate with read_file/search_code; the ranking tells you where the action is)")
            ranked.forEach { m ->
                appendLine("- ${m.path}  [${m.lang}, ${m.loc} loc, ${m.refs} imports]")
                m.symbols.take(12).forEach { s ->
                    appendLine("    ${s.kind} ${s.name} (L${s.line})")
                }
                if (m.symbols.size > 12) appendLine("    … +${m.symbols.size - 12} more symbols")
            }
        }.trim()
    }

    private fun defKind(re: Regex): String = when {
        re.pattern.contains("class") -> "class"
        re.pattern.contains("interface") -> "interface"
        re.pattern.contains("object") -> "object"
        re.pattern.contains("enum") -> "enum"
        re.pattern.contains("type") -> "type"
        re.pattern.contains("def") || re.pattern.contains("fun") || re.pattern.contains("function") -> "fn"
        else -> "sym"
    }

    // ============================================================
    // 3. MINI-VCS — snapshots (git-less undo for risky edits)
    // ============================================================

    object Snapshots {
        fun dir(root: File): File = File(root, ".liman-snapshots")

        fun create(root: File, label: String): Pair<String, Int> {
            val stamp = System.currentTimeMillis()
            val safe = label.replace(Regex("[^a-z0-9-]+", RegexOption.IGNORE_CASE), "-").take(24).trim('-')
            val name = "${stamp}-${safe.ifBlank { "snap" }}.zip"
            val out = dir(root).apply { mkdirs() }
            val target = File(out, name)
            var count = 0
            ZipOutputStream(FileOutputStream(target)).use { zip ->
                walkAll(root) { f ->
                    val rel = f.relativeToOrNull(root)?.toString()?.replace('\\', '/') ?: return@walkAll
                    if (rel.startsWith(".liman-snapshots")) return@walkAll
                    zip.putNextEntry(ZipEntry(rel))
                    FileInputStream(f).use { it.copyTo(zip) }
                    zip.closeEntry()
                    count++
                }
            }
            return name to count
        }

        fun list(root: File): List<String> =
            dir(root).listFiles { f -> f.extension == "zip" }?.sortedByDescending { it.name }?.map { it.name } ?: emptyList()

        /** diff = file-level changes between a snapshot and now. */
        fun diff(root: File, snapshot: String): String {
            val snapFiles = HashMap<String, Long>()
            ZipInputStream(FileInputStream(File(dir(root), snapshot))).use { z ->
                var e = z.nextEntry
                while (e != null) { snapFiles[e.name] = e.size; e = z.nextEntry }
            }
            val nowFiles = HashMap<String, Long>()
            walkAll(root) { f ->
                val rel = f.relativeToOrNull(root)?.toString()?.replace('\\', '/') ?: return@walkAll
                if (!rel.startsWith(".liman-snapshots")) nowFiles[rel] = f.length()
            }
            val added = nowFiles.keys - snapFiles.keys
            val removed = snapFiles.keys - nowFiles.keys
            val changed = nowFiles.filter { (k, v) -> snapFiles[k] != null && snapFiles[k] != v }.keys
            return buildString {
                appendLine("DIFF vs $snapshot: ${added.size} added · ${changed.size} changed · ${removed.size} removed")
                added.take(10).forEach { appendLine("+ $it") }
                changed.take(10).forEach { appendLine("~ $it") }
                removed.take(10).forEach { appendLine("- $it") }
                if (added.size + changed.size + removed.size == 0) append("(workspace identical to the snapshot)")
            }.trim()
        }

        fun restore(root: File, snapshot: String, dryRun: Boolean = false): String {
            val f = File(dir(root), snapshot)
            if (!f.isFile) return "No snapshot '$snapshot'. Available: ${list(root).take(5)}"
            if (dryRun) return diff(root, snapshot)
            // safety net: snapshot the CURRENT state before overwriting it
            val backup = create(root, "pre-restore")
            var count = 0
            val snapNames = HashSet<String>()
            ZipInputStream(FileInputStream(f)).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    snapNames.add(e.name)
                    val out = File(root, e.name)
                    if (!out.canonicalPath.startsWith(root.canonicalPath)) { e = z.nextEntry; continue }
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { z.copyTo(it) }
                    count++
                    e = z.nextEntry
                }
            }
            // true rollback: files created AFTER the snapshot disappear again
            var removed = 0
            walkAll(root) { cur ->
                val rel = cur.relativeToOrNull(root)?.toString()?.replace('\\', '/') ?: return@walkAll
                if (!rel.startsWith(".liman-snapshots") && rel !in snapNames && cur.isFile) {
                    if (runCatching { cur.delete() }.getOrDefault(false)) removed++
                }
            }
            return "Restored $count file(s) (+$removed stray later-file(s) removed) from $snapshot " +
                "(current state saved as ${backup.first} — you can undo the undo)."
        }

        private fun walkAll(dir: File, visit: (File) -> Unit) {
            dir.listFiles()?.sortedBy { it.name }?.forEach { f ->
                when {
                    f.isDirectory -> if (f.name !in SKIP_DIRS && f.name != ".liman-snapshots") walkAll(f, visit)
                    f.isFile && f.length() < 8_000_000 -> visit(f)
                }
            }
        }
    }

    // ============================================================
    // 4. SURGICAL PATCHES — multi-file find/replace batches
    // ============================================================

    data class PatchOp(val file: String, val find: String, val replace: String, val all: Boolean)
    data class PatchResult(val file: String, val applied: Int, val error: String?)

    fun applyPatch(root: File, ops: List<PatchOp>): List<PatchResult> = ops.map { op ->
        val f = File(root, op.file.replace('\\', '/')).let { target ->
            if (target.canonicalPath.startsWith(root.canonicalPath)) target else null
        }
        if (f == null || !f.isFile) return@map PatchResult(op.file, 0, "file not found")
        runCatching {
            val text = f.readText()
            if (!text.contains(op.find)) return@map PatchResult(op.file, 0, "find-text not present")
            val count = if (op.all) text.split(op.find).size - 1 else 1
            val out = if (op.all) text.replace(op.find, op.replace)
            else text.replaceFirst(op.find, op.replace)
            f.writeText(out)
            PatchResult(op.file, count, null)
        }.getOrElse { PatchResult(op.file, 0, it.message?.take(80) ?: "write failed") }
    }

    fun patchReport(results: List<PatchResult>): String = buildString {
        val ok = results.filter { it.error == null }
        val bad = results.filter { it.error != null }
        appendLine("PATCH: ${ok.sumOf { it.applied }} replacement(s) across ${results.size} op(s)" +
            (if (bad.isNotEmpty()) " — ${bad.size} FAILED" else " — all applied"))
        results.forEach { r ->
            if (r.error == null) appendLine("✓ ${r.file}: ${r.applied} replacement(s)")
            else appendLine("✗ ${r.file}: ${r.error}")
        }
        append("Next: code_check the touched files, then run/verify the change.")
    }.trim()

    // ============================================================
    // 5. WEB SESSIONS — persistent cookie jar for http_request
    // ============================================================

    object WebSessions {
        private val json = Json { prettyPrint = false }
        /** session -> (domain -> list of cookie strings) */
        private var store: MutableMap<String, MutableMap<String, MutableList<String>>> = HashMap()

        @Synchronized
        fun load(workspace: File) {
            val f = File(workspace, ".liman/sessions.json")
            store = runCatching {
                val raw = json.decodeFromString(SessionSer, f.readText())
                HashMap<String, MutableMap<String, MutableList<String>>>().also { m ->
                    raw.forEach { (k, v) ->
                        m[k] = HashMap<String, MutableList<String>>().also { d ->
                            v.forEach { (dk, l) -> d[dk] = l.toMutableList() }
                        }
                    }
                }
            }.getOrDefault(HashMap())
        }

        @Synchronized
        fun save(workspace: File) {
            val f = File(workspace, ".liman/sessions.json")
            f.parentFile?.mkdirs()
            runCatching { f.writeText(json.encodeToString(SessionSer, store)) }
        }

        @Synchronized
        fun list(): List<String> = store.keys.sorted()

        @Synchronized
        fun clear(session: String?) {
            if (session == null) store.clear() else store.remove(session)
        }

        private fun domainOf(url: String): String =
            runCatching { java.net.URI(url).host?.removePrefix("www.") ?: "" }.getOrDefault("")

        /** Cookie header to send for this url in this session. */
        @Synchronized
        fun cookieHeader(session: String, url: String): String =
            store[session]?.get(domainOf(url))?.joinToString("; ") { it.substringBefore(";") } ?: ""

        /** Record Set-Cookie headers from a response. */
        @Synchronized
        fun record(session: String, url: String, setCookies: List<String>) {
            if (setCookies.isEmpty()) return
            val dom = store.getOrPut(session) { HashMap() }.getOrPut(domainOf(url)) { ArrayList() }
            setCookies.forEach { raw ->
                val name = raw.substringBefore("=").trim()
                dom.removeAll { it.startsWith("$name=") }
                dom.add(raw.substringBefore(";").trim())
            }
        }

        private val SessionSer = MapSerializer(
            String.serializer(),
            MapSerializer(String.serializer(), ListSerializer(String.serializer()))
        )
    }

    // ============================================================
    // 6. CODE CHECKS — deterministic pre-done gates (pure half)
    // ============================================================

    object CodeCheck {

        /** Kotlin/Java-lite: balance of braces/parens/brackets + unterminated strings. */
        fun structuralCheck(source: String): List<String> {
            val problems = ArrayList<String>()
            var brace = 0; var paren = 0; var bracket = 0
            var inStr: Char? = null
            var inLineComment = false; var inBlockComment = false
            source.forEachIndexed { i, c ->
                val prev = if (i > 0) source[i - 1] else ' '
                when {
                    inLineComment -> if (c == '\n') inLineComment = false
                    inBlockComment -> if (prev == '*' && c == '/') inBlockComment = false
                    inStr != null -> {
                        if (c == inStr && prev != '\\') inStr = null
                        if (c == '\n' && inStr != '"') { problems.add("unterminated ${if (inStr == '"') "double" else "single"} quote near offset $i"); inStr = null }
                    }
                    else -> when {
                        c == '/' && prev == '/' -> inLineComment = true
                        c == '*' && prev == '/' -> inBlockComment = true
                        c == '"' || c == '\'' -> inStr = c
                        c == '{' -> brace++
                        c == '}' -> brace--
                        c == '(' -> paren++
                        c == ')' -> paren--
                        c == '[' -> bracket++
                        c == ']' -> bracket--
                    }
                }
            }
            if (inStr != null) problems.add("unterminated ${if (inStr == '"') "double" else "single"} quote at end of file")
            if (inBlockComment) problems.add("unterminated block comment at end of file")
            if (brace != 0) problems.add("unbalanced braces ($brace)")
            if (paren != 0) problems.add("unbalanced parentheses ($paren)")
            if (bracket != 0) problems.add("unbalanced brackets ($bracket)")
            return problems
        }

        fun jsonCheck(text: String): String? =
            runCatching { Json.parseToJsonElement(text); null }.getOrElse { "invalid JSON: ${it.message?.take(100)}" }

        /** Python-lite: indentation consistency (tabs AND spaces mixed at line starts). */
        fun pythonIndentCheck(source: String): List<String> {
            val problems = ArrayList<String>()
            val tabIndent = source.lines().any { it.startsWith("\t") }
            val spaceIndent = source.lines().any { it.startsWith("    ") }
            if (tabIndent && spaceIndent) problems.add("mixed tabs and spaces for indentation")
            return problems
        }
    }
}
