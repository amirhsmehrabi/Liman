package com.liman.agent.agent

import com.liman.agent.data.Stores

/**
 * Built-in "model-guide" skill: which LLM suits which task, at what cost
 * and quality. Installed automatically on first run so the agent can
 * consult it (and share advice with the user) via use_skill.
 */
object ModelGuide {

    const val SKILL_ID = "model-guide"

    fun markdown(): String = """
---
name: Model Guide
description: Which AI model to use for which task — strengths, weaknesses, cost tiers, vision ability, and how to combine them.
---

# Model Guide (which model for what)

Use this to pick models per task, to explain trade-offs to the user, and to
configure combos. Always personalize with the user's actually available
models from the Providers settings.

## Capability map

| Task | Best model class | Why |
|---|---|---|
| Complex coding / multi-file projects | Frontier coding models (Claude-class, GPT-4.1/o-class, DeepSeek-V3/R1, Qwen-Coder-Max) | long context, strong reasoning, tool use |
| Quick edits / small scripts | Mid-tier fast models (GPT-4o-mini, Gemini Flash, Haiku-class, Qwen-Turbo) | 5–20× cheaper, plenty for small tasks |
| Math / logic puzzles | Reasoning models (o-series, R1, Gemini Pro with thinking, Qwen-Max-Thinking) | deliberate step-by-step reasoning |
| Images: understanding | VISION-capable models only (GPT-4o/4.1, Gemini Pro/Flash, Claude Sonnet/Opus, Qwen-VL, Llama 3.2 Vision, Pixtral) | they accept image input; text-only models cannot see |
| Images: generation | Gemini image models (via image_generate tool) | only generation-capable providers |
| Long documents (>100 pages) | Long-context models (Gemini 1M-token class, Claude 200k) | fits the whole document |
| Persian / multilingual | Gemini, GPT-4o-class, Qwen, Claude | strongest non-English quality |
| Cheap high-volume batch | Free-tier models (OpenRouter :free) | zero cost, rate-limited, quality varies |
| Web agents / tool-heavy loops | Models with strong function-calling (GPT-4o, Gemini Flash/Pro, Claude, Qwen) | fewer malformed tool calls |

## Cost tiers (typical, per 1M tokens)

- Free, NO key at all: OpenCode Free inside Liman (Muse Spark contributor-free models — anonymous, zero setup, self-updating list).
- Free with key/login: OpenRouter `:free` variants, Gemini free-tier key, web chats (rate-limited; best for experiments, drafts, subagents).
- Cheap ($0.10–$1): mini/flash/haiku/turbo class — everyday work.
- Mid ($1–$10): mid-tier pro models — serious coding, analysis.
- Premium ($10–$60+): frontier — hardest problems, final review passes, large refactors.

## Free without any API key (Liman v2.11, deep-researched)

- **OpenCode Free (opencode.ai)** — works anonymously: Muse Spark 1.2/1.3
  contributor-free. It is a shared public pool: occasionally busy, and Liman
  retries automatically with backoff. The model list self-updates from
  OpenCode's live catalog + models.dev.
- **MiMo Code Free (Xiaomi)** — was anonymous until 2026-07-26, then Xiaomi
  sunset the free API ("MiMo free API service has ended"). If it ever
  returns, the Free Catalog sweep will notice new mimo "-free" models.
- **DuckDuckGo AI / llm7 "unused" token** — blocked/challenge-walled or now
  key-required; not usable from an app.
- Free tiers that need an ACCOUNT login but no API key: Gemini (in-app
  Google login), web chats (ChatGPT/Gemini/any site), OpenCode Go, Cline.
  Practical rule: "no key" ≠ "no limits" — shared pools rate-limit.

Strategy: cascade cheap → premium in a combo so cheap models handle easy
turns and premium models catch the hard ones (Liman's failover does this
automatically).

## Quality heuristics

- "Vision" or "VL" or omni-class names → can see images.
- "Thinking"/"R1"/"o1" → reasoning mode, slower but stronger at math/logic.
- "Mini"/"Flash"/"Haiku"/"Turbo"/"Small" → fast & cheap tier.
- "Max"/"Pro"/"Opus"/"Ultra"/"Large" → flagship tier.
- Newer versions usually beat older at the same size (4o > 4-turbo, 2.5 > 2.0).
- Open models (Llama, Qwen, DeepSeek, Mistral, Gemma) often match closed
  models one tier down at a fraction of the cost.

## Combo recipes (Liman)

- **Bargain hunter**: all free models of a provider via the "free combo"
  checkbox → zero cost, auto-failover when one is rate-limited.
- **Workhorse**: Flash/Mini first, Sonnet/GPT-4.1-class second.
- **Heavy hitter**: one frontier model, no fallback (max consistency).
- **Vision tasks**: combo reorders automatically so vision-capable models
  run first whenever images are attached.

## When advising the user

State: what task class they described → which 1–3 concrete models fit →
cost expectation → one caveat (rate limits / context size). Offer to
configure the combo for them.
""".trim()

    /** Installs the skill once (does not overwrite user edits if present). */
    fun ensureInstalled(stores: Stores) {
        val existing = stores.skills.state.value.any { it.id == SKILL_ID }
        if (existing) return
        runCatching {
            SkillSystem(stores).installFromMarkdown(
                name = "Model Guide",
                description = "Which AI model to use for which task — strengths, cost tiers, vision ability, combo recipes.",
                markdown = markdown(),
                sourceUrl = "builtin"
            )
        }
    }
}
