package com.liman.agent.agent

import android.content.Context
import com.liman.agent.data.Stores
import kotlinx.coroutines.delay
import com.liman.agent.llm.RouterServer
import java.io.File
import java.util.Base64
import java.security.MessageDigest

/**
 * v2.22.0 — THE NATIVE APK FACTORY.
 *
 * "I don't need that old HTML-to-APK! I need a REAL application in a real
 * native Android language." — done. Liman now writes actual Kotlin sources
 * and compiles them ON THIS PHONE via the Termux toolchain:
 *
 *   kotlinc → d8 (→dx fallback) → aapt2 link → zip → zipalign → apksigner
 *
 * This is not a WebView shell: the output is a genuine, installable,
 * signed APK of the agent's own Kotlin code (framework APIs, programmatic
 * UI — zero external dependencies, exactly like the classic CLI-built
 * Android apps). The pipeline was verified end-to-end before shipping:
 * the same command sequence, the same android.jar URL, a real signed APK
 * from the scaffold template.
 *
 * One-time environment (action: "setup", installs into Termux):
 *   pkg install openjdk-17 kotlin aapt2 apksigner dx zip
 *   curl android.jar from the official Google platform zip (API 33 —
 *   deliberately: Termux's aapt2 breaks on SDK 35+ platform jars)
 *   keytool-generated debug keystore (pass: limankey)
 *
 * Transfer: project files go TO Termux base64-embedded in the build script
 * (no shared filesystem between apps); the finished APK comes BACK in
 * md5-verified 256KB base64 chunks over the bridge.
 */
object NativeBuilder {

    const val STORE_PASS = "limankey"
    private const val CHUNK = 256 * 1024
    private const val MAX_CHUNKS = 24                      // 6 MB APK ceiling
    const val ANDROID_JAR_URL =
        "https://dl.google.com/android/repository/platform-33-ext5_r01.zip"
    const val API_LEVEL = 33

    // ---------------- naming / validation (pure) ----------------

    fun validPackage(pkg: String): Boolean =
        Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*){1,4}$").matches(pkg.trim())

    /** "My Cool App" → mycoolapp ; used for the default package com.liman.mycoolapp */
    fun slugify(name: String): String =
        name.lowercase().replace(Regex("[^a-z0-9]+"), "").take(24).ifBlank { "app" }

    fun defaultPackage(name: String): String = "com.liman." + slugify(name)

    // ---------------- scaffold (pure file generation) ----------------

    /**
     * Creates a real Kotlin Android project in workspace/native-projects/<slug>/.
     * This exact template compiles through the verified pipeline.
     * v2.30.0: [presetId] also generates res/values/colors.xml + dimens.xml from
     * the design-token kernel, so native apps share one source of truth with web.
     */
    fun scaffold(workspace: File, name: String, pkg: String?, description: String, permissions: List<String>, presetId: String? = null): File {
        val appName = name.trim().take(40).ifBlank { "Liman App" }
        val packageName = (pkg?.trim() ?: defaultPackage(appName)).let {
            if (validPackage(it)) it else defaultPackage(appName)
        }
        val slug = slugify(appName)
        val dir = File(File(workspace, "native-projects"), slug)
        val pkgPath = packageName.replace('.', '/')
        File(dir, "src/$pkgPath").mkdirs()
        File(dir, "res/values").mkdirs()

        File(dir, "AndroidManifest.xml").writeText(manifestXml(packageName, appName, permissions))
        File(dir, "res/values/themes.xml").writeText(themesXml())
        if (presetId != null) {
            DesignTokens.androidColorsXml(presetId)?.let { File(dir, "res/values/colors.xml").writeText(it) }
            File(dir, "res/values/dimens.xml").writeText(buildString {
                appendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
                appendLine("<resources>")
                appendLine("    <!-- spacing token scale (dp) — never hardcode a value outside it -->")
                listOf(4 to "space_1", 8 to "space_2", 12 to "space_3", 16 to "space_4", 24 to "space_5", 32 to "space_6", 48 to "space_7", 64 to "space_8", 96 to "space_9")
                    .forEach { appendLine("    <dimen name=\"${it.second}\">${it.first}dp</dimen>") }
                appendLine("    <!-- radius tokens -->")
                listOf(6 to "radius_sm", 10 to "radius_md", 16 to "radius_lg", 24 to "radius_xl").forEach {
                    appendLine("    <dimen name=\"${it.second}\">${it.first}dp</dimen>")
                }
                appendLine("    <!-- minimum touch target -->")
                appendLine("    <dimen name=\"touch_min\">48dp</dimen>")
                appendLine("</resources>")
            })
        }
        File(dir, "src/$pkgPath/MainActivity.kt").writeText(mainActivityKt(packageName, appName, description))
        File(dir, "PROJECT.md").writeText(projectReadme(appName, packageName, slug))
        return dir
    }

    fun manifestXml(packageName: String, appName: String, permissions: List<String>): String = buildString {
        appendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
        appendLine("<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"")
        appendLine("    package=\"$packageName\"")
        appendLine("    android:versionCode=\"1\"")
        appendLine("    android:versionName=\"1.0\">")
        appendLine("    <uses-sdk android:minSdkVersion=\"24\" android:targetSdkVersion=\"$API_LEVEL\" />")
        permissions.filter { it.isNotBlank() }.forEach { appendLine("    <uses-permission android:name=\"${it.trim()}\" />") }
        appendLine("    <application android:label=\"$appName\" android:theme=\"@style/AppTheme\" android:allowBackup=\"true\">")
        appendLine("        <activity android:name=\".MainActivity\" android:exported=\"true\">")
        appendLine("            <intent-filter>")
        appendLine("                <action android:name=\"android.intent.action.MAIN\" />")
        appendLine("                <category android:name=\"android.intent.category.LAUNCHER\" />")
        appendLine("            </intent-filter>")
        appendLine("        </activity>")
        appendLine("    </application>")
        appendLine("</manifest>")
    }

    fun themesXml(): String =
        """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="android:Theme.Material.NoActionBar" />
</resources>
"""

    /** Programmatic UI, framework-only — the exact shape that compiled through the pipeline. */
    fun mainActivityKt(packageName: String, appName: String, description: String): String = buildString {
        appendLine("package $packageName")
        appendLine()
        appendLine("import android.app.Activity")
        appendLine("import android.os.Bundle")
        appendLine("import android.view.Gravity")
        appendLine("import android.widget.Button")
        appendLine("import android.widget.LinearLayout")
        appendLine("import android.widget.TextView")
        appendLine("import android.widget.Toast")
        appendLine()
        appendLine("class MainActivity : Activity() {")
        appendLine("    override fun onCreate(savedInstanceState: Bundle?) {")
        appendLine("        super.onCreate(savedInstanceState)")
        appendLine("        val root = LinearLayout(this).apply {")
        appendLine("            orientation = LinearLayout.VERTICAL")
        appendLine("            gravity = Gravity.CENTER")
        appendLine("            setBackgroundColor(0xFF121622.toInt())")
        appendLine("        }")
        appendLine("        root.addView(TextView(this).apply {")
        appendLine("            text = \"$appName\"")
        appendLine("            textSize = 24f")
        appendLine("            setTextColor(0xFFFFFFFF.toInt())")
        appendLine("            gravity = Gravity.CENTER")
        appendLine("        })")
        appendLine("        root.addView(TextView(this).apply {")
        appendLine("            text = \"${description.replace("\"", "'").take(160).ifBlank { "Real Kotlin, compiled natively on this phone." }}\"")
        appendLine("            textSize = 14f")
        appendLine("            setTextColor(0xFFB0B8C4.toInt())")
        appendLine("            gravity = Gravity.CENTER")
        appendLine("            setPadding(32, 32, 32, 32)")
        appendLine("        })")
        appendLine("        root.addView(Button(this).apply {")
        appendLine("            text = \"Tap me\"")
        appendLine("            setOnClickListener {")
        appendLine("                Toast.makeText(this@MainActivity, \"It works — built by Liman's native factory.\", Toast.LENGTH_SHORT).show()")
        appendLine("            }")
        appendLine("        })")
        appendLine("        setContentView(root)")
        appendLine("    }")
        appendLine("}")
    }

    private fun projectReadme(appName: String, packageName: String, slug: String): String = """
        # $appName (native Android project)

        A REAL Kotlin Android app. Sources in `src/`, manifest, resources in `res/`.
        Framework APIs only (no AndroidX/Gradle needed — the whole build runs on-device).

        Build: native_apk {action:"build", name:"$slug"} — compiles in Termux
        (kotlinc → d8 → aapt2 → zipalign → apksigner) and returns a signed APK.

        Edit freely with write_file:
        - more screens: add `class SecondActivity : Activity()` in src/, register
          `<activity android:name=".SecondActivity"/>` in AndroidManifest.xml
        - background work: a `Service` class + `<service>` entry + permission
        - resources: strings/colors/layouts under res/ (reference as R.string.…)
        Package: $packageName · minSdk 24 · targetSdk $API_LEVEL
    """.trimIndent()

    // ---------------- Termux scripts (pure generation) ----------------

    /** One-time environment probe: prints "<item>:ok|missing" lines. */
    fun envProbeScript(): String = """
        for t in java kotlinc javac aapt2 d8 dx apksigner zip unzip curl; do
          if command -v ${'$'}t >/dev/null 2>&1; then echo "${'$'}t:ok"; else echo "${'$'}t:missing"; fi
        done
        [ -f ~/liman-native/android.jar ] && echo "android.jar:ok" || echo "android.jar:missing"
        [ -f ~/liman-native/debug.keystore ] && echo "keystore:ok" || echo "keystore:missing"
        echo "--- disk ---"
        df -h ~ | tail -1
        echo "--- versions ---"
        java -version 2>&1 | head -1
        aapt2 version 2>/dev/null || true
        apksigner --version 2>/dev/null || true
        echo "PROBE-DONE"
    """.trimIndent()

    /**
     * v2.30.0 — artifact verification (blueprint §18.3): signature schemes,
     * badging (package/launcher/version/permissions) and sha256, run against
     * the built APK in Termux.
     */
    fun verifyScript(slug: String): String = """
        cd ~/liman-native/projects/$slug || { echo "NO_PROJECT: no built APK for '$slug' (run build first)."; exit 0; }
        [ -f app.apk ] || { echo "NO_APK: nothing at ~/liman-native/projects/$slug/app.apk — build first."; exit 0; }
        echo "--- sha256 ---"
        sha256sum app.apk
        echo "--- signature ---"
        apksigner verify --verbose --print-certs app.apk 2>&1 | head -20
        echo "--- badging ---"
        aapt2 dump badging app.apk 2>/dev/null | grep -E "^(package|sdkVersion|targetSdkVersion|application-label|launchable-activity|uses-permission)" | head -20
        echo "VERIFY-DONE"
    """.trimIndent()

    /** One-time environment install (~200 MB of packages + 65 MB android.jar). */
    fun setupScript(): String = """
        set -e
        mkdir -p ~/liman-native
        echo "=== installing toolchain packages (one-time) ==="
        pkg install -y openjdk-17 kotlin aapt2 apksigner dx zip unzip curl || pkg install -y openjdk-17 kotlin aapt2 apksigner zip unzip curl
        if [ ! -f ~/liman-native/android.jar ]; then
          echo "=== downloading android.jar (API $API_LEVEL, official Google platform zip) ==="
          cd ~/liman-native
          curl -sL -o platform.zip "$ANDROID_JAR_URL"
          unzip -o -q platform.zip "*/android.jar"
          mv android-*/android.jar ~/liman-native/android.jar
          rm -rf platform.zip android-*/
        fi
        if [ ! -f ~/liman-native/debug.keystore ]; then
          echo "=== generating debug keystore ==="
          keytool -genkeypair -keystore ~/liman-native/debug.keystore -alias liman -keyalg RSA -keysize 2048 -validity 10000 -storepass $STORE_PASS -keypass $STORE_PASS -dname "CN=Liman Debug,O=Liman,C=US" 2>/dev/null
        fi
        echo "=== verification ==="
        java -version 2>&1 | head -1
        kotlinc -version 2>&1 | head -1
        ls -la ~/liman-native/android.jar ~/liman-native/debug.keystore
        echo "LIMAN_NATIVE_SETUP_OK"
    """.trimIndent().trim()

    /**
     * The full build: transfers the current project files (base64-embedded),
     * then runs the VERIFIED pipeline. Ends with "LIMAN_BUILD_OK <size> <md5>"
     * on success (set -e aborts with the compiler's real error otherwise).
     */
    fun buildScript(slug: String, files: List<Pair<String, ByteArray>>): String = buildString {
        appendLine("set -e")
        appendLine("PROJ=~/liman-native/projects/$slug")
        appendLine("rm -rf \"\$PROJ\" && mkdir -p \"\$PROJ\"")
        appendLine("cd \"\$PROJ\"")
        appendLine("echo '=== transferring project ==='")
        files.forEach { (path, bytes) ->
            appendLine("mkdir -p \"\$(dirname '$path')\"")
            appendLine("printf %s '${base64(bytes)}' | base64 -d > '$path'")
        }
        appendLine(
            """
            echo '=== [1/6] resources ==='
            aapt2 compile --dir res -o build.res.zip
            echo '=== [2/6] link ==='
            aapt2 link -o app.unaligned.apk -I ~/liman-native/android.jar --manifest AndroidManifest.xml --java build.gen build.res.zip --auto-add-overlay
            echo '=== [3/6] compile Kotlin ==='
            KTS=${'$'}(find src -name '*.kt')
            if [ -n "${'$'}KTS" ]; then
              kotlinc -classpath ~/liman-native/android.jar -jvm-target 1.8 -include-runtime -d app.jar ${'$'}KTS
              CLASSES=app.jar
            else
              find src -name '*.java' > jsources.txt
              javac -source 8 -target 8 -classpath ~/liman-native/android.jar -d build.classes @jsources.txt
              CLASSES=${'$'}(find build.classes -name '*.class')
            fi
            echo '=== [4/6] dex ==='
            if command -v d8 >/dev/null 2>&1; then
              d8 --release --lib ~/liman-native/android.jar --min-api 24 --output . ${'$'}CLASSES
            else
              dx --dex --min-sdk-version 24 --output classes.dex ${'$'}CLASSES
            fi
            echo '=== [5/6] package + align ==='
            zip -q -j app.unaligned.apk classes.dex
            if command -v zipalign >/dev/null 2>&1; then
              zipalign -f 4 app.unaligned.apk app.aligned.apk
            else
              cp app.unaligned.apk app.aligned.apk
            fi
            echo '=== [6/6] sign ==='
            apksigner sign --ks ~/liman-native/debug.keystore --ks-pass pass:$STORE_PASS --ks-key-alias liman --out app.apk app.aligned.apk
            apksigner verify app.apk
            SIZE=${'$'}(stat -c%s app.apk)
            MD5=${'$'}(md5sum app.apk | cut -d' ' -f1)
            echo "LIMAN_BUILD_OK ${'$'}SIZE ${'$'}MD5"
        """.trimIndent()
        )
    }

    /** Fetch APK chunk i (256 KB, base64 single line, md5-checked end-to-end). */
    fun chunkScript(slug: String, index: Int): String =
        "dd if=~/liman-native/projects/$slug/app.apk bs=$CHUNK skip=$index count=1 status=none | base64 -w0"

    /** Collect project files for transfer (text+binary, capped). */
    fun projectFiles(projectDir: File, maxFiles: Int = 64, maxTotalBytes: Int = 500_000): List<Pair<String, ByteArray>> {
        val out = mutableListOf<Pair<String, ByteArray>>()
        var total = 0
        projectDir.walkTopDown()
            .filter { it.isFile && it.parentFile?.name != "build" && !it.name.startsWith(".") }
            .sortedBy { it.path }
            .forEach { f ->
                if (out.size >= maxFiles || total >= maxTotalBytes) return@forEach
                val bytes = f.readBytes()
                if (bytes.size > 200_000) return@forEach
                total += bytes.size
                out += f.relativeTo(projectDir).path.replace('\\', '/') to bytes
            }
        return out
    }

    // ---------------- APK retrieval (pure parts) ----------------

    /** Decode retrieved chunks into the APK bytes; md5 must match the build's. */
    fun assembleChunks(chunks: List<String>, expectedMd5: String?): ByteArray? {
        val all = java.io.ByteArrayOutputStream()
        chunks.forEach { c ->
            val clean = c.trim()
            if (clean.isEmpty()) return@forEach
            val decoded = runCatching { Base64.getDecoder().decode(clean) }.getOrNull() ?: return null
            all.write(decoded, 0, decoded.size)
        }
        val bytes = all.toByteArray()
        if (expectedMd5 != null && md5(bytes) != expectedMd5) return null
        return bytes
    }

    fun md5(bytes: ByteArray): String =
        MessageDigest.getInstance("MD5").digest(bytes).joinToString("") { "%02x".format(it) }

    fun chunkCount(size: Long): Int = ((size + CHUNK - 1) / CHUNK).toInt()

    val maxChunks: Int get() = MAX_CHUNKS

    private fun base64(bytes: ByteArray): String = Base64.getEncoder().encodeToString(bytes)

    // ---------------- v2.24.1 long-job execution (background + poll) ----------------
    //
    // Real-world failure (user logs): `pkg install` + a 65 MB download takes
    // MINUTES on a phone — longer than any single bridge call waits — so the
    // tool answered "No response from Termux" and the whole setup looked
    // broken. Fix: launch the script in the BACKGROUND inside Termux
    // (instant bridge call), then poll its log with SHORT bridge calls until
    // the exit marker appears. No more timeouts, live progress visible.

    /** Wrap any script as a background job with an always-written exit marker. */
    fun jobWrap(scriptBody: String): String {
        // the payload travels base64-encoded (zero quoting hazards);
        // the EXIT trap fires even when `set -e` aborts the script — the
        // exit marker is ALWAYS written, so polling can never hang forever.
        val d = '$' // shell $? must not become a Kotlin template
        val payload = "set -e\n" +
            "trap 'echo LIMAN_JOB_EXIT_${d}? >> ~/liman-native/job.log' EXIT\n" +
            "mkdir -p ~/liman-native\n" +
            scriptBody + "\n"
        val b64 = java.util.Base64.getEncoder().encodeToString(payload.toByteArray())
        return "mkdir -p ~/liman-native && printf %s '$b64' | base64 -d > ~/liman-native/job.sh && " +
            "nohup bash ~/liman-native/job.sh > ~/liman-native/job.log 2>&1 & echo LIMAN_JOB_LAUNCHED"
    }

    /** Short call: tail the job log + report running/done. */
    fun pollScript(): String =
        "tail -c 3000 ~/liman-native/job.log 2>/dev/null; echo; " +
            "grep -q LIMAN_JOB_EXIT_ ~/liman-native/job.log 2>/dev/null && echo LIMAN_JOB_DONE || echo LIMAN_JOB_RUNNING"

    /**
     * v2.25.0: shared poll loop for background Termux jobs — used by the
     * agent tools (native_apk) and by NineRouter.fullSetup. Short bridge
     * calls every intervalMs; returns the log tail once the exit marker
     * appears, or a timeout hint after maxSeconds.
     */
    suspend fun pollJob(
        context: Context, stores: Stores, maxSeconds: Int, intervalMs: Long = 15_000
    ): String {
        val deadline = System.currentTimeMillis() + maxSeconds * 1000L
        var last = ""
        while (System.currentTimeMillis() < deadline) {
            delay(intervalMs)
            last = bridgeRun(context, stores, pollScript(), 45)
            if (last.contains("LIMAN_JOB_DONE")) return last
        }
        return (last.ifBlank { "(no log output yet)" }) +
            "\n[POLL TIMEOUT after ${maxSeconds}s — the job may still be running. Check later with termux_run: tail -c 3000 ~/liman-native/job.log]"
    }

    /** v2.26.0: strip the job-control markers — the agent should see errors, not plumbing. */
    fun cleanJobLog(log: String): String = log
        .lineSequence()
        .filter { l -> !l.contains("LIMAN_JOB_EXIT_") && l != "LIMAN_JOB_DONE" && l != "LIMAN_JOB_RUNNING" && l != "LIMAN_JOB_LAUNCHED" }
        .joinToString("\n")
        .trim()
        .plus(if (log.contains("LIMAN_JOB_EXIT_") && !Regex("LIMAN_JOB_EXIT_0\\b").containsMatchIn(log)) "\n[build process exited with an error code]" else "")

    /**
     * v2.26.0 — THE DEBUGGING TEACHER: real build logs from the user's phone,
     * turned into targeted fix hints so the agent repairs generated Kotlin in
     * ONE retry instead of guessing.
     */
    fun buildHints(log: String): String = buildString {
        val said = mutableSetOf<String>()
        fun once(key: String, hint: String) {
            if (key !in said) { said += key; append("\n\n[FIX HINT] "); append(hint) }
        }
        if (Regex("actual type is 'Long', but 'Int' was expected").containsMatchIn(log)) {
            once("longint", "Kotlin gotcha: hex literals >= 0x80000000 (e.g. 0x881B2242, 0xFFF23B69) are LONG, but Android color APIs (setTextColor/setColor/Color.argb/GradientDrawable) take Int. Fix: declare palette constants as `val PINK = 0xFFF23B69.toInt()` (append .toInt() to EVERY such literal) — then every call site works unchanged.")
        }
        if (log.contains("backing field of 'var ") && log.contains("is not accessible at this point")) {
            once("isinit", "Kotlin gotcha: `obj::prop.isInitialized` is ILLEGAL — ::isInitialized only works for properties declared in the SAME class (this::x.isInitialized). For another object's property use a nullable: `var pViz: VisualizerView? = null` then `screens.pViz?.active = (idx == 1)` — or a plain `var ready = false` flag.")
        }
        if (log.contains("jansi") || log.contains("UnsatisfiedLinkError")) {
            once("jansi", "The jansi/UnsatisfiedLinkError line is harmless kotlinc console-color noise on Termux/arm64 — ignore it and read the REAL compile errors below it.")
        }
        if (Regex("error: unresolved reference").containsMatchIn(log)) {
            once("unresolved", "Unresolved reference: the native pipeline compiles against framework APIs only (no external libraries, no compose, no androidx) — check the exact class/function name and import (e.g. android.graphics.Color, android.widget.*).")
        }
    }

    /** Parse the final log: success marker + exit code. */
    fun jobOutcome(log: String): Triple<Boolean, Int, String> {
        val exit = Regex("LIMAN_JOB_EXIT_(-?\\d+)").findAll(log).lastOrNull()?.groupValues?.get(1)?.toIntOrNull()
        val done = exit != null || log.contains("LIMAN_BUILD_OK") || log.contains("LIMAN_NATIVE_SETUP_OK")
        return Triple(done, exit ?: 0, log)
    }

    // ---------------- bridge plumbing (mirrors termux_run) ----------------

    suspend fun bridgeRun(context: Context, stores: Stores, script: String, timeoutS: Int): String {
        val port = RouterServer.runningPort()
            ?: runCatching {
                val s = stores.settings.state.value
                if (RouterServer.start(stores, s.routerPort, s.routerLan)) s.routerPort else null
            }.getOrNull()
            ?: return "The Termux bridge is not reachable (local router not running) — enable it in Settings → Local router, then retry."
        return TermuxBridge.run(context, port, script, timeoutS * 1000L)
    }

    /** Parse "LIMAN_BUILD_OK <size> <md5>" from build output. */
    fun parseBuildOk(out: String): Triple<Int, String, String>? {
        val m = Regex("LIMAN_BUILD_OK (\\d+) ([0-9a-f]{32})").find(out) ?: return null
        val tail = out.substringAfter(m.value).lineSequence().firstOrNull { it.isNotBlank() } ?: ""
        return Triple(m.groupValues[1].toInt(), m.groupValues[2], tail)
    }
}
