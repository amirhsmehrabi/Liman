package com.liman.agent.agent

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v2.35.0 — CROSS-RUN LEARNING (the Hermes three-layer memory loop).
 *
 * A run that spun, died or completed without ever changing anything leaves a
 * one-line LESSON in `workspace/.liman-lessons.md`. The system prompt already
 * injects that file into every later run ("your OWN past failures — read it
 * now, never repeat them") — this object is the writer that was missing:
 * lessons now accumulate automatically, mechanically, with zero extra model
 * calls, so the same failure shape never burns a whole run twice.
 *
 * Pure Kotlin — unit-tested (RunLessonsLedgerTest).
 */
object RunLessons {

    const val FILE = ".liman-lessons.md"
    private const val MAX_LESSONS = 40

    private val STAMP = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

    fun file(workspace: File): File = File(workspace, FILE)

    /**
     * The one-line prescription per failure shape — deliberately imperative,
     * the exact opposite behavior of the failure that earned it.
     */
    fun prescription(reason: String, mutated: Boolean): String = when (reason) {
        "loop" -> "never repeat an identical call — change exactly one variable per retry, or ask_user for the missing piece"
        "max_cycles" -> "cap research at ~2 cycles, then take the cheapest MUTATING path and converge early"
        "run_ceiling" -> "the token ceiling hit — split the goal into smaller missions before starting"
        "error" -> "the run died mid-task (provider/setup) — verify providers in Settings before long work"
        else -> if (!mutated)
            "research without delivery is not progress — act with a mutating tool or ask_user within 2 cycles"
        else
            "deliver earlier: verify once, then finish — do not re-verify in extra cycles"
    }

    fun line(
        goal: String,
        reason: String,
        cycles: Int,
        toolCalls: Int,
        mutated: Boolean,
        at: Long = System.currentTimeMillis()
    ): String {
        val ts = STAMP.format(Date(at))
        val g = goal.replace("\n", " ").take(120)
        return "- [$ts] GOAL \"$g\" ended=$reason cycles=$cycles calls=$toolCalls mutated=$mutated " +
            "→ ${prescription(reason, mutated)}"
    }

    /**
     * Append one lesson (creates the file with its header). Keeps the newest
     * [MAX_LESSONS] lessons — old lessons age out, fresh failures stay.
     */
    fun append(
        workspace: File,
        goal: String,
        reason: String,
        cycles: Int,
        toolCalls: Int,
        mutated: Boolean,
        at: Long = System.currentTimeMillis()
    ): File {
        val f = file(workspace)
        val header = "# Liman lessons — written automatically after failed or spinning runs.\n" +
            "# Injected into every run's system prompt: read it, never repeat these mistakes.\n\n"
        val existing = if (f.exists()) f.readText().removePrefix(header) else ""
        val lessons = existing.lines().filter { it.startsWith("- ") }.toMutableList()
        lessons += line(goal, reason, cycles, toolCalls, mutated, at)
        val keep = if (lessons.size > MAX_LESSONS) lessons.takeLast(MAX_LESSONS) else lessons
        f.writeText(header + keep.joinToString("\n", postfix = "\n"))
        return f
    }
}
