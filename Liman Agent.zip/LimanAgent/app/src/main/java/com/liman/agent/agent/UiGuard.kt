package com.liman.agent.agent

/**
 * v2.27.0 — THE PERCEPTION + ANTI-FRAGILITY PACK for the `ui` tool.
 *
 * Distilled from two repos the user asked us to study:
 *  • droidclaw (unitedbyai/droidclaw) — "what makes it not fall apart":
 *    stuck-loop detection, repetition tracking, drift detection, action
 *    feedback, multi-turn memory.
 *  • agent-device (callstack/agent-device) — token-efficient accessibility
 *    snapshots with short REF ids ("@e2 [button] Add") that are only valid
 *    from the latest output.
 *
 * Pure logic — unit-tested; DemoService feeds it, Tools appends its hints.
 */
object UiGuard {

    /** One interactive element as seen by `ui snapshot`. */
    data class Element(
        val ref: String,          // @e1, @e2, … (valid from the LATEST snapshot only)
        val kind: String,         // button | field | link | tab | option | toggle | custom
        val text: String,         // visible label, truncated
        val desc: String,         // content description, truncated
        val id: String            // viewId tail (com.app:id/xxx → xxx)
    ) {
        fun line(): String {
            val label = text.ifBlank { desc }.ifBlank { id }.ifBlank { "?" }
            return "$ref [$kind] \"$label\""
        }
    }

    /** Sort interactive nodes into a compact, ref-addressable list. */
    fun assignRefs(raw: List<RawNode>): List<Element> {
        val out = ArrayList<Element>()
        raw.take(60).forEachIndexed { i, n ->
            val kind = when {
                n.editable -> "field"
                n.checkable -> "toggle"
                n.clickable && n.text.startsWith("http") -> "link"
                n.clickable && (n.id.contains("tab", true) || n.desc.contains("tab", true)) -> "tab"
                n.clickable -> "button"
                else -> "custom"
            }
            out.add(
                Element(
                    ref = "@e${i + 1}",
                    kind = kind,
                    text = n.text.take(40),
                    desc = n.desc.take(40),
                    id = n.id.substringAfter('/').take(30)
                )
            )
        }
        return out
    }

    /** Raw node facts collected from the accessibility tree (Android-free). */
    data class RawNode(
        val clickable: Boolean,
        val editable: Boolean,
        val checkable: Boolean,
        val text: String,
        val desc: String,
        val id: String
    )

    /** Stable signature of a screen: which labels exist (order-insensitive). */
    fun signature(elements: List<Element>): String =
        elements.joinToString("|") { it.text.ifBlank { it.desc }.ifBlank { it.id } }
            .let { Integer.toHexString(it.hashCode()) }

    // ------------------------------------------------ anti-fragility state

    private var lastSignature: String? = null
    private var unchangedScreens = 0
    private val recentTargets = ArrayDeque<String>()   // sliding window of action target keys
    private var navOnlyStreak = 0

    fun reset() {
        lastSignature = null; unchangedScreens = 0; recentTargets.clear(); navOnlyStreak = 0
    }

    /**
     * Called by `ui snapshot` — updates screen-change tracking, returns a hint
     * once the same screen has been seen 3 times in a row (droidclaw's
     * "3 steps, no change → recovery hint").
     */
    fun observeScreen(sig: String): String? {
        if (sig == lastSignature) unchangedScreens++ else unchangedScreens = 0
        lastSignature = sig
        return if (unchangedScreens >= 2)
            "⚠ STUCK: the screen has NOT changed after ${unchangedScreens + 1} snapshots — your last actions did nothing. " +
                "Change approach: tap a DIFFERENT control (re-check the refs), scroll to reveal new content, go back, or reconsider the flow."
        else null
    }

    /**
     * Called after every act action. Returns a recovery hint when the agent
     * is looping (same target repeatedly) or drifting (endless navigation
     * without interacting).
     */
    fun recordAction(action: String, target: String): String? {
        val key = action + ":" + target.lowercase().trim()
        recentTargets.addLast(key)
        if (recentTargets.size > 8) recentTargets.removeFirst()
        val navOnly = action in setOf("scroll", "back", "home", "recents", "notifications")
        navOnlyStreak = if (navOnly) navOnlyStreak + 1 else 0
        return when {
            // drift outranks repetition for nav-only sequences: it is the more
            // specific diagnosis ("you're wandering", not "this one key is stuck")
            navOnlyStreak >= 5 ->
                "⚠ DRIFT: $navOnlyStreak navigation-only actions in a row without interacting. " +
                    "Stop swiping around — ui snapshot, choose a specific control, tap it."
            recentTargets.count { it == key } >= 3 ->
                "⚠ REPETITION: you've run '$action' on '$target' 3+ times. STOP repeating it — " +
                    "take a fresh ui snapshot, pick a different control or a different strategy entirely."
            else -> null
        }
    }
}
