package com.liman.agent.data

import com.liman.agent.util.JSON
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import java.io.File

/**
 * v2.20.0 — THE PRIVATE LIBRARY (on-device agentic RAG).
 *
 * Ported from two of the 8 reference frameworks:
 *  - **Agno** — knowledge stores: agents get a persistent document library
 *    and are told to search it FIRST (agentic RAG), using the web only to
 *    fill gaps.
 *  - **RAGFlow** — deep-document retrieval done right: layout-respecting
 *    recursive chunking (never slice mid-sentence when a paragraph boundary
 *    exists), agentic multi-query retrieval (issue several phrasings, merge
 *    across documents), and grounded citations — every hit cites doc#chunk.
 *
 * Phone-scale engineering decisions (Liman doctrine — free & offline):
 *  - **BM25** instead of an embedding API: zero network, zero keys, works
 *    on any language, and beats embeddings on keyword-precise recall at
 *    small corpus sizes (k1=1.5, b=0.75).
 *  - One JSON file per document under filesDir/knowledge/ — crash-safe,
 *    trivially auditable by the user, no DB service.
 */
class KnowledgeStore(private val dir: File) {

    @Serializable
    data class KnowledgeDoc(
        val id: String,
        val name: String,
        val source: String,
        val addedAt: Long,
        val chunks: List<String>
    )

    data class Hit(
        val docName: String,
        val chunkIndex: Int,
        val text: String,
        val score: Double
    )

    @Volatile
    private var cache: List<KnowledgeDoc>? = null

    private fun docs(): List<KnowledgeDoc> {
        cache?.let { return it }
        val loaded = dir.listFiles { f -> f.isFile && f.name.endsWith(".json") }
            .orEmpty()
            .mapNotNull { f ->
                runCatching {
                    JSON.decodeFromString(KnowledgeDoc.serializer(), f.readText())
                }.getOrNull()
            }
            .sortedBy { it.addedAt }
        cache = loaded
        return loaded
    }

    /** Ingest text under a name. Re-ingesting the same name replaces it. */
    fun add(name: String, source: String, text: String, nowMs: Long = System.currentTimeMillis()): KnowledgeDoc {
        val clean = name.trim().take(80).ifBlank { "doc" }
        val doc = KnowledgeDoc(
            id = "kb-" + clean.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-')
                .ifBlank { "doc" } + "-" + (nowMs % 100000),
            name = clean,
            source = source.take(200),
            addedAt = nowMs,
            chunks = Chunker.chunk(text)
        )
        dir.mkdirs()
        // same-name documents replace their predecessor (idempotent re-ingest)
        docs().filter { it.name.equals(clean, ignoreCase = true) }.forEach { old ->
            File(dir, old.id + ".json").delete()
        }
        File(dir, doc.id + ".json").writeText(JSON.encodeToString(KnowledgeDoc.serializer(), doc))
        cache = null
        return doc
    }

    fun list(): List<KnowledgeDoc> = docs()

    fun forget(nameOrId: String): Boolean {
        val q = nameOrId.trim()
        val victim = docs().firstOrNull {
            it.id.equals(q, true) || it.name.equals(q, true)
        } ?: return false
        File(dir, victim.id + ".json").delete()
        cache = null
        return true
    }

    /**
     * Agentic multi-query retrieval (RAGFlow): each query phrasing is scored
     * independently with BM25, results merge by best score per chunk, and
     * every hit carries an exact doc#chunk citation.
     */
    fun search(queries: List<String>, k: Int = 6): List<Hit> {
        val allDocs = docs()
        if (allDocs.isEmpty() || queries.none { it.isNotBlank() }) return emptyList()
        // flatten corpus: (doc, chunkIndex, text)
        val corpus = allDocs.flatMap { d -> d.chunks.mapIndexed { i, t -> Triple(d, i, t) } }
        if (corpus.isEmpty()) return emptyList()
        val tokenized = corpus.map { tokenize(it.third) }
        val avgLen = tokenized.map { it.size }.average().takeIf { it > 0 } ?: 1.0
        val n = corpus.size
        // document frequency per term
        val df = HashMap<String, Int>()
        tokenized.forEach { toks ->
            toks.toSet().forEach { t -> df[t] = (df[t] ?: 0) + 1 }
        }

        fun bm25(queryTokens: List<String>, idx: Int): Double {
            val toks = tokenized[idx]
            if (toks.isEmpty()) return 0.0
            val lenNorm = 1.0 - B + B * toks.size / avgLen
            var score = 0.0
            for (qt in queryTokens.toSet()) {
                val tf = toks.count { it == qt }
                if (tf == 0) continue
                val d = df[qt] ?: 0
                val idf = Math.log(1.0 + (n - d + 0.5) / (d + 0.5))
                score += idf * tf * (K1 + 1.0) / (tf + K1 * lenNorm)
            }
            return score
        }

        val best = HashMap<Pair<String, Int>, Double>()
        for (q in queries) {
            val qTokens = tokenize(q)
            if (qTokens.isEmpty()) continue
            for (i in corpus.indices) {
                val s = bm25(qTokens, i)
                if (s <= 0.0) continue
                val key = corpus[i].first.name to corpus[i].second
                if (s > (best[key] ?: 0.0)) best[key] = s
            }
        }
        return best.entries
            .sortedByDescending { it.value }
            .take(k.coerceIn(1, 20))
            .map { (key, score) ->
                val doc = corpus.first { it.first.name == key.first && it.second == key.second }
                Hit(doc.first.name, key.second, doc.third, score)
            }
    }

    companion object {
        private const val K1 = 1.5
        private const val B = 0.75

        /** Language-agnostic tokenizer: lowercase, split on non-alphanumerics. */
        fun tokenize(s: String): List<String> =
            s.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length in 1..32 }
    }
}

/**
 * Layout-respecting recursive chunker (RAGFlow's core insight: naive slicing
 * destroys meaning — paragraphs first, sentences next, hard cut last resort;
 * ~15% overlap so chunk edges keep their context).
 */
object Chunker {
    private const val TARGET = 900   // ~225 tokens — retrieval-precise yet contextful
    private const val OVERLAP = 130  // ~15% of TARGET

    fun chunk(text: String): List<String> {
        val norm = text.replace("\r\n", "\n").replace('\t', ' ').trim()
        if (norm.isEmpty()) return emptyList()
        if (norm.length <= TARGET) return listOf(norm)

        // 1) split on paragraph boundaries, merge small ones
        val paragraphs = norm.split(Regex("\\n{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
        val blocks = mutableListOf<String>()
        var buf = ""
        for (p in paragraphs) {
            val piece = if (p.length > TARGET) splitLongUnit(p) else listOf(p)
            for (s in piece) {
                if (buf.isEmpty()) buf = s
                else if (buf.length + s.length + 1 <= TARGET) buf += "\n" + s
                else { blocks += buf; buf = s }
            }
        }
        if (buf.isNotEmpty()) blocks += buf

        // 2) apply overlap between consecutive blocks
        val out = mutableListOf<String>()
        for (i in blocks.indices) {
            val b = blocks[i]
            val head = if (i > 0) blocks[i - 1].takeLast(OVERLAP) + "…" else ""
            out += (head + b).trim()
        }
        return out
    }

    /** A single unit that alone exceeds TARGET → sentences → hard cut. */
    private fun splitLongUnit(p: String): List<String> {
        val sentences = p.split(Regex("(?<=[.!?。！？:])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        if (sentences.size <= 1) {
            // hard cut with overlap
            val out = mutableListOf<String>()
            var i = 0
            while (i < p.length) {
                out += p.substring(i, minOf(i + TARGET, p.length))
                i += TARGET - OVERLAP
                if (i + TARGET > p.length && i < p.length) continue
            }
            return out
        }
        val out = mutableListOf<String>()
        var buf = ""
        for (s in sentences) {
            if (buf.isEmpty()) buf = s
            else if (buf.length + s.length + 1 <= TARGET) buf += " " + s
            else { out += buf; buf = buf.takeLast(OVERLAP) + " " + s }
        }
        if (buf.isNotBlank()) out += buf
        return out
    }
}
