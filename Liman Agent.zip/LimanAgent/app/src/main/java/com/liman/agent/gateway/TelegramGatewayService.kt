package com.liman.agent.gateway

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.liman.agent.LimanApplication
import com.liman.agent.R
import com.liman.agent.agent.Agent
import com.liman.agent.agent.buildCombo
import com.liman.agent.data.Conversation
import com.liman.agent.data.Entry
import com.liman.agent.llm.Http
import com.liman.agent.llm.ToolCallData
import com.liman.agent.util.now
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Telegram gateway: turns Liman into a Telegram bot (like Hermes' multi-platform
 * gateways). Long-polls getUpdates while a foreground service runs, pairs with
 * a one-time code so strangers can't burn your API keys, and answers with full
 * agent runs. Every remote conversation is also visible inside the app.
 */
class TelegramGatewayService : Service() {

    companion object {
        const val CHANNEL_ID = "liman_gateway"
        const val NOTIF_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, TelegramGatewayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, TelegramGatewayService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var pollJob: Job? = null

    /** chatId → pending ask_user answer */
    private val pendingQuestions = ConcurrentHashMap<String, CompletableDeferred<String>>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIF_ID, buildNotification("Liman gateway active"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val stores = LimanApplication.get(this).container.stores
        val cfg = stores.telegram.state.value
        if (!cfg.enabled || cfg.botToken.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (pollJob?.isActive == true) return START_STICKY
        pollJob = scope.launch { pollLoop(stores) }
        return START_STICKY
    }

    override fun onDestroy() {
        pollJob?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    // ---------------- polling ----------------

    private suspend fun pollLoop(stores: com.liman.agent.data.Stores) {
        val http = Http.toolClient(45)
        var offset = stores.telegram.state.value.lastUpdateId
        while (currentCoroutineContext().isActive) {
            try {
                val cfg = stores.telegram.state.value
                if (!cfg.enabled || cfg.botToken.isBlank()) break

                val url = "https://api.telegram.org/bot${cfg.botToken}/getUpdates" +
                    "?timeout=25&allowed_updates=%5B%22message%22%5D&offset=${offset + 1}"
                val req = Request.Builder().url(url).get().build()
                val body = Http.await(http.newCall(req)).use { r ->
                    if (!r.isSuccessful) {
                        null
                    } else {
                        r.body?.string()
                    }
                }
                if (body != null) {
                    val obj = body.toJsonObject()
                    val updates = obj?.get("result") as? kotlinx.serialization.json.JsonArray
                    if (updates != null) {
                        for (u in updates) {
                            val uo = u as? kotlinx.serialization.json.JsonObject ?: continue
                            (uo["update_id"] as? JsonPrimitive)?.content?.toLongOrNull()?.let {
                                if (it > offset) offset = it
                            }
                            val msg = uo["message"] as? kotlinx.serialization.json.JsonObject ?: continue
                            runCatching { handleMessage(stores, msg) }
                        }
                        stores.telegram.update { it.lastUpdateId = offset }
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                delay(5000)
            }
        }
        stopSelf()
    }

    // ---------------- message handling ----------------

    private suspend fun handleMessage(stores: com.liman.agent.data.Stores, msg: kotlinx.serialization.json.JsonObject) {
        val cfgNow = stores.telegram.state.value
        val token = cfgNow.botToken
        val chat = msg["chat"] as? kotlinx.serialization.json.JsonObject ?: return
        val chatId = (chat["id"] as? JsonPrimitive)?.content ?: return
        val text = (msg["text"] as? JsonPrimitive)?.content?.trim() ?: return
        if (text.isEmpty()) return
        val from = (msg["from"] as? kotlinx.serialization.json.JsonObject)
            ?.let { (it["first_name"] as? JsonPrimitive)?.content } ?: "chat"

        // ---- pairing gate ----
        if (chatId !in cfgNow.allowedChatIds) {
            val expected = "/start ${cfgNow.pairingCode}"
            if (text.equals(expected, ignoreCase = true)) {
                stores.telegram.update { it.allowedChatIds = it.allowedChatIds + chatId }
                api(token, "sendMessage", chatId, "✅ Paired! I'm Liman — send me any goal and I'll work on it like in the app.\n/new = start a fresh task · /status = check my brain")
            } else {
                api(token, "sendMessage", chatId, "🔒 This bot is private. Open Liman Agent → Settings → Telegram and send the pairing code shown there, like: /start ABC123")
            }
            return
        }

        // ---- pending ask_user answer ----
        pendingQuestions[chatId]?.let { pending ->
            if (pending.isActive && !text.startsWith("/")) {
                pendingQuestions.remove(chatId)
                pending.complete(text)
                return
            }
        }

        // ---- commands ----
        when {
            text == "/start" || text == "/help" -> {
                api(token, "sendMessage", chatId, "I'm Liman, your pocket agent.\n/new — start a fresh task\n/status — providers & state\nAnything else — I'll work on it in cycles (files, web, code, …) and answer here.")
                return
            }

            text == "/new" -> {
                val conv = stores.conversations.newConversation()
                conv.title = "🤖 TG · $from"
                stores.conversations.save(conv)
                stores.telegram.update { it.chatToConv = it.chatToConv + (chatId to conv.id) }
                api(token, "sendMessage", chatId, "🆕 Fresh task started. What's the goal?")
                return
            }

            text == "/status" -> {
                val provs = stores.providers.state.value.filter { it.enabled }
                val s = stores.settings.state.value
                api(token, "sendMessage", chatId, "🧠 Providers: " + (provs.joinToString { "${it.name} (${it.model})" }.ifEmpty { "none!" }) + "\n🔁 Max cycles: ${s.maxCycles}\n🎯 Skills: ${stores.skills.state.value.count { it.enabled }}\n🛠 MCP servers: ${stores.mcp.state.value.count { it.enabled }}")
                return
            }
        }

        // ---- run the agent ----
        val conv: Conversation = stores.telegram.state.value.chatToConv[chatId]
            ?.let { stores.conversations.load(it) }
            ?: stores.conversations.newConversation().also { c ->
                c.title = "🤖 TG · $from"
                stores.telegram.update { it.chatToConv = it.chatToConv + (chatId to c.id) }
            }

        val typing = scope.launch {
            while (isActive) {
                runCatching { api(token, "sendChatAction", chatId, "typing") }
                delay(4000)
            }
        }

        try {
            val host = TelegramHost(this, stores, token, chatId)
            host.attachConversation(conv)
            val agent = Agent(this, stores, host)
            val outcome = agent.run(conv, text, emptyList())
            val reply = outcome.summary.ifBlank {
                "(task ended without a summary — reason: ${outcome.reason})"
            }
            sendLong(token, chatId, reply)
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            sendLong(token, chatId, "⚠️ Task failed: ${t.message ?: t.toString()}")
        } finally {
            typing.cancel()
        }
    }

    // ---------------- Telegram API ----------------

    private fun api(token: String, method: String, chatId: String, text: String): String {
        val body = buildJsonObject {
            put("chat_id", JsonPrimitive(chatId))
            put("text", JsonPrimitive(text.take(4000)))
        }
        return rawApi(token, method, body.toString())
    }

    private fun rawApi(token: String, method: String, jsonBody: String): String {
        val req = Request.Builder()
            .url("https://api.telegram.org/bot$token/$method")
            .header("Content-Type", "application/json")
            .post(jsonBody.toRequestBody("application/json".toMediaType()))
            .build()
        return try {
            Http.toolClient(30).newCall(req).execute().use { resp ->
                resp.body?.string() ?: ""
            }
        } catch (t: Throwable) {
            ""
        }
    }

    private fun sendLong(token: String, chatId: String, text: String) {
        var remaining = text
        while (remaining.isNotEmpty()) {
            var cut = remaining.lastIndexOf('\n', 3900)
            if (cut <= 0) cut = minOf(3900, remaining.length)
            val chunk = remaining.take(cut).trim()
            if (chunk.isNotEmpty()) api(token, "sendMessage", chatId, chunk)
            remaining = remaining.drop(cut).trim()
        }
    }

    // ---------------- notifications ----------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Telegram gateway",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps the Liman Telegram bot connected" }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Liman Agent gateway")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    // ---------------- headless agent host ----------------

    private class TelegramHost(
        private val service: TelegramGatewayService,
        private val stores: com.liman.agent.data.Stores,
        private val token: String,
        private val chatId: String
    ) : Agent.AgentHost {

        private var conv: Conversation? = null

        fun attachConversation(c: Conversation) {
            conv = c
        }

        override fun postEntry(e: Entry) {
            val c = conv ?: return
            synchronized(c) {
                c.entries = c.entries + e
                c.updatedAt = now()
            }
            // persist asynchronously; the conversation stays inspectable in the app
            service.scope.launch { runCatching { stores.conversations.save(c) } }
        }

        override fun onStreamTick(tick: Agent.StreamTick?) {}

        override suspend fun requestApproval(call: ToolCallData): Boolean {
            val cfg = stores.telegram.state.value
            return if (cfg.autoApproveRemote) {
                true
            } else {
                service.api(
                    token, "sendMessage", chatId,
                    "⚠️ Remote task wants to run '${call.name}' — declined by policy. " +
                        "Enable auto-approve in Settings → Telegram to allow remote tool use."
                )
                false
            }
        }

        override suspend fun askUser(question: String, options: List<String>): String {
            val opts = if (options.isEmpty()) "" else "\nOptions: " + options.joinToString(" / ")
            service.api(token, "sendMessage", chatId, "💬 $question$opts\n(Reply here — I'll wait up to 10 minutes.)")
            val deferred = CompletableDeferred<String>()
            service.registerPendingQuestion(chatId, deferred)
            return try {
                withTimeoutOrNull(600_000) { deferred.await() } ?: "(no reply in time)"
            } finally {
                service.unregisterPendingQuestion(chatId)
            }
        }

        override fun speak(text: String) {}
    }

    fun registerPendingQuestion(chatId: String, deferred: CompletableDeferred<String>) {
        pendingQuestions[chatId] = deferred
    }

    fun unregisterPendingQuestion(chatId: String) {
        pendingQuestions.remove(chatId)
    }
}
