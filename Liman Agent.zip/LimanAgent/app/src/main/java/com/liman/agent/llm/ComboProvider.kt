package com.liman.agent.llm

import com.liman.agent.data.ComboConfig
import com.liman.agent.data.ComboMode
import com.liman.agent.util.now
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

class ComboFailureException(cause: Throwable?) :
    Exception("All providers in the combo failed. Last error: ${cause?.message ?: "unknown"}", cause)

/**
 * The resilient multi-provider engine.
 *
 * Modes:
 *  - FAILOVER:   try providers in order; retry+backoff on transient errors; skip to next on failure
 *  - ROUND_ROBIN: rotate the starting provider each request (load spreading)
 *  - RACE:       query all providers at once, first success wins (burns tokens, lowest latency)
 *
 * Health tracking: a provider that just failed goes to the back of the line
 * for [ComboConfig.cooldownMs] without being fully disabled.
 */
class ComboProvider(
    private val handles: List<Handle>,
    private val cfg: ComboConfig,
    private val onEvent: (String) -> Unit = {},
    private val onStats: (id: String, displayName: String, ok: Boolean, ms: Long, error: String) -> Unit = { _, _, _, _, _ -> },
    private val delayer: suspend (Long) -> Unit = { delay(it) }
) {

    data class Handle(
        val id: String,
        val displayName: String,
        val model: String,
        val runner: ProviderRunner
    )

    private val rrCounter = AtomicLong(0)
    private val lastFail = ConcurrentHashMap<String, Long>()
    /** Handles whose model is gone (404 etc.) — dead for the lifetime of this combo. */
    private val dead = ConcurrentHashMap.newKeySet<String>()

    fun describe(): String {
        if (handles.isEmpty()) return "no provider"
        val arrow = when (cfg.mode) {
            ComboMode.FAILOVER -> " → "
            ComboMode.ROUND_ROBIN -> " ⇄ "
            ComboMode.RACE -> " ⚡ "
        }
        return handles.joinToString(arrow) { it.displayName } + "  [${cfg.mode}]"
    }

    suspend fun complete(
        req: LlmRequest,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)? = null
    ): LlmResult {
        if (handles.isEmpty()) {
            throw IllegalStateException(
                "No providers configured. Open Settings → Providers and add one " +
                    "(Gemini only needs a free API key from aistudio.google.com/apikey)."
            )
        }
        return when (cfg.mode) {
            ComboMode.FAILOVER -> sequence(handles, req, onDelta)
            ComboMode.ROUND_ROBIN -> sequence(rotated(), req, onDelta)
            ComboMode.RACE -> race(handles, req, onDelta)
        }
    }

    private fun rotated(): List<Handle> {
        if (handles.size <= 1) return handles
        val i = (rrCounter.getAndIncrement() % handles.size).toInt()
        return handles.drop(i) + handles.take(i)
    }

    private fun backoffMs(attempt: Int): Long =
        minOf(1_500L * (1L shl (attempt - 1)), 8_000L)

    private fun hasImages(req: LlmRequest): Boolean =
        req.messages.any { m -> m.parts.any { it is LPart.Media && it.mime.startsWith("image/") } }

    /** Classifies provider failures so permanent ones aren't retried forever. */
    private fun classify(t: Throwable): Throwable {
        val msg = t.message ?: ""
        return when {
            t is HttpProvException && looksLikeVisionError(msg) -> VisionUnsupportedException(msg)
            t is HttpProvException && looksLikeInvalidModelError(msg) -> InvalidModelException(msg)
            t is HttpProvException && looksLikeInvalidPayloadError(msg) -> InvalidPayloadException(msg)
            else -> t
        }
    }

    // ---------------- sequential (failover / round-robin) ----------------

    private suspend fun sequence(
        list: List<Handle>,
        req: LlmRequest,
        onDelta: (suspend (String, String) -> Unit)?
    ): LlmResult {
        val t = now()
        val alive = list.filter { it.id !in dead }
        if (alive.isEmpty()) {
            throw ComboFailureException(
                InvalidModelException(
                    "Every model in the combo is unavailable (404 / not found). " +
                        "Update the model name in Settings → Providers."
                )
            )
        }
        val healthy = alive.filter { t - (lastFail[it.id] ?: 0L) > cfg.cooldownMs }
        val unhealthy = alive.filter { h -> healthy.none { it.id == h.id } }
        val ordered = healthy + unhealthy
        val retries = cfg.retriesPerProvider.coerceIn(1, 5)
        var lastError: Throwable? = null
        var visionFails = 0
        val wantImages = hasImages(req)

        for ((index, h) in ordered.withIndex()) {
            var attempt = 0
            while (attempt < retries) {
                attempt++
                val t0 = now()
                try {
                    val attemptKey = "${h.displayName}#$attempt"
                    val r = h.runner.complete(req) { _, text ->
                        onDelta?.invoke(attemptKey, text)
                    }
                    if (r.text.isBlank() && r.toolCalls.isEmpty()) throw EmptyResponseException()
                    onStats(h.id, h.displayName, true, now() - t0, "")
                    return r
                } catch (ce: CancellationException) {
                    throw ce
                } catch (raw: Throwable) {
                    val t2 = classify(raw)
                    lastError = t2
                    val err = t2.message?.take(140) ?: t2.javaClass.simpleName
                    onStats(h.id, h.displayName, false, now() - t0, err)
                    when (t2) {
                        is InvalidModelException -> {
                            dead.add(h.id)
                            onEvent("⚠ ${h.displayName}: model unavailable — removed from this run's combo")
                            break
                        }
                        is VisionUnsupportedException -> {
                            if (wantImages) {
                                visionFails++
                                lastFail[h.id] = now()
                                onEvent("⚠ ${h.displayName} can't accept image input — trying next provider")
                                break
                            }
                        }
                        is InvalidPayloadException -> {
                            onEvent("⚠ ${h.displayName} rejected the request payload ($err)")
                            break
                        }
                    }
                    onEvent("⚠ ${h.displayName} failed (attempt $attempt): $err")
                    if (!isRetryableProviderError(t2)) break // fatal for this provider → next one
                    if (attempt < retries) delayer(backoffMs(attempt))
                }
            }
            lastFail[h.id] = now()
            val next = ordered.getOrNull(index + 1)
            if (next != null && next.id !in dead) {
                onEvent("↻ Switching provider: ${h.displayName} → ${next.displayName}")
            }
        }
        // every path failed with vision errors → tell the agent to go text-only
        if (wantImages && visionFails > 0) {
            throw VisionUnsupportedException(
                "No provider in the combo accepts image input. The agent will continue with text only."
            )
        }
        throw ComboFailureException(lastError)
    }

    // ---------------- race ----------------

    private suspend fun race(
        list: List<Handle>,
        req: LlmRequest,
        onDelta: (suspend (String, String) -> Unit)?
    ): LlmResult = coroutineScope {
        val channel = Channel<kotlin.Result<LlmResult>>(Channel.UNLIMITED)
        val jobs = list.mapIndexed { i, h ->
            launch {
                val t0 = now()
                try {
                    val delta: (suspend (String, String) -> Unit)? =
                        if (i == 0) ({ _, text -> onDelta?.invoke("${h.displayName}#race", text) }) else null
                    val r = h.runner.complete(req, delta)
                    if (r.text.isBlank() && r.toolCalls.isEmpty()) throw EmptyResponseException()
                    onStats(h.id, h.displayName, true, now() - t0, "")
                    channel.send(kotlin.Result.success(r))
                } catch (ce: CancellationException) {
                    throw ce
                } catch (t: Throwable) {
                    val err = t.message?.take(140) ?: t.javaClass.simpleName
                    onStats(h.id, h.displayName, false, now() - t0, err)
                    channel.trySend(kotlin.Result.failure(t))
                }
            }
        }

        var winner: LlmResult? = null
        var failures = 0
        var lastError: Throwable? = null
        while (winner == null && failures < list.size) {
            val r = channel.receive()
            val ok = r.getOrNull()
            if (ok != null) winner = ok
            else {
                failures++
                lastError = r.exceptionOrNull()
            }
        }
        jobs.forEach { it.cancel() }
        channel.close()
        winner ?: throw ComboFailureException(lastError)
    }
}
