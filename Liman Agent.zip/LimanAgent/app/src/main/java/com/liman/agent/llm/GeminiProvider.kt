package com.liman.agent.llm

import com.liman.agent.data.ProviderConfig
import com.liman.agent.util.JSON
import com.liman.agent.util.arr
import com.liman.agent.util.int
import com.liman.agent.util.obj
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Google Gemini via the Generative Language REST API.
 * Ready-to-connect: only an API key is required (free tier available from
 * aistudio.google.com/apikey). Supports function calling, multimodal parts
 * and SSE streaming.
 */
class GeminiProvider(private val config: ProviderConfig) : ProviderRunner {

    companion object {
        /**
         * Free-tier pacing: the Gemini free tier allows only a handful of
         * requests per MINUTE, and Liman is an agent — one user message can
         * mean many model calls (every tool round-trip). After a 429 we
         * record a per-provider cooldown (server-supplied retryDelay, or a
         * sane default) and later calls WAIT it out instead of hammering.
         */
        private val cooldownUntil = java.util.concurrent.ConcurrentHashMap<String, Long>()

        /**
         * Turns a raw Gemini error body into a clean, actionable
         * HttpProvException: extracts `error.message` (no raw JSON dump in
         * the chat), the server's retryDelay (RetryInfo) and whether the
         * violated quota is the free-tier DAILY cap (PerDay) — for which
         * retrying is pointless for hours — or a per-minute cap.
         */
        internal fun parseError(code: Int, rawBody: String): HttpProvException {
            var msg = rawBody.take(400).ifBlank { "request failed" }
            var retryAfterMs: Long? = null
            var daily = false
            var perMinute = false
            try {
                val err = (JSON.parseToJsonElement(rawBody) as? JsonObject)?.obj("error")
                val m = err?.str("message")
                if (!m.isNullOrBlank()) msg = m.take(400)
                val details = err?.get("details") as? JsonArray
                for (d in details.orEmpty()) {
                    val dobj = d as? JsonObject ?: continue
                    val type = dobj.str("@type") ?: continue
                    if (type.contains("RetryInfo")) {
                        val secs = dobj.str("retryDelay")?.trimEnd('s')?.toDoubleOrNull()
                        if (secs != null && secs > 0) retryAfterMs = (secs * 1000).toLong()
                    }
                    if (type.contains("QuotaFailure")) {
                        val viols = (dobj.get("violations") as? JsonArray)?.joinToString { it.toString() } ?: ""
                        if (viols.contains("PerDay")) daily = true
                        if (viols.contains("PerMinute") || viols.contains("generate_content_free_tier_requests")) {
                            perMinute = true
                        }
                    }
                }
            } catch (_: Exception) {
            }
            if (!daily && rawBody.contains("PerDay")) daily = true
            if (retryAfterMs == null && code == 429) retryAfterMs = 20_000L
            return HttpProvException(code, msg, retryAfterMs, daily, perMinute)
        }

        /**
         * Image generation used by the agent's image_generate tool
         * (Gemini "nano-banana"-style image models).
         */
        suspend fun generateImage(
            apiKey: String,
            baseUrlRaw: String,
            model: String,
            prompt: String
        ): Pair<String, ByteArray> = withContext(Dispatchers.IO) {
            var b = baseUrlRaw.trim().trimEnd('/')
            if (b.isEmpty()) b = "https://generativelanguage.googleapis.com"
            if (!b.endsWith("/v1beta") && !b.contains("/v1beta/")) b += "/v1beta"
            val url = "$b/models/${model.removePrefix("models/")}:generateContent"
            val body = buildJsonObject {
                put("contents", JsonArray(listOf(buildJsonObject {
                    put("parts", JsonArray(listOf(buildJsonObject { put("text", prompt) })))
                })))
                put("generationConfig", buildJsonObject {
                    put("responseModalities", JsonArray(listOf(
                        kotlinx.serialization.json.JsonPrimitive("TEXT"),
                        kotlinx.serialization.json.JsonPrimitive("IMAGE")
                    )))
                })
            }.toString()
            val request = Request.Builder()
                .url(url)
                .header("Content-Type", "application/json")
                .header("x-goog-api-key", apiKey)
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            val response = Http.await(Http.toolClient(180).newCall(request))
            response.use {
                if (!it.isSuccessful) {
                    throw parseError(it.code, it.body?.string()?.take(500) ?: "")
                }
                val obj = it.body?.string()?.toJsonObject() ?: throw EmptyResponseException()
                val parts = obj.arr("candidates")?.firstOrNull()
                    ?.let { c -> (c as? JsonObject)?.obj("content") }?.arr("parts") ?: emptyList()
                for (el in parts) {
                    val p = el as? JsonObject ?: continue
                    val inline = p.obj("inlineData") ?: continue
                    val mime = inline.str("mimeType") ?: "image/png"
                    val data = inline.str("data") ?: continue
                    return@withContext mime to android.util.Base64.decode(data, android.util.Base64.NO_WRAP)
                }
                throw HttpProvException(502, "No image in Gemini response: ${obj.toString().take(300)}")
            }
        }
    }

    val displayName: String get() = config.name

    private fun baseUrl(): String {
        var b = config.baseUrl.trim().trimEnd('/')
        if (b.isEmpty()) b = "https://generativelanguage.googleapis.com"
        if (!b.endsWith("/v1beta") && !b.contains("/v1beta/")) b += "/v1beta"
        return b
    }

    override suspend fun complete(
        req: LlmRequest,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?
    ): LlmResult = withContext(Dispatchers.IO) {
        // free-tier pacing: wait out any 429 cooldown (server retryDelay) so
        // the agent's rapid tool-cycle calls don't burn the whole quota window
        val until = cooldownUntil[config.id] ?: 0L
        val waitMs = until - System.currentTimeMillis()
        if (waitMs in 1..150_000) kotlinx.coroutines.delay(waitMs)

        val model = config.model.trim().removePrefix("models/")
        val action = if (req.gen.stream) "streamGenerateContent?alt=sse" else "generateContent"
        val url = "${baseUrl()}/models/$model:$action"
        val body = buildRequest(req)
        val request = Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .header("x-goog-api-key", config.apiKey)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = Http.await(Http.client.newCall(request))
        Http.withCancelClose(response) {
            if (!response.isSuccessful) {
                val e = parseError(response.code, response.body?.string()?.take(1500) ?: "")
                if (e.code == 429) {
                    cooldownUntil[config.id] = System.currentTimeMillis() +
                        (e.retryAfterMs ?: 20_000L).coerceIn(3_000L, 120_000L)
                }
                throw e
            }
            parseResponse(response, req.gen.stream, onDelta, config.name, config.model)
        }
    }

    // ---------------- request building ----------------

    private fun buildRequest(req: LlmRequest): JsonObject {
        val systemText = req.messages
            .filter { it.role == Role.SYSTEM }
            .joinToString("\n\n") { it.textOnly() }

        val contents = ArrayList<JsonObject>()
        for (m in req.messages) {
            when (m.role) {
                Role.SYSTEM -> {}
                Role.USER -> contents.add(buildJsonObject {
                    put("role", "user")
                    put("parts", JsonArray(m.parts.mapNotNull { p ->
                        when (p) {
                            is LPart.Text -> if (p.text.isBlank()) null
                            else buildJsonObject { put("text", p.text) }
                            is LPart.Media -> buildJsonObject {
                                put("inlineData", buildJsonObject {
                                    put("mimeType", p.mime)
                                    put("data", p.b64)
                                })
                            }

                            else -> null
                        }
                    }))
                })

                Role.ASSISTANT -> {
                    val parts = ArrayList<JsonObject>()
                    m.parts.filterIsInstance<LPart.Text>()
                        .filter { it.text.isNotBlank() }
                        .forEach { parts.add(buildJsonObject { put("text", it.text) }) }
                    m.parts.filterIsInstance<LPart.ToolCallPart>().forEach { c ->
                        val args = c.argsJson.toJsonObject()
                            ?: runCatching { JSON.parseToJsonElement(c.argsJson) as? JsonObject }.getOrNull()
                        parts.add(buildJsonObject {
                            put("functionCall", buildJsonObject {
                                put("name", c.name)
                                put("args", args ?: buildJsonObject {
                                    // non-object args would be rejected: wrap raw
                                    put("_raw", c.argsJson.take(400))
                                })
                            })
                        })
                    }
                    if (parts.isNotEmpty()) contents.add(buildJsonObject {
                        put("role", "model")
                        put("parts", JsonArray(parts))
                    })
                }

                Role.TOOL -> {
                    val parts = m.parts.filterIsInstance<LPart.ToolResultPart>().map { r ->
                        buildJsonObject {
                            put("functionResponse", buildJsonObject {
                                put("name", r.name)
                                put("response", buildJsonObject { put("output", r.text) })
                            })
                        }
                    }
                    if (parts.isNotEmpty()) contents.add(buildJsonObject {
                        put("role", "user")
                        put("parts", JsonArray(parts))
                    })
                }
            }
        }

        // Gemini wants strict alternation; merge consecutive same-role contents.
        val merged = ArrayList<JsonObject>()
        for (c in contents) {
            val role = c.str("role")
            val last = merged.lastOrNull()
            if (last != null && last.str("role") == role) {
                val combined = (last.arr("parts") ?: JsonArray(emptyList())) + (c.arr("parts") ?: JsonArray(emptyList()))
                merged[merged.size - 1] = buildJsonObject {
                    put("role", role ?: "user")
                    put("parts", JsonArray(combined))
                }
            } else {
                merged.add(c)
            }
        }

        return buildJsonObject {
            if (systemText.isNotBlank()) put("systemInstruction", buildJsonObject {
                put("parts", JsonArray(listOf(buildJsonObject { put("text", systemText) })))
            })
            put("contents", JsonArray(merged))
            if (req.tools.isNotEmpty()) {
                put("tools", JsonArray(listOf(buildJsonObject {
                    put("functionDeclarations", JsonArray(req.tools.map { t ->
                        buildJsonObject {
                            put("name", t.name)
                            put("description", t.description)
                            // Gemini rejects unknown schema keys with
                            // "Invalid JSON payload received. Unknown name …"
                            put("parameters", GeminiSchema.sanitize(safeSchema(t.parametersJson)))
                        }
                    }))
                })))
            }
            put("generationConfig", buildJsonObject {
                put("maxOutputTokens", req.gen.maxTokens)
            })
        }
    }

    // ---------------- response parsing ----------------

    private suspend fun parseResponse(
        response: okhttp3.Response,
        stream: Boolean,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?,
        providerName: String,
        model: String
    ): LlmResult {
        val text = StringBuilder()
        val calls = ArrayList<ToolCallData>()
        var finish: String? = null
        var usage: Usage? = null
        var callCounter = 0

        fun consumeChunk(obj: JsonObject) {
            obj.obj("usageMetadata")?.let { u ->
                usage = Usage(u.int("promptTokenCount") ?: 0, u.int("candidatesTokenCount") ?: 0)
            }
            val cand = obj.arr("candidates")?.firstOrNull() as? JsonObject ?: return
            cand.str("finishReason")?.let { finish = it }
            val parts = cand.obj("content")?.arr("parts") ?: return
            for (el in parts) {
                val p = el as? JsonObject ?: continue
                p.str("text")?.let { text.append(it) }
                p.obj("functionCall")?.let { fc ->
                    calls.add(
                        ToolCallData(
                            id = "gem-${callCounter++}",
                            name = fc.str("name") ?: "",
                            argsJson = fc.obj("args")?.toString() ?: "{}"
                        )
                    )
                }
            }
        }

        if (stream) {
            Http.readLines(response) { line ->
                if (!line.startsWith("data:")) return@readLines
                val data = line.removePrefix("data:").trim()
                if (data.isEmpty()) return@readLines
                val obj = data.toJsonObject() ?: return@readLines
                consumeChunk(obj)
                onDelta?.invoke("gemini", text.toString())
            }
        } else {
            val obj = response.body?.string()?.toJsonObject() ?: throw EmptyResponseException()
            consumeChunk(obj)
        }

        return LlmResult(
            text = text.toString(),
            toolCalls = calls,
            finishReason = finish,
            usage = usage,
            providerName = providerName,
            modelName = model
        )
    }

}
