package com.liman.agent.agent

/**
 * v2.23.0 — LOCAL BRAIN + SURVIVAL KIT (Termux).
 *
 * LOCAL BRAIN: a small LLM (Qwen2.5-0.5B/1.5B Q4 GGUF) served by
 * llama.cpp's OpenAI-compatible llama-server INSIDE Termux on
 * 127.0.0.1:8085 — the same localhost the Termux bridge already uses.
 * Result: Liman works with ZERO API keys (out of the box), fully offline,
 * in total privacy — and auto-escalates to the router when a task needs
 * a bigger brain. Honest limits: a 0.5B model is for light text work
 * (summaries, classification, quick drafting), not hard reasoning.
 *
 * SURVIVAL KIT: Termux:Boot (F-Droid companion app) runs a boot script —
 * wake-lock + crond — so schedules and the brain survive reboots. OEM
 * battery killers are the enemy; the status check tells the user exactly
 * what to whitelist.
 */
object LocalBrain {

    const val PORT = 8085
    const val BASE_URL = "http://127.0.0.1:$PORT/v1"
    const val DEFAULT_MODEL = "qwen2.5-0.5b-instruct-q4_k_m"

    private const val MODEL_URL_05B =
        "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf"
    private const val MODEL_URL_15B =
        "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf"

    fun modelUrl(size: String): String = if (size.contains("1.5")) MODEL_URL_15B else MODEL_URL_05B

    /** One-time: install llama.cpp + download the model (~400 MB / ~1 GB). */
    fun setupScript(size: String): String = """
        set -e
        echo '=== installing llama.cpp (one-time) ==='
        pkg install -y llama-cpp
        command -v llama-server >/dev/null 2>&1 || { echo 'LLAMA_MISSING: llama-server not in this Termux build — try: pkg install root-repo && pkg install llama-cpp, or build from github.com/ggml-org/llama.cpp'; exit 1; }
        mkdir -p ~/liman-llama
        if [ ! -f ~/liman-llama/model.gguf ]; then
          echo '=== downloading model (${if (size.contains("1.5")) "~1 GB" else "~400 MB"}) — one-time ==='
          curl -L --progress-bar -o ~/liman-llama/model.gguf "${modelUrl(size)}"
          ls -la ~/liman-llama/model.gguf
        fi
        echo 'LIMAN_LOCAL_SETUP_OK — now: local_ai {action:"start"}'
    """.trimIndent()

    /** Start the OpenAI-compatible server in the background (survives this script). */
    fun startScript(ctxLen: Int = 4096): String = """
        if curl -s --max-time 3 http://127.0.0.1:$PORT/v1/models | grep -q data; then
          echo 'ALREADY_RUNNING'
          exit 0
        fi
        command -v llama-server >/dev/null 2>&1 || { echo 'llama-server missing — run local_ai {action:"setup"} first'; exit 1; }
        [ -f ~/liman-llama/model.gguf ] || { echo 'model missing — run local_ai {action:"setup"} first'; exit 1; }
        nohup llama-server --host 127.0.0.1 --port $PORT -m ~/liman-llama/model.gguf -c $ctxLen --api-key liman-local -t 4 >/dev/null 2>&1 &
        sleep 8
        if curl -s --max-time 5 http://127.0.0.1:$PORT/v1/models | grep -q data; then
          echo 'LIMAN_LOCAL_AI_RUNNING'
        else
          echo 'server did not come up within 8s — it may still be loading; retry status in ~30s'
        fi
    """.trimIndent()

    fun stopScript(): String = """
        pkill -f 'llama-server.*$PORT' && echo 'STOPPED' || echo 'not running'
    """.trimIndent()

    fun statusScript(): String = """
        command -v llama-server >/dev/null 2>&1 && echo 'llama-cpp:installed' || echo 'llama-cpp:missing'
        [ -f ~/liman-llama/model.gguf ] && echo "model:$(stat -c%s ~/liman-llama/model.gguf) bytes" || echo 'model:missing'
        if curl -s --max-time 4 http://127.0.0.1:$PORT/v1/models | grep -q data; then echo 'server:RUNNING'; else echo 'server:stopped'; fi
        [ -f ~/.termux/boot/liman-brain.sh ] && echo 'boot-script:ok' || echo 'boot-script:missing'
        echo 'PROBE-DONE'
    """.trimIndent()

    /** The survival kit: Termux:Boot script (wake-lock + cron heartbeat + optional brain). */
    fun survivalScript(startBrainToo: Boolean): String = """
        set -e
        pkg install -y cronie termux-services unzip 2>/dev/null || pkg install -y cronie
        mkdir -p ~/.termux/boot
        cat > ~/.termux/boot/liman-survival.sh <<'EOS'
        #!/data/data/com.termux/files/usr/bin/sh
        termux-wake-lock
        sv-enable crond 2>/dev/null || crond 2>/dev/null
        EOS
        chmod +x ~/.termux/boot/liman-survival.sh
        ${if (startBrainToo) """
        cat > ~/.termux/boot/liman-brain.sh <<'EOS'
        #!/data/data/com.termux/files/usr/bin/sh
        sleep 20
        nohup llama-server --host 127.0.0.1 --port $PORT -m ~/liman-llama/model.gguf -c 4096 --api-key liman-local -t 4 >/dev/null 2>&1 &
        EOS
        chmod +x ~/.termux/boot/liman-brain.sh
        """.trimIndent() else "# (brain autostart not requested)"
        }
        termux-wake-lock || true
        crond 2>/dev/null || sv-enable crond 2>/dev/null || true
        echo 'LIMAN_SURVIVAL_OK'
        echo 'NOTE: install the Termux:Boot app (F-Droid) and open it once, or boot scripts will not run. Also whitelist Termux from battery optimization (Settings → Battery → Termux → No restrictions).'
    """.trimIndent()

    /** JSON body for the OpenAI-compatible /v1/chat/completions probe. */
    fun probeBody(): String =
        """{"model":"$DEFAULT_MODEL","messages":[{"role":"user","content":"Say OK"}],"max_tokens":8}"""

    /** Values for adding the provider inside Liman (Settings → Providers). */
    fun providerHints(): String =
        "Add provider: kind=OpenAI-compatible · baseUrl=$BASE_URL · apiKey=liman-local · model=$DEFAULT_MODEL"
}
