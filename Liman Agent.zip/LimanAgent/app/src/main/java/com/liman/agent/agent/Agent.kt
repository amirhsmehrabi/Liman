package com.liman.agent.agent

import android.content.Context
import com.liman.agent.data.AgentSettings
import com.liman.agent.data.Conversation
import com.liman.agent.data.Entry
import com.liman.agent.data.ProviderKind
import com.liman.agent.data.ReviewMode
import com.liman.agent.data.Stores
import com.liman.agent.llm.ComboProvider
import com.liman.agent.llm.EmptyResponseException
import com.liman.agent.llm.InvalidModelException
import com.liman.agent.llm.InvalidPayloadException
import com.liman.agent.llm.OpenCodeFreeProvider
import com.liman.agent.llm.VisionUnsupportedException
import com.liman.agent.llm.GenSettings
import com.liman.agent.llm.HttpProvException
import com.liman.agent.llm.LlmMessage
import com.liman.agent.llm.LlmRequest
import com.liman.agent.llm.LlmResult
import com.liman.agent.llm.LPart
import com.liman.agent.llm.OpenAiProvider
import com.liman.agent.llm.AnthropicProvider
import com.liman.agent.llm.WebChatProvider
import com.liman.agent.llm.GeminiProvider
import com.liman.agent.llm.ProviderRunner
import com.liman.agent.llm.Role
import com.liman.agent.llm.ToolCallData
import com.liman.agent.llm.ToolSpec
import com.liman.agent.util.arr
import com.liman.agent.util.ellipsize
import com.liman.agent.util.estimateTokens
import com.liman.agent.util.fmtBytes
import com.liman.agent.util.genId
import com.liman.agent.util.int
import com.liman.agent.util.now
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import com.liman.agent.util.truncateMiddle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.serialization.json.JsonPrimitive
import java.io.File

/** Signals that the request exceeded the model's context — caller compacts and retries. */
class ContextTooLongException(message: String) : Exception(message)

/**
 * Liman's cycle engine:
 *
 *   ORIENT → PLAN → [ THINK → ACT (tools) → OBSERVE ]× → VERIFY (self-review) → FINISH
 *
 * Efficiency & resilience features:
 *  - optional planning pass before the loop
 *  - parallel execution of read-only tool batches
 *  - loop detection (identical repeated tool calls → nudge, then stop)
 *  - context budget with 3-stage compaction (truncate → drop old media → summarize)
 *  - self-review after finishing (report-only or iterate mode)
 *  - provider failover handled by the ComboProvider at every LLM call
 */
class Agent(
    private val appContext: Context,
    private val stores: Stores,
    private val host: AgentHost,
    private val isSubagent: Boolean = false
) {

    interface AgentHost {
        /** Thread-safe; the host persists + renders the entry. */
        fun postEntry(e: Entry)

        fun onStreamTick(tick: StreamTick?)

        /**
         * Live run status for the UI heartbeat: what the agent is doing now
         * and whether it is blocked/waiting (retry, network, approval…).
         */
        fun onStatus(phase: String, waiting: Boolean) {}

        suspend fun requestApproval(call: ToolCallData): Boolean

        suspend fun askUser(question: String, options: List<String>): String

        fun speak(text: String)

        /**
         * v2.31 — live mission/roadmap state: fired whenever the mission tool
         * plans or updates, so the UI checklist card tracks progress in real
         * time. Default no-op (headless/subagent hosts).
         */
        fun onMissionState(title: String, tasks: List<MissionTask>) {}
    }

    data class StreamTick(val attemptKey: String, val text: String, val cycle: Int)

    data class RunStats(
        var cycles: Int = 0,
        var toolCalls: Int = 0,
        var mutatingCalls: Int = 0,
        var tokensIn: Int = 0,
        var tokensOut: Int = 0,
        var startedAt: Long = now(),
        val providerResults: MutableMap<String, Int> = LinkedHashMap()
    ) {
        fun summaryLine(): String {
            val secs = (now() - startedAt) / 1000
            val providers = providerResults.entries.joinToString(", ") { "${it.key}×${it.value}" }
                .ifEmpty { "none" }
            return "Run stats: $cycles cycle(s) · $toolCalls tool call(s) ($mutatingCalls mutating) · " +
                "$tokensIn tok in / $tokensOut tok out · providers: $providers · ${secs}s"
        }
    }

    data class RunOutcome(val summary: String, val reason: String)

    private data class Review(
        val score: Int,
        val verdict: String,
        val critique: String,
        val issues: List<String>
    )

    suspend fun run(
        conv: Conversation,
        userText: String,
        ingested: List<FileIngestor.Ingested>,
        usageChatId: String? = null,
        resume: Boolean = false,
        /** v2.31 — subagents inherit the PARENT's workspace (chat or root). */
        workspaceOverride: File? = null
    ): RunOutcome {
        // CREDIT METER: which chat the usage dashboard should bill this run
        // to (subagent calls are attributed to the parent conversation).
        val usageChat = usageChatId ?: conv.id
        val settings = stores.settings.state.value
        // v2.31 — PER-CHAT WORKSPACES: own folder per conversation (new chats),
        // root for legacy chats / scheduled missions / overridden subagents.
        val workspace = workspaceOverride
            ?: (if (conv.ownWorkspace) stores.chatWorkspace(conv.id) else stores.workspace)
        // v2.36 — DELIVERABLES: snapshot the workspace before the run so every
        // file the run creates/modifies can be attached to the final answer.
        val wsBefore = Deliverables.inventory(workspace)
        val stats = RunStats()
        // v2.35.0 — declared at run() scope: the error/cancel catch blocks
        // also feed it to the cross-run lesson writer in finishRun.
        val progress = RunProgress()
        var history: List<LlmMessage> = hydrate(conv.llmMessages, workspace)

        // effective goal: on resume it comes from the checkpoint (v2.20)
        var goal = userText
        try {
            // ---------- v2.20 CRASH RECOVERY (LangGraph checkpoint) ----------
            // A surviving checkpoint means the process died mid-run; rehydrate
            // the exact transcript and continue instead of starting over.
            if (resume) {
                val cp = RunCheckpointer.load(stores.runstate, conv.id)
                if (cp != null) {
                    history = hydrate(cp.messages, workspace)
                    goal = cp.goal
                    host.postEntry(
                        Entry.NoteEntry("⚡ Resuming interrupted run from cycle ${cp.cycle} — the checkpoint survived the crash.", "info")
                    )
                    history = history + LlmMessage(
                        Role.USER,
                        listOf(
                            LPart.Text(
                                "[System] Your run was interrupted at cycle ${cp.cycle}. The transcript above is exactly where you stopped. " +
                                    "Continue the task now — do NOT redo finished work (check workspace files if unsure) and finish with the final summary when done."
                            )
                        )
                    )
                }
            } else {
            // ---------- user message ----------
            val parts = buildList {
                val t = userText.ifBlank { if (ingested.isEmpty()) "" else "Please analyze the attached file(s)." }
                if (t.isNotBlank()) add(LPart.Text(t))
                ingested.forEach { ing ->
                    val info = "[Attached file: ${ing.displayName} — ${ing.kindNote}, ${ing.sizeBytes.fmtBytes()}]"
                    add(LPart.Text(if (!ing.text.isNullOrEmpty()) "$info\n${ing.text}" else info))
                    ing.media.forEach { add(it) }
                }
            }
            if (parts.isEmpty()) return finishRun(conv, history, "Empty request.", "noop")
            history = history + LlmMessage(Role.USER, parts)
            host.postEntry(Entry.UserEntry(userText.ifBlank { "(files)" }, ingested.map { it.displayName }))
            }

            // v2.20 — LangGraph checkpoint: snapshot run state before the loop
            RunCheckpointer.save(
                stores.runstate,
                CheckpointData(conv.id, goal, 0, now(), dehydrate(history))
            )

            // ---------- combo + tools (vision-first ordering when images present) ----------
            // v2.20: computed from history (not `parts`) so the resume path —
            // which skips the user-message block — also detects images
            val hasImages = history.lastOrNull { it.role == Role.USER }?.parts
                ?.any { it is LPart.Media && it.mime.startsWith("image/") } == true
            if (hasImages) host.postEntry(Entry.NoteEntry("👁 Images attached — vision-capable models will be tried first", "info"))
            val combo = buildCombo(stores, { msg -> host.postEntry(Entry.NoteEntry(msg, "switch")) }, hasImages)

            // Skills (self-improvement layer) — model-guide ships built-in
            ModelGuide.ensureInstalled(stores)
            val skillSystem = SkillSystem(stores)

            // MCP servers → dynamic tools
            val dynamicTools = mutableListOf<DynamicTool>()
            for (srv in stores.mcp.state.value.filter { it.enabled && it.url.isNotBlank() }) {
                runCatching {
                    val client = McpClient(srv.url, srv.bearerToken)
                    client.initialize()
                    val remoteTools = client.listTools()
                    remoteTools.forEach { t ->
                        val toolName = ("mcp_" + srv.name.filter { it.isLetterOrDigit() }.lowercase() +
                            "_" + t.name.filter { it.isLetterOrDigit() }.lowercase()).take(60)
                        dynamicTools += DynamicTool(
                            ToolSpec(
                                toolName,
                                ("[MCP ${srv.name}] " + t.description).take(900),
                                t.inputSchemaJson
                            ),
                            if (t.readOnly) ToolRisk.SAFE else ToolRisk.WRITE
                        ) { args ->
                            val r = client.callTool(t.name, args)
                            ToolOutcome(r.text, !r.isError, r.media)
                        }
                    }
                    host.postEntry(
                        Entry.NoteEntry("🔌 MCP '${srv.name}' connected — ${remoteTools.size} tools available", "info")
                    )
                }.onFailure {
                    host.postEntry(
                        Entry.NoteEntry("🔌 MCP '${srv.name}' connection failed: ${it.message?.take(140)}", "warn")
                    )
                }
            }

            val tools = ToolRegistry(
                ToolContext(
                    appContext = appContext,
                    workspace = workspace,
                    stores = stores,
                    providers = stores.providers.state.value,
                    requestApproval = { host.requestApproval(it) },
                    askUser = { q, o -> host.askUser(q, o) },
                    onPromptAnswered = { q, a -> host.postEntry(Entry.PromptEntry(q, a)) },
                    skillSystem = skillSystem,
                    spawnSubagent = if (!isSubagent && settings.subagentsEnabled) {
                        { objective, contextNote -> runSubagent(objective, contextNote, goal, usageChat, workspace) }
                    } else null,
                    dynamicTools = dynamicTools,
                    onMissionState = { title, tasks -> host.onMissionState(title, tasks) }
                )
            )

            // ---------- automatic skill loading ----------
            if (settings.skillsAutoLoad && skillSystem.enabled().isNotEmpty()) {
                val picked = runCatching {
                    skillSystem.pickForRequest(goal.ifBlank { "(analyze the attached files)" }, combo)
                }.getOrDefault(emptyList())
                if (picked.isNotEmpty()) {
                    val instructions = skillSystem.instructionsFor(picked)
                    history = history + LlmMessage(
                        Role.USER,
                        listOf(
                            LPart.Text(
                                "[Skill instructions auto-loaded for this task — follow them where relevant]\n$instructions"
                            )
                        )
                    )
                    host.postEntry(Entry.NoteEntry("🎯 Skills auto-loaded: ${picked.joinToString()}", "info"))
                }
            }

            // ---------- v2.36: PLANNING CEREMONY REMOVED ----------
            // The pre-run "Planning…" pass and the Plan/Build mode never worked
            // well (an extra LLM call before every task; a mode users had to
            // manage). Gone. The mission tool still gives multi-step work a
            // LIVE checklist — the agent plans by DOING, one step at a time.
            val simpleTask = TaskHeuristics.isSimpleTask(goal)
            DiagLog.noteRun()
            DiagLog.log("agent", "run start — goal: " + goal.take(160) + " · review=${settings.reviewMode} · simpleTask=$simpleTask")

            // prompt right-sizing: a weak first-combo model (flash-lite, minis,
            // 7B-class, anonymous free) gets the compact prompt with the goal
            // anchored at the top — weak models drown in long prompts
            val compactPrompt = runCatching {
                val comboIds = stores.combo.state.value.providerIds
                val firstModel = stores.providers.state.value
                    .firstOrNull { it.id in comboIds }?.model
                    ?: stores.providers.state.value.firstOrNull()?.model.orEmpty()
                PromptSizing.compactFor(firstModel)
            }.getOrDefault(false)

            // ---------- main cycle loop ----------
            var cycle = 0
            var reviewRound = 0
            var lastSig: String? = null
            var repeats = 0
            // HERO MODE budget: how many times we may push an all-talk reply
            // back to the model with an "act NOW" nudge (per run).
            var nudgesUsed = 0
            // v2.35.0 — salvage coaching + finish-gate budgets (per run)
            var formatRescues = 0
            var finishRejects = 0
            // v2.34.0 — THE PROGRESS AUDITOR: repetition / stall / chatter detection
            // (instantiated at run() scope since v2.35.0 — see above)

            while (true) {
                // v2.31 — subagents stay focused: hard cap so one delegated
                // subtask can't eat the whole run budget.
                val cycleCap = if (isSubagent) minOf(settings.maxCycles, 12) else settings.maxCycles
                if (cycle >= cycleCap) {
                    DiagLog.warn("agent", "cycle limit $cycleCap reached — tools=${stats.toolCalls} tokens=${stats.tokensIn + stats.tokensOut}")
                    host.postEntry(Entry.NoteEntry("Stopped: reached the cycle limit ($cycleCap).", "warn"))
                    return finishRun(conv, history, "", "max_cycles", goal, workspace, progress, stats, wsBefore)
                }
                // v2.27.0 RUN CEILING (knotwork logic): an automation that starts
                // looping cannot quietly spend the user's tokens — the run tree
                // is bounded and SAYS SO instead of looking broken.
                val ceiling = settings.runTokenCeiling
                if (ceiling > 0 && stats.tokensIn + stats.tokensOut > ceiling) {
                    DiagLog.warn("ceiling", "run passed ${stats.tokensIn + stats.tokensOut} tokens (ceiling $ceiling) — pausing")
                    host.postEntry(Entry.NoteEntry("⏸ Run ceiling: this run passed ${stats.tokensIn + stats.tokensOut} tokens (ceiling $ceiling — Settings → Agent → Run token ceiling). Everything so far is saved; ask me to continue to resume the work.", "warn"))
                    return finishRun(conv, history, "", "run_ceiling", goal, workspace, progress, stats, wsBefore)
                }
                cycle++
                stats.cycles = cycle

                val sys = SystemPrompt.build(
                    settings, stores, workspace,
                    skillCatalog = skillSystem.catalogText(),
                    mcpToolNames = dynamicTools.map { it.spec.name },
                    isSubagent = isSubagent,
                    userGoal = goal,
                    // weak models get a compact prompt — they drown in long ones
                    compact = compactPrompt
                )
                // NOTE: temperature is not sent to providers — reasoning model
                // families reject it and API defaults work with every model.
                val gen = GenSettings(
                    maxTokens = settings.maxOutputTokens,
                    stream = settings.streaming
                )

                host.onStatus("Thinking · cycle $cycle", false)

                // Never die on provider/network errors: retry with backoff and
                // resume automatically when everything is connected again.
                var result: LlmResult? = null
                var contextRetries = 0
                var messagesUsed: List<LlmMessage> = emptyList()
                while (result == null) {
                    val messages = listOf(LlmMessage(Role.SYSTEM, listOf(LPart.Text(sys)))) + history
                    messagesUsed = messages
                    result = try {
                        completeResilient(combo, LlmRequest(messages, tools.specs, gen), cycle)
                    } catch (cle: ContextTooLongException) {
                        contextRetries++
                        if (contextRetries > 2) throw cle
                        host.onStatus("Context too long — compacting…", true)
                        DiagLog.warn("compact", "context exceeded budget — compacting (retry $contextRetries)")
                        host.postEntry(
                            Entry.NoteEntry(
                                "Context too long — compacting older history and retrying.",
                                "warn"
                            )
                        )
                        history = compactIfNeeded(
                            history,
                            settings.copy(
                                contextBudgetTokens = (settings.contextBudgetTokens / (contextRetries + 1))
                                    .coerceAtLeast(4_000)
                            ),
                            combo
                        )
                        null
                    }
                }
                host.onStreamTick(null)

                // ---------- HERO MODE v2.35.0: rescue tool calls written as text ----------
                // Weak/free models sometimes write the call as JSON — or as
                // Claude-style XML markup (<function_calls><invoke>…). Both
                // shapes are rescued here and the raw markup is scrubbed from
                // the visible text. Before v2.35 the XML shape leaked into
                // the chat as garbage AND the run ended with nothing executed.
                var formatFeedback: String? = null
                if (result.toolCalls.isEmpty()) {
                    val salvage = TextToolCalls.parseDetailed(
                        result.text,
                        tools.specs.map { it.name }.toSet()
                    )
                    if (salvage.calls.isNotEmpty()) {
                        host.postEntry(
                            Entry.NoteEntry(
                                "Recovered ${salvage.calls.size} tool call(s) the model wrote as text — executing them.",
                                "warn"
                            )
                        )
                        result = result.copy(
                            text = TextToolCalls.redact(result.text, salvage),
                            toolCalls = salvage.calls.mapIndexed { i, (n, a) ->
                                ToolCallData("text-$cycle-$i", n, a)
                            }
                        )
                    } else if (salvage.hadMarkup && formatRescues < 2) {
                        // markup that parsed to NOTHING (broken shape or
                        // invented tools): coach the model on the correct
                        // format and continue — never end a run with garbage.
                        formatRescues++
                        result = result.copy(
                            text = TextToolCalls.redact(result.text, salvage)
                                .ifBlank { "(the model attempted a tool call in an unreadable format)" }
                        )
                        formatFeedback = TextToolCalls.formatFeedback(salvage, tools.specs.map { it.name })
                        DiagLog.warn(
                            "salvage",
                            "unreadable tool markup — coaching format ($formatRescues/2), unknown tools: " +
                                salvage.unknownTools.joinToString(",").ifEmpty { "-" }
                        )
                    }
                }

                val usedIn = result.usage?.promptTokens ?: estimateTokens(messagesUsed.joinToString("") { it.textOnly() })
                val usedOut = result.usage?.completionTokens ?: estimateTokens(result.text)
                stats.tokensIn += usedIn
                stats.tokensOut += usedOut
                DiagLog.log("llm", "cycle $cycle · ${result.providerName}/${result.modelName} · in=$usedIn out=$usedOut · ${stats.toolCalls} toolCalls")
                // CREDIT METER: every model call is persisted with an
                // estimated cost so the user can control their spend.
                runCatching {
                    stores.usage.record(
                        usageChat, conv.title,
                        result.providerName.ifBlank { "unknown" },
                        result.modelName.ifBlank { "unknown" },
                        usedIn.toLong(), usedOut.toLong()
                    )
                }
                if (result.providerName.isNotBlank()) {
                    stats.providerResults[result.providerName] = (stats.providerResults[result.providerName] ?: 0) + 1
                }

                history = history + LlmMessage(
                    Role.ASSISTANT,
                    buildList {
                        if (result.text.isNotBlank()) add(LPart.Text(result.text))
                        result.toolCalls.forEach { add(LPart.ToolCallPart(it.id, it.name, it.argsJson)) }
                    }
                )
                host.postEntry(
                    Entry.AssistantEntry(
                        result.text, result.providerName, result.modelName, cycle,
                        now(), result.usage?.promptTokens ?: 0, result.usage?.completionTokens ?: 0
                    )
                )
                if (settings.ttsEnabled && result.text.isNotBlank()) host.speak(result.text)

                val finishCall = result.toolCalls.firstOrNull { it.name == "finish" }
                if (result.toolCalls.isEmpty() || finishCall != null) {
                    var finalText = result.text
                    if (finishCall != null && finalText.isBlank()) {
                        finalText = finishCall.argsJson.toJsonObject()?.str("summary") ?: ""
                    }

                    // ---------- v2.35.0 FORMAT REPAIR: markup that parsed to nothing ----------
                    // The reply contained tool-call markup we could NOT
                    // execute (broken shape / invented tools). Coach the model
                    // on the correct format and continue the run — do NOT end
                    // it with half-garbage.
                    if (formatFeedback != null) {
                        host.postEntry(
                            Entry.NoteEntry(
                                "🔧 Broken tool-call markup — showing the model the correct format ($formatRescues/2)…",
                                "warn"
                            )
                        )
                        history = history + LlmMessage(
                            Role.USER,
                            listOf(LPart.Text(formatFeedback!!))
                        )
                        continue
                    }

                    // ---------- HERO MODE: all talk, no action ----------
                    // "Ok, I will connect to your account and deploy…" is NOT
                    // an acceptable final answer — nothing happened. Reject it
                    // and push the model to actually call its tools (max 2
                    // nudges per run so Q&A replies are never trapped).
                    if (nudgesUsed < 3 && finalText.isNotBlank() &&
                        HeroMode.shouldForceAction(finalText, goal, stats.toolCalls, cycle)
                    ) {
                        nudgesUsed++
                        DiagLog.warn("hero", "nudge $nudgesUsed/3 — all-talk reply rejected, forcing action")
                        host.postEntry(
                            Entry.NoteEntry(
                                "All talk, no tools — pushing Liman to actually DO it (" + nudgesUsed + "/3)…",
                                "warn"
                            )
                        )
                        if (finishCall != null) {
                            // answer the dangling finish call so the history
                            // stays protocol-valid for every provider
                            history = history + LlmMessage(
                                Role.TOOL,
                                listOf(
                                    LPart.ToolResultPart(
                                        finishCall.id,
                                        finishCall.name,
                                        "[System] finish REJECTED: you announced actions but executed nothing. Do the work with your tools now."
                                    )
                                )
                            )
                        }
                        history = history + LlmMessage(
                            Role.USER,
                            listOf(LPart.Text(HeroMode.nudge(nudgesUsed)))
                        )
                        continue
                    }
                    // ---------- v2.35.0 FINISH GATE: read-only finish on a DO-task ----------
                    // The agent read/searched a lot, changed nothing, and now
                    // wants to finish with a thin narrative — the "turns
                    // around itself" failure. Reject (max 2) and demand a
                    // real action; substantial delivered content passes.
                    if (finishCall != null && finishRejects < 2 &&
                        HeroMode.looksLikeTask(goal) && stats.mutatingCalls == 0 &&
                        stats.toolCalls > 0 && finalText.length < 400
                    ) {
                        finishRejects++
                        DiagLog.warn(
                            "finish-gate",
                            "finish rejected ($finishRejects/2) — ${stats.toolCalls} read-only call(s), zero state changes on a do-task"
                        )
                        history = history + LlmMessage(
                            Role.TOOL,
                            listOf(
                                LPart.ToolResultPart(
                                    finishCall.id, finishCall.name,
                                    "[System] finish REJECTED: this is a DO-task, but all ${stats.toolCalls} of your calls " +
                                        "were read-only — nothing was built, changed or delivered. " +
                                        "Take ONE mutating action now (write_file / run_code / http_request / render_html / …). " +
                                        "If you are blocked, call ask_user with the single unblocking question instead. " +
                                        "If the task genuinely needs no artifact, finish again immediately with the complete result."
                                )
                            )
                        )
                        host.postEntry(
                            Entry.NoteEntry(
                                "Finish rejected — research without delivery on a do-task. Demanding a real action…",
                                "warn"
                            )
                        )
                        continue
                    }

                    // ---------- self-review ----------
                    if (settings.reviewMode != ReviewMode.OFF &&
                        reviewRound < settings.maxReviewIterations && finalText.isNotBlank() &&
                        !(simpleTask && stats.toolCalls <= 3)   // v2.24.1: no review tax on light tasks
                    ) {
                        reviewRound++
                        val review = runCatching { runReview(goal, history, finalText, combo, usageChat, conv.title) }.getOrNull()
                        if (review != null) {
                            host.postEntry(Entry.ReviewEntry(review.score, review.verdict, review.critique, review.issues))
                            if (settings.reviewMode == ReviewMode.ITERATE && review.verdict != "complete") {
                                host.postEntry(Entry.NoteEntry("Reviewer verdict: incomplete — iterating…", "review"))
                                history = history + LlmMessage(
                                    Role.USER,
                                    listOf(
                                        LPart.Text(
                                            "[Reviewer feedback — the work is not complete yet. Fix these issues now, then finish again with an updated summary.]\n" +
                                                review.issues.joinToString("\n").ifBlank { "Improve completeness." }
                                        )
                                    )
                                )
                                continue
                            }
                        }
                    }
                    host.postEntry(Entry.NoteEntry(stats.summaryLine(), "stats"))
                    return finishRun(conv, history, finalText, "completed", goal, workspace, progress, stats, wsBefore)
                }

                // ---------- execute tools ----------
                val calls = result.toolCalls
                host.onStatus(
                    if (calls.size == 1) "Acting · ${calls.first().name}" else "Acting · ${calls.size} tools",
                    false
                )
                val outcomes = executeCalls(calls, tools)
                stats.toolCalls += outcomes.size

                // ---------- v2.34.0 PROGRESS AUDIT ----------
                val report = progress.record(cycle, calls, result.text)
                stats.mutatingCalls += report.mutating
                DiagLog.log(
                    "progress",
                    "cycle $cycle · mutating=${report.mutating} new=${report.newDistinct} " +
                        "repeat=${report.repeatedAll} text=${report.textChars} chars"
                )
                if (progress.needsDirective(cycleCap, cycle)) {
                    val directive = progress.directive(cycleCap, cycle)
                    DiagLog.warn("progress", "directive injected (${directive.take(80)}…)")
                    host.postEntry(
                        Entry.NoteEntry(
                            "⚡ Progress audit — repeating without progress. Acting differently or asking you now…",
                            "warn"
                        )
                    )
                    history = history + LlmMessage(
                        Role.USER,
                        listOf(LPart.Text(directive))
                    )
                }

                history = history + LlmMessage(
                    Role.TOOL,
                    outcomes.map { (call, out) ->
                        // REFLEXION (ReAct+Reflexion hybrid): a failed tool gets a
                        // structured self-critique demand — weak models especially
                        // retry the identical call otherwise
                        val text = if (out.ok) out.text else out.text +
                            "\n[System] This attempt FAILED. Before retrying, state in ONE line: what exactly went wrong, and what you will CHANGE — an identical retry fails identically. Two different failed attempts → switch strategy (route-change ladder)."
                        LPart.ToolResultPart(call.id, call.name, text)
                    }
                )
                outcomes.forEach { (call, out) ->
                    host.postEntry(
                        // display-only redaction: tokens never appear in the chat UI
                        // (the model still sees the real args in history)
                        Entry.ToolEntry(cycle, call.name, Secrets.redact(call.argsJson.prettyJson()), out.text, out.ok, out.ms)
                    )
                }

                val producedMedia = outcomes.flatMap { it.second.media }
                if (producedMedia.isNotEmpty()) {
                    history = history + LlmMessage(
                        Role.USER,
                        buildList {
                            add(
                                LPart.Text(
                                    "[System] Files produced by tools, attached below for visual inspection: " +
                                        producedMedia.joinToString(", ") { it.filename }
                                )
                            )
                            addAll(producedMedia.take(6))
                        }
                    )
                }

                // v2.20 — LangGraph checkpoint: survive process death mid-run
                RunCheckpointer.save(
                    stores.runstate,
                    CheckpointData(conv.id, goal, cycle, now(), dehydrate(history))
                )

                // ---------- loop detection ----------
                val sig = calls.joinToString("|") { it.name + ":" + it.argsJson }
                repeats = if (sig == lastSig) repeats + 1 else 0
                lastSig = sig
                if (repeats == 1) {
                    history = history + LlmMessage(
                        Role.USER,
                        listOf(
                            LPart.Text(
                                "[System warning: you just repeated the exact same tool calls with identical arguments. " +
                                    "Repeating again will end the task. Change your approach.]"
                            )
                        )
                    )
                    host.postEntry(Entry.NoteEntry("Loop detected — nudging the agent to change approach.", "warn"))
                }
                if (repeats >= 3) {
                    host.postEntry(Entry.NoteEntry("Stopped: repeated identical actions too many times.", "warn"))
                    return finishRun(conv, history, "", "loop", goal, workspace, progress, stats, wsBefore)
                }

                // ---------- context budget ----------
                // proactive: compact at ~70% fill so quality never rots
                val estTokens = estimateTokens(history.joinToString("") { it.textOnly() })
                val willCompact = estTokens > settings.contextBudgetTokens * 0.7
                if (willCompact) DiagLog.warn("compact", "context at ~${(estTokens * 100 / settings.contextBudgetTokens)}% of budget — compacting early (context-rot guard)")
                history = compactIfNeeded(history, settings, combo, if (willCompact) 0.7 else 1.0)
            }
        } catch (ce: CancellationException) {
            host.onStreamTick(null)
            host.postEntry(Entry.NoteEntry("Stopped by user.", "warn"))
            return finishRun(conv, history, "", "cancelled", goal, workspace, progress, stats, wsBefore)
        } catch (t: Throwable) {
            host.onStreamTick(null)
            // graceful degradation: the run stops, but the user gets a real
            // partial result instead of a dead stop
            host.postEntry(
                Entry.NoteEntry(
                    "Run paused: ${t.message?.take(200) ?: t.toString()}\n" +
                        "Everything done so far is saved — check the workspace files. " +
                        "Fix the provider in Settings and send the task again to continue.",
                    "error"
                )
            )
            val filesSoFar = workspace.walkTopDown().filter { it.isFile }.take(12).toList()
                .joinToString("\n") { "- ${it.name}" }
            val partial = buildString {
                append("I could not finish the task: ")
                append(t.message?.take(200) ?: t.toString())
                if (filesSoFar.isNotBlank()) {
                    append("\n\nWork completed so far (workspace files):\n")
                    append(filesSoFar)
                }
                append("\n\nThe run stopped safely — nothing was lost.")
            }
            return finishRun(conv, history, partial, "error", goal, workspace, progress, stats, wsBefore)
        }
    }

    // ============================================================
    // internals
    // ============================================================

    /**
     * The core "never give up" wrapper around every LLM call.
     * On provider/network failures it waits (connectivity-aware backoff)
     * and retries — the run only continues once things work again.
     * The user sees every state live through [AgentHost.onStatus].
     */
    private suspend fun completeResilient(
        combo: ComboProvider,
        req: LlmRequest,
        cycle: Int
    ): LlmResult {
        val startedAt = now()
        var waitS = 8L
        var postedErrorNote = false
        // adaptive request shape — the agent degrades the request instead of dying
        var current = req
        var strippedImages = false
        var windowed = false
        var droppedTools = false
        var payloadFails = 0

        fun stripImages(r: LlmRequest): LlmRequest = r.copy(
            messages = r.messages.map { m ->
                m.copy(
                    parts = m.parts.map { p ->
                        if (p is LPart.Media) {
                            LPart.Text(
                                "[An image (${p.filename.ifBlank { p.mime }}) was attached but this model cannot see images — it was removed. If the image content matters, describe what you need differently.]"
                            )
                        } else p
                    }
                )
            }
        )

        fun window(r: LlmRequest): LlmRequest {
            if (r.messages.size <= 10) return r
            val head = r.messages.firstOrNull { it.role == Role.USER }
            val tail = r.messages.takeLast(10)
            return r.copy(
                messages = (head?.let { listOf(it) } ?: emptyList()) + tail
            )
        }

        while (true) {
            try {
                return combo.complete(current) { attempt, text ->
                    host.onStreamTick(StreamTick(attempt, text, cycle))
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                val msg = t.message ?: t.toString()

                // request-shape errors that compaction can fix → let caller react
                if (msg.contains("context length", ignoreCase = true) ||
                    msg.contains("too long", ignoreCase = true) ||
                    msg.contains("reduce the length", ignoreCase = true) ||
                    msg.contains("input length", ignoreCase = true) ||
                    msg.contains("prompt is too large", ignoreCase = true)
                ) {
                    throw ContextTooLongException(msg)
                }

                // ---- adaptive recovery ladder: degrade the request, never stall ----
                when (t) {
                    is VisionUnsupportedException -> if (!strippedImages) {
                        strippedImages = true
                        current = stripImages(current)
                        host.postEntry(
                            Entry.NoteEntry(
                                "👁 No provider in the combo can see images — continuing with text only. " +
                                    "The task keeps going; the agent will find another way.",
                                "warn"
                            )
                        )
                        continue
                    }
                    is InvalidPayloadException -> {
                        payloadFails++
                        when {
                            !strippedImages -> {
                                strippedImages = true
                                current = stripImages(current)
                                host.postEntry(Entry.NoteEntry("⚠ Payload rejected — retrying without images", "warn"))
                                continue
                            }
                            !windowed && payloadFails >= 2 -> {
                                windowed = true
                                current = window(current)
                                host.postEntry(Entry.NoteEntry("⚠ Payload rejected — retrying with a trimmed history", "warn"))
                                continue
                            }
                            !droppedTools && payloadFails >= 3 -> {
                                droppedTools = true
                                current = current.copy(tools = emptyList())
                                host.postEntry(
                                    Entry.NoteEntry(
                                        "⚠ Payload still rejected — asking the model to answer directly without tools this turn",
                                        "warn"
                                    )
                                )
                                continue
                            }
                        }
                    }
                }

                // all models dead (e.g. every model 404s) — surface clearly, don't spin 15 min
                if (t.cause is InvalidModelException || t is InvalidModelException) {
                    host.postEntry(
                        Entry.NoteEntry(
                            "⚠ Every model in the combo is unavailable (wrong/removed model names?). " +
                                "Fix the model in Settings → Providers, then send the task again.",
                            "error"
                        )
                    )
                    throw t
                }

                // keep trying for up to 15 minutes, then give up honestly
                if (now() - startedAt > 15 * 60_000L) throw t

                // quota/rate-limit aware waiting: use the server-supplied
                // retryDelay when we have it (Gemini free tier), and treat the
                // free-tier DAILY cap differently — retrying is pointless for
                // hours, so say so honestly and slow the loop way down
                var nextWaitS = waitS
                var quotaDaily = false
                var retryHintS: Long? = null
                (t as? HttpProvException)?.let { he ->
                    if (he.quotaDaily) quotaDaily = true
                    he.retryAfterMs?.let { ra ->
                        retryHintS = (ra / 1000L).coerceIn(6L, 150L)
                    }
                }
                if (quotaDaily) nextWaitS = 300L
                else if (retryHintS != null) nextWaitS = retryHintS!!

                if (!postedErrorNote) {
                    postedErrorNote = true
                    val note = when {
                        quotaDaily ->
                            "⚠️ Gemini free-tier DAILY quota is exhausted — waiting will not help " +
                                "until it resets (around midnight Pacific time). Liman keeps retrying " +
                                "every ~5 min and will instantly use any OTHER provider in your combo. " +
                                "Tips: add a second provider (Settings → Providers), or switch to a " +
                                "flash model — flash models have much higher free limits than pro.\n" +
                                "Details: ${msg.take(160)}"
                        retryHintS != null ->
                            "⚠️ Rate limited (free tier, per-minute) — Liman waits ${retryHintS}s " +
                                "and paces its calls to match, then continues automatically. " +
                                "One agent message = several model calls (every tool step), " +
                                "so free-tier limits are hit faster than in a plain chat app.\n" +
                                "Details: ${msg.take(160)}"
                        else ->
                            "⚠️ LLM call failed: ${msg.take(200)}\n" +
                                "Liman will keep retrying and resume automatically — no action needed."
                    }
                    host.postEntry(Entry.NoteEntry(note, "error"))
                }

                val online = isOnline()
                val waitedSoFar = (now() - startedAt) / 1000
                if (online) {
                    host.onStatus("⚠️ Provider problem — retrying in ${nextWaitS}s (waited ${waitedSoFar}s)", true)
                } else {
                    host.onStatus("📴 Network offline — waiting for connection… (retry in ${nextWaitS}s)", true)
                }
                delay(nextWaitS * 1000)
                waitS = (nextWaitS * 1.7).toLong().coerceAtMost(120L)
                host.onStatus("Retrying…", false)
            }
        }
    }

    private fun isOnline(): Boolean = try {
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val network = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(network)
        caps?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (t: Throwable) {
        true
    }

    private fun finishRun(
        conv: Conversation,
        history: List<LlmMessage>,
        summary: String,
        reason: String,
        goal: String = "",
        workspace: File? = null,
        progress: RunProgress? = null,
        stats: RunStats? = null,
        wsBefore: Map<String, Long>? = null
    ): RunOutcome {
        DiagLog.log("agent", "run finished ($reason)")
        // v2.36 — DELIVERABLES: embed the files this run produced in the chat
        // as downloadable chips right under the final answer.
        runCatching {
            if (workspace != null && wsBefore != null && reason != "cancelled" && reason != "noop") {
                val rootWs = File(appContext.filesDir, "workspace")
                val arts = Deliverables.collect(workspace, wsBefore, rootWs)
                if (arts.isNotEmpty()) {
                    host.postEntry(
                        Entry.FileEntry(arts.map { com.liman.agent.data.Deliverable(it.path, it.name, it.sizeBytes) })
                    )
                    DiagLog.log("deliverables", "${arts.size} file(s) attached to the final answer: " + arts.joinToString { it.name })
                }
            }
        }
        // v2.35.0 — CROSS-RUN LEARNING (Hermes loop): a run that spun, died
        // or completed without ever changing anything leaves a one-line
        // lesson in workspace/.liman-lessons.md — the system prompt injects
        // that file into every later run, so the mistake never repeats.
        runCatching {
            if (workspace != null && progress != null && goal.isNotBlank()) {
                val mutated = (stats?.mutatingCalls ?: 0) > 0
                val bad = reason in setOf("loop", "max_cycles", "run_ceiling", "error") ||
                    (reason == "completed" && !mutated && progress.directivesUsed > 0)
                if (bad) {
                    RunLessons.append(
                        workspace, goal, reason,
                        stats?.cycles ?: progress.cycles, stats?.toolCalls ?: 0, mutated
                    )
                    DiagLog.warn("lessons", "run lesson appended to .liman-lessons.md ($reason)")
                }
            }
        }
        // v2.35.0 — RUN LEDGER + performance audit every 15 runs
        runCatching {
            val audit = RunLedger.record(appContext.filesDir, reason, stats?.cycles ?: 0, stats?.toolCalls ?: 0)
            if (audit != null) {
                host.postEntry(Entry.NoteEntry(audit.headline + "\n" + audit.body, "info"))
                DiagLog.log("audit", "performance audit compiled at run ${audit.runs}")
            }
        }
        // v2.20 — a normal exit clears the checkpoint: a surviving file
        // therefore always means "crashed mid-run" (the resume signal)
        RunCheckpointer.clear(stores.runstate, conv.id)
        conv.llmMessages = dehydrate(history)
        conv.updatedAt = now()
        return RunOutcome(summary, reason)
    }

    private suspend fun executeCalls(
        calls: List<ToolCallData>,
        tools: ToolRegistry
    ): List<Pair<ToolCallData, ToolOutcome>> {
        val allSafe = calls.all { tools.riskOf(it.name) == ToolRisk.SAFE }
        val subagentBatch = calls.size > 1 && calls.all { it.name == "spawn_subagent" }
        // cap parallelism so huge batches don't starve the dispatcher / trip providers
        val capped = calls.take(12)
        val overflow = calls.size - capped.size
        if (overflow > 0) {
            host.postEntry(
                Entry.NoteEntry("⏳ Executing ${capped.size} of ${calls.size} calls now (rest queued next turn)", "info")
            )
        }
        return if ((allSafe && capped.size > 1) || subagentBatch) {
            coroutineScope {
                capped.map { c ->
                    async {
                        runCatching { tools.execute(c) }
                            .getOrElse {
                                if (it is kotlinx.coroutines.CancellationException) throw it
                                ToolOutcome("Tool crashed: ${it.message ?: it.toString()}", false)
                            }
                    }
                }.awaitAll()
            }.mapIndexed { i, out -> capped[i] to out }
        } else {
            capped.map { c ->
                c to runCatching { tools.execute(c) }
                    .getOrElse {
                        if (it is kotlinx.coroutines.CancellationException) throw it
                        ToolOutcome("Tool crashed: ${it.message ?: it.toString()}", false)
                    }
            }
        }
    }

    /**
     * Runs a nested agent with its own cycle, tools and conversation.
     * The subagent's transcript is saved as a normal conversation
     * (title "🤖 …") so the user can inspect exactly what it did.
     */
    private suspend fun runSubagent(objective: String, contextNote: String, parentGoal: String, usageChatId: String? = null, parentWorkspace: File? = null): String {
        val t0 = now()
        host.postEntry(Entry.NoteEntry("🤖 Spawning subagent: ${objective.ellipsize(140)}", "info"))
        val subConv = stores.conversations.newConversation()
        subConv.title = "🤖 ${objective.take(34)}"
        val subHost = object : AgentHost {
            override fun postEntry(e: Entry) {
                synchronized(subConv) {
                    subConv.entries = subConv.entries + e
                    subConv.updatedAt = now()
                }
            }

            override fun onStreamTick(tick: StreamTick?) {}

            override suspend fun requestApproval(call: ToolCallData): Boolean =
                host.requestApproval(call)

            override suspend fun askUser(question: String, options: List<String>): String =
                host.askUser(question, options)

            override fun speak(text: String) {}
        }
        val sub = Agent(appContext, stores, subHost, isSubagent = true)
        val outcome = runCatching {
            sub.run(
                conv = subConv,
                usageChatId = usageChatId,
                // v2.31 — the subagent works in the PARENT's workspace: it must
                // see and change the same files the parent is building with.
                workspaceOverride = parentWorkspace,
                userText = buildString {
                    appendLine("OBJECTIVE: $objective")
                    if (contextNote.isNotBlank()) appendLine("CONTEXT: $contextNote")
                    appendLine("PARENT GOAL: ${parentGoal.take(600)}")
                    appendLine()
                    appendLine("Work independently with your tools, then finish with a concise result: what you found/built and any workspace file paths.")
                },
                ingested = emptyList()
            )
        }
        stores.conversations.save(subConv)
        val summary = outcome.fold(
            onSuccess = { it.summary.ifBlank { "(subagent ended: ${it.reason})" } },
            onFailure = { throw it }
        )
        val secs = (now() - t0) / 1000
        host.postEntry(Entry.SubagentEntry(genId("sub"), objective, "done", "$summary\n(${secs}s)"))
        return summary
    }

    private suspend fun runReview(
        goal: String,
        history: List<LlmMessage>,
        finalText: String,
        combo: ComboProvider,
        usageChatId: String? = null,
        chatTitle: String = ""
    ): Review? {
        val digest = history.takeLast(40).joinToString("\n") { m ->
            when (m.role) {
                Role.USER -> "U: " + m.textOnly().take(400)
                Role.ASSISTANT -> {
                    val calls = m.parts.filterIsInstance<LPart.ToolCallPart>().joinToString(", ") { it.name }
                    val t = m.textOnly().take(300)
                    "A: $t${if (calls.isNotEmpty()) " [called: $calls]" else ""}"
                }

                Role.TOOL -> {
                    val names = m.parts.filterIsInstance<LPart.ToolResultPart>().joinToString(",") { it.name }
                    val head = m.parts.filterIsInstance<LPart.ToolResultPart>().firstOrNull()?.text?.take(220) ?: ""
                    "T($names): $head"
                }

                Role.SYSTEM -> ""
            }
        }.take(15_000)

        val sys = "You are Liman's strict internal reviewer. Judge whether the agent's work fully achieved " +
            "the user's goal. Consider completeness, correctness, and whether claims are backed by tool results. " +
            "Respond with ONLY a JSON object, no markdown fences: " +
            """{"verdict":"complete" or "incomplete","score":<integer 0-10>,"critique":"one or two sentences","issues":["issue", ...]}"""
        val user = "GOAL:\n${goal.take(2000)}\n\nWORK LOG (condensed):\n$digest\n\nFINAL ANSWER:\n${finalText.take(4000)}"

        val res = combo.complete(
            LlmRequest(
                listOf(
                    LlmMessage(Role.SYSTEM, listOf(LPart.Text(sys))),
                    LlmMessage(Role.USER, listOf(LPart.Text(user)))
                ),
                emptyList(),
                GenSettings(0.2, 700, false)
            )
        ) { _, _ -> }

        // CREDIT METER: reviewer calls are model calls too
        runCatching {
            stores.usage.record(
                usageChatId ?: "review", chatTitle,
                res.providerName.ifBlank { "reviewer" },
                res.modelName.ifBlank { "unknown" },
                (res.usage?.promptTokens ?: 0).toLong(),
                (res.usage?.completionTokens ?: 0).toLong()
            )
        }

        val txt = res.text
        val start = txt.indexOf('{')
        val end = txt.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        val obj = txt.substring(start, end + 1).toJsonObject() ?: return null
        return Review(
            score = obj.int("score")?.coerceIn(0, 10) ?: 5,
            verdict = (obj.str("verdict") ?: "incomplete").lowercase(),
            critique = obj.str("critique") ?: "",
            issues = obj.arr("issues")
                ?.mapNotNull { (it as? JsonPrimitive)?.content }
                .orEmpty()
        )
    }

    private suspend fun compactIfNeeded(
        history: List<LlmMessage>,
        settings: AgentSettings,
        combo: ComboProvider,
        fillFactor: Double = 1.0
    ): List<LlmMessage> {
        var h = history
        val budget = settings.contextBudgetTokens
        // v2.29.0 (blueprint §9.1): compact at 60-70% fill, not 100% — "context
        // rot" degrades quality well before the window is full
        val trigger = (budget * fillFactor).toInt()
        if (estimateTokens(h.joinToString("") { it.textOnly() }) <= trigger) return h

        // Stage 1: truncate long tool results
        h = h.map { m ->
            if (m.role == Role.TOOL) {
                LlmMessage(m.role, m.parts.map { p ->
                    if (p is LPart.ToolResultPart && p.text.length > 1200) {
                        p.copy(text = p.text.truncateMiddle(1200))
                    } else p
                })
            } else m
        }
        if (estimateTokens(h.joinToString("") { it.textOnly() }) <= budget) return h

        // Stage 2: drop media from older messages (keep the last 6 intact)
        val cutoff = (h.size - 6).coerceAtLeast(0)
        h = h.mapIndexed { i, m ->
            if (i < cutoff) LlmMessage(m.role, m.parts.filter { it !is LPart.Media }) else m
        }
        val est = estimateTokens(h.joinToString("") { it.textOnly() })
        if (est <= budget || !settings.smartCompaction) return h

        // Stage 3: summarize older turns with the model itself
        val keep = h.takeLast(8)
        val older = h.dropLast(8)
        if (older.isEmpty()) return h
        val digest = older.joinToString("\n") { m ->
            when (m.role) {
                Role.ASSISTANT -> "A: " + m.textOnly().take(600)
                Role.TOOL -> "T: " + m.textOnly().take(400)
                Role.USER -> "U: " + m.textOnly().take(500)
                Role.SYSTEM -> ""
            }
        }.take(12_000)
        val summary = runCatching {
            combo.complete(
                LlmRequest(
                    listOf(
                        LlmMessage(
                            Role.SYSTEM,
                            listOf(
                                LPart.Text(
                                    "You are compacting an agent session. Produce ONLY this structure (compact markdown, under 350 words). " +
                                        "Be exhaustive on constraints, decisions and learned; drop verbose tool output.\n" +
                                        "GOAL: the user's original objective\n" +
                                        "CONSTRAINTS: explicit user constraints and policy limits hit\n" +
                                        "COMPLETED: steps done — with the evidence they worked\n" +
                                        "CURRENT_STATE: device/app/file state right now\n" +
                                        "IN_PROGRESS: what was happening at compaction time\n" +
                                        "NEXT_STEPS: ordered\n" +
                                        "DECISIONS: decision — why — alternatives rejected\n" +
                                        "LEARNED: app quirks, selectors that work, dead ends\n" +
                                        "ARTIFACTS: file paths, urls, ids created"
                                )
                            )
                        ),
                        LlmMessage(Role.USER, listOf(LPart.Text("Compress this work log:\n$digest")))
                    ),
                    emptyList(),
                    GenSettings(0.2, 600, false)
                )
            ) { _, _ -> }
        }.getOrNull()?.text?.trim() ?: return h
        return listOf(LlmMessage(Role.USER, listOf(LPart.Text("[Earlier context summary]\n$summary")))) + keep
    }

    private fun hydrate(messages: List<LlmMessage>, workspace: File): List<LlmMessage> =
        messages.map { m ->
            LlmMessage(m.role, m.parts.map { p ->
                if (p is LPart.Media && p.b64.isBlank() && p.filename.isNotBlank()) {
                    val f = File(workspace, p.filename).sandboxChildSafe(workspace)
                    if (f != null && f.exists()) {
                        val decoded = AndroidMedia.decodeImage(f)
                        if (decoded != null) {
                            LPart.Media(
                                decoded.first,
                                android.util.Base64.encodeToString(decoded.second, android.util.Base64.NO_WRAP),
                                p.filename
                            )
                        } else p
                    } else LPart.Text("[missing image: ${p.filename}]")
                } else p
            })
        }

    private fun dehydrate(messages: List<LlmMessage>): List<LlmMessage> =
        messages.map { m ->
            LlmMessage(m.role, m.parts.map { p ->
                if (p is LPart.Media && p.b64.length > 48_000) p.copy(b64 = "") else p
            })
        }

    private fun File.sandboxChildSafe(root: File): File? = try {
        val r = root.canonicalFile
        val c = this.canonicalFile
        if (c.path.startsWith(r.path + File.separator)) c else null
    } catch (t: Throwable) {
        null
    }

    private fun String.prettyJson(): String =
        runCatching { com.liman.agent.util.JSON.parseToJsonElement(this).toString() }.getOrDefault(this)

}

/** True when the model name looks vision-capable (used for ordering + badges). */
fun looksVisionCapable(model: String): Boolean {
    val m = model.lowercase()
    return listOf("vision", "-vl", "vl-", "gpt-4o", "gpt-4.1", "omni", "gemini", "claude", "llama-3.2", "pixtral", "qwen-vl", "gemma").any { it in m }
}

/** True when the model is free (OpenRouter-style ":free" suffix or 'free' in name). */
fun isFreeModel(model: String): Boolean {
    val m = model.lowercase()
    return m.endsWith(":free") || m.endsWith("-free") || m.contains("free")
}

/** Builds the live ComboProvider from current store state. */
fun buildCombo(stores: Stores, onEvent: (String) -> Unit, wantVision: Boolean = false): ComboProvider {
    val all = stores.providers.state.value.filter { it.enabled }
    val ids = stores.combo.state.value.providerIds.filter { id -> all.any { it.id == id } }
    val ordered = if (ids.isEmpty()) all else ids.mapNotNull { id -> all.firstOrNull { it.id == id } }
    val handles = ArrayList<ComboProvider.Handle>()
    ordered.forEach { cfg ->
        val runner: ProviderRunner = when (cfg.kind) {
            ProviderKind.OPENAI_COMPATIBLE -> OpenAiProvider(cfg)
            ProviderKind.GEMINI -> GeminiProvider(cfg)
            ProviderKind.ANTHROPIC -> AnthropicProvider(cfg)
            ProviderKind.WEB_CHAT -> WebChatProvider(cfg)
            ProviderKind.OPENCODE_FREE -> OpenCodeFreeProvider(cfg)
        }
        handles += ComboProvider.Handle(cfg.id, cfg.name, cfg.model, runner)
        // free-pool expansion: every free model of this provider becomes a failover handle
        if (cfg.useFreePool && cfg.freeModels.isNotEmpty()) {
            cfg.freeModels
                .filter { it != cfg.model }
                .take(12)
                .forEach { m ->
                    val poolCfg = cfg.copy(id = cfg.id, model = m)
                    val r: ProviderRunner = when (cfg.kind) {
                        ProviderKind.OPENAI_COMPATIBLE -> OpenAiProvider(poolCfg)
                        ProviderKind.GEMINI -> GeminiProvider(poolCfg)
                        ProviderKind.ANTHROPIC -> AnthropicProvider(poolCfg)
                        ProviderKind.WEB_CHAT -> WebChatProvider(poolCfg)
                        ProviderKind.OPENCODE_FREE -> OpenCodeFreeProvider(poolCfg)
                    }
                    handles += ComboProvider.Handle(cfg.id, "${cfg.name} (free)", m, r)
                }
        }
    }
    // smart routing: when the request carries images, try vision-capable models first
    val finalHandles = if (wantVision) {
        val (vis, rest) = handles.partition { looksVisionCapable(it.model) }
        if (vis.isNotEmpty()) vis + rest else handles
    } else handles
    return ComboProvider(finalHandles, stores.combo.state.value, onEvent)
}
