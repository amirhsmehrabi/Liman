package com.liman.agent.llm

import com.liman.agent.data.ProviderConfig
import com.liman.agent.util.arr
import com.liman.agent.util.int
import com.liman.agent.util.obj
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Anthropic Messages API (Claude). API-key only, native tool use,
 * multimodal images/documents and SSE streaming.
 */
class AnthropicProvider(private val config: ProviderConfig) : ProviderRunner {

    val displayName: String get() = config.name

    private fun messagesUrl(): String {
        var b = config.baseUrl.trim().trimEnd('/')
        if (b.isEmpty()) b = "https://api.anthropic.com"
        if (b.endsWith("/messages")) return b
        if (!b.endsWith("/v1") && !b.contains("/v1/")) b += "/v1"
        return "$b/messages"
    }

    override suspend fun complete(
        req: LlmRequest,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?
    ): LlmResult = withContext(Dispatchers.IO) {
        val url = messagesUrl()
        val body = buildRequest(req)
        val request = Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .header("x-api-key", config.apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = Http.await(Http.client.newCall(request))
        Http.withCancelClose(response) {
            if (!response.isSuccessful) {
                throw HttpProvException(response.code, response.body?.string()?.take(1500) ?: "")
            }
            parseResponse(response, req.gen.stream, onDelta, config.name, config.model)
        }
    }

    // ---------------- request building ----------------

    private fun buildRequest(req: LlmRequest): JsonObject {
        val systemText = req.messages
            .filter { it.role == Role.SYSTEM }
            .joinToString("\n\n") { it.textOnly() }

        val messages = ArrayList<JsonObject>()
        for (m in req.messages) {
            when (m.role) {
                Role.SYSTEM -> {}

                Role.USER -> {
                    val blocks = ArrayList<JsonObject>()
                    m.parts.filterIsInstance<LPart.Text>()
                        .filter { it.text.isNotBlank() }
                        .forEach { blocks.add(buildJsonObject { put("type", "text"); put("text", it.text) }) }
                    m.parts.filterIsInstance<LPart.Media>().forEach { p ->
                        if (p.mime.startsWith("image/")) {
                            blocks.add(buildJsonObject {
                                put("type", "image")
                                put("source", buildJsonObject {
                                    put("type", "base64")
                                    put("media_type", p.mime)
                                    put("data", p.b64)
                                })
                            })
                        } else if (p.mime == "application/pdf") {
                            blocks.add(buildJsonObject {
                                put("type", "document")
                                put("source", buildJsonObject {
                                    put("type", "base64")
                                    put("media_type", "application/pdf")
                                    put("data", p.b64)
                                })
                            })
                        }
                    }
                    if (blocks.isNotEmpty()) messages.add(buildJsonObject {
                        put("role", "user")
                        put("content", JsonArray(blocks))
                    })
                }

                Role.ASSISTANT -> {
                    val blocks = ArrayList<JsonObject>()
                    m.parts.filterIsInstance<LPart.Text>()
                        .filter { it.text.isNotBlank() }
                        .forEach { blocks.add(buildJsonObject { put("type", "text"); put("text", it.text) }) }
                    m.parts.filterIsInstance<LPart.ToolCallPart>().forEach { c ->
                        val input = c.argsJson.toJsonObject()
                        blocks.add(buildJsonObject {
                            put("type", "tool_use")
                            put("id", c.id)
                            put("name", c.name)
                            put("input", input ?: kotlinx.serialization.json.JsonObject(emptyMap()))
                        })
                    }
                    if (blocks.isNotEmpty()) messages.add(buildJsonObject {
                        put("role", "assistant")
                        put("content", JsonArray(blocks))
                    })
                }

                Role.TOOL -> {
                    val blocks = m.parts.filterIsInstance<LPart.ToolResultPart>().map { r ->
                        buildJsonObject {
                            put("type", "tool_result")
                            put("tool_use_id", r.toolCallId)
                            put("content", r.text)
                        }
                    }
                    if (blocks.isNotEmpty()) messages.add(buildJsonObject {
                        put("role", "user")
                        put("content", JsonArray(blocks))
                    })
                }
            }
        }

        // Merge consecutive same-role messages (Anthropic requires alternation).
        val merged = ArrayList<JsonObject>()
        for (m in messages) {
            val role = m.str("role")
            val last = merged.lastOrNull()
            if (last != null && last.str("role") == role) {
                val combined = (last.arr("content") ?: JsonArray(emptyList())) +
                    (m.arr("content") ?: JsonArray(emptyList()))
                merged[merged.size - 1] = buildJsonObject {
                    put("role", role ?: "user")
                    put("content", JsonArray(combined))
                }
            } else {
                merged.add(m)
            }
        }

        return buildJsonObject {
            if (systemText.isNotBlank()) put("system", systemText)
            put("model", config.model)
            put("max_tokens", req.gen.maxTokens)
            put("stream", req.gen.stream)
            put("messages", JsonArray(merged))
            if (req.tools.isNotEmpty()) {
                put("tools", JsonArray(req.tools.map { t ->
                    buildJsonObject {
                        put("name", t.name)
                        put("description", t.description)
                        put("input_schema", safeSchema(t.parametersJson))
                    }
                }))
            }
        }
    }

    // ---------------- response parsing ----------------

    private class ToolBuilder {
        var id: String = ""
        var name: String = ""
        val input = StringBuilder()
    }

    private suspend fun parseResponse(
        response: okhttp3.Response,
        stream: Boolean,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?,
        providerName: String,
        model: String
    ): LlmResult {
        val text = StringBuilder()
        val toolBuilders = LinkedHashMap<Int, ToolBuilder>()
        var finish: String? = null
        var usageIn = 0
        var usageOut = 0

        if (stream) {
            Http.readLines(response) { line ->
                if (!line.startsWith("data:")) return@readLines
                val data = line.removePrefix("data:").trim()
                if (data.isEmpty()) return@readLines
                val obj = data.toJsonObject() ?: return@readLines
                when (obj.str("type")) {
                    "message_start" -> {
                        usageIn = obj.obj("message")?.obj("usage")?.int("input_tokens") ?: 0
                    }

                    "content_block_start" -> {
                        val idx = obj.int("index") ?: 0
                        val block = obj.obj("content_block")
                        if (block?.str("type") == "tool_use") {
                            toolBuilders[idx] = ToolBuilder().apply {
                                id = block.str("id") ?: ""
                                name = block.str("name") ?: ""
                            }
                        }
                    }

                    "content_block_delta" -> {
                        val delta = obj.obj("delta") ?: return@readLines
                        when (delta.str("type")) {
                            "text_delta" -> {
                                text.append(delta.str("text") ?: "")
                                onDelta?.invoke("anthropic", text.toString())
                            }

                            "input_json_delta" -> {
                                val idx = obj.int("index") ?: 0
                                toolBuilders[idx]?.input?.append(delta.str("partial_json") ?: "")
                            }
                        }
                    }

                    "message_delta" -> {
                        obj.obj("delta")?.str("stop_reason")?.let { finish = it }
                        obj.obj("usage")?.int("output_tokens")?.let { usageOut = it }
                    }
                }
            }
        } else {
            val obj = response.body?.string()?.toJsonObject() ?: throw EmptyResponseException()
            usageIn = obj.obj("usage")?.int("input_tokens") ?: 0
            usageOut = obj.obj("usage")?.int("output_tokens") ?: 0
            finish = obj.str("stop_reason")
            val content = obj.arr("content") ?: emptyList()
            for (el in content) {
                val block = el as? JsonObject ?: continue
                when (block.str("type")) {
                    "text" -> text.append(block.str("text") ?: "")
                    "tool_use" -> toolBuilders[toolBuilders.size] = ToolBuilder().apply {
                        id = block.str("id") ?: ""
                        name = block.str("name") ?: ""
                        (block.obj("input") ?: kotlinx.serialization.json.JsonObject(emptyMap()))
                            .let { input.append(it.toString()) }
                    }
                }
            }
        }

        val calls = toolBuilders.values.map { b ->
            ToolCallData(
                id = b.id.ifBlank { com.liman.agent.util.genId("ant") },
                name = b.name,
                argsJson = b.input.toString().ifBlank { "{}" }
            )
        }
        return LlmResult(
            text = text.toString(),
            toolCalls = calls,
            finishReason = finish,
            usage = Usage(usageIn, usageOut),
            providerName = providerName,
            modelName = model
        )
    }
}
