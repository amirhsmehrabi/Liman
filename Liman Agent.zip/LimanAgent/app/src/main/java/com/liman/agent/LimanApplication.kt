package com.liman.agent

import android.app.Application
import android.content.Context
import android.net.Uri
import com.liman.agent.data.Stores
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File

class LimanApplication : Application() {

    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // v2.28.0 Doctor's Log — record the version + start the session
        runCatching {
            com.liman.agent.agent.DiagLog.appVersion =
                packageManager.getPackageInfo(packageName, 0).versionName ?: "unknown"
        }
        // v2.34.0 PERMANENT CODE LOG — every event also lands on disk, split
        // into per-day files (diag-* / errors-* / crash-*), NEVER auto-cleaned.
        runCatching {
            com.liman.agent.agent.DiagLog.dir = java.io.File(filesDir, "logs").apply { mkdirs() }
            com.liman.agent.agent.DiagLog.installCrashHandler()
        }
        com.liman.agent.agent.DiagLog.newSession()
        com.liman.agent.llm.WebChatHost.appContext = this
        // v2.10 one-shot: make sure the router is ON (user asked to enable & run it)
        if (!container.stores.settings.state.value.routerBootLatch) {
            container.stores.settings.update {
                it.routerEnabled = true
                it.routerBootLatch = true
            }
        }
        // v2.10.1 one-shot: give port 20128 to the REAL 9Router (npm/Termux) —
        // Liman's mini-router moves to 20129 so both can run side by side.
        if (!container.stores.settings.state.value.routerPortMoved) {
            val oldPort = container.stores.settings.state.value.routerPort
            container.stores.settings.update {
                it.routerPort = 20129
                it.routerPortMoved = true
            }
            if (oldPort == 20128) {
                container.stores.providers.state.value
                    .filter { it.presetId == "limanrouter" || it.baseUrl.contains("127.0.0.1:$oldPort") }
                    .forEach {
                        it.baseUrl = it.baseUrl.replace("127.0.0.1:$oldPort", "127.0.0.1:20129")
                        container.stores.providers.upsert(it)
                    }
            }
        }
        // boot the local 9Router-compatible gateway + dashboard
        runCatching { com.liman.agent.agent.Scheduler.ensureScheduled(this) }
        // v2.21 — keep automations synced onto the scheduler (boot + changes)
        runCatching { com.liman.agent.agent.Scheduler.syncPipelines(this) }
        // v2.23 — SUPER AGENT: context triggers (charging/battery/screen/wifi)
        runCatching { com.liman.agent.agent.Triggers.registerDynamic(this) }
        runCatching { com.liman.agent.agent.DefaultSkills.ensure(container.stores.skills) }
        // v2.20 — OpenClaw-style file-based intelligence: HEARTBEAT.md is the
        // agent's standing checklist; scheduled heartbeat runs read it first
        runCatching {
            val hb = File(container.stores.workspace, "HEARTBEAT.md")
            if (!hb.exists()) hb.writeText(
                """# HEARTBEAT — Liman's standing checklist
Scheduled/heartbeat runs read this file FIRST. Do exactly what the active
items list. If nothing needs attention, reply exactly NO_REPLY and end.

## Active items (empty — the user adds recurring checks here)
<!-- Examples:
- [ ] Skim new job offers for the campaign in workspace/jobsearch/ and notify only if one fits
- [ ] Check workspace/campaigns/inbox for replies and draft follow-ups
-->

## Rules
- Never invent recurring tasks. Never repeat old tasks from chat history.
- One line per item, keep it current: delete items that are done or stale.
- Ask the user (once) before adding anything new here.
"""
            )
        }
                val st = container.stores.settings.state.value
        if (st.routerEnabled) {
            runCatching {
                com.liman.agent.llm.RouterServer.start(
                    container.stores, st.routerPort, st.routerLan
                )
            }
        }
        // v2.11: free no-key models work out of the box — seed the OpenCode
        // Free provider once and keep its model list self-updated (24h TTL)
        runCatching {
            if (!container.stores.settings.state.value.freeProviderSeeded) {
                com.liman.agent.llm.FreeCatalog.ensureProvider(container.stores)
                container.stores.settings.update { it.freeProviderSeeded = true }
            }
            container.appScope.launch {
                runCatching { com.liman.agent.llm.FreeCatalog.dailySync(container.stores) }
            }
        }
    }

    companion object {
        fun get(context: Context): LimanApplication =
            context.applicationContext as LimanApplication
    }
}

class AppContainer(context: Context) {
    val stores = Stores(context)
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val workspace: File get() = stores.workspace

    /** Handoff points for the Android share-intent flow. */
    @Volatile
    var pendingShare: PendingShare? = null
    val pendingImports = HashMap<String, List<String>>()
    val pendingDrafts = HashMap<String, String>()
}

data class PendingShare(val text: String, val uris: List<Uri>)
