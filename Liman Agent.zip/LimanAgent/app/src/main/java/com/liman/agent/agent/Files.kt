package com.liman.agent.agent

import java.io.File
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Element
import org.w3c.dom.Node

/**
 * Pure-JVM extractors for Office/HTML/archive formats (no Android deps, so
 * they are unit-testable). Each returns human/model-readable text.
 */
object OfficeExtractors {

    private const val W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val SPREAD = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val DRAW = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val RELS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    private fun db() = DocumentBuilderFactory.newInstance().apply {
        isNamespaceAware = true
    }

    // ---------------- DOCX ----------------

    fun docx(file: File, maxChars: Int = 60_000): String = try {
        ZipFile(file).use { zip ->
            val entry = zip.getEntry("word/document.xml")
                ?: return "(no word/document.xml inside ${file.name} — is it a real .docx?)"
            val doc = db().newDocumentBuilder().parse(zip.getInputStream(entry))
            val sb = StringBuilder()
            val paragraphs = doc.getElementsByTagNameNS(W, "p")
            for (i in 0 until paragraphs.length) {
                val line = collectWText(paragraphs.item(i) as Element)
                if (line.isNotBlank()) sb.appendLine(line)
                if (sb.length > maxChars) {
                    sb.appendLine("…[truncated]")
                    break
                }
            }
            sb.toString().trim().ifBlank { "(empty document)" }
        }
    } catch (t: Throwable) {
        "(could not parse ${file.name} as .docx: ${t.message})"
    }

    private fun collectWText(el: Element): String {
        val sb = StringBuilder()
        var node: Node? = el.firstChild
        while (node != null) {
            when (node.nodeType) {
                Node.TEXT_NODE -> sb.append(node.nodeValue ?: "")
                Node.ELEMENT_NODE -> {
                    val e = node as Element
                    when (e.localName) {
                        "t" -> sb.append(e.textContent ?: "")
                        "tab" -> sb.append('\t')
                        "br", "cr" -> sb.append('\n')
                        else -> sb.append(collectWText(e))
                    }
                }
            }
            node = node.nextSibling
        }
        return sb.toString()
    }

    // ---------------- XLSX ----------------

    fun xlsx(file: File, maxChars: Int = 60_000): String = try {
        ZipFile(file).use { zip ->
            // shared strings
            val shared = ArrayList<String>()
            zip.getEntry("xl/sharedStrings.xml")?.let { e ->
                val doc = db().newDocumentBuilder().parse(zip.getInputStream(e))
                val sis = doc.getElementsByTagNameNS(SPREAD, "si")
                for (i in 0 until sis.length) shared.add(collectAnyText(sis.item(i) as Element))
            }
            // sheet name -> entry mapping via workbook + rels
            val rels = HashMap<String, String>()
            zip.getEntry("xl/_rels/workbook.xml.rels")?.let { e ->
                val doc = db().newDocumentBuilder().parse(zip.getInputStream(e))
                val rs = doc.getElementsByTagNameNS("*", "Relationship")
                for (i in 0 until rs.length) {
                    val e2 = rs.item(i) as Element
                    val id = e2.getAttribute("Id")
                    val target = e2.getAttribute("Target") ?: continue
                    if (id.isNotBlank()) rels[id] = target
                }
            }
            val sheets = ArrayList<Pair<String, String>>() // name -> zip entry name
            zip.getEntry("xl/workbook.xml")?.let { e ->
                val doc = db().newDocumentBuilder().parse(zip.getInputStream(e))
                val ss = doc.getElementsByTagNameNS(SPREAD, "sheet")
                for (i in 0 until ss.length) {
                    val e2 = ss.item(i) as Element
                    val name = e2.getAttribute("name") ?: "sheet$i"
                    val rid = e2.getAttributeNS(RELS, "id")
                    val target = rels[rid] ?: continue
                    val entryName = if (target.startsWith("/")) target.removePrefix("/") else "xl/$target"
                    sheets.add(name to entryName)
                }
            }
            if (sheets.isEmpty()) {
                zip.entries().asSequence()
                    .filter { Regex("xl/worksheets/sheet\\d+\\.xml").matches(it.name) }
                    .sortedBy { it.name }
                    .forEach { sheets.add(it.name.removePrefix("xl/").removeSuffix(".xml") to it.name) }
            }

            val sb = StringBuilder()
            sb.appendLine("[Excel workbook: ${file.name}, ${sheets.size} sheet(s)]")
            for ((name, entryName) in sheets.take(6)) {
                val entry = zip.getEntry(entryName) ?: continue
                sb.appendLine()
                sb.appendLine("== Sheet: $name ==")
                val doc = db().newDocumentBuilder().parse(zip.getInputStream(entry))
                val rows = doc.getElementsByTagNameNS(SPREAD, "row")
                val maxRows = 400
                for (r in 0 until minOf(rows.length, maxRows)) {
                    val rowEl = rows.item(r) as Element
                    val cells = rowEl.getElementsByTagNameNS(SPREAD, "c")
                    val colToVal = HashMap<Int, String>()
                    var maxCol = -1
                    for (c in 0 until cells.length) {
                        val cell = cells.item(c) as Element
                        val ref = cell.getAttribute("r") ?: continue
                        val col = colIndexFromRef(ref)
                        if (col < 0 || col >= 40) continue
                        val type = cell.getAttribute("t")
                        val value: String = when (type) {
                            "s" -> {
                                val v = firstChildText(cell, "v")
                                val idx = v?.trim()?.toIntOrNull() ?: continue
                                shared.getOrNull(idx) ?: ""
                            }

                            "inlineStr" -> collectAnyText(firstChildElement(cell, "is") ?: cell)

                            "str" -> firstChildText(cell, "v") ?: ""

                            else -> firstChildText(cell, "v") ?: ""
                        }
                        colToVal[col] = value
                        if (col > maxCol) maxCol = col
                    }
                    if (maxCol < 0) continue
                    val line = (0..maxCol).joinToString(",") { csv(colToVal[it] ?: "") }
                    sb.appendLine(line)
                    if (sb.length > maxChars) {
                        sb.appendLine("…[truncated]")
                        break
                    }
                }
                if (rows.length > maxRows) sb.appendLine("…(${rows.length - maxRows} more rows)")
                if (sb.length > maxChars) break
            }
            sb.toString().trim()
        }
    } catch (t: Throwable) {
        "(could not parse ${file.name} as .xlsx: ${t.message})"
    }

    private fun colIndexFromRef(ref: String): Int {
        var col = 0
        for (ch in ref) {
            if (ch.isLetter()) col = col * 26 + (ch.uppercaseChar() - 'A' + 1)
            else break
        }
        return col - 1
    }

    private fun firstChildElement(el: Element, localName: String): Element? {
        var node: Node? = el.firstChild
        while (node != null) {
            if (node.nodeType == Node.ELEMENT_NODE && (node as Element).localName == localName) return node
            node = node.nextSibling
        }
        return null
    }

    private fun firstChildText(el: Element, localName: String): String? =
        firstChildElement(el, localName)?.textContent

    private fun collectAnyText(el: Element): String {
        val sb = StringBuilder()
        var node: Node? = el.firstChild
        while (node != null) {
            when (node.nodeType) {
                Node.TEXT_NODE -> sb.append(node.nodeValue ?: "")
                Node.ELEMENT_NODE -> sb.append(collectAnyText(node as Element))
            }
            node = node.nextSibling
        }
        return sb.toString()
    }

    private fun csv(s: String): String =
        if (s.contains(',') || s.contains('"') || s.contains('\n')) "\"${s.replace("\"", "\"\"")}\"" else s

    // ---------------- PPTX ----------------

    fun pptx(file: File, maxChars: Int = 60_000): String = try {
        ZipFile(file).use { zip ->
            val sb = StringBuilder()
            sb.appendLine("[PowerPoint: ${file.name}]")
            val slideEntries = zip.entries().asSequence()
                .filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it.name) }
                .sortedBy { it.name }
                .toList()
            for ((i, entry) in slideEntries.withIndex()) {
                val doc = db().newDocumentBuilder().parse(zip.getInputStream(entry))
                val ts = doc.getElementsByTagNameNS(DRAW, "t")
                val text = (0 until ts.length).joinToString(" ") { ts.item(it).textContent ?: "" }
                sb.appendLine("— Slide ${i + 1} —")
                sb.appendLine(text.trim().take(2000))
                if (sb.length > maxChars) {
                    sb.appendLine("…[truncated]")
                    break
                }
            }
            sb.toString().trim().ifBlank { "(no text found in slides)" }
        }
    } catch (t: Throwable) {
        "(could not parse ${file.name} as .pptx: ${t.message})"
    }

    // ---------------- EPUB ----------------

    fun epub(file: File, maxChars: Int = 60_000): String = try {
        ZipFile(file).use { zip ->
            val sb = StringBuilder()
            sb.appendLine("[EPUB e-book: ${file.name}]")
            val htmlEntries = zip.entries().asSequence()
                .filter { it.name.endsWith(".xhtml") || it.name.endsWith(".html") }
                .sortedBy { it.name }
                .take(60)
            for (entry in htmlEntries) {
                val html = zip.getInputStream(entry).readBytes().toString(Charsets.UTF_8)
                sb.appendLine(htmlToText(html, maxChars - sb.length))
                if (sb.length > maxChars) {
                    sb.appendLine("…[truncated]")
                    break
                }
            }
            sb.toString().trim()
        }
    } catch (t: Throwable) {
        "(could not parse ${file.name} as EPUB: ${t.message})"
    }

    // ---------------- HTML ----------------

    fun htmlToText(html: String, maxChars: Int = 60_000): String {
        var s = html
        s = s.replace(Regex("(?is)<script.*?</script>"), " ")
        s = s.replace(Regex("(?is)<style.*?</style>"), " ")
        s = s.replace(Regex("(?is)<!--.*?-->"), " ")
        s = s.replace(Regex("(?i)</(p|div|tr|li|h[1-6]|blockquote|section|article)>"), "\n")
        s = s.replace(Regex("(?i)<br\\s*/?>"), "\n")
        s = s.replace(Regex("<[^>]+>"), " ")
        s = decodeEntities(s)
        s = s.replace(Regex("[ \\t\\x0B\\f\\r]+"), " ")
        s = s.replace(Regex("\\n ?\\n+"), "\n")
        return s.trim().take(maxChars)
    }

    fun decodeEntities(s: String): String {
        var r = s
        r = Regex("&#x([0-9a-fA-F]+);").replace(r) { m ->
            m.groupValues[1].toIntOrNull(16)?.toChar()?.toString() ?: m.value
        }
        r = Regex("&#(\\d+);").replace(r) { m ->
            m.groupValues[1].toIntOrNull()?.toChar()?.toString() ?: m.value
        }
        r = r.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
            .replace("&nbsp;", " ").replace("&hellip;", "…").replace("&mdash;", "—")
            .replace("&ndash;", "–").replace("&rsquo;", "’").replace("&lsquo;", "‘")
            .replace("&ldquo;", "“").replace("&rdquo;", "”")
        return r
    }

    // ---------------- ZIP ----------------

    fun zipListing(file: File): String = try {
        ZipFile(file).use { zip ->
            val entries = zip.entries().asSequence().take(300).toList()
            buildString {
                appendLine("[Archive: ${file.name}, ${entries.size}+ entries]")
                entries.forEach {
                    appendLine("- ${it.name} (${it.size} B${if (it.isDirectory) ", dir" else ""})")
                }
            }
        }
    } catch (t: Throwable) {
        "(could not read archive ${file.name}: ${t.message})"
    }

    fun zipEntryText(file: File, entryName: String, maxChars: Int = 40_000): String = try {
        ZipFile(file).use { zip ->
            val e = zip.getEntry(entryName)
                ?: return "(no entry named '$entryName' in ${file.name})"
            val bytes = zip.getInputStream(e).readBytes()
            if (looksLikeText(bytes)) String(bytes, Charsets.UTF_8).take(maxChars)
            else hexPreview(bytes)
        }
    } catch (t: Throwable) {
        "(could not extract '$entryName' from ${file.name}: ${t.message})"
    }

    fun looksLikeText(bytes: ByteArray): Boolean {
        val n = minOf(bytes.size, 4096)
        if (n == 0) return true
        var printable = 0
        for (i in 0 until n) {
            val b = bytes[i]
            if (b == 0x00.toByte() || b == 0x1b.toByte()) return false
            if (b in 0x20..0x7e || b == '\n'.code.toByte() || b == '\r'.code.toByte() || b == '\t'.code.toByte()) printable++
        }
        return printable.toDouble() / n > 0.85
    }

    fun hexPreview(bytes: ByteArray, cap: Int = 1024): String {
        val sb = StringBuilder()
        sb.appendLine("[binary content, first ${minOf(bytes.size, cap)} bytes as hex]")
        for (i in 0 until minOf(bytes.size, cap) step 32) {
            val end = minOf(i + 32, bytes.size)
            sb.appendLine(bytes.copyOfRange(i, end).joinToString(" ") { String.format("%02x", it) })
        }
        return sb.toString()
    }
}
