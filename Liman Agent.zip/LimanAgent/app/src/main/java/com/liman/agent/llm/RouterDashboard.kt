package com.liman.agent.llm

import com.liman.agent.data.ComboConfig
import com.liman.agent.data.ProviderConfig
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * 9Router dashboard — a single self-contained HTML page served by the local
 * router at http://127.0.0.1:<port>/ . Everything dynamic is fetched from
 * /api/status, so the page itself is a static constant with zero external
 * resources (works offline, no CDN, no fonts).
 *
 * What it gives the user in any browser on the phone:
 *  • router on/off + LAN toggle (persisted to settings, same as the app UI)
 *  • every provider: name, kind, link, model, API key (masked / reveal),
 *    enable switch, inline editing, free/paid badge
 *  • combo config (mode, retries, cooldown)
 *  • all routes/special models with a live "test" button
 *  • copy-ready endpoints + curl examples
 *  • live request log
 */

internal fun maskKey(k: String): String = when {
    k.isBlank() -> ""
    k == "local" -> "local"
    k.length <= 8 -> "••••••"
    else -> k.take(4) + "••••••••" + k.takeLast(3)
}

internal fun routerStatusJson(
    running: Boolean,
    port: Int,
    lan: Boolean,
    lanUrl: String?,
    enabled: Boolean,
    requests: Long,
    uptimeMs: Long,
    providers: List<ProviderConfig>,
    combo: ComboConfig,
    comboNames: (String) -> String,
    models: List<String>,
    log: List<String>,
    revealKeys: Boolean
): String = buildJsonObject {
    put("ok", true)
    put("running", running)
    put("enabled", enabled)
    put("port", port)
    put("lan", lan)
    put("lanUrl", lanUrl)
    put("requests", requests)
    put("uptimeMs", uptimeMs)
    put("providers", kotlinx.serialization.json.buildJsonArray {
        providers.forEach { p ->
            add(buildJsonObject {
                put("id", p.id)
                put("name", p.name)
                put("kind", p.kind.name)
                put("baseUrl", p.baseUrl)
                put("model", p.model)
                put("apiKey", if (revealKeys) p.apiKey else maskKey(p.apiKey))
                put("hasKey", p.apiKey.isNotBlank())
                put("enabled", p.enabled)
                put("free", p.kind == com.liman.agent.data.ProviderKind.WEB_CHAT ||
                    (p.kind == com.liman.agent.data.ProviderKind.GEMINI && p.apiKey.isNotBlank()) ||
                    p.freeModels.isNotEmpty() || p.useFreePool)
                put("freeModels", p.freeModels.size)
                put("useFreePool", p.useFreePool)
            })
        }
    })
    put("combo", buildJsonObject {
        put("mode", combo.mode.name)
        put("retriesPerProvider", combo.retriesPerProvider)
        put("cooldownMs", combo.cooldownMs)
        put("members", kotlinx.serialization.json.buildJsonArray {
            combo.providerIds.forEach { id ->
                add(buildJsonObject { put("id", id); put("name", comboNames(id)) })
            }
        })
    })
    put("models", kotlinx.serialization.json.buildJsonArray {
        models.forEach { add(kotlinx.serialization.json.JsonPrimitive(it)) }
    })
    put("log", kotlinx.serialization.json.buildJsonArray {
        log.forEach { add(kotlinx.serialization.json.JsonPrimitive(it)) }
    })
}.toString()

// ============================================================
// The page. NOTE: this is a Kotlin raw string — it must contain
// NO dollar signs (JS below uses string concatenation only).
// ============================================================
internal val ROUTER_DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>9Router · Liman</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; -webkit-font-smoothing:antialiased; }
  body { background:#0D1117; color:#EFF3F0; font-family:'Vazirmatn','Segoe UI',system-ui,-apple-system,sans-serif; padding:18px 14px 60px; max-width:760px; margin:0 auto; }
  a { color:#6EC9F9; text-decoration:none; } a:hover { text-decoration:underline; }
  h1 { font-size:20px; }
  h1 span { background:linear-gradient(90deg,#9EE8C7,#6EC9F9); -webkit-background-clip:text; background-clip:text; color:transparent; }
  .sub { color:#A8B3AC; font-size:12px; margin-top:3px; }
  .head { display:flex; align-items:center; gap:12px; margin-bottom:16px; flex-wrap:wrap; }
  .pill { font-size:11px; font-weight:700; border-radius:12px; padding:4px 11px; }
  .pill.on { background:#123324; color:#9EE8C7; }
  .pill.off { background:#3A1E24; color:#F0BFA5; }
  .card { background:#161D26; border:1px solid #28313A; border-radius:16px; padding:14px; margin-bottom:14px; }
  .card h2 { font-size:13px; color:#9EE8C7; margin-bottom:10px; letter-spacing:.4px; text-transform:uppercase; }
  .row { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
  .dim { color:#A8B3AC; font-size:12px; } .tiny { color:#55605B; font-size:10.5px; }
  button { border:none; cursor:pointer; font-family:inherit; border-radius:12px; padding:8px 14px; font-size:12.5px; font-weight:600; color:#EFF3F0; background:#1E2732; border:1px solid #28313A; transition:.15s; }
  button:hover { border-color:#9EE8C7; }
  button.primary { background:linear-gradient(135deg,#2F6FE4,#1B4FD1); border:none; color:#F3F7FF; }
  button.danger { background:#3A1E24; color:#F0BFA5; border:none; }
  button:disabled { opacity:.45; cursor:default; }
  input, select { background:#0D1117; border:1px solid #28313A; color:#EFF3F0; border-radius:10px; padding:7px 10px; font-size:12.5px; font-family:inherit; outline:none; min-width:0; }
  input:focus, select:focus { border-color:#6EC9F9; }
  .code { font-family:ui-monospace,Menlo,monospace; background:#0D1117; border:1px solid #28313A; border-radius:10px; padding:8px 10px; font-size:11.5px; color:#9EE8C7; overflow-x:auto; white-space:nowrap; }
  .ep { display:flex; gap:8px; align-items:center; margin-bottom:8px; }
  .ep .code { flex:1; }
  .copy { background:#1B3A2E; color:#9EE8C7; border:none; border-radius:9px; padding:5px 10px; font-size:11px; cursor:pointer; }
  .prov { background:#10161E; border:1px solid #28313A; border-radius:14px; padding:12px; margin-bottom:10px; }
  .prov .top { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:8px; }
  .prov b { font-size:14px; }
  .tag { font-size:9.5px; font-weight:700; border-radius:7px; padding:2px 7px; }
  .tag.free { background:#123324; color:#9EE8C7; } .tag.paid { background:#3A2E1E; color:#F0BFA5; }
  .tag.kind { background:#1B3346; color:#C9E8F9; }
  .switch { position:relative; width:38px; height:21px; background:#28313A; border-radius:12px; cursor:pointer; transition:.18s; flex-shrink:0; }
  .switch::after { content:''; position:absolute; top:2.5px; left:3px; width:16px; height:16px; border-radius:50%; background:#A8B3AC; transition:.18s; }
  .switch.on { background:linear-gradient(135deg,#2F6FE4,#1B4FD1); }
  .switch.on::after { left:19px; background:#F3F7FF; }
  .field { display:flex; flex-direction:column; gap:3px; flex:1; min-width:130px; }
  .field label { font-size:9.5px; color:#55605B; text-transform:uppercase; letter-spacing:.5px; }
  .grid { display:flex; gap:8px; flex-wrap:wrap; }
  .logbox { font-family:ui-monospace,Menlo,monospace; font-size:10.5px; color:#A8B3AC; background:#0A0E13; border:1px solid #28313A; border-radius:10px; padding:10px; max-height:220px; overflow:auto; line-height:1.7; }
  .chip { display:inline-block; background:#1B3346; color:#C9E8F9; border-radius:9px; padding:3px 9px; font-size:11px; margin:2px; font-family:ui-monospace,Menlo,monospace; cursor:pointer; }
  .testout { margin-top:10px; }
  .stat { text-align:center; flex:1; min-width:90px; background:#10161E; border-radius:12px; padding:9px 6px; }
  .stat b { display:block; font-size:16px; color:#9EE8C7; }
  .stat span { font-size:9.5px; color:#55605B; text-transform:uppercase; letter-spacing:.5px; }
  .note { background:#3A2E1E; border:1px solid #66573F; color:#F0BFA5; border-radius:12px; padding:10px 12px; font-size:12px; margin-bottom:14px; }
  .okmsg { color:#9EE8C7; font-size:12px; } .errmsg { color:#F0BFA5; font-size:12px; white-space:pre-wrap; }
</style>
</head>
<body>
  <div class="head">
    <div style="flex:1;min-width:200px">
      <h1>9<span>Router</span> · Liman</h1>
      <div class="sub" id="subtitle">local gateway on this phone</div>
    </div>
    <span class="pill off" id="runpill">…</span>
  </div>

  <div class="note" id="offnote" style="display:none">
    The router is currently <b>off</b>. Turn it on — it boots now and auto-starts with the app.
  </div>

  <div class="card">
    <div class="row" style="margin-bottom:12px">
      <div class="stat"><b id="s-req">0</b><span>requests</span></div>
      <div class="stat"><b id="s-up">0s</b><span>uptime</span></div>
      <div class="stat"><b id="s-prov">0</b><span>providers</span></div>
      <div class="stat"><b id="s-route">0</b><span>routes</span></div>
    </div>
    <div class="row">
      <button class="primary" id="btn-power" onclick="setRouter(true)">▶ Start router</button>
      <button class="danger" id="btn-stop" onclick="setRouter(false)">■ Stop</button>
      <span class="dim" style="display:flex;align-items:center;gap:7px">LAN
        <span class="switch" id="lan-sw" onclick="toggleLan()"></span>
      </span>
      <span class="tiny" id="lan-url"></span>
    </div>
  </div>

  <div class="card">
    <h2>Endpoints — OpenAI-compatible</h2>
    <div class="ep"><div class="code" id="ep-base"></div><button class="copy" onclick="cp('ep-base')">copy</button></div>
    <div class="ep"><div class="code" id="ep-models"></div><button class="copy" onclick="cp('ep-models')">copy</button></div>
    <div class="ep"><div class="code" id="ep-chat"></div><button class="copy" onclick="cp('ep-chat')">copy</button></div>
    <div class="code" id="curl" style="white-space:pre;overflow-x:auto;color:#A8B3AC"></div>
    <div class="tiny" style="margin-top:6px">Any app or CLI on this phone can point at these. From another device use the LAN URL (enable LAN above, same Wi-Fi).</div>
  </div>

  <div class="card">
    <h2>Routes &amp; test</h2>
    <div id="models"></div>
    <div class="tiny" style="margin:6px 0 10px">auto = all routes free-first · free = free routes only · or any exact model name</div>
    <div class="row">
      <input id="testmodel" placeholder="auto" style="flex:1;min-width:120px">
      <button class="primary" onclick="testRoute()">Send test</button>
    </div>
    <div class="testout" id="testout"></div>
  </div>

  <div class="card">
    <h2>Providers</h2>
    <div id="providers"></div>
    <div class="tiny">Tap a key field to edit — changes save to the app instantly. Keys are masked; reveal re-fetches them once.</div>
    <div class="row" style="margin-top:8px">
      <button onclick="revealKeys()">👁 Reveal keys</button>
      <button onclick="window.location.reload()">↻ Reload</button>
    </div>
  </div>

  <div class="card">
    <h2>Combo</h2>
    <div class="row" style="margin-bottom:8px">
      <span class="dim" style="width:52px">mode</span>
      <select id="cb-mode" onchange="setCombo()">
        <option>FAILOVER</option><option>ROUND_ROBIN</option><option>RACE</option>
      </select>
      <span class="dim" style="width:52px;margin-left:8px">retries</span>
      <input id="cb-retries" type="number" style="width:64px" onchange="setCombo()">
      <span class="dim" style="width:52px;margin-left:8px">cooldown</span>
      <input id="cb-cool" type="number" style="width:84px" onchange="setCombo()">
    </div>
    <div id="combo-members" class="dim"></div>
  </div>

  <div class="card">
    <h2>Live log</h2>
    <div class="logbox" id="log">—</div>
  </div>

<script>
  var REVEAL = false;
  var CUR = null;

  function esc(s) {
    return String(s === null || s === undefined ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function cp(id) {
    var t = document.getElementById(id).textContent;
    if (navigator.clipboard) navigator.clipboard.writeText(t);
  }
  function post(u, body) {
    return fetch(u, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) })
      .then(function(r){ return r.json(); });
  }
  function fmtUp(ms) {
    var s = Math.floor(ms/1000);
    if (s < 60) return s + 's';
    var m = Math.floor(s/60); s = s % 60;
    if (m < 60) return m + 'm ' + s + 's';
    return Math.floor(m/60) + 'h ' + (m % 60) + 'm';
  }
  function editing() {
    var a = document.activeElement;
    return a && (a.tagName === 'INPUT' || a.tagName === 'SELECT');
  }

  function setRouter(on) { post('/api/state', { enabled: on }).then(function(){ refresh(); }); }
  function toggleLan() {
    if (!CUR) return;
    post('/api/state', { lan: !CUR.lan }).then(function(){ setTimeout(refresh, 400); });
  }
  function setCombo() {
    post('/api/combo', {
      mode: document.getElementById('cb-mode').value,
      retriesPerProvider: parseInt(document.getElementById('cb-retries').value || '1', 10),
      cooldownMs: parseInt(document.getElementById('cb-cool').value || '30000', 10)
    }).then(function(){ refresh(); });
  }
  function toggleProv(id, on) { post('/api/providers/' + id, { enabled: on }).then(function(){ refresh(); }); }
  function saveProv(id) {
    post('/api/providers/' + id, {
      name: document.getElementById('f-name-' + id).value,
      baseUrl: document.getElementById('f-url-' + id).value,
      model: document.getElementById('f-model-' + id).value,
      apiKey: document.getElementById('f-key-' + id).value
    }).then(function(){ refresh(); });
  }
  function revealKeys() {
    REVEAL = !REVEAL;
    refresh();
  }
  function testRoute() {
    var m = document.getElementById('testmodel').value || 'auto';
    var out = document.getElementById('testout');
    out.innerHTML = '<span class="dim">sending test through route “' + esc(m) + '” …</span>';
    post('/api/test', { model: m }).then(function(r) {
      try {
        var txt = r.choices[0].message.content;
        out.innerHTML = '<div class="okmsg">✓ ' + esc(txt).substring(0, 400) + '</div>';
      } catch (e) {
        out.innerHTML = '<div class="errmsg">' + esc(JSON.stringify(r)).substring(0, 500) + '</div>';
      }
    }).catch(function(e) {
      out.innerHTML = '<div class="errmsg">request failed: ' + esc(String(e)) + '</div>';
    });
  }

  function render(s) {
    CUR = s;
    document.getElementById('runpill').textContent = s.running ? '● RUNNING :' + s.port : '○ OFF';
    document.getElementById('runpill').className = 'pill ' + (s.running ? 'on' : 'off');
    document.getElementById('subtitle').textContent = 'local gateway · http://127.0.0.1:' + s.port + (s.lan ? ' · LAN exposed' : ' · localhost only');
    document.getElementById('offnote').style.display = s.running ? 'none' : 'block';
    document.getElementById('s-req').textContent = s.requests;
    document.getElementById('s-up').textContent = fmtUp(s.uptimeMs);
    document.getElementById('s-prov').textContent = s.providers.length;
    document.getElementById('s-route').textContent = s.models.length;
    document.getElementById('btn-power').disabled = s.running;
    document.getElementById('btn-stop').disabled = !s.running;
    var sw = document.getElementById('lan-sw');
    sw.className = 'switch' + (s.lan ? ' on' : '');
    document.getElementById('lan-url').textContent = s.lanUrl ? ('LAN: ' + s.lanUrl) : '';

    var host = 'http://' + window.location.host;
    document.getElementById('ep-base').textContent = host + '/v1';
    document.getElementById('ep-models').textContent = host + '/v1/models';
    document.getElementById('ep-chat').textContent = host + '/v1/chat/completions';
    document.getElementById('curl').textContent =
      'curl ' + host + '/v1/chat/completions \\\n' +
      '  -H "Content-Type: application/json" \\\n' +
      '  -d \'{"model":"auto","messages":[{"role":"user","content":"hi"}]}\'';

    var models = document.getElementById('models');
    models.innerHTML = '';
    s.models.forEach(function(m) {
      var c = document.createElement('span');
      c.className = 'chip';
      c.textContent = m;
      c.onclick = function() { document.getElementById('testmodel').value = m; };
      models.appendChild(c);
    });

    if (!editing()) {
      var provs = document.getElementById('providers');
      var h = '';
      if (s.providers.length === 0) h = '<div class="dim">No providers configured yet — add them in the Liman app under Providers.</div>';
      s.providers.forEach(function(p) {
        h += '<div class="prov"><div class="top">'
          + '<b>' + esc(p.name) + '</b>'
          + '<span class="tag kind">' + esc(p.kind) + '</span>'
          + (p.free ? '<span class="tag free">FREE</span>' : '<span class="tag paid">PAID</span>')
          + '<span style="flex:1"></span>'
          + '<span class="tiny" style="display:flex;align-items:center;gap:6px">enabled <span class="switch ' + (p.enabled ? 'on' : '') + '" onclick="toggleProv(\'' + p.id + '\',' + (!p.enabled) + ')"></span></span>'
          + '</div><div class="grid">'
          + '<div class="field"><label>name</label><input id="f-name-' + p.id + '" value="' + esc(p.name) + '"></div>'
          + '<div class="field" style="flex:2"><label>base url</label><input id="f-url-' + p.id + '" value="' + esc(p.baseUrl) + '"></div>'
          + '</div><div class="grid" style="margin-top:6px">'
          + '<div class="field"><label>model</label><input id="f-model-' + p.id + '" value="' + esc(p.model) + '"></div>'
          + '<div class="field" style="flex:2"><label>api key</label><input id="f-key-' + p.id + '" value="' + esc(p.apiKey) + '" ' + (p.kind === 'WEB_CHAT' ? 'disabled' : '') + '></div>'
          + '</div><div class="row" style="margin-top:8px">'
          + '<button onclick="saveProv(\'' + p.id + '\')">Save</button>'
          + (p.freeModels > 0 ? '<span class="tiny">' + p.freeModels + ' free models in pool</span>' : '')
          + '</div></div>';
      });
      provs.innerHTML = h;

      document.getElementById('cb-mode').value = s.combo.mode;
      document.getElementById('cb-retries').value = s.combo.retriesPerProvider;
      document.getElementById('cb-cool').value = s.combo.cooldownMs;
      var mem = s.combo.members.map(function(m) { return esc(m.name); }).join(' · ');
      document.getElementById('combo-members').textContent = mem ? ('members: ' + mem) : 'members: (all enabled providers)';
    }

    var lb = document.getElementById('log');
    lb.textContent = s.log.length ? s.log.join('\n') : 'no requests yet';
  }

  function refresh() {
    fetch('/api/status' + (REVEAL ? '?reveal=1' : ''))
      .then(function(r){ return r.json(); })
      .then(render)
      .catch(function(e) {
        document.getElementById('runpill').textContent = '○ UNREACHABLE';
        document.getElementById('runpill').className = 'pill off';
      });
  }
  refresh();
  setInterval(function(){ if (!editing()) refresh(); }, 3000);
</script>
</body>
</html>
"""
