package com.liman.agent.agent

import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * v2.31 — THE CREATIVE VECTOR ENGINE (blueprint Volume 3).
 *
 * "An LLM should never freehand path data. It retrieves real artwork, composes
 * vetted parts, or parameterizes a deterministic generator — and proves the
 * result passes a validator and a slop detector before it shows you."
 *
 * Three supply routes:
 *   A. RETRIEVE  (real artwork: Iconify API + sanitize + license ledger)
 *   B. COMPOSE   (kit parts — DesignTokens.kitCss + embedded icons cover this)
 *   C. GENERATE  (deterministic recipes below — 17 shipped)
 *
 * Plus the two quality gates, pure Kotlin, unit-tested:
 *   - SlopDetector  (24-rule aesthetic score, §10)
 *   - SvgValidator  (structural validity, §11)
 *
 * Every recipe: valid viewBox, ≤2 decimals, namespaced ids, currentColor or
 * caller palette, no external refs, `_meta` comment with params (reproducible).
 */
object VectorEngine {

    // ============================================================
    // Deterministic seeded RNG (reproducible output — same seed, same art)
    // ============================================================
    class Rng(seed: Long) {
        private var s = seed and 0x7FFFFFFF
        fun next(): Double {
            s = (s * 48271) % 0x7FFFFFFF
            return s.toDouble() / 0x7FFFFFFF
        }
        fun range(a: Double, b: Double) = a + (b - a) * next()
        fun int(a: Int, b: Int) = (range(a.toDouble(), (b + 1).toDouble())).toInt()
    }

    data class RecipeResult(
        val svg: String,
        val nodes: Int,
        val bytes: Int,
        val warnings: List<String> = emptyList()
    )

    private fun f(v: Double): String {
        val r = (v * 100).toInt() / 100.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
    }

    private fun wrap(viewBox: String, w: Int, h: Int, body: String, meta: String): String =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<!-- _meta: $meta -->\n" +
            "<svg xmlns=\"http://www.w3.org/2000/svg" +
            "\" width=\"$w\" height=\"$h\" viewBox=\"$viewBox\" fill=\"none\" role=\"img\">\n$body</svg>\n"

    // ============================================================
    // §6 THE RECIPE LIBRARY — 17 deterministic generators
    // ============================================================

    fun recipeIds(): List<String> = listOf(
        "shape/wave-divider", "shape/scallop", "shape/blob-organic", "shape/superformula",
        "shape/rounded-polygon", "shape/squircle",
        "bg/dot-fade-grid", "bg/sunburst", "bg/topo-lines",
        "pattern/truchet", "pattern/cross-hatch", "pattern/low-poly", "pattern/grain",
        "data/chart-bar", "data/chart-line", "data/chart-donut",
        "scene/identicon"
    )

    /** Compact param docs for the model. */
    fun recipeCatalog(): String = listOf(
        "shape/wave-divider" to "width,height,layers(1-4),amplitude,frequency,phase,seed,fill(currentColor)",
        "shape/scallop" to "width,height,n,depth,direction(up|down)",
        "shape/blob-organic" to "size,lobes(3-9),amplitude(0.05-0.3),seed",
        "shape/superformula" to "size,m(1-16),n1,n2,n3,steps",
        "shape/rounded-polygon" to "size,sides(3-12),radius,rotation",
        "shape/squircle" to "size,smooth(0-1)",
        "bg/dot-fade-grid" to "width,height,step,maxR,falloff(radial|linear),origin(x,y),seed",
        "bg/sunburst" to "size,rays(8-48),seed",
        "bg/topo-lines" to "size,levels(4-12),scale,seed",
        "pattern/truchet" to "width,height,cell,variant(arc|line|triangle),seed",
        "pattern/cross-hatch" to "width,height,angles(2-3),density,seed",
        "pattern/low-poly" to "width,height,cell,jitter,seed,fill",
        "pattern/grain" to "width,height,density(0.02-0.08),seed (native-safe dot form)",
        "data/chart-bar" to "values[],labels[],width,height",
        "data/chart-line" to "series[],width,height",
        "data/chart-donut" to "values[],labels[],size",
        "scene/identicon" to "seed,size,fg(currentColor)"
    ).joinToString("\n") { "- ${it.first} — params: ${it.second}" }

    fun runRecipe(id: String, p: Map<String, String>): RecipeResult? {
        val num = { k: String, d: Double -> p[k]?.toDoubleOrNull() ?: d }
        val seed = num("seed", 4711.0).toLong()
        return when (id) {
            "shape/wave-divider" -> waveDivider(
                num("width", 1440.0).toInt(), num("height", 120.0).toInt(),
                num("layers", 3.0).toInt().coerceIn(1, 4), num("amplitude", 18.0), num("frequency", 0.8), seed
            )
            "shape/scallop" -> scallop(
                num("width", 1440.0).toInt(), num("height", 60.0).toInt(),
                num("n", 24.0).toInt().coerceAtLeast(2), num("depth", 18.0), p["direction"] ?: "down"
            )
            "shape/blob-organic" -> blobOrganic(
                num("size", 400.0), num("lobes", 5.0).toInt().coerceIn(3, 9), num("amplitude", 0.14), seed
            )
            "shape/superformula" -> superformula(
                num("size", 400.0), num("m", 6.0), num("n1", 1.0), num("n2", 7.0), num("n3", 8.0), num("steps", 240.0).toInt()
            )
            "shape/rounded-polygon" -> roundedPolygon(
                num("size", 200.0), num("sides", 6.0).toInt().coerceIn(3, 12), num("radius", 24.0), num("rotation", 0.0)
            )
            "shape/squircle" -> squircle(num("size", 200.0), num("smooth", 0.7))
            "bg/dot-fade-grid" -> dotFadeGrid(
                num("width", 800.0).toInt(), num("height", 600.0).toInt(), num("step", 28.0), num("maxR", 5.0), seed
            )
            "bg/sunburst" -> sunburst(num("size", 800.0), num("rays", 24.0).toInt().coerceIn(8, 48), seed)
            "bg/topo-lines" -> topoLines(num("size", 600.0), num("levels", 8.0).toInt().coerceIn(4, 12), num("scale", 0.02), seed)
            "pattern/truchet" -> truchet(
                num("width", 600.0).toInt(), num("height", 600.0).toInt(), num("cell", 60.0), p["variant"] ?: "arc", seed
            )
            "pattern/cross-hatch" -> crossHatch(
                num("width", 600.0).toInt(), num("height", 400.0).toInt(), num("angles", 3.0).toInt().coerceIn(2, 3), num("density", 14.0), seed
            )
            "pattern/low-poly" -> lowPoly(
                num("width", 800.0).toInt(), num("height", 600.0).toInt(), num("cell", 80.0), num("jitter", 0.45), seed
            )
            "pattern/grain" -> grain(
                num("width", 400.0).toInt(), num("height", 400.0).toInt(), num("density", 0.04), seed
            )
            "data/chart-bar" -> chartBar(
                (p["values"] ?: "").split(",", ";").mapNotNull { it.trim().toDoubleOrNull() },
                num("width", 640.0).toInt(), num("height", 360.0).toInt()
            )
            "data/chart-line" -> chartLine(
                (p["values"] ?: "").split(",", ";").mapNotNull { it.trim().toDoubleOrNull() },
                num("width", 640.0).toInt(), num("height", 360.0).toInt()
            )
            "data/chart-donut" -> chartDonut(
                (p["values"] ?: "").split(",", ";").mapNotNull { it.trim().toDoubleOrNull() }, num("size", 320.0)
            )
            "scene/identicon" -> identicon(seed, num("size", 140.0))
            else -> null
        }
    }

    // ---- shape/ ----

    private fun waveDivider(w: Int, h: Int, layers: Int, amp: Double, freq: Double, seed: Long): RecipeResult {
        val rng = Rng(seed)
        val sb = StringBuilder()
        var nodes = 0
        val step = max(12.0, w / 60.0)
        for (l in 0 until layers) {
            val a = amp * (1.0 - l * 0.35)
            val f2 = freq * (1.0 + l * 0.7)
            val phase = rng.range(0.0, 6.28)
            val opacity = 1.0 - l * (0.7 / layers)
            sb.append("<path d=\"M0 ${f(h.toDouble())}")
            var x = 0.0
            while (x <= w) {
                val y = h / 2.0 + a * sin(x / w * 6.28 * f2 + phase) +
                    a * 0.4 * sin(x / w * 6.28 * f2 * 2.7 + phase * 2.0)
                sb.append(" L${f(x)} ${f(y)}"); nodes++
                x += step
            }
            sb.append(" L$w $h L0 $h Z\" fill=\"currentColor\" fill-opacity=\"${f(opacity)}\"/>")
        }
        val svg = wrap("0 0 $w $h", w, h, sb.toString(), "wave-divider w=$w h=$h layers=$layers amp=$amp freq=$freq seed=$seed")
        return RecipeResult(svg, nodes, svg.length)
    }

    private fun scallop(w: Int, h: Int, n: Int, depth: Double, direction: String): RecipeResult {
        val period = w.toDouble() / n
        val r = period / 2.0
        val flip = if (direction == "up") -1 else 1
        val sb = StringBuilder("<path d=\"M0 ${f(h / 2.0)}")
        for (i in 0 until n) {
            val x0 = i * period
            sb.append(" A${f(r)} ${f(r)} 0 0 ${if (flip > 0) 1 else 0} ${f(x0 + period)} ${f(h / 2.0)}")
        }
        sb.append(" L$w 0 L0 0 Z\" fill=\"currentColor\"/>")
        val svg = wrap("0 0 $w $h", w, h, sb.toString(), "scallop n=$n depth=$depth dir=$direction")
        return RecipeResult(svg, n, svg.length)
    }

    private fun blobOrganic(size: Double, lobes: Int, amplitude: Double, seed: Long): RecipeResult {
        val rng = Rng(seed)
        val cx = size / 2; val cy = size / 2
        val base = size * 0.36
        val harms = (1..3).map { (it to rng.range(0.4, 1.0)) }
        val rFun = { t: Double ->
            var r = 1.0
            harms.forEach { (k, a) -> r += amplitude * a * sin(k * t + k * seed % 6.28) }
            base * r
        }
        val steps = 72
        val pts = (0 until steps).map { i ->
            val t = 2 * Math.PI * i / steps
            val r = rFun(t)
            Pair(cx + r * cos(t), cy + r * sin(t))
        }
        // smooth closed catmull-rom-ish cubic through the points
        val sb = StringBuilder("<path d=\"M${f(pts[0].first)} ${f(pts[0].second)}")
        for (i in pts.indices) {
            val p0 = pts[(i - 1 + pts.size) % pts.size]; val p1 = pts[i]
            val p2 = pts[(i + 1) % pts.size]; val p3 = pts[(i + 2) % pts.size]
            val c1 = Pair(p1.first + (p2.first - p0.first) / 6.0, p1.second + (p2.second - p0.second) / 6.0)
            val c2 = Pair(p2.first - (p3.first - p1.first) / 6.0, p2.second - (p3.second - p1.second) / 6.0)
            sb.append(" C${f(c1.first)} ${f(c1.second)} ${f(c2.first)} ${f(c2.second)} ${f(p2.first)} ${f(p2.second)}")
        }
        sb.append(" Z\" fill=\"currentColor\"/>")
        val svg = wrap("0 0 ${f(size)} ${f(size)}", size.toInt(), size.toInt(), sb.toString(), "blob-organic lobes=$lobes amp=$amplitude seed=$seed")
        return RecipeResult(svg, steps, svg.length)
    }

    private fun superformula(size: Double, m: Double, n1: Double, n2: Double, n3: Double, steps: Int): RecipeResult {
        fun r(t: Double): Double {
            val a = 1.0; val b = 1.0
            val t1 = (abs(cos(m * t / 4)) / a).pow(n2)
            val t2 = (abs(sin(m * t / 4)) / b).pow(n3)
            return (t1 + t2).pow(-1.0 / n1)
        }
        val cx = size / 2; val cy = size / 2
        // normalize: superformula radii are unbounded — scale so the shape
        // always sits inside the viewBox with optical padding (no clipping)
        val raw = (0..steps).map { i -> val t = 2 * Math.PI * i / steps; r(t) }
        val rMax = raw.max().coerceAtLeast(1e-9)
        val pts = (0..steps).map { i ->
            val t = 2 * Math.PI * i / steps
            val rr = raw[i] / rMax * size * 0.44
            Pair(cx + rr * cos(t), cy + rr * sin(t))
        }
        val sb = StringBuilder("<path d=\"M${f(pts[0].first)} ${f(pts[0].second)}")
        for (i in 1 until pts.size) sb.append(" L${f(pts[i].first)} ${f(pts[i].second)}")
        sb.append(" Z\" fill=\"currentColor\"/>")
        val svg = wrap("0 0 ${f(size)} ${f(size)}", size.toInt(), size.toInt(), sb.toString(),
            "superformula m=$m n1=$n1 n2=$n2 n3=$n3 seed=fixed")
        return RecipeResult(svg, steps, svg.length)
    }

    private fun roundedPolygon(size: Double, sides: Int, radius: Double, rotation: Double): RecipeResult {
        val cx = size / 2; val cy = size / 2
        val R = size * 0.42
        val verts = (0 until sides).map { i ->
            val a = rotation + 2 * Math.PI * i / sides - Math.PI / 2
            Pair(cx + R * cos(a), cy + R * sin(a))
        }
        val r = min(radius, R * 0.45)
        val sb = StringBuilder()
        for (i in 0 until sides) {
            val prev = verts[(i - 1 + sides) % sides]; val cur = verts[i]; val next = verts[(i + 1) % sides]
            fun toward(from: Pair<Double, Double>, to: Pair<Double, Double>): Pair<Double, Double> {
                val d = sqrt((to.first - from.first).pow(2) + (to.second - from.second).pow(2))
                val k = r / d
                return Pair(from.first + (to.first - from.first) * k, from.second + (to.second - from.second) * k)
            }
            val a1 = toward(cur, prev); val a2 = toward(cur, next)
            sb.append(if (i == 0) "M${f(a1.first)} ${f(a1.second)}" else " L${f(a1.first)} ${f(a1.second)}")
            sb.append(" A${f(r)} ${f(r)} 0 0 1 ${f(a2.first)} ${f(a2.second)}")
        }
        sb.append(" Z\" fill=\"currentColor\"/>")
        val svg = wrap("0 0 ${f(size)} ${f(size)}", size.toInt(), size.toInt(), sb.toString(),
            "rounded-polygon sides=$sides radius=$radius rot=$rotation")
        return RecipeResult(svg, sides * 2, svg.length)
    }

    private fun squircle(size: Double, smooth: Double): RecipeResult {
        val n = 4.0 + (1.0 - smooth.coerceIn(0.0, 1.0)) * 8.0  // superellipse exponent
        val cx = size / 2; val cy = size / 2
        val a = size * 0.46; val b = size * 0.46
        val steps = 96
        val sb = StringBuilder("<path d=\"")
        for (i in 0..steps) {
            val t = 2 * Math.PI * i / steps - Math.PI
            val x = a * signPow(cos(t), 2.0 / n)
            val y = b * signPow(sin(t), 2.0 / n)
            sb.append(if (i == 0) "M${f(cx + x)} ${f(cy + y)}" else " L${f(cx + x)} ${f(cy + y)}")
        }
        sb.append(" Z\" fill=\"currentColor\"/>")
        val svg = wrap("0 0 ${f(size)} ${f(size)}", size.toInt(), size.toInt(), sb.toString(), "squircle smooth=$smooth n=$n")
        return RecipeResult(svg, steps, svg.length)
    }

    private fun signPow(v: Double, p: Double): Double = v.let { if (it < 0) -((-it).pow(p)) else it.pow(p) }

    // ---- bg/ ----

    private fun dotFadeGrid(w: Int, h: Int, step: Double, maxR: Double, seed: Long): RecipeResult {
        val rng = Rng(seed)
        val cx = w / 2.0; val cy = h / 2.0
        val maxD = sqrt(cx * cx + cy * cy)
        val sb = StringBuilder()
        var nodes = 0
        var y = step / 2
        while (y < h) {
            var x = step / 2
            while (x < w) {
                val d = sqrt((x - cx).pow(2) + (y - cy).pow(2)) / maxD
                val rr = maxR * (1.0 - d) * rng.range(0.75, 1.0)
                if (rr > 0.4) {
                    sb.append("<circle cx=\"${f(x)}\" cy=\"${f(y)}\" r=\"${f(rr)}\" fill=\"currentColor\"/>")
                    nodes++
                }
                x += step
            }
            y += step
        }
        val svg = wrap("0 0 $w $h", w, h, sb.toString(), "dot-fade-grid step=$step maxR=$maxR seed=$seed")
        return RecipeResult(svg, nodes, svg.length)
    }

    private fun sunburst(size: Double, rays: Int, seed: Long): RecipeResult {
        val rng = Rng(seed)
        val cx = size * 0.32; val cy = size * 0.3
        val R = size * 1.1
        val sb = StringBuilder()
        for (i in 0 until rays) {
            val jitter = rng.range(-0.06, 0.06)
            val a0 = 2 * Math.PI * i / rays + jitter
            val a1 = 2 * Math.PI * (i + 0.5) / rays + jitter
            val op = rng.range(0.06, 0.16)
            sb.append(
                "<path d=\"M${f(cx)} ${f(cy)} L${f(cx + R * cos(a0))} ${f(cy + R * sin(a0))} " +
                    "L${f(cx + R * cos(a1))} ${f(cy + R * sin(a1))} Z\" fill=\"currentColor\" fill-opacity=\"${f(op)}\"/>"
            )
        }
        val svg = wrap("0 0 ${f(size)} ${f(size)}", size.toInt(), size.toInt(), sb.toString(), "sunburst rays=$rays seed=$seed")
        return RecipeResult(svg, rays, svg.length)
    }

    /** value-noise field → marching-squares contour extraction (§6.1 topo-lines). */
    private fun topoLines(size: Double, levels: Int, scale: Double, seed: Long): RecipeResult {
        val N = 40
        val rng = Rng(seed)
        val gridSeed = List(4) { rng.range(0.0, 100.0) }
        val hash = { x: Int, y: Int -> (sin(x * 127.1 + y * 311.7 + gridSeed[0]) * 43758.5453).let { it - kotlin.math.floor(it) } }
        fun noise(x: Double, y: Double): Double {
            val xi = kotlin.math.floor(x); val yi = kotlin.math.floor(y)
            val xf = x - xi; val yf = y - yi
            val s = hash(xi.toInt(), yi.toInt()); val t = hash((xi + 1).toInt(), yi.toInt())
            val u2 = hash(xi.toInt(), (yi + 1).toInt()); val v = hash((xi + 1).toInt(), (yi + 1).toInt())
            val sx = xf * xf * (3 - 2 * xf); val sy = yf * yf * (3 - 2 * yf)
            return (s * (1 - sx) + t * sx) * (1 - sy) + (u2 * (1 - sx) + v * sx) * sy
        }
        val field = Array(N + 1) { i -> DoubleArray(N + 1) { j -> noise(j * scale * N / 2, i * scale * N / 2) } }
        val sb = StringBuilder()
        var nodes = 0
        for (l in 1..levels) {
            val level = l.toDouble() / (levels + 1)
            sb.append("<path stroke=\"currentColor\" stroke-width=\"1\" fill=\"none\" fill-opacity=\"0\" d=\"")
            var started = false
            for (i in 0 until N) for (j in 0 until N) {
                val c = doubleArrayOf(field[i][j], field[i][j + 1], field[i + 1][j + 1], field[i + 1][j])
                val x0 = j.toDouble() * size / N; val y0 = i.toDouble() * size / N
                val cell = size / N
                fun interp(a: Double, b: Double): Double = (level - a) / (b - a)
                val edges = ArrayList<Triple<Double, Double, Double>>()  // x1,y1 → x2,y2 (angle for sort)
                if ((c[0] > level) != (c[1] > level)) edges.add(Triple(x0 + cell * interp(c[0], c[1]), y0, 0.0))
                if ((c[1] > level) != (c[2] > level)) edges.add(Triple(x0 + cell, y0 + cell * interp(c[1], c[2]), 1.0))
                if ((c[2] > level) != (c[3] > level)) edges.add(Triple(x0 + cell * interp(c[3], c[2]), y0 + cell, 0.0))
                if ((c[3] > level) != (c[0] > level)) edges.add(Triple(x0, y0 + cell * interp(c[0], c[3]), 1.0))
                if (edges.size >= 2) {
                    val (ax, ay, _) = edges[0]; val (bx, by, _) = edges[1]
                    if (!started) { sb.append("M${f(ax)} ${f(ay)}"); started = true } else sb.append(" M${f(ax)} ${f(ay)}")
                    sb.append(" L${f(bx)} ${f(by)}"); nodes++
                }
            }
            sb.append("\"/>")
        }
        val svg = wrap("0 0 ${f(size)} ${f(size)}", size.toInt(), size.toInt(), sb.toString(), "topo-lines levels=$levels scale=$scale seed=$seed")
        return RecipeResult(svg, nodes, svg.length)
    }

    // ---- pattern/ ----

    private fun truchet(w: Int, h: Int, cell: Double, variant: String, seed: Long): RecipeResult {
        val rng = Rng(seed)
        val sb = StringBuilder()
        var nodes = 0
        val cols = (w / cell).toInt(); val rows = (h / cell).toInt()
        val r = cell / 2
        for (i in 0 until cols) for (j in 0 until rows) {
            val x = i * cell; val y = j * cell
            when (variant) {
                "line" -> {
                    val horiz = rng.next() > 0.5
                    sb.append(if (horiz)
                        "<path d=\"M${f(x)} ${f(y + r)} L${f(x + cell)} ${f(y + r)}\"/>"
                    else
                        "<path d=\"M${f(x + r)} ${f(y)} L${f(x + r)} ${f(y + cell)}\"/>")
                }
                "triangle" -> {
                    val dir = if (rng.next() > 0.5) 0 else 1
                    sb.append(if (dir == 0)
                        "<path d=\"M${f(x)} ${f(y)} L${f(x + cell)} ${f(y)} L${f(x)} ${f(y + cell)} Z\"/>"
                    else
                        "<path d=\"M${f(x + cell)} ${f(y)} L${f(x + cell)} ${f(y + cell)} L${f(x)} ${f(y + cell)} Z\"/>")
                }
                else -> {  // arc — the classic
                    val dir = if (rng.next() > 0.5) 0 else 1
                    sb.append(if (dir == 0)
                        "<path d=\"M${f(x)} ${f(y)} A${f(r)} ${f(r)} 0 0 1 ${f(x + cell)} ${f(y + cell)}\"/>"
                    else
                        "<path d=\"M${f(x + cell)} ${f(y)} A${f(r)} ${f(r)} 0 0 0 ${f(x)} ${f(y + cell)}\"/>")
                }
            }
            nodes++
        }
        val head = "<g stroke=\"currentColor\" stroke-width=\"${f(cell / 15)}\" fill=\"none\">"
        val svg = wrap("0 0 $w $h", w, h, head + sb.toString() + "</g>", "truchet cell=$cell variant=$variant seed=$seed")
        return RecipeResult(svg, nodes, svg.length)
    }

    private fun crossHatch(w: Int, h: Int, angleCount: Int, density: Double, seed: Long): RecipeResult {
        val rng = Rng(seed)
        val sb = StringBuilder()
        var nodes = 0
        val angles = (0 until angleCount).map { Math.PI / 4.0 * it + rng.range(-0.05, 0.05) }
        for (a in angles) {
            val spacing = density * rng.range(0.8, 1.3)
            val diag = sqrt((w * w + h * h).toDouble())
            var off = -diag / 2
            while (off < diag / 2) {
                val cx = w / 2.0 + off * cos(a + Math.PI / 2)
                val cy = h / 2.0 + off * sin(a + Math.PI / 2)
                sb.append(
                    "<path d=\"M${f(cx - diag / 2 * cos(a))} ${f(cy - diag / 2 * sin(a))} " +
                        "L${f(cx + diag / 2 * cos(a))} ${f(cy + diag / 2 * sin(a))}\"/>"
                )
                off += spacing; nodes++
            }
        }
        val head = "<g stroke=\"currentColor\" stroke-width=\"1\" fill=\"none\">"
        val svg = wrap("0 0 $w $h", w, h, head + sb.toString() + "</g>", "cross-hatch angles=$angleCount density=$density seed=$seed")
        return RecipeResult(svg, nodes, svg.length)
    }

    private fun lowPoly(w: Int, h: Int, cell: Double, jitter: Double, seed: Long): RecipeResult {
        val rng = Rng(seed)
        val cols = (w / cell).toInt() + 1; val rows = (h / cell).toInt() + 1
        val pts = Array(rows) { i -> Array(cols) { j ->
            val jx = if (j == 0 || j == cols - 1) 0.0 else rng.range(-jitter, jitter) * cell
            val jy = if (i == 0 || i == rows - 1) 0.0 else rng.range(-jitter, jitter) * cell
            Pair(j * cell + jx, i * cell + jy)
        } }
        val sb = StringBuilder()
        var nodes = 0
        fun tri(a: Pair<Double, Double>, b: Pair<Double, Double>, c: Pair<Double, Double>) {
            // one light vector (from top-left) shades each face by its normal
            val e1 = Pair(b.first - a.first, b.second - a.second)
            val e2 = Pair(c.first - a.first, c.second - a.second)
            val cross = e1.first * e2.second - e1.second * e2.first
            val shade = (0.5 + 0.5 * min(1.0, abs(cross) / (cell * cell))).coerceIn(0.08, 0.5)
            sb.append("<path d=\"M${f(a.first)} ${f(a.second)} L${f(b.first)} ${f(b.second)} L${f(c.first)} ${f(c.second)} Z\" fill=\"currentColor\" fill-opacity=\"${f(shade)}\"/>")
            nodes++
        }
        for (i in 0 until rows - 1) for (j in 0 until cols - 1) {
            val flip = rng.next() > 0.5
            val p00 = pts[i][j]; val p10 = pts[i][j + 1]; val p01 = pts[i + 1][j]; val p11 = pts[i + 1][j + 1]
            if (flip) { tri(p00, p11, p10); tri(p00, p11, p01) } else { tri(p01, p10, p00); tri(p01, p10, p11) }
        }
        val svg = wrap("0 0 $w $h", w, h, sb.toString(), "low-poly cell=$cell jitter=$jitter seed=$seed")
        return RecipeResult(svg, nodes, svg.length)
    }

    /** Native-safe grain: seeded tileable dot pattern (no filters — §6.3 note). */
    private fun grain(w: Int, h: Int, density: Double, seed: Long): RecipeResult {
        val rng = Rng(seed)
        val sb = StringBuilder()
        val count = (w * h * density / 10).toInt().coerceAtMost(4000)
        val dots = (0 until count).map { _ -> Triple(rng.next() * w, rng.next() * h, rng.range(0.4, 1.1)) }
            .joinToString("") { (x, y, r) -> "<circle cx=\"${f(x)}\" cy=\"${f(y)}\" r=\"${f(r)}\" fill=\"currentColor\"/>" }
        sb.append("<g fill-opacity=\"0.05\">").append(dots).append("</g>")
        val svg = wrap("0 0 $w $h", w, h, sb.toString(), "grain density=$density seed=$seed")
        return RecipeResult(svg, count, svg.length)
    }

    // ---- data/ (charts take REAL data, exact scales, no chartjunk) ----

    private fun chartBar(values: List<Double>, w: Int, h: Int): RecipeResult? {
        if (values.size < 2) return null
        val pad = 40.0
        val maxV = (values.maxOrNull() ?: 1.0).coerceAtLeast(0.001)
        val bw = (w - pad * 2) / (values.size * 1.6)
        val sb = StringBuilder()
        values.forEachIndexed { i, v ->
            val bh = (h - pad * 2) * (v / maxV)
            val x = pad + i * (w - pad * 2) / values.size + bw * 0.3
            val y = h - pad - bh
            sb.append("<path d=\"M${f(x)} ${f(y)} h${f(bw)} v${f(bh)} h${f(-bw)} Z\" fill=\"currentColor\" fill-opacity=\"${f(0.75 + 0.25 * v / maxV)}\"/>")
            sb.append("<text x=\"${f(x + bw / 2)}\" y=\"${f(y - 6)}\" font-size=\"12\" text-anchor=\"middle\" fill=\"currentColor\" opacity=\"0.8\">${fmtVal(v)}</text>")
        }
        sb.append("<path d=\"M${f(pad)} ${f(h - pad)} H${f(w - pad)}\" stroke=\"currentColor\" stroke-width=\"1\" opacity=\"0.4\"/>")
        val svg = wrap("0 0 $w $h", w, h, sb.toString(), "chart-bar n=${values.size}")
        return RecipeResult(svg, values.size * 2, svg.length)
    }

    private fun chartLine(values: List<Double>, w: Int, h: Int): RecipeResult? {
        if (values.size < 2) return null
        val pad = 40.0
        val maxV = values.maxOrNull() ?: 1.0; val minV = values.minOrNull() ?: 0.0
        val span = (maxV - minV).coerceAtLeast(0.001)
        fun px(i: Int) = pad + i * (w - pad * 2) / (values.size - 1)
        fun py(v: Double) = h - pad - (h - pad * 2) * (v - minV) / span
        val d = values.indices.joinToString("") { i ->
            (if (i == 0) "M" else " L") + "${f(px(i))} ${f(py(values[i]))}"
        }
        val area = "$d L${f(px(values.size - 1))} ${f(h - pad)} L${f(pad)} ${f(h - pad)} Z"
        val sb = StringBuilder()
            .append("<path d=\"$area\" fill=\"currentColor\" fill-opacity=\"0.12\"/>")
            .append("<path d=\"$d\" stroke=\"currentColor\" stroke-width=\"2\" fill=\"none\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/>")
        values.forEachIndexed { i, v ->
            sb.append("<circle cx=\"${f(px(i))}\" cy=\"${f(py(v))}\" r=\"3\" fill=\"currentColor\"/>")
        }
        val svg = wrap("0 0 $w $h", w, h, sb.toString(), "chart-line n=${values.size}")
        return RecipeResult(svg, values.size * 2, svg.length)
    }

    private fun chartDonut(values: List<Double>, size: Double): RecipeResult? {
        if (values.size < 2) return null
        val total = values.sum().coerceAtLeast(0.001)
        val cx = size / 2; val cy = size / 2
        val rOut = size * 0.4; val rIn = size * 0.26
        var a0 = -Math.PI / 2
        val gap = 0.02
        val sb = StringBuilder()
        values.forEachIndexed { i, v ->
            val sweep = 2 * Math.PI * (v / total)
            val a1 = a0 + sweep - gap
            val large = if (sweep > Math.PI) 1 else 0
            fun pt(r: Double, a: Double) = "${f(cx + r * cos(a))} ${f(cy + r * sin(a))}"
            sb.append(
                "<path d=\"M${pt(rOut, a0)} A${f(rOut)} ${f(rOut)} 0 $large 1 ${pt(rOut, a1)} " +
                    "L${pt(rIn, a1)} A${f(rIn)} ${f(rIn)} 0 $large 0 ${pt(rIn, a0)} Z\" " +
                    "fill=\"currentColor\" fill-opacity=\"${f(0.45 + 0.55 * (i + 1) / values.size)}\"/>"
            )
            a0 += sweep
        }
        val svg = wrap("0 0 ${f(size)} ${f(size)}", size.toInt(), size.toInt(), sb.toString(), "chart-donut n=${values.size}")
        return RecipeResult(svg, values.size, svg.length)
    }

    private fun fmtVal(v: Double): String =
        if (v == v.toLong().toDouble()) v.toLong().toString() else String.format("%.1f", v)

    // ---- scene/ ----

    /** Deterministic 5×5 mirrored identicon from a seed hash (§6.6 avatar-geo). */
    private fun identicon(seed: Long, size: Double): RecipeResult {
        val rng = Rng(seed)
        val cell = size / 7
        val sb = StringBuilder()
        var nodes = 0
        for (i in 0 until 3) for (j in 0 until 5) {
            if (rng.next() > 0.5) {
                sb.append("<rect x=\"${f((i + 1) * cell)}\" y=\"${f((j + 1) * cell)}\" width=\"${f(cell)}\" height=\"${f(cell)}\" fill=\"currentColor\"/>")
                if (i < 2) sb.append("<rect x=\"${f((5 - i) * cell)}\" y=\"${f((j + 1) * cell)}\" width=\"${f(cell)}\" height=\"${f(cell)}\" fill=\"currentColor\"/>")
                nodes++
            }
        }
        val svg = wrap("0 0 ${f(size)} ${f(size)}", size.toInt(), size.toInt(), sb.toString(), "identicon seed=$seed")
        return RecipeResult(svg, nodes, svg.length)
    }

    // ============================================================
    // §9 THE DESIGN DIRECTION CONTRACT
    // ============================================================

    fun directionContract(): String = """
DESIGN DIRECTION CONTRACT (DIRECTION.md — one per project, written BEFORE any vector/UI work, from the subject not from taste):

0. THE FOUR QUESTIONS (answer in prose first):
   - What is the subject's WORLD? (physical objects, materials, documents, instruments, vernacular — a budgeting app lives among receipts, ledgers, envelopes, stamps; motifs come from here, and this kills the rocket/lightbulb/shield cliché)
   - Who is the AUDIENCE? (age, expertise, glanceable-on-phone vs desk vs projected)
   - What is the JOB of the graphics? (orient=hero · explain=diagram · delight=identicon · reassure=empty state · signal=icon)
   - What must it NOT look like? (name two real competitors/aesthetics you're avoiding — negative direction beats positive adjectives)

1. COMMITTED AESTHETIC: name it ("Industrial ledger", "Botanical print", "Terminal brutalism", "Coastal riso") + the one sentence a stranger should say.
2. PALETTE (locked): ink / paper / rule + ONE accent (≤10% of any screen) + accent-2 (≤5%, semantic) + success/warning/danger (state only). Never pure #000 or #FFF. Contrast ≥4.5:1 body.
3. TYPE: display (the personality — must not be Inter/Roboto/system-ui/Poppins/Space Grotesk; those are the AI defaults) + body + mono for data. Max 2 families + 1 mono. Scale ratio 1.2-1.25.
4. VECTOR RULES: stroke width (one constant), terminals, joins, corner radius (one value or 0), 24u grid with 2u padding, light direction (one vector or flat), gradients allowed/banned, blur allowed/banned, shadows, texture %, max hues per asset (2-3), node budgets (icon 60 · illustration 400 · background 1200), pinned icon set (do not mix sets).
5. FORBIDDEN (explicit list — high-severity slop hits): purple/indigo/violet of any hue · blurred gradient blobs · glassmorphism by reflex · 3D-render look · rocket/lightbulb/shield/puzzle metaphors · same soft-grey-shadow cards everywhere · gradient text · emoji as icons · colored left-border strips · tracked-out ALL-CAPS eyebrows · "A · B · C" meta strings · → on every button · tinted near-black #0B0B0B · exactly three feature cards in a row.
6. MOTIF BANK: 6-12 concrete motifs from question 0 (perforated receipt edge, stamp ring, registration marks, roast curve, gauge bezel ticks…). This is what makes the work specific.
7. THE ONE BOLD THING: which single element is loud on each screen; everything else quiet. Two loud focal areas = fail.
8. CHANGE CONTROL: written once before building; amended only with user approval; per-screen variety comes from composition, not a new palette.

Write it to DIRECTION.md in the project folder with the user (draft → they approve). Then every VectorBrief, recipe run and retrieved asset is checked against it.
""".trim()

    // ============================================================
    // §7 ROUTE A — RETRIEVE (Iconify API + sanitize + license ledger)
    // ============================================================

    private val ICON_LICENSES = mapOf(
        "lucide" to "ISC", "tabler" to "MIT", "ph" to "MIT", "mdi" to "Apache-2.0",
        "material-symbols" to "Apache-2.0", "heroicons" to "MIT", "solar" to "CC-BY-4.0 (attribution!)",
        "iconoir" to "MIT", "carbon" to "Apache-2.0", "fluent" to "MIT", "bi" to "MIT",
        "ri" to "Apache-2.0", "radix-icons" to "MIT", "si" to "CC0 (brand marks — never redraw trademarks)",
        "svg-spinners" to "MIT", "twemoji" to "CC-BY-4.0", "noto" to "OFL/CC-BY", "circle-flags" to "MIT"
    )

    /**
     * Fetch an icon from the Iconify public API and SANITIZE it (a retrieved
     * SVG is untrusted input — script/onclick/external href are real XSS
     * vectors in a WebView). Returns the sanitized SVG + license line.
     */
    fun retrieve(prefix: String, name: String): Result2 {
        val url = "https://api.iconify.design/$prefix/$name.svg"
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000; conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "LimanAgent/1.0 (on-device agent)")
            if (conn.responseCode !in 200..299) return Result2(null, "HTTP ${conn.responseCode} from $url", false)
            val raw = conn.inputStream.bufferedReader().readText()
            val clean = sanitize(raw)
                ?: return Result2(null, "Retrieved SVG failed sanitization (script/handlers/external refs) — refusing it.", false)
            val lic = ICON_LICENSES[prefix] ?: "check https://icon-sets.iconify.design/$prefix/ (license varies per set)"
            Result2(clean, lic, true)
        } catch (e: Exception) {
            Result2(null, "retrieve failed: ${e.message?.take(120)}", false)
        }
    }

    data class Result2(val svg: String?, val note: String, val ok: Boolean)

    /** §7.9.6 sanitize: strip scripts, event handlers, external refs, DOCTYPE/entities. */
    fun sanitize(svg: String): String? {
        if (svg.contains("<script") || Regex("""\son\w+\s*=""").containsMatchIn(svg) ||
            svg.contains("javascript:") || svg.contains("data:text/html") || svg.contains("<!DOCTYPE") ||
            svg.contains("<!ENTITY")
        ) return null
        var s = svg.replace(Regex("""<foreignObject[\s\S]*?</foreignObject>"""), "")
        // external href (keep fragment-only refs)
        s = s.replace(Regex("""(href|xlink:href)\s*=\s*"(?!#)[^"]*["]"""), "")
        return if (!s.contains("<svg")) null else s
    }

    // ============================================================
    // §10 THE SLOP DETECTOR — deterministic aesthetic score
    // ============================================================

    data class SlopHit(val rule: String, val severity: String, val problem: String, val fix: String)

    data class SlopReport(
        val score: Int,
        val verdict: String,       // clean | minor | slop
        val hits: List<SlopHit>,
        val stats: String,
        val nextAction: String
    )

    private val CLICHE = listOf("#6366F1", "#8B5CF6", "#A855F7", "#7C3AED", "#EC4899", "#3B82F6")
    private val FONT_CLICHE = listOf("inter", "roboto", "arial", "helvetica", "poppins", "system-ui", "space grotesk", "montserrat", "open sans", "geist")
    private val MOTIF_CLICHE = listOf("rocket", "lightbulb", "light-bulb", "shield", "puzzle", "growth-arrow")

    fun slopScore(svg: String, name: String = ""): SlopReport {
        val hits = ArrayList<SlopHit>()
        var weightHit = 0
        var weightAll = 0
        fun hit(rule: String, sev: String, weight: Int, problem: String, fix: String, counts: Boolean = true) {
            hits.add(SlopHit(rule, sev, problem, fix))
            if (counts) weightHit += weight
        }

        // gather stats
        val hexes = Regex("#[0-9a-fA-F]{6}").findAll(svg).map { it.value.uppercase() }.toList()
        val gradients = Regex("<(linear|radial)Gradient").findAll(svg).count()
        val elements = Regex("<[a-zA-Z]").findAll(svg).count()
        val paths = Regex("<path\\b").findAll(svg).count()
        val filters = Regex("<filter\\b").findAll(svg).count()
        val ids = Regex("""\bid="([^"]+)"""").findAll(svg).map { it.groupValues[1] }.toList()
        val fonts = Regex("""font-family="([^"]+)["]""").findAll(svg).map { it.groupValues[1].lowercase() }.toList()
        val blurMatches = Regex("""blur\((\d+(?:\.\d+)?)px\)""").findAll(svg).map { it.groupValues[1].toDouble() }.toList()

        // 24 palette_cliche — ΔE-lite: hue+sat distance to the AI-default ramp
        val cliched = hexes.map { hex -> CLICHE.any { c -> colorDist(hex, c) } }.count { it }
        if (cliched >= 2) hit("palette_cliche", "high", 3, "$cliched colour(s) within ΔE<12 of the indigo→violet→pink AI-default ramp",
            "Re-derive from DIRECTION.md / design tokens — one subject-derived accent instead of #6366F1-family defaults.")

        // 4 blob_bg — large blurred shapes behind content
        val bigBlur = blurMatches.count { it > 24 }
        if (bigBlur >= 2) hit("blob_bg", "high", 3, "$bigBlur shape(s) with blur > 24px — the default 'atmosphere' of every AI landing page",
            "Use a recipe instead (bg/topo-lines, bg/dot-fade-grid) or a posterized mesh (bands), never blurred ellipses.")

        // 5 gradient_abuse
        if (elements > 0 && gradients > elements / 6.0 && gradients > 1)
            hit("gradient_abuse", "med", 2, "$gradients gradients across $elements elements",
                "Max one gradient per 6 elements; flat + tints reads more designed than gradient soup.")

        // 13 raster_embed
        if (svg.contains("<image")) hit("raster_embed", "high", 3, "<image> inside an SVG — defeats the point of vector",
            "Use real vector paths or a retrieved icon; never embed raster data.")

        // 14 emoji_glyph
        if (Regex("""<text[^>]*>[^<]*[🌀-🫿]""").containsMatchIn(svg))
            hit("emoji_glyph", "high", 3, "emoji codepoint inside <text>", "Draw it: use a twemoji/noto retrieved SVG, not a text emoji.")

        // 16 dup_ids
        if (ids.size != ids.distinct().size) hit("dup_ids", "high", 3, "duplicate id attributes — inlining breaks",
            "Namespace ids per asset (recipe outputs already do).")

        // 15 dead_defs
        val defs = Regex("<defs").findAll(svg).count()
        if (defs > 0 && ids.distinct().count { id -> !svg.contains("url(#$id)") && !svg.contains("href=\"#$id\"") } > 0)
            hit("dead_defs", "low", 1, "unreferenced defs (gradients/filters declared, never used)",
                "Delete unreferenced defs — they're copy-paste residue.")

        // 17 font_cliche + 18 font_count
        if (fonts.any { f -> FONT_CLICHE.any { f.contains(it) } })
            hit("font_cliche", "med", 2, "AI-default font family as the primary face",
                "Pick a display face with personality (see DIRECTION.md type section); Inter/system-ui is the uniform of generated pages.")
        if (fonts.distinct().size > 2) hit("font_count", "low", 1, "${fonts.distinct().size} font families", "Max 2 families (+1 mono for data).")

        // 9b precision_noise — hand-emitted path data signature
        val coords = Regex("""-?\d+\.\d{3,}""").findAll(svg).count()
        val allNums = Regex("""-?\d+(?:\.\d+)?""").findAll(svg).count()
        if (allNums > 20 && coords.toDouble() / allNums > 0.35)
            hit("precision_noise", "med", 2, "${(100.0 * coords / allNums).toInt()}% of coordinates carry ≥3 decimals — the signature of hand-emitted path data",
                "Don't freehand beziers. Use a recipe (deterministic, 2-decimal) or retrieve a real asset.")

        // 12 viewbox_fit — content bbox vs viewBox (approximation via coordinate extremes)
        val vb = Regex("""viewBox="([\d. -]+)["]""").find(svg)?.groupValues?.get(1)?.trim()?.split(" ")
        if (vb != null && vb.size == 4) {
            val (vx, vy, vw, vh) = listOf(vb[0].toDouble(), vb[1].toDouble(), vb[2].toDouble(), vb[3].toDouble())
            val xs = ArrayList<Double>(); val ys = ArrayList<Double>()
            Regex("""[ML]\s*(-?[\d.]+)[ ,]+(-?[\d.]+)""").findAll(svg).forEach { m ->
                xs += m.groupValues[1].toDouble(); ys += m.groupValues[2].toDouble()
            }
            if (xs.size >= 4) {
                val minX = xs.min(); val maxX = xs.max(); val minY = ys.min(); val maxY = ys.max()
                if (maxX > vx + vw + 1 || maxY > vy + vh + 1 || minX < vx - 1 || minY < vy - 1)
                    hit("viewbox_fit", "high", 3, "content extends outside the viewBox — it will clip",
                        "Fix the viewBox or the geometry; clipped icons are the loudest broken tell.")
                else {
                    val padL = minX - vx; val padR = vx + vw - maxX
                    val padT = minY - vy; val padB = vy + vh - maxY
                    val asym = (abs(padL - padR) + abs(padT - padB)) / (vw + vh)
                    if (asym > 0.24) hit("viewbox_fit", "high", 3, "padding is asymmetric (${f(padL)}/${f(padR)} h, ${f(padT)}/${f(padB)} v) — off-center copy-paste",
                        "Optically center the content with 2u padding inside the viewBox.")
                }
            }
        }

        // 19 motif_cliche
        val hay = (name + " " + svg.take(600)).lowercase()
        val motif = MOTIF_CLICHE.firstOrNull { hay.contains(it) }
        if (motif != null) hit("motif_cliche", "med", 2, "'$motif' — one of the four most overused software metaphors",
            "Derive a motif from the SUBJECT instead (see DIRECTION.md question 0).")

        // 24 security — blocking, not scored
        if (svg.contains("<script") || Regex("""\son\w+\s*=""").containsMatchIn(svg) || svg.contains("javascript:"))
            hit("security", "block", 0, "script/event-handler/javascript: URI in an SVG — XSS vector",
                "Strip before use (the retrieve route sanitizes automatically).", counts = false)

        // total weights: high=3 med=2 low=1 over the scored rule universe
        weightAll = 3 * 6 + 2 * 6 + 1 * 3   // ≈ the 15 scorable rules above
        val score = if (hits.any { it.severity == "block" }) 100
        else (100.0 * weightHit / weightAll).toInt().coerceIn(0, 100)
        val hasHigh = hits.any { it.severity == "high" }
        val verdict = when {
            hits.any { it.severity == "block" } -> "slop"
            hasHigh || score >= 20 -> "slop"
            score < 8 -> "clean"
            else -> "minor"
        }
        val next = when {
            hits.any { it.rule == "palette_cliche" || it.rule == "blob_bg" } ->
                "iterate: switch to a recipe (vector_studio op:recipe_run) with the DIRECTION.md palette — do NOT reseed the same approach"
            hits.any { it.rule == "precision_noise" || it.rule == "viewbox_fit" } ->
                "iterate: replace hand-written path data with a recipe or a retrieved asset"
            verdict == "slop" -> "iterate: change ONE thing the report names, then re-score (max 2 iterations, then change route)"
            else -> "ship"
        }
        val stats = "nodes≈${Regex("""[MLCQAHSZTmlcqahzszt]""").findAll(svg).count()}, bytes=${svg.length}, paths=$paths, gradients=$gradients, filters=$filters, hues=${hexes.distinct().size}"
        return SlopReport(score, verdict, hits, stats, next)
    }

    /** cheap ΔE: RGB-space distance normalized 0-100 */
    private fun colorDist(a: String, b: String): Boolean {
        fun rgb(h: String) = listOf(
            h.substring(1, 3).toInt(16), h.substring(3, 5).toInt(16), h.substring(5, 7).toInt(16)
        )
        val (r1, g1, b1) = rgb(a); val (r2, g2, b2) = rgb(b)
        val d = sqrt(((r1 - r2).toDouble().pow(2) + (g1 - g2).toDouble().pow(2) + (b1 - b2).toDouble().pow(2)) / 3.0)
        return d < 28   // ≈ ΔE<12 in this rough space
    }

    /** Human-readable report for tool output. */
    fun slopReportText(r: SlopReport): String = buildString {
        appendLine("SLOP SCORE: ${r.score}/100 — verdict: ${r.verdict.uppercase()} ${when (r.verdict) { "clean" -> "✅"; "minor" -> "🟡"; else -> "⛔" }}")
        appendLine(r.stats)
        if (r.hits.isEmpty()) appendLine("No AI-tells detected. Ship it.")
        else {
            appendLine("Hits:")
            r.hits.take(8).forEach { appendLine("- [${it.severity}] ${it.rule}: ${it.problem}\n  fix: ${it.fix}") }
            appendLine("next: ${r.nextAction}")
        }
    }.trim()

    // ============================================================
    // §11 THE SVG VALIDATOR — structural gate (runs before slop)
    // ============================================================

    data class Validation(val ok: Boolean, val errors: List<String>, val warnings: List<String>)

    private val CMD_ARGS = mapOf(
        'M' to 2, 'L' to 2, 'H' to 1, 'V' to 1, 'C' to 6, 'S' to 4, 'Q' to 4, 'T' to 2, 'A' to 7, 'Z' to 0,
        'm' to 2, 'l' to 2, 'h' to 1, 'v' to 1, 'c' to 6, 's' to 4, 'q' to 4, 't' to 2, 'a' to 7, 'z' to 0
    )

    fun validate(svg: String, target: String = "web"): Validation {
        val errors = ArrayList<String>()
        val warnings = ArrayList<String>()
        if (!svg.contains("<svg")) return Validation(false, listOf("no <svg> root element"), warnings)
        if (!Regex("""viewBox="[\d. -]+"""").containsMatchIn(svg)) errors.add("missing or malformed viewBox")
        if (!svg.contains("xmlns=\"http://www.w3.org/2000/svg\"") && svg.trimStart().startsWith("<?xml"))
            warnings.add("standalone SVG should declare the SVG namespace")
        if (svg.contains("<script") || Regex("""\son\w+\s*=""").containsMatchIn(svg))
            errors.add("security: script/event handler present")
        if (Regex("""href\s*=\s*"(?!#)[^"]*["]""").containsMatchIn(svg))
            errors.add("security: external href reference")

        // path data validation: per-segment arg counts, finite numbers, arc radii
        Regex("""\sd="([^"]*)["]""").findAll(svg).forEach { m ->
            val d = m.groupValues[1]
            var cmds = 0
            Regex("""[MLHVCSQTAZmlhvcsqtaz][^MLHVCSQTAZmlhvcsqtaz]*""").findAll(d).forEach { seg ->
                val cmd = seg.value[0]
                val need = CMD_ARGS[cmd] ?: return@forEach
                cmds++
                val nums = Regex("""-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?""")
                    .findAll(seg.value.substring(1)).mapNotNull { it.value.toDoubleOrNull() }.toList()
                if (nums.size != nums.count { !it.isInfinite() && !it.isNaN() })
                    errors.add("path data: non-finite number in segment '$cmd'")
                if (need > 0 && nums.isNotEmpty() && nums.size % need != 0)
                    errors.add("path data: '$cmd' needs multiples of $need args, got ${nums.size} in “${d.take(50)}…”")
                if ((cmd == 'A' || cmd == 'a') && nums.size >= 7 && nums[0] == 0.0 && nums[1] == 0.0)
                    warnings.add("arc with zero radius (treated as line — usually a bug)")
            }
            if (cmds > 400) warnings.add("$cmds path commands — over the 400-node illustration budget (icon budget is 60)")
        }

        // dup ids
        val ids = Regex("""\sid="([^"]+)["]""").findAll(svg).map { it.groupValues[1] }.toList()
        if (ids.size != ids.distinct().size) errors.add("duplicate id attributes")

        // budgets
        if (svg.length > 30_000) warnings.add("${svg.length / 1024} KB — over the 30 KB illustration budget")
        val paths = Regex("<path\\b").findAll(svg).count()
        if (paths > 60) warnings.add("$paths paths — over the 60-path budget")

        // target compatibility (§11.5)
        if (target == "android-vd") {
            if (svg.contains("<text")) errors.add("android-vd: <text> is not supported by VectorDrawable — convert to paths")
            if (svg.contains("<filter") || svg.contains("blur(")) errors.add("android-vd: filters are not supported")
            if (svg.contains("<mask")) errors.add("android-vd: masks are not supported")
            if (Regex("<(linear|radial)Gradient[^>]*>.{0,400}?<stop").findAll(svg).any { Regex("<stop").findAll(it.value).count() > 2 })
                errors.add("android-vd: gradients with >2 stops are not supported")
            if (Regex("""<(circle|rect|line|polyline|ellipse)\b""").containsMatchIn(svg))
                warnings.add("android-vd: contains primitive shapes (circle/rect/line…) — convert with svg_icon op:convert before res/drawable/")
        }
        return Validation(errors.isEmpty(), errors, warnings)
    }

    fun validationText(v: Validation): String = buildString {
        appendLine(if (v.ok) "VALIDATION: ✅ structurally valid" else "VALIDATION: ⛔ ${v.errors.size} error(s)")
        v.errors.forEach { appendLine("- ERROR: $it") }
        v.warnings.forEach { appendLine("- warn: $it") }
        if (v.ok && v.warnings.isEmpty()) appendLine("(path data checked: command/arg counts, finite numbers, arc radii; ids unique; budgets ok)")
    }.trim()

    // ============================================================
    // §3.1 — the 3-line plan the model emits before any vector work
    // ============================================================

    fun protocol(): String = """
VECTOR PROTOCOL (emit before touching any file):
  INTENT:  <purpose> · <slot & size> · <theme> · <job: orient|explain|delight|reassure|signal>
  ROUTE:   retrieve | compose | generate  + one-sentence justification
  METHOD:  <recipe id + the 3-8 params that matter | iconify prefix/name | kit part>
RULE 0: You do not draw by writing path data. Hand-written paths longer than ~12 commands are a bug, not a style.
Route table: functional icon→RETRIEVE (iconify) · brand logo→RETRIEVE (simple-icons only) · app monogram→GENERATE · hero with people→RETRIEVE (Open Peeps/unDraw) · abstract bg→GENERATE (topo/dot-grid/sunburst) · divider→GENERATE (wave/scallop) · texture→GENERATE (truchet/hatch/grain) · empty state→COMPOSE kit · chart→GENERATE from real data · avatar→GENERATE identicon.
Escalation: 2 failed slop checks on one route → SWITCH ROUTE, don't reseed. Never ship a failed generation.
Verify chain (cheapest first): validate → slop_score → (render_html with the SVG inlined to eyeball it) → report numbers. No screenshot, no claim.
""".trim()
}
