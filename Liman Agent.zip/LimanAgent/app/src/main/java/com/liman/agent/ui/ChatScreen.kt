package com.liman.agent.ui

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.AnimatedContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.liman.agent.LimanApplication
import com.liman.agent.R
import com.liman.agent.agent.HtmlRenderer
import com.liman.agent.agent.buildCombo
import com.liman.agent.data.Entry
import com.liman.agent.util.Str
import com.liman.agent.util.fmtBytes
import com.liman.agent.util.fmtTime
import com.liman.agent.util.prettyJsonOrSelf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    vm: ChatViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val container = remember { LimanApplication.get(context).container }

    val entries by vm.entries.collectAsState()
    val running by vm.running.collectAsState()
    val tick by vm.streamTick.collectAsState()
    val runStatus by vm.runStatus.collectAsState()
    val approval by vm.pendingApproval.collectAsState()
    val prompt by vm.pendingPrompt.collectAsState()
    val imports by vm.pendingImports.collectAsState()
    val steers by vm.pendingSteers.collectAsState()
    val livePreview by vm.livePreview.collectAsState()
    val conv by vm.conversation.collectAsState()
    val settings by vm.settings.collectAsState()
    val providers by vm.providers.collectAsState()

    // language: setting wins, "system" follows the device locale
    val fa = when (settings.language) {
        "fa" -> true
        "en" -> false
        else -> java.util.Locale.getDefault().language == "fa"
    }
    val t = remember(fa) { Str(fa) }

    var input by remember { mutableStateOf("") }
    var showRename by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showWorkspace by remember { mutableStateOf(false) }
    var wsFiles by remember { mutableStateOf<List<File>>(emptyList()) }
    var wsFileAction by remember { mutableStateOf<File?>(null) }
    var htmlViewerFile by remember { mutableStateOf<File?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }
    var showDiagLog by remember { mutableStateOf(false) }
    var entryBaseline by remember { mutableStateOf(Int.MAX_VALUE) }
    // v2.31
    var showModelPicker by remember { mutableStateOf(false) }
    var showAllWorkspaces by remember { mutableStateOf(false) }
    var allWsFiles by remember { mutableStateOf<List<File>>(emptyList()) }
    var wsPlusMenu by remember { mutableStateOf(false) }
    var roadmapOpen by remember { mutableStateOf(true) }

    val listState = rememberLazyListState()

    val combos by container.stores.combo.state.collectAsState()
    val comboDesc = remember(providers, combos) {
        runCatching { buildCombo(container.stores, {}) }.getOrNull()?.describe() ?: "no provider"
    }

    // launchers
    val attachLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> if (uris.isNotEmpty()) vm.attach(uris) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) vm.importToWorkspace(uris) {
            scope.launch(Dispatchers.IO) { wsFiles = vm.listWorkspace() }
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/markdown")
    ) { uri ->
        if (uri != null) toast = vm.exportMarkdown(uri)
    }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()?.let { input = if (input.isBlank()) it else "$input $it" }
        }
    }

    LaunchedEffect(Unit) { input = vm.consumeDraft() }
    LaunchedEffect(settings.ttsEnabled) { if (settings.ttsEnabled) vm.ensureTts() }

    // smart following: auto-scroll only while the user is at the bottom;
    // scrolling up suspends following; a jump pill brings them back
    var follow by remember { mutableStateOf(true) }
    val atBottom by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val lastVisible = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            info.totalItemsCount == 0 || lastVisible >= info.totalItemsCount - 2
        }
    }
    LaunchedEffect(atBottom) { if (atBottom) follow = true }
    LaunchedEffect(listState.isScrollInProgress) {
        if (listState.isScrollInProgress && !atBottom) follow = false
    }
    LaunchedEffect(entries.size, tick?.text?.length ?: 0) {
        if (!follow) return@LaunchedEffect
        val n = entries.size + if (tick != null) 1 else 0
        if (n > 0) listState.animateScrollToItem(n - 1)
    }
    LaunchedEffect(toast) {
        if (toast != null) {
            kotlinx.coroutines.delay(2500)
            toast = null
        }
    }
    LaunchedEffect(entries.size) {
        if (entries.size < entryBaseline) entryBaseline = entries.size
    }

    fun doSend() {
        val text = input.trim()
        // v2.27.0 SLASH COMMANDS (openclaude logic): quick client-side actions
        if (text.startsWith("/") && text.length > 1) {
            val cmd = text.substringBefore(' ').lowercase()
            when (cmd) {
                "/stop" -> { vm.stop(); input = "" ; toast = if (fa) "متوقف شد" else "Stopped" }
                "/new", "/clear" -> { onBack(); toast = "Chat list — tap + for a new chat"; input = "" }
                "/help" -> {
                    toast = "/stop · /new · /help — plus everything else goes to the agent as usual"
                    input = ""
                }
                else -> { vm.send(text); input = "" } // unknown slash → let the agent interpret it
            }
            return
        }
        vm.send(text)
        input = ""
    }

    val dir = if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalStr provides t, LocalLayoutDirection provides dir) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            LimanIcon(R.drawable.ic_back, MaterialTheme.colorScheme.onSurface)
                        }
                    },
                    title = {
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            Text(
                                conv?.title ?: t.task,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1
                            )
                            Text(
                                comboDesc,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    },
                    actions = {
                        // v2.28.0 — the Doctor's Log: what happened in the backend
                        IconButton(onClick = { showDiagLog = true }) {
                            LimanIcon(R.drawable.ic_description, MaterialTheme.colorScheme.onSurface)
                        }
                        IconButton(onClick = { showWorkspace = true }) {
                            LimanIcon(R.drawable.ic_folder, MaterialTheme.colorScheme.onSurface)
                        }
                        IconButton(onClick = onOpenSettings) {
                            LimanIcon(R.drawable.ic_settings, MaterialTheme.colorScheme.onSurface)
                        }
                        IconButton(onClick = { showMenu = true }) {
                            LimanIcon(R.drawable.ic_more, MaterialTheme.colorScheme.onSurface)
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                leadingIcon = { LimanIcon(R.drawable.ic_edit_file, MaterialTheme.colorScheme.onSurfaceVariant, size = 18) },
                                text = { Text(t.renameTask) },
                                onClick = { showMenu = false; showRename = true }
                            )
                            DropdownMenuItem(
                                leadingIcon = { LimanIcon(R.drawable.ic_share, MaterialTheme.colorScheme.onSurfaceVariant, size = 18) },
                                text = { Text(t.exportMd) },
                                onClick = {
                                    showMenu = false
                                    exportLauncher.launch(vm.suggestFileName())
                                }
                            )
                            DropdownMenuItem(
                                leadingIcon = { LimanIcon(R.drawable.ic_delete_file, MaterialTheme.colorScheme.onSurfaceVariant, size = 18) },
                                text = { Text(t.clearConv) },
                                onClick = { showMenu = false; vm.clearConversation() }
                            )
                        }
                    }
                )
            },
            bottomBar = {
                // floating pill input (bento)
                Surface(
                    color = MaterialTheme.colorScheme.background,
                    shadowElevation = 0.dp
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .imePadding()
                            .navigationBarsPadding()
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        // v2.36 — the live mission checklist card (plan/build mode removed)
                        conv?.roadmap?.let { r ->
                            RoadmapCard(
                                roadmap = r,
                                expanded = roadmapOpen,
                                onToggle = { roadmapOpen = !roadmapOpen }
                            )
                        }
                        if (imports.isNotEmpty()) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                            ) {
                                imports.forEach { imp ->
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier.clickableNoIndication { vm.removeImport(imp.relPath) }
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(start = 10.dp, end = 8.dp, top = 6.dp, bottom = 6.dp)
                                        ) {
                                            LimanIcon(R.drawable.ic_attach, MaterialTheme.colorScheme.onSurfaceVariant, size = 13)
                                            Spacer(Modifier.width(5.dp))
                                            Text(
                                                "${imp.name} (${imp.size.fmtBytes()})",
                                                style = MaterialTheme.typography.labelMedium
                                            )
                                            Spacer(Modifier.width(4.dp))
                                            LimanIcon(R.drawable.ic_close, MaterialTheme.colorScheme.onSurfaceVariant, size = 13)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.size(6.dp))
                        }
                        // v2.33 — contextual LIVE PREVIEW pane (coding tasks only)
                        livePreview?.let { lp ->
                            androidx.compose.animation.AnimatedVisibility(
                                visible = true,
                                enter = androidx.compose.animation.slideInVertically(
                                    animationSpec = spring(dampingRatio = 0.75f, stiffness = 300f)
                                ) { it } + androidx.compose.animation.fadeIn(),
                                exit = androidx.compose.animation.slideOutVertically { it } + androidx.compose.animation.fadeOut()
                            ) {
                                LivePreviewPane(
                                    imagePath = lp.imagePath,
                                    url = lp.url,
                                    label = lp.label,
                                    onDismiss = { vm.dismissPreview() }
                                )
                            }
                        }
                        // v2.33 — steering chips (queued mid-run messages)
                        SteerChipsRow(steers, onRemove = { vm.removeSteer(it) })
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)
                            )
                        ) {
                            Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(4.dp)) {
                                IconButton(onClick = { attachLauncher.launch(arrayOf("*/*")) }) {
                                    LimanIcon(R.drawable.ic_attach, MaterialTheme.colorScheme.onSurfaceVariant, size = 21)
                                }
                                OutlinedTextField(
                                    value = input,
                                    onValueChange = { input = it },
                                    modifier = Modifier.weight(1f),
                                    placeholder = {
                                        Text(
                                            if (running) t.workingHint else t.inputHint,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                        )
                                    },
                                    maxLines = 5,
                                    shape = RoundedCornerShape(22.dp),
                                    enabled = true,
                                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                        unfocusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                                        focusedBorderColor = androidx.compose.ui.graphics.Color.Transparent,
                                        unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                                        focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent
                                    )
                                )
                                // send ⇄ stop morph: the primary action transitions
                                // inside the SAME bounds — position & target stay stable
                                AnimatedContent(
                                    targetState = running,
                                    transitionSpec = {
                                        (scaleIn(
                                            animationSpec = spring(dampingRatio = 0.8f, stiffness = 500f),
                                            initialScale = 0.6f
                                        ) + fadeIn()) togetherWith (scaleOut(targetScale = 0.6f) + fadeOut())
                                    },
                                    label = "sendStop"
                                ) { runningNow ->
                                    if (runningNow && input.isNotBlank()) {
                                    // v2.33 — steer: queue the message for the moment
                                    // this run finishes (chip appears above)
                                    val steerInteraction = remember { MutableInteractionSource() }
                                    val steerScale = pressScale(steerInteraction, pressed = 0.8f)
                                    IconButton(
                                        onClick = { vm.queueSteer(input.trim()); input = "" },
                                        interactionSource = steerInteraction
                                    ) {
                                        Box(
                                            Modifier
                                                .size(36.dp)
                                                .graphicsLayer { scaleX = steerScale; scaleY = steerScale }
                                                .background(
                                                    MaterialTheme.colorScheme.tertiaryContainer,
                                                    RoundedCornerShape(13.dp)
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            LimanIcon(
                                                R.drawable.ic_arrow_forward,
                                                MaterialTheme.colorScheme.onTertiaryContainer,
                                                size = 18
                                            )
                                        }
                                    }
                                } else if (runningNow) {
                                    // pulsing stop button
                                    val ticker = androidx.compose.animation.core.rememberInfiniteTransition(label = "stop")
                                    val p by ticker.animateFloat(
                                        initialValue = 1f,
                                        targetValue = 0.78f,
                                        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                                            androidx.compose.animation.core.tween(500),
                                            androidx.compose.animation.core.RepeatMode.Reverse
                                        ),
                                        label = "p"
                                    )
                                    IconButton(onClick = { vm.stop() }) {
                                        Box(
                                            Modifier
                                                .size(36.dp)
                                                .graphicsLayer { scaleX = p; scaleY = p }
                                                .background(
                                                    MaterialTheme.colorScheme.errorContainer,
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            LimanIcon(R.drawable.ic_stop, MaterialTheme.colorScheme.error, size = 18)
                                        }
                                    }
                                } else {
                                    // springy send button
                                    val sendInteraction = remember { MutableInteractionSource() }
                                    val sendScale = pressScale(sendInteraction, pressed = 0.8f)
                                    val sendPressed by sendInteraction.collectIsPressedAsState()
                                    val rotate by animateFloatAsState(
                                        targetValue = if (sendPressed) -16f else 0f,
                                        animationSpec = spring(
                                            dampingRatio = Spring.DampingRatioMediumBouncy,
                                            stiffness = 600f
                                        ),
                                        label = "rotate"
                                    )
                                    val canSend = input.isNotBlank() || imports.isNotEmpty()
                                    IconButton(
                                        onClick = { if (canSend) doSend() },
                                        interactionSource = sendInteraction,
                                        enabled = canSend
                                    ) {
                                        Box(
                                            Modifier
                                                .size(40.dp)
                                                .graphicsLayer {
                                                    scaleX = sendScale
                                                    scaleY = sendScale
                                                    rotationZ = rotate
                                                }
                                                .background(
                                                    // v2.34 FLUID CANVAS — the sky→indigo signature gradient
                                                    if (canSend) Brush.linearGradient(
                                                        listOf(
                                                            com.liman.agent.ui.theme.LimanExtras.RailA,
                                                            com.liman.agent.ui.theme.LimanExtras.RailB
                                                        )
                                                    ) else androidx.compose.ui.graphics.Brush.linearGradient(
                                                        listOf(
                                                            MaterialTheme.colorScheme.surfaceVariant,
                                                            MaterialTheme.colorScheme.surfaceVariant
                                                        )
                                                    ),
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            LimanIcon(
                                                R.drawable.ic_send,
                                                if (canSend) com.liman.agent.ui.theme.LimanExtras.OnSignalFallback
                                                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                                size = 19
                                            )
                                        }
                                    }
                                    }
                                }
                                IconButton(onClick = {
                                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                        putExtra(
                                            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                                        )
                                    }
                                    runCatching { micLauncher.launch(intent) }
                                        .onFailure { toast = "Speech recognition not available" }
                                }) { LimanIcon(R.drawable.ic_mic, MaterialTheme.colorScheme.onSurfaceVariant, size = 20) }
                            }
                        }
                    }
                }
            }
        ) { pad ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(pad)
            ) {
                // ---- live heartbeat: always show what Liman is doing ----
                RunStatusBar(
                    running = running,
                    phase = runStatus.phase,
                    waiting = runStatus.waiting,
                    startedAt = runStatus.startedAt,
                    lastActivityAt = runStatus.lastActivityAt,
                    onStop = { vm.stop() }
                )

                // v2.36 — quick model switch (the Plan/Build strip is gone)
                ModeStrip(
                    modelLabel = comboDesc,
                    onPickModel = { showModelPicker = true }
                )

                // v2.20 — LangGraph crash-resume: this conversation has a run
                // that was killed mid-flight; its checkpoint survived
                vm.interruptedGoal.value?.let { ig ->
                    if (!running) {
                        Card(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.tertiaryContainer
                            )
                        ) {
                            Row(
                                Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        "⚡ Interrupted run recovered",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        ig,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                                        maxLines = 2
                                    )
                                }
                                TextButton(onClick = { vm.resumeInterrupted() }) { Text("Resume") }
                                TextButton(onClick = { vm.dismissInterrupted() }) { Text("Dismiss") }
                            }
                        }
                    }
                }

                Box(
                    Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    if (entries.isEmpty() && !running) {
                        Box(Modifier.fillMaxSize()) {
                            // aurora: two soft drifting light fields behind the welcome
                            AuroraBackdrop(Modifier.fillMaxSize())
                            Column(
                                Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                // one short, subtle reveal — the identity mark settles in
                                var shown by remember { mutableStateOf(false) }
                                LaunchedEffect(Unit) { shown = true }
                                val markScale by animateFloatAsState(
                                    targetValue = if (shown) 1f else 0.6f,
                                    animationSpec = spring(dampingRatio = 0.75f, stiffness = 380f),
                                    label = "mark"
                                )
                                val markAlpha by androidx.compose.animation.core.animateFloatAsState(
                                    targetValue = if (shown) 1f else 0f,
                                    animationSpec = spring(dampingRatio = 1f, stiffness = 380f),
                                    label = "markAlpha"
                                )
                                Box(Modifier.graphicsLayer { scaleX = markScale; scaleY = markScale; alpha = markAlpha }) {
                                    ApertureMark(ApertureState.IDLE, size = 68)
                                }
                                Spacer(Modifier.size(18.dp))
                                Text(
                                    t.welcomeTitle,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Text(
                                    t.welcomeSub,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(top = 6.dp, bottom = 8.dp)
                                )
                                Spacer(Modifier.size(6.dp))
                            t.suggestions.forEachIndexed { idx, (s, icon) ->
                                var shown by remember { mutableStateOf(false) }
                                LaunchedEffect(Unit) {
                                    kotlinx.coroutines.delay(80L * idx)
                                    shown = true
                                }
                                val cardInteraction = remember { MutableInteractionSource() }
                                val cardScale = pressScale(cardInteraction, pressed = 0.96f)
                                val appear by animateFloatAsState(
                                    targetValue = if (shown) 1f else 0f,
                                    animationSpec = spring(dampingRatio = 0.7f, stiffness = 300f),
                                    label = "appear$idx"
                                )
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .graphicsLayer {
                                            scaleX = cardScale * (0.92f + 0.08f * appear)
                                            scaleY = cardScale * (0.92f + 0.08f * appear)
                                            alpha = appear
                                        },
                                    shape = RoundedCornerShape(18.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                                    ),
                                    interactionSource = cardInteraction,
                                    onClick = { input = s }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(13.dp)
                                    ) {
                                        LimanIcon(iconRes(icon), MaterialTheme.colorScheme.primary, size = 19)
                                        Spacer(Modifier.width(12.dp))
                                        Text(s, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }
                        }
                    } else {
                        // v2.34 FLUID CANVAS — living backdrop: two slow-drifting
                        // blue nebula blobs behind the conversation (subtle, GPU-cheap)
                        FluidBlobs()
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            itemsIndexed(entries) { idx, e ->
                                // v2.27.0 knotwork date chips — the chat list stays a working list
                                val day = dayLabelOf(e.ts())
                                val prevDay = if (idx > 0) dayLabelOf(entries[idx - 1].ts()) else null
                                if (day != null && day != prevDay) DateChip(day)
                                val cycle = cycleOf(e)
                                val prevCycle = if (idx > 0) cycleOf(entries[idx - 1]) else null
                                if (cycle != null && cycle != prevCycle && cycle > 1) {
                                    CycleDivider(cycle)
                                }
                                if (idx >= entryBaseline) EnterSpring { EntryView(e) } else EntryView(e)
                            }
                            tick?.let { tt -> item { EnterSpring { StreamingBubble(tt.attemptKey, tt.text, tt.cycle) } } }
                        }
                    }
                    // jump-to-latest: appears when the user scrolled up during a run
                    androidx.compose.animation.AnimatedVisibility(
                        visible = !follow && entries.isNotEmpty() && !atBottom,
                        enter = slideInVertically(
                            animationSpec = spring(dampingRatio = 0.8f, stiffness = 400f)
                        ) { it / 2 } + fadeIn(),
                        exit = slideOutVertically { it / 2 } + fadeOut(),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 16.dp, bottom = 10.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(18.dp),
                            shadowElevation = 4.dp,
                            modifier = Modifier.clickableNoIndication {
                                follow = true
                                scope.launch {
                                    listState.animateScrollToItem(
                                        (listState.layoutInfo.totalItemsCount - 1).coerceAtLeast(0)
                                    )
                                }
                            }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(start = 12.dp, end = 14.dp, top = 7.dp, bottom = 7.dp)
                            ) {
                                LimanIcon(R.drawable.ic_arrow_forward, MaterialTheme.colorScheme.onPrimary, size = 15)
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    t.jumpLatest,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
                    androidx.compose.animation.AnimatedVisibility(
                        visible = toast != null,
                        enter = slideInVertically(
                            animationSpec = spring(dampingRatio = 0.75f, stiffness = 380f)
                        ) { it / 2 } + fadeIn(),
                        exit = slideOutVertically { it / 2 } + fadeOut(),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(12.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.inverseSurface,
                            shape = RoundedCornerShape(16.dp),
                            tonalElevation = 6.dp
                        ) {
                            Text(
                                toast.orEmpty(),
                                color = MaterialTheme.colorScheme.inverseOnSurface,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // ---------- approval dialog ----------
        approval?.let { ap ->
            AlertDialog(
                onDismissRequest = { vm.respondApproval(false, false) },
                icon = { LimanIcon(toolIconRes(ap.call.name), MaterialTheme.colorScheme.primary, size = 26) },
                title = { Text(t.allowTool) },
                text = {
                    Column {
                        Text(
                            t.agentWants + " " + ap.call.name,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.size(8.dp))
                        MonoBox(ap.call.argsJson.prettyJsonOrSelf())
                    }
                },
                confirmButton = {
                    Row {
                        TextButton(onClick = { vm.respondApproval(true, true) }) { Text(t.alwaysAllow) }
                        TextButton(onClick = { vm.respondApproval(true, false) }) { Text(t.allow) }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { vm.respondApproval(false, false) }) { Text(t.deny) }
                }
            )
        }

        // ---------- ask_user dialog ----------
        prompt?.let { pp ->
            var answer by remember(pp.question) { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { vm.skipPrompt() },
                icon = { LimanIcon(R.drawable.ic_ask_user, MaterialTheme.colorScheme.tertiary, size = 26) },
                title = { Text(t.limanAsks) },
                text = {
                    Column {
                        DirectionalText(pp.question)
                        if (pp.options.isNotEmpty()) {
                            Spacer(Modifier.size(10.dp))
                            pp.options.forEach { opt ->
                                FilterChip(
                                    selected = answer == opt,
                                    onClick = { answer = opt },
                                    label = { Text(opt) },
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(Modifier.size(10.dp))
                        OutlinedTextField(
                            value = answer,
                            onValueChange = { answer = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("…") }
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { vm.answerPrompt(answer) }) { Text(t.answer) } },
                dismissButton = { TextButton(onClick = { vm.skipPrompt() }) { Text(t.skip) } }
            )
        }

        // ---------- rename dialog ----------
        if (showRename) {
            var name by remember { mutableStateOf(conv?.title ?: "") }
            AlertDialog(
                onDismissRequest = { showRename = false },
                title = { Text(t.renameTask) },
                text = {
                    OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth())
                },
                confirmButton = {
                    TextButton(onClick = { vm.rename(name); showRename = false }) { Text(t.save) }
                },
                dismissButton = { TextButton(onClick = { showRename = false }) { Text(t.cancel) } }
            )
        }

        // ---------- v2.31: model/provider picker ----------
        if (showModelPicker) {
            ModalBottomSheet(onDismissRequest = { showModelPicker = false }) {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text("Model", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Switch provider or model for this and future runs. Current: $comboDesc",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.size(10.dp))
                    LazyColumn(Modifier.heightIn(max = 460.dp)) {
                        item {
                            ProviderRow(
                                title = "All providers",
                                subtitle = "failover team — every enabled provider in sequence",
                                selected = providers.filter { it.enabled }.map { it.id } ==
                                    container.stores.combo.state.value.providerIds,
                                onClick = {
                                    toast = vm.switchProvider(null, null)
                                    showModelPicker = false
                                }
                            )
                        }
                        providers.filter { it.enabled }.forEach { pr ->
                            val selected = container.stores.combo.state.value.providerIds == listOf(pr.id)
                            item {
                                ProviderRow(
                                    title = pr.name,
                                    subtitle = pr.model.ifBlank { "(default model)" },
                                    selected = selected,
                                    onClick = {
                                        toast = vm.switchProvider(pr.id, null)
                                        showModelPicker = false
                                    }
                                )
                            }
                            val models = (listOf(pr.model) + pr.freeModels).filter { it.isNotBlank() }.distinct().take(8)
                            models.forEach { m ->
                                item {
                                    ProviderRow(
                                        title = m,
                                        subtitle = "${pr.name} · model",
                                        selected = selected && pr.model == m,
                                        small = true,
                                        onClick = {
                                            toast = vm.switchProvider(pr.id, m)
                                            showModelPicker = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.size(28.dp))
                }
            }
        }

        // ---------- v2.31: all-workspaces browser ----------
        if (showAllWorkspaces) {
            ModalBottomSheet(onDismissRequest = { showAllWorkspaces = false }) {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text("All workspaces", style = MaterialTheme.typography.headlineSmall)
                    Text(
                        "Every file across every chat (root workspace). Tapping a file copies it into THIS chat's workspace and stages it for the next message.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.size(8.dp))
                    if (allWsFiles.isEmpty()) {
                        Text("(no files anywhere yet)")
                    } else {
                        LazyColumn(Modifier.heightIn(max = 420.dp)) {
                            items(allWsFiles.take(150)) { f ->
                                val rel = f.relativeToOrNull(container.workspace)?.toString()?.replace('\\', '/') ?: f.name
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickableNoIndication {
                                            vm.importFromAllWorkspaces(rel)
                                            showAllWorkspaces = false
                                            toast = "Copied into this chat + attached"
                                        }
                                        .padding(vertical = 8.dp)
                                ) {
                                    LimanIcon(fileIconRes(f), MaterialTheme.colorScheme.primary, size = 18)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(f.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                                        Text(
                                            rel.substringBeforeLast('/').ifBlank { "/" },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                    Text("${f.length().fmtBytes()}", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.size(28.dp))
                }
            }
        }


        // ---------- workspace sheet ----------
        if (showWorkspace) {
            LaunchedEffect(Unit) {
                withContext(Dispatchers.IO) { wsFiles = vm.listWorkspace() }
            }
            ModalBottomSheet(onDismissRequest = { showWorkspace = false }) {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LimanIcon(R.drawable.ic_folder, MaterialTheme.colorScheme.primary, size = 22)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(t.workspace, style = MaterialTheme.typography.headlineSmall)
                            Text(
                                if (conv?.ownWorkspace == true) "This chat's own folder — other chats stay separate."
                                else "Shared workspace (legacy chat).",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        Box {
                            FilledTonalButton(
                                onClick = { wsPlusMenu = true },
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text("+", style = MaterialTheme.typography.titleLarge)
                            }
                            DropdownMenu(expanded = wsPlusMenu, onDismissRequest = { wsPlusMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Upload from storage") },
                                    onClick = { wsPlusMenu = false; importLauncher.launch(arrayOf("*/*")) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Browse all workspaces") },
                                    onClick = {
                                        wsPlusMenu = false
                                        scope.launch(Dispatchers.IO) {
                                            allWsFiles = vm.listAllWorkspaces()
                                        }
                                        showAllWorkspaces = true
                                    }
                                )
                            }
                        }
                    }
                    Spacer(Modifier.size(8.dp))
                    if (wsFiles.isEmpty()) {
                        Text("(workspace is empty — import files or let the agent create some)")
                    } else {
                        LazyColumn(Modifier.heightIn(max = 420.dp)) {
                            itemsIndexed(wsFiles) { _, f ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                ) {
                                    LimanIcon(fileIconRes(f), MaterialTheme.colorScheme.primary, size = 19)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            f.relativeToOrNull(container.workspace)?.toString()
                                                ?.replace('\\', '/') ?: f.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            maxLines = 1
                                        )
                                        Text(
                                            "${f.length().fmtBytes()} · ${f.lastModified().fmtTime()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    TextButton(onClick = { wsFileAction = f }) { Text("•••") }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.size(28.dp))
                }
            }
        }

        // ---------- file action dialog ----------
        wsFileAction?.let { f ->
            val rel = f.relativeToOrNull(container.workspace)?.toString()?.replace('\\', '/') ?: f.name
            val isHtml = f.extension.lowercase() in setOf("html", "htm")
            AlertDialog(
                onDismissRequest = { wsFileAction = null },
                icon = { LimanIcon(fileIconRes(f), MaterialTheme.colorScheme.primary, size = 28) },
                title = { Text(f.name, style = MaterialTheme.typography.titleMedium) },
                text = { Text("${f.length().fmtBytes()} · $rel") },
                confirmButton = {
                    TextButton(onClick = {
                        vm.addImport(rel)
                        wsFileAction = null
                        toast = t.addedToMsg
                    }) { Text(t.attachNext) }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = {
                            if (isHtml) {
                                htmlViewerFile = f
                            } else {
                                vm.openFileIntent(f)?.let {
                                    runCatching { context.startActivity(it) }
                                        .onFailure { toast = t.noAppOpen }
                                } ?: run { toast = t.cannotOpen }
                            }
                            wsFileAction = null
                        }) { Text(t.view) }
                        if (f.extension.equals("apk", ignoreCase = true)) {
                            TextButton(onClick = {
                                vm.installApkIntent(f)?.let {
                                    runCatching { context.startActivity(it) }
                                        .onFailure { toast = t.noInstaller }
                                } ?: run { toast = t.cannotOpen }
                                wsFileAction = null
                            }) { Text(t.install) }
                        }
                        TextButton(onClick = {
                            vm.shareFileIntent(f)?.let {
                                runCatching { context.startActivity(Intent.createChooser(it, "Share file")) }
                            }
                            wsFileAction = null
                        }) { Text(t.share) }
                        TextButton(onClick = {
                            vm.deleteWorkspaceFile(f)
                            scope.launch(Dispatchers.IO) { wsFiles = vm.listWorkspace() }
                            wsFileAction = null
                        }) { Text(t.delete) }
                    }
                }
            )
        }

        // ---------- in-app HTML viewer ----------
        htmlViewerFile?.let { f ->
            HtmlViewerDialog(file = f, onClose = { htmlViewerFile = null })
        }
    }

    // v2.28.0 — the Doctor's Log overlay (draws over the chat)
    if (showDiagLog) {
        DiagLogScreen(onBack = { showDiagLog = false })
    }
}

/** no-ripple clickable helper for tonal chips */
private fun Modifier.clickableNoIndication(onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = MutableInteractionSource(),
        indication = null,
        onClick = onClick
    )

/**
 * Internal HTML viewer: renders a workspace HTML file (plus its sibling
 * css/js/assets) fully offline in an in-app WebView — no external browser.
 */
@Composable
fun HtmlViewerDialog(file: File, onClose: () -> Unit) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.background,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    LimanIcon(R.drawable.ic_render_html, MaterialTheme.colorScheme.primary, size = 18)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        file.name,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onClose) {
                        LimanIcon(R.drawable.ic_close, MaterialTheme.colorScheme.onSurface, size = 20)
                    }
                }
                val baseDir = file.parentFile ?: file
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.allowFileAccess = false
                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(
                                    view: WebView,
                                    request: WebResourceRequest
                                ): WebResourceResponse? {
                                    val rel = request.url.path?.removePrefix("/") ?: return null
                                    val f2 = HtmlRenderer.resolveWithin(baseDir, rel) ?: return null
                                    if (!f2.isFile) return null
                                    return try {
                                        WebResourceResponse(
                                            HtmlRenderer.mimeFor(f2.name), "utf-8", f2.inputStream()
                                        )
                                    } catch (e: Exception) {
                                        null
                                    }
                                }
                            }
                            loadUrl("https://liman.local/${file.name}")
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                )
            }
        }
    }
}

/** Which agent cycle an entry belongs to (for the timeline dividers). */
private fun cycleOf(e: Entry): Int? = when (e) {
    is Entry.ToolEntry -> e.cycle
    is Entry.AssistantEntry -> e.cycle.takeIf { it > 0 }
    else -> null
}

private fun iconRes(name: String): Int = when (name) {
    "ic_web_search" -> R.drawable.ic_web_search
    "ic_build_apk" -> R.drawable.ic_build_apk
    "ic_read_file" -> R.drawable.ic_read_file
    "ic_image_generate" -> R.drawable.ic_image_generate
    "ic_memory" -> R.drawable.ic_memory
    "ic_read_link" -> R.drawable.ic_read_link
    else -> R.drawable.ic_bot
}

fun fileIconRes(f: File): Int = when (f.extension.lowercase()) {
    in IMAGE_EXTS_HELPER -> R.drawable.ic_image_generate
    in VIDEO_EXTS_HELPER -> R.drawable.ic_render_html
    in AUDIO_EXTS_HELPER -> R.drawable.ic_mic
    "pdf" -> R.drawable.ic_read_file
    "docx", "doc" -> R.drawable.ic_read_file
    "xlsx", "xls" -> R.drawable.ic_read_file
    "pptx" -> R.drawable.ic_read_file
    "zip", "jar" -> R.drawable.ic_folder
    "md", "txt" -> R.drawable.ic_description
    "html", "htm" -> R.drawable.ic_render_html
    "js", "kt", "java", "py", "ts", "json" -> R.drawable.ic_run_js
    else -> R.drawable.ic_description
}

private val IMAGE_EXTS_HELPER = setOf("png", "jpg", "jpeg", "webp", "gif", "bmp", "heic", "heif")
private val VIDEO_EXTS_HELPER = setOf("mp4", "mkv", "webm", "mov", "3gp", "avi", "m4v")
private val AUDIO_EXTS_HELPER = setOf("mp3", "wav", "m4a", "aac", "ogg", "flac", "opus")


/**
 * Aurora backdrop (empty state only): two soft radial light fields drifting
 * slowly — mint + apricot over graphite. Calm, not distracting; disabled
 * entirely when the user turned system animations off.
 */
@Composable
fun AuroraBackdrop(modifier: Modifier = Modifier) {
    if (reducedMotion()) return
    val transition = rememberInfiniteTransition(label = "aurora")
    val x by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(12_000, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "ax"
    )
    val y by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(16_000, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "ay"
    )
    val mint = MaterialTheme.colorScheme.primary
    val apricot = MaterialTheme.colorScheme.tertiary
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        // mint field, upper-left drift
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(mint.copy(alpha = 0.13f), Color.Transparent),
                center = Offset(w * (0.28f + 0.14f * x), h * (0.30f + 0.10f * y)),
                radius = w * 0.6f
            ),
            radius = w * 0.6f,
            center = Offset(w * (0.28f + 0.14f * x), h * (0.30f + 0.10f * y))
        )
        // apricot field, lower-right counter-drift
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(apricot.copy(alpha = 0.09f), Color.Transparent),
                center = Offset(w * (0.78f - 0.12f * x), h * (0.62f + 0.12f * (1f - y))),
                radius = w * 0.55f
            ),
            radius = w * 0.55f,
            center = Offset(w * (0.78f - 0.12f * x), h * (0.62f + 0.12f * (1f - y)))
        )
    }
}


// ============================================================
// v2.27.0 — knotwork-style date chips
// ============================================================

private fun Entry.ts(): Long = when (this) {
    is Entry.UserEntry -> ts
    is Entry.AssistantEntry -> ts
    is Entry.ToolEntry -> ts
    is Entry.NoteEntry -> ts
    is Entry.ReviewEntry -> ts
    is Entry.PromptEntry -> ts
    is Entry.SubagentEntry -> ts
    is Entry.FileEntry -> ts
}

private fun dayLabelOf(ts: Long): String? {
    if (ts <= 0) return null
    val cal = java.util.Calendar.getInstance()
    val today = cal.get(java.util.Calendar.DAY_OF_YEAR)
    val year = cal.get(java.util.Calendar.YEAR)
    cal.timeInMillis = ts
    return when {
        cal.get(java.util.Calendar.YEAR) == year && cal.get(java.util.Calendar.DAY_OF_YEAR) == today -> "Today"
        cal.get(java.util.Calendar.YEAR) == year && cal.get(java.util.Calendar.DAY_OF_YEAR) == today - 1 -> "Yesterday"
        else -> java.text.SimpleDateFormat("EEE, MMM d", java.util.Locale.US).format(java.util.Date(ts))
    }
}

@Composable
private fun DateChip(label: String) {
    Row(
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
            )
        }
    }
}

// ============================================================
// v2.31 — PLAN ⇄ BUILD strip, roadmap card, provider picker rows
// ============================================================

/**
 * v2.36 — the mode strip, simplified: the Plan/Build toggle is gone (it
 * never worked well); what remains is the live model chip
 * (tap → provider/model picker).
 */
@Composable
private fun ModeStrip(
    modelLabel: String,
    onPickModel: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
    ) {
        // model chip — tap to switch provider/model
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
            modifier = Modifier
                .weight(1f)
                .clickableNoIndication { onPickModel() }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 10.dp, end = 8.dp, top = 6.dp, bottom = 6.dp)
            ) {
                Text("⚡", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.width(6.dp))
                Text(
                    modelLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Text("⌄", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}


/** The mission checklist card — live progress as the agent works. */
@Composable
private fun RoadmapCard(
    roadmap: com.liman.agent.data.Roadmap,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val done = roadmap.tasks.count { it.status == "done" }
    val total = roadmap.tasks.size.coerceAtLeast(1)
    val progress by animateFloatAsState(
        targetValue = done.toFloat() / total,
        animationSpec = tween(600), label = "roadmapProgress"
    )
    AnimatedVisibility(
        visible = true,
        enter = fadeIn() + slideInVertically(spring(dampingRatio = 0.8f, stiffness = 380f)) { it / 3 },
        exit = fadeOut()
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp)
        ) {
            Column(Modifier.padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (done == total) "✅ Mission — all done" else "🛠 Mission checklist",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${roadmap.title.take(26)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1, modifier = Modifier.weight(1f)
                    )
                    Text(
                        "$done/$total",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (done == total) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onToggle) { Text(if (expanded) "▴" else "▾") }
                }
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().padding(end = 6.dp),
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                AnimatedVisibility(visible = expanded) {
                    Column(Modifier.padding(top = 6.dp, end = 6.dp)) {
                        roadmap.tasks.take(10).forEach { task ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 3.dp)
                            ) {
                                val mark = when (task.status) {
                                    "done" -> "✅"
                                    "in_progress" -> "⏳"
                                    "failed" -> "❌"
                                    "blocked" -> "⛔"
                                    else -> "⬜"
                                }
                                Text(mark, style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    task.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (task.status == "done") MaterialTheme.colorScheme.onSurfaceVariant
                                    else androidx.compose.ui.graphics.Color.Unspecified,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProviderRow(title: String, subtitle: String, selected: Boolean, small: Boolean = false, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickableNoIndication { onClick() }
            .padding(horizontal = 4.dp, vertical = 8.dp)
    ) {
        Text(
            if (selected) "◉" else "○",
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(end = 10.dp)
        )
        Column {
            Text(
                title,
                style = if (small) MaterialTheme.typography.bodySmall else MaterialTheme.typography.bodyLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                maxLines = 1
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}


// ============================================================
// v2.34.0 FLUID CANVAS — the living backdrop from the accepted
// HTML design: two blurred blue nebula blobs drifting forever
// behind the chat. Pure Canvas, no bitmaps, reduced-motion aware.
// ============================================================
@Composable
fun FluidBlobs() {
    if (reducedMotion()) return
    val tr = rememberInfiniteTransition(label = "blobs")
    val t1 by tr.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "b1"
    )
    val t2 by tr.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(21000, easing = LinearEasing), RepeatMode.Reverse),
        label = "b2"
    )
    val blob = if (androidx.compose.foundation.isSystemInDarkTheme())
        com.liman.agent.ui.theme.LimanExtras.RailA else com.liman.agent.ui.theme.LimanExtras.RailB
    Canvas(Modifier.fillMaxSize()) {
        // blob 1 — top right, drifts diagonally
        val r1 = size.width * 0.85f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(blob.copy(alpha = 0.14f), Color.Transparent),
                center = Offset(size.width * (0.85f - 0.08f * t1), size.height * (0.06f + 0.1f * t1)),
                radius = r1
            ),
            radius = r1,
            center = Offset(size.width * (0.85f - 0.08f * t1), size.height * (0.06f + 0.1f * t1))
        )
        // blob 2 — bottom left
        val r2 = size.width * 0.75f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(com.liman.agent.ui.theme.LimanExtras.RailB.copy(alpha = 0.10f), Color.Transparent),
                center = Offset(size.width * (0.05f + 0.1f * t2), size.height * (0.75f - 0.08f * t2)),
                radius = r2
            ),
            radius = r2,
            center = Offset(size.width * (0.05f + 0.1f * t2), size.height * (0.75f - 0.08f * t2))
        )
    }
}
