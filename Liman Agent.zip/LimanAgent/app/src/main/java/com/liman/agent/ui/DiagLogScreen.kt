package com.liman.agent.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liman.agent.agent.DiagLog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v2.28.0 — THE DOCTOR'S LOG SCREEN.
 *
 * The user asked: "add a log button that can get the log of Liman app usage
 * and the errors or bridge errors — export it into an md file as a report of
 * what happened in the backend, so I can hand it back for repair."
 *
 * Reached from the chat top bar (log icon). Export writes the full Markdown
 * report via SAF.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagLogScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var events by remember { mutableStateOf(DiagLog.snapshot()) }
    var toast by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/markdown")
    ) { uri ->
        if (uri == null) { toast = "Export cancelled"; return@rememberLauncherForActivityResult }
        toast = runCatching {
            context.contentResolver.openOutputStream(uri)?.use { os ->
                os.write(DiagLog.toMarkdown().toByteArray(Charsets.UTF_8))
            } ?: error("stream closed")
            "Diagnostic report exported ✅ — attach it when reporting a problem"
        }.getOrElse { "Export failed: ${it.message}" }
        events = DiagLog.snapshot()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Column {
                    Text("Backend log", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${events.size} events · ${DiagLog.counts()[DiagLog.Level.ERROR] ?: 0} errors · ${DiagLog.counts()[DiagLog.Level.WARN] ?: 0} warnings",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
                },
                actions = {
                    TextButton(onClick = { DiagLog.clear(); events = DiagLog.snapshot() }) { Text("Clear") }
                    TextButton(onClick = {
                        exportLauncher.launch("liman-diag-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".md")
                    }) { Text("Export .md") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (toast != null) {
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        toast!!,
                        Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            // v2.34 — the permanent on-disk code log (never cleaned, per-day files)
            Text(
                DiagLog.permanentLogInfo(),
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            if (events.isEmpty()) {
                Text(
                    "Nothing logged yet. Use the app — every agent cycle, tool call and bridge error lands here.",
                    Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(
                    reverseLayout = false,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(events) { e ->
                        val color = when (e.level) {
                            DiagLog.Level.ERROR -> MaterialTheme.colorScheme.error
                            DiagLog.Level.WARN -> com.liman.agent.ui.theme.LimanExtras.Warn
                            DiagLog.Level.DEBUG -> MaterialTheme.colorScheme.onSurfaceVariant
                            DiagLog.Level.INFO -> MaterialTheme.colorScheme.onSurface
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.surface,
                            shape = MaterialTheme.shapes.small,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp)
                        ) {
                            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                Text(
                                    SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(e.ts)) +
                                        "  " + e.level.name + "  " + e.tag,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    e.msg,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = color,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 1.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
