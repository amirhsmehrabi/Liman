package com.liman.agent.agent

import com.liman.agent.llm.Http
import com.liman.agent.util.ellipsize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.Request
import java.io.IOException

/**
 * v2.23.0 — THE GITHUB RESEARCH ENGINE.
 *
 * The user's directive: when facing a task or coding project, Liman should
 * SEARCH GitHub repositories (titles + READMEs), find the relevant project,
 * DIVE DEEP into that repo's code, and USE it — adapt the code, run it,
 * build on it. GitHub-first is now a main way of solving tasks.
 *
 * Free out of the box: repository search, READMEs, file trees and raw file
 * content all work WITHOUT a token (60 req/hr core, 10 req/min search).
 * With a personal access token (action:'token') the ceiling is 5000/hr.
 */
object GithubResearch {

    private const val API = "https://api.github.com"
    private const val RAW = "https://raw.githubusercontent.com"
    const val TOKEN_NAME = "github_token"

    data class RepoHit(
        val fullName: String,
        val description: String,
        val stars: Int,
        val language: String,
        val updatedAt: String,
        val topics: List<String>,
        val defaultBranch: String
    )

    // ---------------- pure URL/validation helpers (tested) ----------------

    fun validRepo(repo: String): Boolean =
        Regex("""^[\w.\-]+/[\w.\-]+$""").matches(repo.trim()) && !repo.contains("..")

    fun searchUrl(query: String, language: String?, limit: Int, sort: String = "stars"): String {
        val q = buildString {
            append(query.trim())
            if (!language.isNullOrBlank()) append(" language:").append(language.trim())
        }
        return "$API/search/repositories?q=${enc(q)}&sort=$sort&order=desc&per_page=${limit.coerceIn(1, 30)}"
    }

    fun readmeUrl(repo: String): String = "$API/repos/${repo.trim()}/readme"

    fun treeUrl(repo: String, branch: String): String =
        "$API/repos/${repo.trim()}/git/trees/${branch.ifBlank { "HEAD" }}?recursive=1"

    fun fileUrl(repo: String, path: String, branch: String): String =
        "$RAW/${repo.trim()}/${branch.ifBlank { "HEAD" }}/${path.trim().trimStart('/')}"

    fun enc(s: String): String = java.net.URLEncoder.encode(s, "UTF-8")

    // ---------------- parsers (pure, tested) ----------------

    fun parseRepos(json: String): List<RepoHit> = runCatching {
        val arr = JSONB.parseToJsonElement(json).jsonObject["items"] as? JsonArray ?: return emptyList()
        arr.mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            RepoHit(
                fullName = o["full_name"]?.jsonPrimitive?.contentOrNull ?: return@mapNotNull null,
                description = o["description"]?.jsonPrimitive?.contentOrNull ?: "",
                stars = o["stargazers_count"]?.jsonPrimitive?.contentOrNull?.toIntOrNull() ?: 0,
                language = o["language"]?.jsonPrimitive?.contentOrNull ?: "",
                updatedAt = o["updated_at"]?.jsonPrimitive?.contentOrNull ?: "",
                topics = (o["topics"] as? JsonArray)?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList(),
                defaultBranch = o["default_branch"]?.jsonPrimitive?.contentOrNull ?: "main"
            )
        }
    }.getOrDefault(emptyList())

    fun parseTreePaths(json: String, filter: String?, limit: Int = 200): List<String> = runCatching {
        val o = JSONB.parseToJsonElement(json).jsonObject
        (o["tree"] as? JsonArray)?.mapNotNull { el ->
            (el as? JsonObject)?.get("path")?.jsonPrimitive?.contentOrNull
        } ?: emptyList()
    }.getOrDefault(emptyList())
        .filter { filter.isNullOrBlank() || it.contains(filter.trim(), ignoreCase = true) }
        .take(limit)

    /** true when the HTTP failure means the unauthenticated quota ran out. */
    fun isRateLimit(code: Int, body: String): Boolean =
        (code == 403 || code == 429) && body.lowercase().contains("rate limit")

    // ---------------- formatters (pure, tested) ----------------

    fun formatRepos(hits: List<RepoHit>, query: String): String = buildString {
        appendLine("GitHub repositories for \"$query\" (${hits.size} best matches):")
        hits.forEachIndexed { i, r ->
            appendLine()
            appendLine("${i + 1}. ${r.fullName} — ★${r.stars} · ${r.language.ifBlank { "?" }} · updated ${r.updatedAt.take(10)}")
            if (r.description.isNotBlank()) appendLine("   ${r.description.ellipsize(200)}")
            if (r.topics.isNotEmpty()) appendLine("   topics: ${r.topics.take(6).joinToString(", ")}")
            appendLine("   → dive in: github {action:'readme', repo:'${r.fullName}'} then {action:'tree'} and {action:'file'}")
        }
    }

    fun formatReadme(repo: String, markdown: String, maxChars: Int = 12_000): String {
        val body = markdown.take(maxChars)
        val note = if (markdown.length > maxChars) "\n…(README truncated at $maxChars chars — fetch specific files with github {action:'file'})" else ""
        return "README of $repo:\n----\n$body$note"
    }

    // ---------------- network (suspend) ----------------

    private fun get(url: String, token: String?, accept: String): Pair<Int, String> {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "LimanAgent/2.23 (Android agent)")
            .header("Accept", accept)
            .apply { token?.takeIf { it.isNotBlank() }?.let { header("Authorization", "Bearer $it") } }
            .build()
        Http.toolClient(40).newCall(req).execute().use { resp ->
            val body = runCatching { resp.body?.string() }.getOrNull() ?: ""
            return resp.code to body
        }
    }

    suspend fun search(query: String, language: String?, limit: Int, token: String?): String =
        withContext(Dispatchers.IO) {
            if (query.isBlank()) return@withContext "Missing search query."
            val (code, body) = runCatching { get(searchUrl(query, language, limit), token, "application/vnd.github+json") }
                .getOrElse { return@withContext "GitHub unreachable: ${it.message}" }
            if (isRateLimit(code, body)) return@withContext rateLimitMsg(token)
            if (code != 200) return@withContext "GitHub search failed (HTTP $code): ${body.ellipsize(300)}"
            val hits = parseRepos(body)
            if (hits.isEmpty()) "No GitHub repositories matched \"$query\"${if (!language.isNullOrBlank()) " (language: $language)" else ""}. Try broader terms or different keywords."
            else formatRepos(hits, query)
        }

    suspend fun readme(repo: String, token: String?, maxChars: Int = 12_000): String =
        withContext(Dispatchers.IO) {
            if (!validRepo(repo)) return@withContext "'$repo' is not a valid owner/repo."
            val (code, body) = runCatching { get(readmeUrl(repo), token, "application/vnd.github.raw+json") }
                .getOrElse { return@withContext "GitHub unreachable: ${it.message}" }
            when {
                isRateLimit(code, body) -> rateLimitMsg(token)
                code == 404 -> "No README found for $repo (try github {action:'tree'} to see what's in the repo)."
                code != 200 -> "README fetch failed (HTTP $code): ${body.ellipsize(300)}"
                else -> formatReadme(repo, body, maxChars)
            }
        }

    suspend fun tree(repo: String, filter: String?, token: String?): String =
        withContext(Dispatchers.IO) {
            if (!validRepo(repo)) return@withContext "'$repo' is not a valid owner/repo."
            // trees need a ref; HEAD works via redirects on the API — use the API contents fallback on failure
            val (code, body) = runCatching { get(treeUrl(repo, "HEAD"), token, "application/vnd.github+json") }
                .getOrElse { return@withContext "GitHub unreachable: ${it.message}" }
            when {
                isRateLimit(code, body) -> rateLimitMsg(token)
                code == 404 -> "Repo $repo not found (or empty)."
                code != 200 -> "Tree fetch failed (HTTP $code): ${body.ellipsize(300)}"
                else -> {
                    val paths = parseTreePaths(body, filter)
                    val truncated = body.contains("\"truncated\": true")
                    if (paths.isEmpty()) "No paths${if (!filter.isNullOrBlank()) " matching '$filter'" else ""} in $repo."
                    else buildString {
                        appendLine("File tree of $repo${if (!filter.isNullOrBlank()) " (filter '$filter')" else ""} — ${paths.size} path(s)${if (truncated) " (tree truncated by GitHub; list subfolders with a path filter)" else ""}:")
                        paths.forEach { appendLine("- $it") }
                        appendLine("→ fetch any file: github {action:'file', repo:'$repo', path:'<path>'}")
                    }
                }
            }
        }

    suspend fun file(repo: String, path: String, branch: String, token: String?, maxChars: Int = 30_000): String =
        withContext(Dispatchers.IO) {
            if (!validRepo(repo)) return@withContext "'$repo' is not a valid owner/repo."
            if (path.isBlank()) return@withContext "Missing 'path' (get one from github {action:'tree'})."
            val (code, body) = runCatching { get(fileUrl(repo, path, branch), token, "text/plain") }
                .getOrElse { return@withContext "GitHub unreachable: ${it.message}" }
            when {
                isRateLimit(code, body) -> rateLimitMsg(token)
                code == 404 -> "File not found: $repo/$path (check the path with github {action:'tree'})."
                code != 200 -> "File fetch failed (HTTP $code): ${body.ellipsize(300)}"
                else -> {
                    val note = if (body.length > maxChars) "\n…(truncated at $maxChars chars)" else ""
                    "FILE $repo/$path:\n----\n${body.take(maxChars)}$note"
                }
            }
        }

    /**
     * The composite the doctrine tells the agent to run FIRST: search by
     * title/keywords, then pull the READMEs of the top 3 by stars so the
     * agent can judge which repo to dive into.
     */
    suspend fun research(query: String, language: String?, token: String?): String =
        withContext(Dispatchers.IO) {
            if (query.isBlank()) return@withContext "Missing research query."
            val (code, body) = runCatching { get(searchUrl(query, language, 8), token, "application/vnd.github+json") }
                .getOrElse { return@withContext "GitHub unreachable: ${it.message}" }
            if (isRateLimit(code, body)) return@withContext rateLimitMsg(token)
            if (code != 200) return@withContext "GitHub research failed (HTTP $code): ${body.ellipsize(300)}"
            val hits = parseRepos(body)
            if (hits.isEmpty()) return@withContext "No GitHub repositories matched \"$query\". Try broader terms."
            val sb = StringBuilder(formatRepos(hits, query))
            sb.appendLine()
            sb.appendLine("==== DEEP DIVE — READMEs of the top ${minOf(3, hits.size)} by stars ====")
            hits.take(3).forEach { h ->
                sb.appendLine()
                val (rc, rb) = runCatching { get(readmeUrl(h.fullName), token, "application/vnd.github.raw+json") }
                    .getOrElse { -1 to "" }
                sb.appendLine(
                    if (rc == 200) formatReadme(h.fullName, rb, 4_000)
                    else "(README of ${h.fullName} unavailable — HTTP $rc)"
                )
            }
            sb.appendLine()
            sb.appendLine("NEXT: pick the winning repo → github {action:'tree'} to map its code → {action:'file'} for the files you need → adapt/run them (run_code, run_js, termux_run, native_apk). Respect the repo's license when reusing code.")
            sb.toString()
        }

    private fun rateLimitMsg(token: String?): String =
        if (token.isNullOrBlank())
            "GitHub rate limit reached (60 req/hr without a token). " +
                "Add a personal access token (github {action:'token', token:'ghp_…'}) for 5000/hr, or retry in a few minutes."
        else
            "GitHub rate limit reached even with the token (5000/hr) — retry in a few minutes."

    private val JSONB = kotlinx.serialization.json.Json { ignoreUnknownKeys = true }
}
