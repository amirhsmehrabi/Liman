package com.liman.agent.agent

import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * v2.16.0 — MEGA AGENT core (adopted from the ORION MEGA spec).
 *
 * The mechanisms that turn a reactive agent into a maximal-autonomy
 * execution agent, as pure testable logic:
 *  - [Secrets.redact]    — tokens never appear in UI/logs/reports
 *  - [Trash]             — backup-before-destructive file ops
 *  - [MissionTracker]    — task decomposition: plan → checklist → checkpoint
 *  - [SubagentBrief]     — role library + brief contract for subagents
 *  - [ScheduleLogic]     — is a scheduled mission due right now?
 */
object Secrets {

    private val PATTERNS = listOf(
        // explicit schemes: sk-…, ghp_…, xox…, AIza…, glpat-…
        Regex("""(?i)\b((?:sk|rk|pk)-[A-Za-z0-9_-]{8,})\b"""),
        Regex("""\b((?:ghp|gho|github_pat|xox[bpso]|glpat-|AIza)[A-Za-z0-9_\-]{10,})\b"""),
        // header forms
        Regex("""(?i)(bearer\s+)([A-Za-z0-9._\-]{12,})"""),
        Regex("""(?i)((?:api[_-]?key|token|authorization|password|secret)["'\s:=]{1,3})([A-Za-z0-9._\-+\/]{16,})"""),
        // long opaque blobs (hex/base64-ish, 24+ chars)
        Regex("""\b([A-Za-z0-9+\/_\-]{40,})\b""")
    )

    /** Mask secret-looking strings for DISPLAY (history keeps the real value). */
    fun redact(text: String): String {
        var out = text
        for (re in PATTERNS) {
            out = out.replace(re) { m ->
                val g = m.groupValues
                when {
                    // two groups: literal prefix (e.g. "Bearer ") + the secret
                    g.size >= 3 && g[2].isNotBlank() -> g[1] + mask(g[2])
                    // one capture group: the whole match is the secret
                    g.size >= 2 && g[1].isNotBlank() -> mask(g[1])
                    else -> mask(m.value)
                }
            }
        }
        return out
    }

    private fun mask(s: String): String =
        if (s.length <= 8) "••••••••"
        else s.take(4) + "…" + s.takeLast(2) + " (redacted)"
}

/** Backup-before-destructive: nothing the agent deletes is ever truly gone. */
object Trash {
    fun backup(file: File, workspaceRoot: File): File? {
        if (!file.exists()) return null
        return runCatching {
            val trash = File(workspaceRoot, ".trash").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val safeName = file.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val target = File(trash, "${safeName}.$stamp")
            if (file.isDirectory) file.copyRecursively(target, overwrite = true)
            else file.copyTo(target, overwrite = true)
            target
        }.getOrNull()
    }
}

/** One task in a decomposed mission. */
data class MissionTask(
    val id: String,
    val goal: String,
    val criteria: String = "",
    var status: String = "pending" // pending | in_progress | done | failed | blocked
)

/**
 * Mission decomposition state (the `mission` tool's backing store).
 * ORION §4: restate end-state → machine-checkable criteria → tasks with
 * dependencies → checklist → checkpoint after every task → T-FINAL re-runs
 * ALL criteria fresh.
 */
class MissionTracker {
    var title: String = ""
        private set
    var tasks: List<MissionTask> = emptyList()
        private set

    fun plan(title: String, tasks: List<MissionTask>) {
        this.title = title
        this.tasks = tasks
    }

    /**
     * v2.26.0 — fuzzy task resolution. Real-world bug: models invent task ids
     * ("probe") or use the goal text / an index ("task 1", "#2") and got a
     * dead-end "Unknown task id". Resolution order: exact → case-insensitive →
     * 1-based index ("2", "#2", "task 2") → goal-text containment → id fragment.
     */
    fun resolveTaskId(input: String): MissionTask? {
        val raw = input.trim()
        if (raw.isEmpty() || tasks.isEmpty()) return null
        tasks.firstOrNull { it.id == raw }?.let { return it }
        val lower = raw.lowercase()
        tasks.firstOrNull { it.id.equals(lower, ignoreCase = true) }?.let { return it }
        val idx = Regex("""^(?:task\s*)?#?(\d+)$""").find(lower)?.groupValues?.get(1)?.toIntOrNull()
        if (idx != null && idx in 1..tasks.size) return tasks[idx - 1]
        tasks.firstOrNull { it.goal.contains(raw, ignoreCase = true) && raw.length >= 3 }?.let { return it }
        tasks.firstOrNull { it.id.contains(lower, ignoreCase = true) && lower.length >= 2 }?.let { return it }
        return null
    }

    fun update(taskId: String, status: String): Boolean {
        val t = resolveTaskId(taskId) ?: return false
        val i = tasks.indexOfFirst { it.id == t.id }
        if (i < 0) return false
        tasks = tasks.toMutableList().also { it[i] = it[i].copy(status = status) }
        return true
    }

    fun isPlanned(): Boolean = tasks.isNotEmpty()

    /** Rendered checklist — shown in the tool card so the user sees the plan live. */
    fun render(): String {
        if (!isPlanned()) return "(no mission plan yet)"
        val marks = mapOf("done" to "✅", "in_progress" to "▶️", "failed" to "❌", "blocked" to "⛔")
        val done = tasks.count { it.status == "done" }
        val head = "MISSION: $title — $done/${tasks.size} done"
        val body = tasks.joinToString("\n") { t ->
            val m = marks[t.status] ?: "⬜"
            val crit = if (t.criteria.isBlank()) "" else "  [✓: ${t.criteria}]"
            "$m ${t.id} ${t.goal}$crit"
        }
        return "$head\n$body"
    }
}

/** Role library + brief contract for subagents (ORION §5). */
object SubagentBrief {

    private val ROLES = mapOf(
        "scout" to "Explore code/web/environment and answer ONE question with evidence (findings + paths). Read-only.",
        "architect" to "Design files/interfaces/dataflow for the task. Return a design ≤400 words. Read-only.",
        "builder" to "Implement exactly one task in the workspace. Full tools. Return created files + how to run.",
        "runner" to "Execute and babysit processes/commands. Return exit codes + log tail.",
        "verifier" to "Adversarially re-check acceptance criteria. Return PASS/FAIL per criterion + evidence.",
        "deployer" to "Run deployment procedures (API deploys, DNS, uploads). Return URLs + statuses.",
        "auditor" to "Pre-flight check of a risky/external step. Return GO/NO-GO + reasons."
    )

    fun roleNames(): List<String> = ROLES.keys.toList()

    fun roleLine(role: String): String? =
        ROLES[role.trim().lowercase()]

    /** Build the brief contract that travels with a subagent dispatch. */
    fun build(
        role: String?,
        goal: String,
        context: String,
        constraints: List<String>,
        acceptanceCriteria: List<String>
    ): String = buildString {
        val normalized = role?.trim()?.lowercase()?.takeIf { roleLine(it) != null } ?: "builder"
        appendLine("You are a $normalized-subagent of Liman.")
        appendLine("ROLE: " + (roleLine(normalized) ?: ROLES.getValue("builder")))
        appendLine("GOAL: $goal")
        if (context.isNotBlank()) appendLine("CONTEXT: $context")
        if (constraints.isNotEmpty()) {
            appendLine("CONSTRAINTS:")
            constraints.forEach { appendLine("- $it") }
        }
        if (acceptanceCriteria.isNotEmpty()) {
            appendLine("ACCEPTANCE CRITERIA (all must be PROVEN with observed evidence):")
            acceptanceCriteria.forEach { appendLine("- $it") }
        }
        appendLine("REPORT FORMAT: Result / Evidence / Side effects / Blockers. Work independently, then finish with a concise result.")
    }
}

/**
 * v2.18 — prompt right-sizing. Weak models (flash-lite, minis, 7B-class,
 * anonymous free tiers) drown in a huge system prompt: they lose the goal,
 * hallucinate tool args and stop following rules. Research consensus
 * (ReflAct, EMNLP 2025): weak models gain the most from (a) a SHORT prompt
 * with the goal anchored at the top, (b) explicit goal-state checks each
 * turn. So when the active model looks weak, Liman swaps to a compact
 * system prompt with the SAME rules, distilled.
 */
object PromptSizing {
    private val WEAK_MARKERS = listOf(
        "lite", "nano", "tiny", "small", "mini", "fast", "1b", "2b", "3b", "4b",
        "7b", "8b", "13b", "free", "spark", "muse", "small"
    )

    /** True → use the compact system prompt for this model. */
    fun compactFor(model: String): Boolean {
        val m = model.lowercase()
        // token-boundary match: "mini" must not fire inside "gemini"
        return WEAK_MARKERS.any { marker ->
            Regex("(^|[^a-z0-9])" + Regex.escape(marker) + "([^a-z0-9]|$)").containsMatchIn(m)
        }
    }
}

/**
 * Pure due-time math for scheduled missions (the cron engine).
 * Modes: daily at HH:MM, or every N hours.
 */
object ScheduleLogic {

    /**
     * Daily mode: due when today's HH:MM has passed AND the task hasn't run
     * today yet. Interval mode: due when N hours elapsed since lastRunAt.
     */
    fun isDue(dailyAt: String, everyHours: Int, lastRunAt: Long, now: Long = System.currentTimeMillis()): Boolean {
        return if (everyHours > 0) {
            now - lastRunAt >= everyHours * 3_600_000L
        } else {
            val (h, m) = parseHm(dailyAt) ?: return false
            val cal = Calendar.getInstance().apply {
                timeInMillis = now
                set(Calendar.HOUR_OF_DAY, h)
                set(Calendar.MINUTE, m)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val todayTarget = cal.timeInMillis
            // last run before today's target time AND now past it → due
            now >= todayTarget && lastRunAt < todayTarget
        }
    }

    /**
     * v2.20 (OpenClaw heartbeat activeHours): "HH:MM-HH:MM" gate — a task
     * only fires inside its window (overnight windows like 22:00-06:00
     * supported). null/blank/malformed = always allowed.
     */
    fun activeHoursOk(activeHours: String?, now: Long = System.currentTimeMillis()): Boolean {
        if (activeHours.isNullOrBlank()) return true
        val m = Regex("""^(\d{1,2}):(\d{2})-(\d{1,2}):(\d{2})$""").find(activeHours.trim()) ?: return true
        val (h1, m1, h2, m2) = m.destructured
        val start = h1.toInt() * 60 + m1.toInt()
        val end = h2.toInt() * 60 + m2.toInt()
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val cur = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return if (start <= end) cur in start..end else cur >= start || cur <= end
    }

    /** v2.21 — sub-hour interval missions (watchtowers, pipelines): every N minutes. */
    fun isDueMinutes(everyMinutes: Int, lastRunAt: Long, now: Long = System.currentTimeMillis()): Boolean {
        if (everyMinutes <= 0) return false
        return now - lastRunAt >= everyMinutes * 60_000L
    }

    fun parseHm(s: String): Pair<Int, Int>? {
        val m = Regex("""^(\d{1,2}):(\d{2})$""").find(s.trim()) ?: return null
        val h = m.groupValues[1].toInt()
        val min = m.groupValues[2].toInt()
        return if (h in 0..23 && min in 0..59) h to min else null
    }
}
