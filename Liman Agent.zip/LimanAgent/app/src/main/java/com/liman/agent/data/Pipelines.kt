package com.liman.agent.data

import com.liman.agent.util.JSON
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import java.io.File

/**
 * v2.21.0 — AUTOMATIONS (the pipeline engine).
 *
 * "＋ New Automation: every day at 8, check these Telegram channels, find
 * useful engineering news, summarize it in Persian, dedupe, post it to my
 * channel." → one Pipeline with a trigger and ordered STEPS, running as a
 * full headless agent cycle on the Scheduler — even with the app closed.
 *
 * A pipeline is TWO things:
 *  - the record in this store (trigger + pointer to the definition file),
 *  - the definition file in the workspace (human-readable markdown: steps
 *    with types fetch / transform / filter / dedupe / output / notify /
 *    approval — the AI TRANSFORM step is a first-class node: translate,
 *    summarize, rewrite, classify — insertable between any source and any
 *    output).
 *
 * Cross-platform bridges (Telegram→Instagram, Gmail→Telegram, web→files) are
 * just pipelines whose fetch/output steps use the right tools (http_request,
 * telethon via termux_run, or the `ui` tool for apps without APIs).
 */
@Serializable
data class Pipeline(
    val id: String,
    var name: String,
    var description: String = "",
    /** manual | daily | interval */
    var triggerKind: String = "manual",
    /** daily trigger: "HH:MM" */
    var dailyAt: String = "08:00",
    /** interval trigger: minutes (>=15) — takes precedence over everyHours */
    var everyMinutes: Int = 0,
    /** interval trigger: hours (used when everyMinutes == 0) */
    var everyHours: Int = 0,
    var enabled: Boolean = true,
    var lastRunAt: Long = 0L,
    /** optional "HH:MM-HH:MM" gate (OpenClaw activeHours) */
    var activeHours: String? = null,
    /** workspace-relative path of the definition file */
    val file: String = "",
    val createdAt: Long = 0L
)

class PipelineStore(private val file: File) {
    private val _state = MutableStateFlow<List<Pipeline>>(emptyList())
    val state: StateFlow<List<Pipeline>> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(ListSerializer(Pipeline.serializer()), file.readText())
        }.getOrDefault(emptyList())
    }

    fun get(id: String): Pipeline? = _state.value.firstOrNull { it.id == id }

    fun upsert(p: Pipeline) {
        val list = _state.value.toMutableList()
        val idx = list.indexOfFirst { it.id == p.id }
        if (idx >= 0) list[idx] = p else list.add(p)
        _state.value = list
        save()
    }

    fun delete(id: String) {
        _state.value = _state.value.filter { it.id != id }
        save()
    }

    fun touch(id: String) {
        val p = get(id) ?: return
        upsert(p.copy(lastRunAt = System.currentTimeMillis()))
    }

    private fun save() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(ListSerializer(Pipeline.serializer()), _state.value))
        }
    }
}

/** Pure helpers for pipeline definitions + run prompts (unit-tested). */
object PipelineDef {

    /** Render the definition markdown the agent (and the user) can read/edit. */
    fun render(name: String, description: String, steps: List<Pair<String, String>>): String = buildString {
        appendLine("# Automation: $name")
        if (description.isNotBlank()) appendLine(description)
        appendLine()
        appendLine("## STEPS (execute in order, with your tools)")
        steps.forEachIndexed { i, (type, instruction) ->
            appendLine("${i + 1}. [$type] $instruction")
        }
        appendLine()
        appendLine("## STATE")
        appendLine("Keep the run-state file updated: processed item ids/hashes (dedupe), last-run results, next actions. Never repeat processed items.")
        appendLine("## HEADLESS RULES")
        appendLine("No user approval is possible mid-run: for anything needing approval, save a DRAFT to the workspace and notify; never send on the user's behalf without pre-authorization. If nothing new needs doing, reply exactly NO_REPLY.")
    }

    /** Human trigger summary for lists/UI. */
    fun triggerText(p: Pipeline): String = when (p.triggerKind) {
        "daily" -> "daily ${p.dailyAt}"
        "interval" -> when {
            p.everyMinutes > 0 -> "every ${p.everyMinutes}m"
            p.everyHours > 0 -> "every ${p.everyHours}h"
            else -> "manual"
        }
        else -> "manual"
    } + (p.activeHours?.let { " · active $it" } ?: "")

    /** The headless run prompt for a pipeline (self-contained). */
    fun runPrompt(p: Pipeline): String = buildString {
        appendLine("AUTOMATION RUN: ${p.name}")
        if (p.description.isNotBlank()) appendLine("What it does: ${p.description}")
        appendLine()
        appendLine("Read the pipeline definition at workspace/${p.file} and execute its STEPS in order, using your tools.")
        appendLine("Follow its STATE and HEADLESS RULES sections exactly: dedupe against the state file, draft+notify instead of asking, NO_REPLY when nothing needs doing. Keep this run focused and short — it runs unattended.")
    }
}
