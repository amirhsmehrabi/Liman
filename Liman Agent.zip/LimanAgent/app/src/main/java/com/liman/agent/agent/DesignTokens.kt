package com.liman.agent.agent

/**
 * v2.30.0 — THE DESIGN SYSTEM KERNEL (APP FACTORY blueprint §4 + §10).
 *
 * "Quality = Constraint + Templates + Feedback Loops." The model composes
 * TOKENS, never raw hex/px — one source of truth generates CSS for web
 * targets and Android XML resources for native scaffolds, so a web prototype
 * and the native app look identical.
 *
 * Pure Kotlin — unit-tested.
 */
object DesignTokens {

    data class Preset(
        val id: String,
        val vibe: String,
        val keyMoves: String,
        val brand: String,           // 500 (light)
        val brandStrong: String,     // 600 (light) / 500 (dark)
        val brandSoft: String,       // 50 (light tint)
        val onBrand: String,
        val surface: String,         // light base
        val surfaceRaised: String,
        val surfaceSunken: String,
        val onSurface: String,
        val onSurfaceMuted: String,
        val borderSubtle: String,
        val borderDefault: String,
        // dark
        val dSurface: String,
        val dSurfaceRaised: String,
        val dSurfaceSunken: String,
        val dOnSurface: String,
        val dOnSurfaceMuted: String,
        val dBorderSubtle: String,
        val dBorderDefault: String,
        val dBrand: String,
        val radius: String,          // sm|md|lg|xl|none
        val elevationStyle: String   // borders|tonal|hairline|hard-shadow|blur
    )

    val PRESETS = listOf(
        Preset(
            "swiss-minimal", "calm, editorial, precise",
            "1 accent (indigo), generous whitespace (sections space 6-8), 1px borders instead of shadows, left-aligned type, no gradients",
            "#4F46E5", "#4338CA", "#EEF2FF", "#FFFFFF",
            "#FFFFFF", "#FAFAFA", "#F4F4F5", "#18181B", "#71717A",
            "#F4F4F5", "#E4E4E7",
            "#0B0B0C", "#141416", "#070708", "#F4F4F5", "#A1A1AA", "#1C1C1F", "#2A2A2E", "#818CF8",
            "md", "borders"
        ),
        Preset(
            "soft-material", "friendly, rounded, Google-ish",
            "tonal surfaces instead of shadows, radius lg/xl, brand.50 fills, expressive type scale, FAB + bottom nav patterns",
            "#6750A4", "#7E56C2", "#EADDFF", "#FFFFFF",
            "#FEF7FF", "#F7F2FA", "#EDE7F3", "#1D1B20", "#49454F",
            "#ECE6F0", "#CAC4D0",
            "#141218", "#1D1B22", "#0F0E13", "#E6E0E9", "#CAC4D0", "#0F0E13", "#49454F", "#D0BCFF",
            "lg", "tonal"
        ),
        Preset(
            "dark-terminal", "technical, dense, hacker",
            "true-black base, mono for data, ONE neon accent, hairline separators, high info density, glow only on focus",
            "#22D3EE", "#06B6D4", "#0E3A40", "#04222A",
            "#0B0B0C", "#141416", "#070708", "#E5E7EB", "#9CA3AF",
            "#1C1C1F", "#2A2A2E",
            "#050506", "#0D0D0F", "#020203", "#E5E7EB", "#9CA3AF", "#111114", "#1F1F23", "#22D3EE",
            "sm", "hairline"
        ),
        Preset(
            "neo-brutalist", "bold, playful, sticker-like",
            "saturated accent, 2-3px solid black borders, hard offset shadow (4px 4px 0 #000), radius none, oversized display type",
            "#FF5A36", "#E64826", "#FFE4DC", "#FFFFFF",
            "#FFFFFF", "#FFF8F5", "#FFEDE7", "#111111", "#555555",
            "#111111", "#111111",
            "#141414", "#1D1D1D", "#0A0A0A", "#F5F5F5", "#B3B3B3", "#2A2A2A", "#3F3F3F", "#FF7A5C",
            "none", "hard-shadow"
        ),
        Preset(
            "glass-aurora", "premium, marketing, atmospheric",
            "dark base + 2 large blurred radial gradients, translucent cards (8% white, blur), radius xl, thin light borders, big type",
            "#A78BFA", "#8B5CF6", "#2E1065", "#FFFFFF",
            "#0F1017", "#161826", "#0A0B10", "#F4F4F5", "#A1A1AA",
            "#FFFFFF1F", "#FFFFFF33",
            "#0F1017", "#161826", "#0A0B10", "#F4F4F5", "#A1A1AA", "#FFFFFF12", "#FFFFFF20", "#A78BFA",
            "xl", "blur"
        )
    )

    fun preset(id: String): Preset? = PRESETS.firstOrNull { it.id == id }

    /** §10.1 layout archetypes — every screen must declare one. */
    val ARCHETYPES = listOf(
        "list-detail" to "top bar + scrollable list + detail sheet (notes, tasks, mail)",
        "dashboard" to "header + KPI row (2-4) + charts + recent activity (analytics, fitness)",
        "onboarding" to "full-bleed illustration + headline + 1 CTA + progress dots",
        "auth" to "centered card, ≤3 fields, 1 primary CTA",
        "feed" to "sticky header + media cards + infinite scroll + FAB (social, news)",
        "form-wizard" to "step indicator + 1 question group per step + back/next",
        "settings" to "grouped rows with icon + label + value + chevron",
        "landing" to "hero → features(3) → how-it-works → testimonial → CTA → footer",
        "tool" to "single screen: input → action → output, no chrome (utilities)"
    )

    val SPACE_SCALE = listOf(0, 4, 8, 12, 16, 24, 32, 48, 64, 96)
    val TYPE_SCALE = listOf(12, 14, 16, 18, 22, 28, 36, 48)

    /** The token law the model must follow (blueprint §4.3). */
    fun contract(): String = buildString {
        appendLine("DESIGN TOKEN CONTRACT — you compose tokens, never raw values:")
        appendLine("COLOR  surface.base|raised|sunken  on.surface|muted  brand.500|600|50  border.subtle|default|strong  semantic.success|warning|danger|info")
        appendLine("SPACE  only: 0,4,8,12,16,24,32,48,64,96 px/dp — nothing else")
        appendLine("RADIUS sm(6) md(10) lg(16) xl(24) full — from the preset")
        appendLine("TYPE   only: 12,14,16,18,22,28,36,48 · body ≥16 · captions ≥12 · max 2 families (1 sans + 1 mono for data)")
        appendLine("ELEV   follow the preset's elevation style (borders/tonal/hairline/hard-shadow/blur)")
        appendLine("HARD RULES: never invent a hex code or an off-scale px/dp; text on surface uses on.* tokens (contrast ≥4.5:1 body, ≥3:1 large); touch targets ≥44px/48dp; dark mode = the same tokens from the preset's dark block, not a separate design; pick ONE preset per project and never mix; declare ONE layout archetype per screen; max 1 accent, ≤2 fonts, ≤3 elevation levels.")
    }

    /** tokens.css content for web targets (CSS custom properties). */
    fun tokensCss(presetId: String): String? {
        val p = preset(presetId) ?: return null
        return buildString {
            appendLine("/* Design tokens — preset '${p.id}' (${p.vibe}). Generated by design_tokens. DO NOT hand-edit values. */")
            appendLine(":root {")
            appendLine("  --brand-500: ${p.brand}; --brand-600: ${p.brandStrong}; --brand-50: ${p.brandSoft}; --on-brand: ${p.onBrand};")
            appendLine("  --surface-base: ${p.surface}; --surface-raised: ${p.surfaceRaised}; --surface-sunken: ${p.surfaceSunken};")
            appendLine("  --on-surface: ${p.onSurface}; --on-muted: ${p.onSurfaceMuted};")
            appendLine("  --border-subtle: ${p.borderSubtle}; --border-default: ${p.borderDefault};")
            appendLine("  --success: #16A34A; --warning: #D97706; --danger: #DC2626; --info: #0284C7;")
            appendLine("  --radius-sm: 6px; --radius-md: 10px; --radius-lg: 16px; --radius-xl: 24px; --radius-full: 999px;")
            appendLine("  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px; --space-5: 24px; --space-6: 32px; --space-7: 48px; --space-8: 64px; --space-9: 96px;")
            appendLine("  --type-xs: 12px; --type-sm: 14px; --type-base: 16px; --type-lg: 18px; --type-xl: 22px; --type-2xl: 28px; --type-3xl: 36px; --type-4xl: 48px;")
            appendLine("  --motion-fast: 120ms; --motion-base: 200ms; --motion-slow: 320ms;")
            appendLine("  --font-sans: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;")
            appendLine("  --font-mono: ui-monospace, SFMono-Regular, Menlo, monospace;")
            appendLine("}")
            appendLine("@media (prefers-color-scheme: dark) {")
            appendLine("  :root {")
            appendLine("    --brand-500: ${p.dBrand}; --brand-600: ${p.dBrand};")
            appendLine("    --surface-base: ${p.dSurface}; --surface-raised: ${p.dSurfaceRaised}; --surface-sunken: ${p.dSurfaceSunken};")
            appendLine("    --on-surface: ${p.dOnSurface}; --on-muted: ${p.dOnSurfaceMuted};")
            appendLine("    --border-subtle: ${p.dBorderSubtle}; --border-default: ${p.dBorderDefault};")
            appendLine("  }")
            appendLine("}")
        }
    }

    /** Android res/values/colors.xml + dimens.xml from the same preset (native target). */
    fun androidColorsXml(presetId: String): String? {
        val p = preset(presetId) ?: return null
        return buildString {
            appendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
            appendLine("<resources>")
            appendLine("    <color name=\"brand\">${p.brand}</color>")
            appendLine("    <color name=\"brand_strong\">${p.brandStrong}</color>")
            appendLine("    <color name=\"brand_soft\">${p.brandSoft}</color>")
            appendLine("    <color name=\"on_brand\">${p.onBrand}</color>")
            appendLine("    <color name=\"surface\">${p.surface}</color>")
            appendLine("    <color name=\"surface_raised\">${p.surfaceRaised}</color>")
            appendLine("    <color name=\"surface_sunken\">${p.surfaceSunken}</color>")
            appendLine("    <color name=\"on_surface\">${p.onSurface}</color>")
            appendLine("    <color name=\"on_surface_muted\">${p.onSurfaceMuted}</color>")
            appendLine("    <color name=\"border_subtle\">${p.borderSubtle}</color>")
            appendLine("    <color name=\"border_default\">${p.borderDefault}</color>")
            appendLine("    <color name=\"semantic_success\">#16A34A</color>")
            appendLine("    <color name=\"semantic_warning\">#D97706</color>")
            appendLine("    <color name=\"semantic_danger\">#DC2626</color>")
            append("</resources>")
        }.trim()
    }

    /** The compact web component kit (blueprint §6.1) — class vocabulary + states. */
    fun kitCss(): String = """
/* Liman web kit v1 — compose these classes; extend via CSS vars, never inline styles. */
.stack{display:flex;flex-direction:column;gap:var(--space-3)} .row{display:flex;align-items:center;gap:var(--space-2)}
.grid{display:grid;gap:var(--space-4);grid-template-columns:repeat(auto-fit,minmax(260px,1fr))}
.container{max-width:1200px;margin:0 auto;padding:0 var(--space-4)} .section{padding-block:var(--space-7)}
.divider{border:0;border-top:1px solid var(--border-subtle)}
.card{background:var(--surface-raised);border:1px solid var(--border-subtle);border-radius:var(--radius-lg);padding:var(--space-4)}
.panel{background:var(--surface-sunken);border-radius:var(--radius-md);padding:var(--space-4)}
.display{font-size:var(--type-4xl);font-weight:700;letter-spacing:-0.02em;line-height:1.15}
.h1{font-size:var(--type-3xl);font-weight:600;line-height:1.15}.h2{font-size:var(--type-2xl);font-weight:600;line-height:1.2}
.h3{font-size:var(--type-xl);font-weight:600}.h4{font-size:var(--type-lg);font-weight:600}
.body{font-size:var(--type-base);line-height:1.5}.lead{font-size:var(--type-lg);color:var(--on-muted);line-height:1.5}
.caption{font-size:var(--type-sm);color:var(--on-muted)}.code{font-family:var(--font-mono);font-size:var(--type-sm)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);min-height:44px;padding:0 var(--space-4);border-radius:var(--radius-md);font-size:var(--type-base);font-weight:600;border:1px solid transparent;cursor:pointer;transition:transform var(--motion-fast) ease,opacity var(--motion-fast) ease}
.btn--primary{background:var(--brand-500);color:var(--on-brand)} .btn--primary:hover{background:var(--brand-600)}
.btn--secondary{background:transparent;color:var(--on-surface);border-color:var(--border-default)}
.btn--ghost{background:transparent;color:var(--on-surface)} .btn--danger{background:var(--danger);color:#fff}
.btn--sm{min-height:36px;padding:0 var(--space-3);font-size:var(--type-sm)}
.btn:disabled{opacity:.5;cursor:not-allowed} .btn:active{transform:scale(.97)}
.btn:focus-visible,.input:focus-visible,.chip:focus-visible{outline:2px solid var(--brand-500);outline-offset:2px}
.field{display:flex;flex-direction:column;gap:var(--space-1)} .field label{font-size:var(--type-sm);font-weight:600}
.input,.textarea,.select{min-height:44px;padding:var(--space-2) var(--space-3);border:1px solid var(--border-default);border-radius:var(--radius-md);background:var(--surface-base);color:var(--on-surface);font-size:var(--type-base)}
.textarea{min-height:96px;resize:vertical}
.badge{display:inline-flex;padding:2px var(--space-2);border-radius:var(--radius-full);font-size:var(--type-xs);font-weight:600;background:var(--brand-50);color:var(--brand-600)}
.chip{display:inline-flex;align-items:center;gap:var(--space-1);min-height:36px;padding:0 var(--space-3);border-radius:var(--radius-full);border:1px solid var(--border-default);background:var(--surface-raised);color:var(--on-surface);cursor:pointer}
.alert{border-radius:var(--radius-md);padding:var(--space-3) var(--space-4);font-size:var(--type-sm)}
.alert--danger{background:var(--danger);color:#fff}.alert--success{background:var(--success);color:#fff}
.empty{display:flex;flex-direction:column;align-items:center;gap:var(--space-3);padding:var(--space-8);color:var(--on-muted);text-align:center}
.topbar{display:flex;align-items:center;justify-content:space-between;padding:var(--space-3) var(--space-4);border-bottom:1px solid var(--border-subtle);background:var(--surface-base);position:sticky;top:0;z-index:10}
.bottom-nav{display:flex;position:sticky;bottom:0;background:var(--surface-base);border-top:1px solid var(--border-subtle)}
.bottom-nav a{flex:1;display:flex;flex-direction:column;align-items:center;gap:2px;padding:var(--space-2);font-size:var(--type-xs);color:var(--on-muted);text-decoration:none;min-height:48px}
.bottom-nav a.active{color:var(--brand-500);font-weight:600}
.list-item{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border-bottom:1px solid var(--border-subtle)}
.icon{inline-size:1.25em;block-size:1.25em;flex:none} .sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}
.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
""".trim()
}
