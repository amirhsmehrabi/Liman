package com.liman.agent.ui

import com.liman.agent.util.fmtBytes
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.Image
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liman.agent.R
import com.liman.agent.data.Entry
import com.liman.agent.ui.theme.LimanExtras
import com.liman.agent.util.Str
import com.liman.agent.util.fmtTime
import com.liman.agent.util.isPersian

/** UI strings for the current language; provided at the root of every screen. */
val LocalStr = staticCompositionLocalOf { Str(fa = false) }

// ============================================================
// Icons (Material Symbols via Iconify) — the emoji era is over
// ============================================================

fun toolIconRes(name: String): Int = when (name) {
    "list_files" -> R.drawable.ic_list_files
    "read_file" -> R.drawable.ic_read_file
    "write_file" -> R.drawable.ic_write_file
    "append_file" -> R.drawable.ic_append_file
    "edit_file" -> R.drawable.ic_edit_file
    "delete_file" -> R.drawable.ic_delete_file
    "http_request" -> R.drawable.ic_http_request
    "web_search" -> R.drawable.ic_web_search
    "read_link" -> R.drawable.ic_read_link
    "memory_save", "memory_recall" -> R.drawable.ic_memory
    "calculator" -> R.drawable.ic_calculator
    "run_js" -> R.drawable.ic_run_js
    "render_html" -> R.drawable.ic_render_html
    "datetime" -> R.drawable.ic_datetime
    "ask_user" -> R.drawable.ic_ask_user
    "image_generate" -> R.drawable.ic_image_generate
    "build_apk" -> R.drawable.ic_build_apk
    "use_skill" -> R.drawable.ic_use_skill
    "search_skills" -> R.drawable.ic_search_skills
    "install_skill" -> R.drawable.ic_install_skill
    "spawn_subagent" -> R.drawable.ic_spawn_subagent
    "storage_list" -> R.drawable.ic_storage_list
    "storage_read" -> R.drawable.ic_storage_read
    "storage_write" -> R.drawable.ic_storage_write
    "mcp_connect" -> R.drawable.ic_mcp_connect
    "profile_update" -> R.drawable.ic_profile_update
    "finish" -> R.drawable.ic_finish
    else -> if (name.startsWith("mcp_")) R.drawable.ic_mcp_connect else R.drawable.ic_bot
}

/** Minimal single-tint icon. */
@Composable
fun LimanIcon(res: Int, tint: Color, modifier: Modifier = Modifier, size: Int = 20) {
    Icon(
        painter = painterResource(res),
        contentDescription = null,
        tint = tint,
        modifier = modifier.size(size.dp)
    )
}

// ============================================================
// Motion system ("Quiet Intelligence")
// Springs follow the 2026 research consensus: GPU-only props,
// subtle bounce, consistent families — one focus of motion at a time.
// ============================================================

object MotionK {
    /** containers settle smoothly (no overshoot) */
    val settle = spring<Float>(dampingRatio = 1f, stiffness = 300f)
    /** pop-ins / badges: snappy with a hint of bounce */
    val pop = spring<Float>(dampingRatio = 0.78f, stiffness = 500f)
    /** entrances: balanced */
    val enter = spring<Float>(dampingRatio = 0.85f, stiffness = 350f)
}

/** True when the user disabled system animations → strip decorative loops. */
@Composable
fun reducedMotion(): Boolean {
    val context = androidx.compose.ui.platform.LocalContext.current
    return remember {
        android.provider.Settings.Global.getFloat(
            context.contentResolver,
            android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f
        ) == 0f
    }
}

// ============================================================
// The animated identity: a "soft aperture" — a ring that opens,
// focuses and expands. Motion maps to real states only.
// ============================================================

enum class ApertureState { IDLE, THINKING, WORKING, STREAMING, DONE }

/**
 * The Liman mark: a rounded ring with an aperture opening and a small
 * focus dot. Recognizable when still; animates only for real states.
 */
@Composable
fun ApertureMark(
    state: ApertureState,
    size: Int = 24,
    color: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    val calm = reducedMotion()
    val animate = !calm && state != ApertureState.IDLE && state != ApertureState.DONE

    var rot = 0f
    var breath = 0f
    if (animate) {
        val transition = rememberInfiniteTransition(label = "aperture")
        val period = when (state) {
            ApertureState.THINKING -> 2600
            ApertureState.WORKING -> 1600
            else -> 3400
        }
        val r by transition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(period, easing = androidx.compose.animation.core.LinearEasing)),
            label = "rot"
        )
        val b by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse
            ),
            label = "breath"
        )
        rot = r
        breath = b
    }
    val alpha = if (state == ApertureState.STREAMING) 0.55f + 0.25f * breath else 1f
    val strokeWidth = (size * (0.075f + 0.02f * breath)).dp

    Canvas(modifier.then(Modifier.size(size.dp))) {
        val stroke = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
        val inset = strokeWidth.toPx() / 2 + 1f
        val arcSize = Size(this.size.width - inset * 2, this.size.height - inset * 2)
        val topLeft = Offset(inset, inset)
        // aperture: ring with a 70° opening, rotating for active states
        val gap = 70f
        drawArc(
            color = color.copy(alpha = alpha),
            startAngle = -90f + rot + gap / 2,
            sweepAngle = 360f - gap,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = stroke
        )
        // focus dot riding the leading edge of the opening
        val angleRad = Math.toRadians((-90f + rot + gap / 2).toDouble())
        val radius = minOf(arcSize.width, arcSize.height) / 2
        val cx = topLeft.x + arcSize.width / 2
        val cy = topLeft.y + arcSize.height / 2
        val dotX = cx + (radius * Math.cos(angleRad)).toFloat()
        val dotY = cy + (radius * Math.sin(angleRad)).toFloat()
        drawCircle(
            color = color.copy(alpha = alpha),
            radius = strokeWidth.toPx() * 0.75f,
            center = Offset(dotX, dotY)
        )
    }
}

// ============================================================
// RTL-aware text
// ============================================================

/**
 * Text that flips to right-to-left (with proper layout direction) when the
 * content is Persian. Used for every user/assistant message.
 */
@Composable
fun DirectionalText(
    text: String,
    modifier: Modifier = Modifier,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.bodyLarge,
    color: Color = Color.Unspecified,
    fontWeight: FontWeight? = null,
    textAlign: TextAlign? = null,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip
) {
    val rtl = remember(text) { isPersian(text) }
    @Composable
    fun content() {
        Text(
            text, modifier = modifier, style = style, color = color,
            fontWeight = fontWeight, textAlign = textAlign,
            maxLines = maxLines, overflow = overflow
        )
    }
    if (rtl) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { content() }
    } else {
        content()
    }
}

// ============================================================
// Expressive motion toolkit (springs, waves, bob — the 2026 feel)
// ============================================================

/** Springy press feedback: returns a scale to apply via graphicsLayer. */
@Composable
fun pressScale(interactionSource: MutableInteractionSource, pressed: Float = 0.96f): Float {
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) pressed else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = 700f
        ),
        label = "pressScale"
    )
    return scale
}

/** Expressive entrance: slide-up + fade with a soft spring overshoot. */
@Composable
fun EnterSpring(content: @Composable () -> Unit) {
    val state = remember { androidx.compose.animation.core.MutableTransitionState(false) }
    state.targetState = true
    androidx.compose.animation.AnimatedVisibility(
        visibleState = state,
        enter = androidx.compose.animation.fadeIn(
            animationSpec = spring(dampingRatio = 1f, stiffness = 380f)
        ) + androidx.compose.animation.slideInVertically(
            animationSpec = spring(dampingRatio = 0.72f, stiffness = 340f),
            initialOffsetY = { it / 5 }
        )
    ) { content() }
}

/** Three-dot wave typing indicator (expressive replacement for "…"). */
@Composable
fun WaveDots(color: Color, dotSize: Int = 7) {
    val transition = rememberInfiniteTransition(label = "wave")
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(3) { i ->
            val t by transition.animateFloat(
                initialValue = 0f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(400, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse,
                    initialStartOffset = androidx.compose.animation.core.StartOffset(i * 140)
                ),
                label = "dot$i"
            )
            Box(
                Modifier
                    .size(dotSize.dp)
                    .graphicsLayer {
                        translationY = -4.dp.toPx() * t
                        alpha = 0.35f + 0.65f * t
                    }
                    .background(color, CircleShape)
            )
        }
    }
}

/** Gentle infinite bob (hero elements, floating accents). */
@Composable
fun Modifier.bob(amount: Float = 6f, period: Int = 2400): Modifier {
    val transition = rememberInfiniteTransition(label = "bob")
    val y by transition.animateFloat(
        initialValue = -amount,
        targetValue = amount,
        animationSpec = infiniteRepeatable(tween(period, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "y"
    )
    return graphicsLayer { translationY = y.dp.toPx() }
}

// ============================================================
// Bento bubbles & cards
// ============================================================

@OptIn(ExperimentalFoundationApi::class)
// ============================================================
// Tap-to-copy chip + the gradient connection rail
// ============================================================

/**
 * Small copy chip that appears near a message when the user taps it.
 * Tapping the chip copies the text and confirms with a checkmark.
 */
@Composable
fun CopyChip(visible: Boolean, onCopy: () -> Unit, alignEnd: Boolean = false) {
    val t = LocalStr.current
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(visible) {
        if (visible) {
            copied = false
            kotlinx.coroutines.delay(2600)
        }
    }
    androidx.compose.animation.AnimatedVisibility(
        visible = visible,
        enter = androidx.compose.animation.scaleIn(
            animationSpec = spring(dampingRatio = 0.7f, stiffness = 500f), initialScale = 0.5f
        ) + androidx.compose.animation.fadeIn(),
        exit = androidx.compose.animation.scaleOut(targetScale = 0.6f) + androidx.compose.animation.fadeOut()
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
            modifier = Modifier
                .padding(top = 2.dp)
                .then(if (alignEnd) Modifier else Modifier)
                .clickableNoIndication {
                    onCopy()
                    copied = true
                }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
            ) {
                LimanIcon(
                    if (copied) R.drawable.ic_check else R.drawable.ic_copy,
                    if (copied) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    size = 13
                )
                Spacer(Modifier.width(5.dp))
                Text(
                    if (copied) t.copied else t.copy,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

/** clickable helper without ripple (used by chips and bubbles). */
@Composable
private fun Modifier.clickableNoIndication(onClick: () -> Unit): Modifier {
    val interaction = remember { MutableInteractionSource() }
    return this.then(
        Modifier.clickable(
            interactionSource = interaction,
            indication = null,
            onClick = onClick
        )
    )
}

/**
 * The connection rail: a thin vertical line with a gradient pulse that
 * travels down and back — linking consecutive assistant bubbles into one
 * visual thread. [active] = an answer is streaming right now.
 */
@Composable
fun GradientRail(active: Boolean, height: Dp? = null) {
    val calm = reducedMotion()
    val travel = if (active && !calm) {
        val transition = rememberInfiniteTransition(label = "rail")
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse
            ),
            label = "pulse"
        ).value
    } else 0.5f

    val a = LimanExtras.RailA
    val b = LimanExtras.RailB
    val dim = MaterialTheme.colorScheme.outlineVariant
    val modifier = if (height != null) Modifier.height(height) else Modifier.fillMaxHeight()
    Canvas(modifier.width(16.dp)) {
        val lineX = size.width / 2
        val h = size.height
        // base thread
        drawLine(
            color = dim,
            start = Offset(lineX, 0f),
            end = Offset(lineX, h),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
        if (active && !calm) {
            // traveling gradient pulse: a bright segment moving down & back
            val seg = h * 0.28f
            val center = seg / 2 + (h - seg) * travel
            val brush = Brush.verticalGradient(
                colors = listOf(a.copy(alpha = 0f), a, b, b.copy(alpha = 0f)),
                startY = center - seg / 2,
                endY = center + seg / 2
            )
            drawLine(
                brush = brush,
                start = Offset(lineX, center - seg / 2),
                end = Offset(lineX, center + seg / 2),
                strokeWidth = 2.5.dp.toPx(),
                cap = StrokeCap.Round
            )
            // node glow at the pulse center
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(b.copy(alpha = 0.45f), Color.Transparent),
                    center = Offset(lineX, center),
                    radius = 6.dp.toPx()
                ),
                radius = 6.dp.toPx(),
                center = Offset(lineX, center)
            )
        } else {
            // resting: a quiet static gradient on the thread
            drawLine(
                brush = Brush.verticalGradient(listOf(a.copy(alpha = 0.35f), b.copy(alpha = 0.35f))),
                start = Offset(lineX, 0f),
                end = Offset(lineX, h),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun UserBubble(entry: Entry.UserEntry) {
    val clipboard = LocalClipboardManager.current
    val t = LocalStr.current
    var showCopy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
        // v2.27.0 knotwork bubble geometry: asymmetric 16/16/4/16, tonal container
        val shape = RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp)
        val userBg = if (isSystemInDarkTheme()) LimanExtras.ChatUserBgDark else LimanExtras.ChatUserBgLight
        Box(
            Modifier
                .fillMaxWidth(0.85f)
                .clip(shape)
                .background(userBg)
                .combinedClickable(
                    onClick = { showCopy = !showCopy },
                    onLongClick = {
                        clipboard.setText(AnnotatedString(entry.text))
                        showCopy = true
                    }
                )
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 11.dp)) {
                entry.attachments.forEach {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LimanIcon(R.drawable.ic_attach, userBubbleInk(), size = 13)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            it.substringAfterLast('/'),
                            style = MaterialTheme.typography.labelMedium,
                            color = userBubbleInk()
                        )
                    }
                }
                if (entry.attachments.isNotEmpty()) Spacer(Modifier.size(5.dp))
                DirectionalText(
                    entry.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = userBubbleInk()
                )
                // v2.33 minimal: no always-on timestamp — long-press reveals copy
            }
        }
        CopyChip(visible = showCopy, onCopy = { clipboard.setText(AnnotatedString(entry.text)) }, alignEnd = true)
    }
    LaunchedEffect(showCopy) {
        if (showCopy) {
            kotlinx.coroutines.delay(2600)
            showCopy = false
        }
    }
}

/** ink used on the tonal user bubble (knotwork-style pair) */
@Composable
private fun userBubbleInk() =
    if (isSystemInDarkTheme()) com.liman.agent.ui.theme.LimanExtras.ChatUserFgDark
    else com.liman.agent.ui.theme.LimanExtras.ChatUserFgLight

@Composable
fun AssistantBubble(entry: Entry.AssistantEntry) {
    val clipboard = LocalClipboardManager.current
    var showCopy by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        // ---- the connection rail links this answer to the previous one ----
        GradientRail(active = false)
        Spacer(Modifier.width(2.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ApertureMark(ApertureState.DONE, size = 18)
                Spacer(Modifier.width(7.dp))
                Text(
                    buildString {
                        append("Liman")
                        if (entry.model.isNotBlank()) append(" · ${entry.model}")
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.width(8.dp))
                CycleBadge(entry.cycle)
            }
            Spacer(Modifier.size(5.dp))
            if (entry.text.isBlank()) {
                Text(
                    "…working (tool calls)",
                    style = MaterialTheme.typography.bodyMedium,
                    fontStyle = FontStyle.Italic,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                // the answer in a soft tonal bubble — linked, rounded, readable
                val shape = RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)
                Box(
                    Modifier
                        .clip(shape)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
                        .border(
                            BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            shape
                        )
                        .clickableNoIndication { showCopy = !showCopy }
                ) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                        SelectionContainer {
                            MarkdownText(entry.text)
                        }
                    }
                }
                CopyChip(visible = showCopy, onCopy = { clipboard.setText(AnnotatedString(entry.text)) })
            }
        }
    }
    LaunchedEffect(showCopy) {
        if (showCopy) {
            kotlinx.coroutines.delay(2600)
            showCopy = false
        }
    }
}

@Composable
fun CycleBadge(cycle: Int) {
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
        shape = RoundedCornerShape(9.dp)
    ) {
        Text(
            "C$cycle",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ToolCard(entry: Entry.ToolEntry) {
    // v2.33.0 FLUID CANVAS — the answer is a CHAIN: every tool call is a node
    // on a quiet left rail (mono label, ms, tap to expand). Consecutive rows
    // stack into one continuous chain that reads like a live build log.
    var expanded by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    var showCopy by remember { mutableStateOf(false) }
    val okColor = MaterialTheme.colorScheme.primary
    val errColor = MaterialTheme.colorScheme.error
    val nodeColor = if (entry.ok) okColor else errColor

    Row(
        Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .combinedClickable(onClick = { expanded = !expanded; if (!entry.ok) showCopy = !showCopy })
    ) {
        // rail + node segment
        Canvas(Modifier.width(18.dp).fillMaxHeight()) {
            val x = size.width / 2
            drawLine(
                color = nodeColor.copy(alpha = 0.28f),
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
            // node dot at the top of the row
            drawCircle(
                brush = Brush.linearGradient(listOf(nodeColor, nodeColor.copy(alpha = 0.6f))),
                radius = 4.dp.toPx(),
                center = Offset(x, 8.dp.toPx())
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f).padding(top = 1.dp, bottom = 7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    entry.tool,
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    color = nodeColor
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "${entry.ms} ms",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
                Spacer(Modifier.weight(1f))
                Text(
                    if (expanded) "▾" else "▸",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
            if (expanded) {
                Spacer(Modifier.size(6.dp))
                Text("arguments", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                MonoBox(entry.argsJson, maxLines = 12)
                Spacer(Modifier.size(6.dp))
                Text("result", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                MonoBox(entry.result, maxLines = 40)
                if (!entry.ok) {
                    CopyChip(
                        visible = showCopy,
                        onCopy = {
                            clipboard.setText(
                                AnnotatedString(
                                    "tool: " + entry.tool + "\nargs: " + entry.argsJson + "\nresult: " + entry.result
                                )
                            )
                        }
                    )
                }
            } else {
                Text(
                    entry.result.ellipsize(150),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun MonoBox(text: String, maxLines: Int = 30) {
    Surface(
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.55f),
        shape = RoundedCornerShape(10.dp)
    ) {
        Text(
            text,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            maxLines = maxLines,
            modifier = Modifier
                .padding(9.dp)
                .heightIn(max = 300.dp)
                .verticalScroll(rememberScrollState())
        )
    }
}

private fun String.ellipsize(n: Int): String = if (length <= n) this else take(n) + "…"

@Composable
fun NoteCard(entry: Entry.NoteEntry) {
    val clipboard = LocalClipboardManager.current
    var showCopy by remember { mutableStateOf(false) }
    val (bg, fg) = when (entry.kind) {
        "warn" -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.55f) to MaterialTheme.colorScheme.onTertiaryContainer
        "error" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
        "switch" -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) to MaterialTheme.colorScheme.onPrimaryContainer
        "plan" -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) to MaterialTheme.colorScheme.onPrimaryContainer
        "review" -> MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f) to MaterialTheme.colorScheme.onSecondaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        color = bg,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (entry.kind == "error" || entry.kind == "warn")
                    Modifier.clickableNoIndication { showCopy = !showCopy }
                else Modifier
            )
    ) {
        Column(Modifier.padding(10.dp)) {
            if (entry.kind == "plan") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LimanIcon(R.drawable.ic_route, fg, size = 14)
                    Spacer(Modifier.width(6.dp))
                    Text("PLAN", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = fg)
                }
                Spacer(Modifier.size(4.dp))
                DirectionalText(entry.text.removePrefix("PLAN\n"), style = MaterialTheme.typography.bodySmall, color = fg)
            } else {
                DirectionalText(
                    entry.text,
                    style = MaterialTheme.typography.labelMedium,
                    color = fg,
                    textAlign = if (entry.kind == "info" || entry.kind == "stats") TextAlign.Center else TextAlign.Start,
                    modifier = if (entry.kind == "info" || entry.kind == "stats") Modifier.fillMaxWidth() else Modifier
                )
                CopyChip(visible = showCopy, onCopy = { clipboard.setText(AnnotatedString(entry.text)) })
                LaunchedEffect(showCopy) {
                    if (showCopy) {
                        kotlinx.coroutines.delay(2600)
                        showCopy = false
                    }
                }
            }
        }
    }
}

@Composable
fun ReviewCard(entry: Entry.ReviewEntry) {
    val good = entry.verdict.equals("complete", ignoreCase = true)
    Surface(
        color = if (good) LimanExtras.Success.copy(alpha = 0.14f)
        else MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LimanIcon(
                    R.drawable.ic_shield,
                    if (good) LimanExtras.Success else MaterialTheme.colorScheme.tertiary,
                    size = 16
                )
                Spacer(Modifier.width(7.dp))
                Text(
                    "Self-review · ${entry.score}/10 · ${entry.verdict}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            if (entry.critique.isNotBlank()) {
                Spacer(Modifier.size(4.dp))
                DirectionalText(entry.critique, style = MaterialTheme.typography.bodySmall)
            }
            if (entry.issues.isNotEmpty()) {
                Spacer(Modifier.size(4.dp))
                entry.issues.take(6).forEach {
                    Text("• ${it.ellipsize(160)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun PromptCard(entry: Entry.PromptEntry) {
    Surface(
        color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LimanIcon(R.drawable.ic_ask_user, MaterialTheme.colorScheme.tertiary, size = 15)
                Spacer(Modifier.width(7.dp))
                DirectionalText(entry.question, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.size(4.dp))
            DirectionalText(
                "→ ${entry.answer}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SubagentCard(entry: Entry.SubagentEntry) {
    var expanded by remember { mutableStateOf(false) }
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LimanIcon(R.drawable.ic_spawn_subagent, MaterialTheme.colorScheme.secondary, size = 16)
                Spacer(Modifier.width(8.dp))
                Text(
                    when (entry.status) {
                        "running" -> "Subagent working…"
                        "failed" -> "Subagent failed"
                        else -> "Subagent result"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    style = MaterialTheme.typography.titleSmall
                )
            }
            Spacer(Modifier.size(4.dp))
            DirectionalText(
                "Objective: ${entry.objective}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium
            )
            if (entry.summary.isNotBlank()) {
                Spacer(Modifier.size(4.dp))
                if (expanded) {
                    DirectionalText(entry.summary, style = MaterialTheme.typography.bodySmall)
                } else {
                    DirectionalText(
                        entry.summary,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    if (expanded) "less" else "more",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .padding(top = 2.dp)
                        .clickable { expanded = !expanded }
                )
            }
        }
    }
}

@Composable
fun EntryView(entry: Entry) {
    when (entry) {
        is Entry.UserEntry -> UserBubble(entry)
        is Entry.AssistantEntry -> AssistantBubble(entry)
        is Entry.ToolEntry -> ToolCard(entry)
        is Entry.NoteEntry -> NoteCard(entry)
        is Entry.ReviewEntry -> ReviewCard(entry)
        is Entry.PromptEntry -> PromptCard(entry)
        is Entry.SubagentEntry -> SubagentCard(entry)
        is Entry.FileEntry -> FilesCard(entry)
    }
}

// ============================================================
// v2.36.0 — DELIVERABLES: files embedded in the final answer,
// downloadable right from the chat bubble
// ============================================================

@Composable
fun FilesCard(entry: Entry.FileEntry) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Column(Modifier.padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 6.dp)) {
            Text(
                "📎 Files ready to download",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(2.dp))
            entry.files.forEach { d ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 2.dp)
                ) {
                    Text(deliverableIcon(d.name), style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            d.name,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            d.sizeBytes.fmtBytes(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    TextButton(onClick = { saveDeliverable(context, d) }) { Text("Save") }
                    TextButton(onClick = { shareDeliverable(context, d) }) { Text("Share") }
                }
            }
        }
    }
}

private fun deliverableIcon(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "zip", "7z", "tar", "gz" -> "🗜️"
    "apk" -> "📦"
    "pdf" -> "📕"
    "docx", "doc", "txt", "md" -> "📘"
    "xlsx", "csv" -> "📗"
    "pptx" -> "📙"
    "svg", "png", "jpg", "jpeg", "webp", "gif", "ico" -> "🖼️"
    "mp3", "wav", "m4a", "ogg" -> "🎵"
    "mp4", "webm" -> "🎬"
    else -> "📄"
}

fun deliverableFile(context: android.content.Context, d: com.liman.agent.data.Deliverable): java.io.File =
    java.io.File(java.io.File(context.filesDir, "workspace"), d.path)

private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "zip" -> "application/zip"
    "apk" -> "application/vnd.android.package-archive"
    "pdf" -> "application/pdf"
    "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    "csv" -> "text/csv"
    "svg" -> "image/svg+xml"
    "png" -> "image/png"
    "jpg", "jpeg" -> "image/jpeg"
    "webp" -> "image/webp"
    "gif" -> "image/gif"
    "mp3" -> "audio/mpeg"
    "wav" -> "audio/wav"
    "m4a" -> "audio/mp4"
    "mp4" -> "video/mp4"
    "webm" -> "video/webm"
    "html" -> "text/html"
    "json" -> "application/json"
    "txt", "md" -> "text/plain"
    else -> "application/octet-stream"
}

private fun uniqueFile(dir: java.io.File, name: String): java.io.File {
    var f = java.io.File(dir, name)
    var i = 1
    val base = name.substringBeforeLast('.')
    val ext = name.substringAfterLast('.', "")
    while (f.exists()) {
        f = if (ext.isNotEmpty()) java.io.File(dir, "$base (${i}).$ext") else java.io.File(dir, "$base (${i})")
        i++
    }
    return f
}

/** Save a deliverable into the user's Downloads (MediaStore on 10+, app
 *  downloads folder on older devices) — one tap, no file manager needed. */
fun saveDeliverable(context: android.content.Context, d: com.liman.agent.data.Deliverable) {
    val src = deliverableFile(context, d)
    if (!src.exists()) {
        android.widget.Toast.makeText(context, "File missing in workspace: ${d.name}", android.widget.Toast.LENGTH_SHORT).show()
        return
    }
    val result = runCatching {
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME, d.name)
                put(android.provider.MediaStore.Downloads.MIME_TYPE, mimeFor(d.name))
                put(android.provider.MediaStore.Downloads.RELATIVE_PATH, "Download/Liman")
            }
            val uri = context.contentResolver.insert(
                android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
            ) ?: error("MediaStore insert failed")
            context.contentResolver.openOutputStream(uri)?.use { out ->
                src.inputStream().use { it.copyTo(out) }
            } ?: error("could not open output stream")
            "Saved to Downloads/Liman/${d.name}"
        } else {
            val dir = java.io.File(
                context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), "Liman"
            ).apply { mkdirs() }
            val dst = uniqueFile(dir, d.name)
            src.copyTo(dst, overwrite = false)
            "Saved to ${dst.absolutePath}"
        }
    }.getOrElse { "Could not save: ${it.message}" }
    android.widget.Toast.makeText(context, result, android.widget.Toast.LENGTH_LONG).show()
}

/** Share a deliverable through the Android share sheet (FileProvider URI). */
fun shareDeliverable(context: android.content.Context, d: com.liman.agent.data.Deliverable) {
    val src = deliverableFile(context, d)
    if (!src.exists()) {
        android.widget.Toast.makeText(context, "File missing in workspace: ${d.name}", android.widget.Toast.LENGTH_SHORT).show()
        return
    }
    runCatching {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context, context.packageName + ".fileprovider", src
        )
        val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = mimeFor(d.name)
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(i, "Share ${d.name}"))
    }.onFailure {
        android.widget.Toast.makeText(context, "Share failed: ${it.message}", android.widget.Toast.LENGTH_SHORT).show()
    }
}

// ============================================================
// Live run heartbeat — proves the agent is alive (or honestly waiting)
// ============================================================

@Composable
fun RunStatusBar(
    running: Boolean,
    phase: String,
    waiting: Boolean,
    startedAt: Long,
    lastActivityAt: Long,
    onStop: () -> Unit
) {
    if (!running) return
    val t = LocalStr.current
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        while (true) {
            nowMs = System.currentTimeMillis()
            kotlinx.coroutines.delay(1000)
        }
    }
    val elapsedS = if (startedAt > 0) ((nowMs - startedAt) / 1000).coerceAtLeast(0) else 0
    val idleS = if (lastActivityAt > 0) ((nowMs - lastActivityAt) / 1000).coerceAtLeast(0) else 0
    val stalled = idleS > 25

    // v2.33 FLUID CANVAS: a hairline gradient wave + one quiet pill — the run
    // is visible without eating the chat.
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)) {
        HairlineProgress(stalled = stalled || waiting)
        Spacer(Modifier.height(4.dp))
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            shape = RoundedCornerShape(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 11.dp, end = 2.dp, top = 3.dp, bottom = 3.dp)
            ) {
                if (waiting || stalled) {
                    val ticker = rememberInfiniteTransition(label = "wait")
                    val pulse by ticker.animateFloat(
                        initialValue = 1f, targetValue = 0.25f,
                        animationSpec = infiniteRepeatable(tween(650, easing = LinearEasing), RepeatMode.Reverse),
                        label = "p"
                    )
                    Box(
                        Modifier
                            .size(8.dp)
                            .background(MaterialTheme.colorScheme.secondary.copy(alpha = pulse), CircleShape)
                    )
                } else {
                    WaveDots(MaterialTheme.colorScheme.primary, dotSize = 7)
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    androidx.compose.animation.AnimatedContent(
                        targetState = phase.ifBlank { t.workingHint },
                        transitionSpec = {
                            (
                                androidx.compose.animation.slideInVertically(
                                    animationSpec = spring(dampingRatio = 0.8f, stiffness = 380f)
                                ) { it / 2 } + androidx.compose.animation.fadeIn()
                                ) togetherWith (
                                androidx.compose.animation.slideOutVertically { -it / 2 } +
                                    androidx.compose.animation.fadeOut()
                                )
                        },
                        label = "phase"
                    ) { p ->
                        Text(
                            p,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                    }
                }
                Text(
                    "${elapsedS}s",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                IconButton(onClick = onStop, modifier = Modifier.size(30.dp)) {
                    LimanIcon(R.drawable.ic_stop, MaterialTheme.colorScheme.error, size = 15)
                }
            }
        }
    }
}

/** v2.33 — 2dp indeterminate gradient wave (the 2026 hairline progress). */
@Composable
fun HairlineProgress(stalled: Boolean = false) {
    val a = LimanExtras.RailA
    val b = LimanExtras.RailB
    val calm = reducedMotion()
    val travel = if (!calm) {
        val tr = rememberInfiniteTransition(label = "hair")
        tr.animateFloat(
            initialValue = 0f, targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(if (stalled) 2600 else 1200, easing = FastOutSlowInEasing), RepeatMode.Restart
            ),
            label = "t"
        ).value
    } else 0.5f
    val trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
    Canvas(Modifier.fillMaxWidth().height(2.5.dp)) {
        drawLine(
            color = trackColor,
            start = Offset(0f, size.height / 2),
            end = Offset(size.width, size.height / 2),
            strokeWidth = size.height
        )
        val seg = size.width * 0.28f
        val cx = seg / 2 + (size.width - seg) * travel
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(a.copy(alpha = 0f), a, b, b.copy(alpha = 0f)),
                startX = cx - seg / 2, endX = cx + seg / 2
            ),
            start = Offset(cx - seg / 2, size.height / 2),
            end = Offset(cx + seg / 2, size.height / 2),
            strokeWidth = size.height
        )
    }
}

/** v2.33 — steering chips: messages queued while the agent runs. */
@Composable
fun SteerChipsRow(steers: List<String>, onRemove: (Int) -> Unit) {
    if (steers.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp)) {
        steers.forEachIndexed { i, txt ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .padding(vertical = 2.dp)
                    .clip(RoundedCornerShape(13.dp, 13.dp, 4.dp, 13.dp))
                    .background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.10f))
                    .border(
                        BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.45f)),
                        RoundedCornerShape(13.dp, 13.dp, 4.dp, 13.dp)
                    )
                    .padding(start = 10.dp, end = 4.dp, top = 5.dp, bottom = 5.dp)
            ) {
                Text(
                    "STEER",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.padding(end = 7.dp)
                )
                Text(
                    txt,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(6.dp))
                IconButton(onClick = { onRemove(i) }, modifier = Modifier.size(24.dp)) {
                    Text("✕", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Text(
            "sends automatically when the current run finishes",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.padding(start = 4.dp)
        )
    }
}

/** v2.33 — the contextual LIVE PREVIEW pane: docks only for coding tasks.
 *  Shows the latest render_html screenshot (auto-refreshed as the agent
 *  iterates) + the dev_server URL when live. */
@Composable
fun LivePreviewPane(
    imagePath: String?,
    url: String?,
    label: String,
    onDismiss: () -> Unit
) {
    var bitmap by remember(imagePath) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(imagePath) {
        if (imagePath != null) bitmap = withContext(Dispatchers.IO) {
            runCatching {
                android.graphics.BitmapFactory.decodeFile(imagePath)?.let {
                    // cap the decode size so huge full-page renders stay smooth
                    if (it.width > 1200) {
                        val scale = 1200f / it.width
                        android.graphics.Bitmap.createScaledBitmap(it, 1200, (it.height * scale).toInt(), true)
                    } else it
                }
            }.getOrNull()
        }
    }
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.38f),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            // header: breathing live dot + label/url + close
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 7.dp, bottom = 5.dp)
            ) {
                val ticker = rememberInfiniteTransition(label = "livedot")
                val pulse by ticker.animateFloat(
                    initialValue = 1f, targetValue = 0.3f,
                    animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse),
                    label = "p"
                )
                Box(
                    Modifier
                        .size(7.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = pulse), CircleShape)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    url ?: "LIVE PREVIEW — $label",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Text("✕", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            // the front itself — the latest render, checked right here
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                val bmp = bitmap
                if (bmp != null) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "live preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        WaveDots(MaterialTheme.colorScheme.primary, dotSize = 8)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (imagePath == null) "waiting for the first render…" else "rendering…",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Text(
                "the agent iterates here — every render updates this pane",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
            )
        }
    }
}

/** Slim divider that visually separates agent cycles in the timeline. */
@Composable
fun CycleDivider(cycle: Int) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        androidx.compose.material3.HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
        Text(
            "  CYCLE $cycle  ",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        androidx.compose.material3.HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        )
    }
}

@Composable
fun StreamingBubble(attemptKey: String, text: String, cycle: Int) {
    val t = LocalStr.current
    val transition = rememberInfiniteTransition(label = "cursor")
    val alpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.15f,
        animationSpec = infiniteRepeatable(tween(550, easing = LinearEasing), RepeatMode.Reverse),
        label = "alpha"
    )
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        // active rail: the gradient pulse travels down and back while the
        // answer grows — this is the "connected" visual
        GradientRail(active = true)
        Spacer(Modifier.width(2.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ApertureMark(
                    if (text.isBlank()) ApertureState.THINKING else ApertureState.STREAMING,
                    size = 22
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "${t.thinking}${if (attemptKey.isNotBlank()) " · ${attemptKey.substringBefore('#')}" else ""}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(8.dp))
                CycleBadge(cycle)
            }
            Spacer(Modifier.size(5.dp))
            if (text.isNotBlank()) {
                val shape = RoundedCornerShape(6.dp, 20.dp, 20.dp, 20.dp)
                Box(
                    Modifier
                        .clip(shape)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
                        .border(
                            BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
                            shape
                        )
                ) {
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        modifier = Modifier.padding(horizontal = 15.dp, vertical = 11.dp)
                    ) {
                        SelectionContainer(Modifier.weight(1f, fill = false)) {
                            MarkdownText(text)
                        }
                        Text(
                            "▍",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = alpha)
                        )
                    }
                }
            } else {
                WaveDots(MaterialTheme.colorScheme.primary, dotSize = 9)
            }
        }
    }
}
