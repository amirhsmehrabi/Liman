package com.liman.agent.agent

/**
 * v2.30.0 — VECTOR-FIRST ASSET PIPELINE (APP FACTORY blueprint §5).
 *
 * "No raster assets anywhere in generated output." Base icon set embedded
 * (Lucide-style 24px stroke grammar) + a pure-Kotlin SVG → VectorDrawable
 * converter for the common case (paths/circles/rects/lines — the converter
 * REJECTS filters/masks/text rather than producing broken drawables).
 */
object SvgIcon {

    /** icon name → inner SVG elements (viewBox 0 0 24 24, stroke=currentColor, width 1.75) */
    val ICONS: Map<String, String> = mapOf(
        "search" to """<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>""",
        "plus" to """<path d="M12 5v14M5 12h14"/>""",
        "check" to """<path d="m4 12 5 5L20 6"/>""",
        "x" to """<path d="M6 6l12 12M18 6L6 18"/>""",
        "menu" to """<path d="M4 6h16M4 12h16M4 18h16"/>""",
        "close" to """<path d="M6 6l12 12M18 6L6 18"/>""",
        "trash" to """<path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m3 0-1 13a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2L6 7"/>""",
        "edit" to """<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>""",
        "copy" to """<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>""",
        "share" to """<path d="M12 3v13M8 7l4-4 4 4M5 15v4a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-4"/>""",
        "download" to """<path d="M12 3v13m0 0 4-4m-4 4-4-4M5 21h14"/>""",
        "upload" to """<path d="M12 21V8m0 0 4 4m-4-4-4 4M5 3h14"/>""",
        "refresh" to """<path d="M21 12a9 9 0 1 1-2.6-6.4M21 3v6h-6"/>""",
        "home" to """<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1Z"/>""",
        "arrow-left" to """<path d="M20 12H4m0 0 6-6m-6 6 6 6"/>""",
        "arrow-right" to """<path d="M4 12h16m0 0-6-6m6 6-6 6"/>""",
        "chevron-down" to """<path d="m6 9 6 6 6-6"/>""",
        "chevron-right" to """<path d="m9 6 6 6-6 6"/>""",
        "user" to """<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/>""",
        "bell" to """<path d="M18 9a6 6 0 1 0-12 0c0 6-3 7-3 7h18s-3-1-3-7M10.3 21a2 2 0 0 0 3.4 0"/>""",
        "lock" to """<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 1 1 8 0v4"/>""",
        "eye" to """<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>""",
        "calendar" to """<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4m8-4v4M3 11h18"/>""",
        "clock" to """<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>""",
        "file" to """<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Zm0 0v5h5"/>""",
        "folder" to """<path d="M3 7a2 2 0 0 1 2-2h4l2 3h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>""",
        "send" to """<path d="M22 2 11 13M22 2l-7 20-4-9-9-4Z"/>""",
        "play" to """<path d="m7 4 13 8-13 8Z"/>""",
        "image" to """<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m3 18 6-5 4 3 3-2 5 4"/>""",
        "alert" to """<path d="M12 3 2 20h20Z"/><path d="M12 10v4m0 3v.5"/>""",
        "info" to """<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8v.5"/>""",
        "settings" to """<path d="M4 6h10m4 0h2M4 12h2m4 0h10M4 18h13m3 0h0"/><circle cx="16" cy="6" r="2"/><circle cx="8" cy="12" r="2"/><circle cx="19" cy="18" r="2"/>""",
        "chart" to """<path d="M4 20V10m5 10V4m5 16v-7m5 7V8"/>""",
        "tag" to """<path d="M3 12V4a1 1 0 0 1 1-1h8l9 9-9 9Z"/><circle cx="7.5" cy="7.5" r="1"/>""",
        "link" to """<path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7L12.5 19"/>"""
    )

    /** Full standalone SVG for an icon. */
    fun svg(name: String): String? = ICONS[name]?.let { body ->
        """<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">$body</svg>"""
    }

    // ---------------------------------------------- SVG → VectorDrawable

    private val SVG_TAG = Regex("""<svg\b([^>]*)>""", RegexOption.DOT_MATCHES_ALL)
    private val ELEMENT = Regex("""<(path|circle|rect|line|polyline)\b([^>]*?)(?:/>|>(.*?)</\1>)""", RegexOption.DOT_MATCHES_ALL)
    private val ATTR = { tag: String, name: String ->
        Regex("\\b$name\\s*=\\s*\"([^\"]*)\"").find(tag)?.groupValues?.get(1)
    }

    /**
     * Convert SVG markup to an Android VectorDrawable. Supports the icon
     * grammar (path/circle/rect/line/polyline, stroke or fill) and REJECTS
     * unsupported features (filter/mask/clipPath/pattern/image/text) with a
     * clear message instead of emitting a broken drawable.
     */
    fun toVectorDrawable(svgText: String, name: String = "ic_icon"): Result {
        if (Regex("""<(filter|mask|clipPath|pattern|image|text)\b""").containsMatchIn(svgText))
            return Result(null, "SVG uses an unsupported feature (filter/mask/clipPath/pattern/image/text). " +
                "VectorDrawable can't render it — simplify to plain paths (see the icon spec).", false)
        val svgTag = SVG_TAG.find(svgText) ?: return Result(null, "No <svg> element found.", false)
        val svgAttrs = svgTag.groupValues[1]
        val viewBox = ATTR(svgAttrs, "viewBox") ?: "0 0 24 24"
        val w = ATTR(svgAttrs, "width")?.filter { it.isDigit() } ?: "24"
        val h = ATTR(svgAttrs, "height")?.filter { it.isDigit() } ?: "24"
        val strokeW = ATTR(svgAttrs, "stroke-width") ?: "1.75"
        val hasStroke = svgText.contains("stroke=")
        val xml = StringBuilder()
        xml.appendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
        xml.appendLine("<!-- generated by Liman svg_icon from SVG master; tint via android:tint -->")
        xml.appendLine("<vector xmlns:android=\"http://schemas.android.com/apk/res/android\"")
        xml.appendLine("    android:width=\"${w}dp\"")
        xml.appendLine("    android:height=\"${h}dp\"")
        xml.appendLine("    android:viewportWidth=\"${viewBox.trim().split(" ").getOrNull(2) ?: "24"}\"")
        xml.appendLine("    android:viewportHeight=\"${viewBox.trim().split(" ").getOrNull(3) ?: "24"}\">")
        var count = 0
        ELEMENT.findAll(svgText).forEach { m ->
            val tag = m.groupValues[0]
            val attrs = m.groupValues[2]
            val d = pathData(m.groupValues[1], attrs)
            if (d != null) {
                count++
                xml.appendLine("    <path")
                xml.appendLine("        android:pathData=\"$d\"")
                if (hasStroke) {
                    xml.appendLine("        android:strokeColor=\"#FF000000\"")
                    xml.appendLine("        android:strokeWidth=\"$strokeW\"")
                    xml.appendLine("        android:strokeLineCap=\"round\"")
                    xml.appendLine("        android:strokeLineJoin=\"round\"")
                    if (!ATTR(attrs, "fill").let { it != null && it != "none" })
                        xml.appendLine("        android:fillColor=\"#00000000\"")
                }
                val fill = ATTR(attrs, "fill")
                if (fill != null && fill != "none" && !hasStroke)
                    xml.appendLine("        android:fillColor=\"#FF000000\"")
                xml.appendLine("        />")
            }
        }
        xml.appendLine("</vector>")
        return if (count == 0) Result(null, "No convertible elements (path/circle/rect/line/polyline) found.", false)
        else Result(xml.toString(), null, true)
    }

    /** convert one SVG element to path data */
    private fun pathData(tag: String, attrs: String): String? = when (tag) {
        "path" -> ATTR(attrs, "d")
        "circle" -> {
            val cx = ATTR(attrs, "cx")?.toFloatOrNull() ?: return null
            val cy = ATTR(attrs, "cy")?.toFloatOrNull() ?: return null
            val r = ATTR(attrs, "r")?.toFloatOrNull() ?: return null
            "M ${cx - r} $cy A $r $r 0 1 0 ${cx + r} $cy A $r $r 0 1 0 ${cx - r} $cy"
        }
        "rect" -> {
            val x = ATTR(attrs, "x")?.toFloatOrNull() ?: 0f
            val y = ATTR(attrs, "y")?.toFloatOrNull() ?: 0f
            val w2 = ATTR(attrs, "width")?.toFloatOrNull() ?: return null
            val h2 = ATTR(attrs, "height")?.toFloatOrNull() ?: return null
            "M$x $y H${x + w2} V${y + h2} H$x Z"
        }
        "line" -> {
            val x1 = ATTR(attrs, "x1") ?: return null; val y1 = ATTR(attrs, "y1") ?: return null
            val x2 = ATTR(attrs, "x2") ?: return null; val y2 = ATTR(attrs, "y2") ?: return null
            "M$x1 $y1 L$x2 $y2"
        }
        "polyline" -> ATTR(attrs, "points")?.let { pts ->
            "M" + pts.trim().replace(Regex("\\s+"), " L")
        }
        else -> null
    }

    data class Result(val xml: String?, val error: String?, val ok: Boolean)

    /** The icon spec (blueprint §5.1) — given to the model verbatim. */
    fun spec(): String = """
ICON SPEC (every icon must comply):
- viewBox="0 0 24 24", stroke-based, stroke-width="1.75", stroke-linecap/join="round", fill="none", stroke="currentColor".
- 2px optical padding; live area 20×20; nothing touches the viewBox edge.
- Max 3 path elements. No <filter>, <mask>, <clipPath>, <pattern>, <image>, <text>.
- No hardcoded colors — currentColor (web) / tintable VectorDrawable (Android).
- Name: kebab-case verb-noun (arrow-left, trash-2, user-plus). Prefer the embedded set (svg_icon op:list) over drawing new paths.
WEB: inline SVG sprite + <use href="#i-x"> (inherits color); aria-hidden="true" + aria-label on icon-only buttons.
ANDROID: svg_icon op:convert → res/drawable/ic_x.xml (lowercase_underscore names only); tint with android:tint="?attr/colorControlNormal".
APP ICON: one 108×108 SVG master, art inside the central 66dp safe zone (adaptive masks crop the outer 18dp), + monochrome layer for Android 13+ themed icons.
""".trim()
}
