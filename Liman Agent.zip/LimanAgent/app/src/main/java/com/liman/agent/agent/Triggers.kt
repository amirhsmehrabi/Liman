package com.liman.agent.agent

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import com.liman.agent.LimanApplication
import com.liman.agent.data.ScheduledTask
import com.liman.agent.data.Trigger
import com.liman.agent.util.genId
import com.liman.agent.util.now
import kotlinx.coroutines.launch

/**
 * v2.23.0 — CONTEXT TRIGGERS: the phone's real-world events become agent work.
 *
 * charging_on/off · battery_low/ok · screen_on/off · wifi_on/off · boot —
 * each trigger runs a full headless agent cycle with its prompt (results
 * appear as conversations + notifications, exactly like scheduled missions).
 * Cooldowns guard against event storms. Tasker-class triggers, free, on-device.
 */
object Triggers {

    val KINDS = listOf(
        "charging_on", "charging_off", "battery_low", "battery_ok",
        "screen_on", "screen_off", "wifi_on", "wifi_off", "boot"
    )

    data class KindDef(val kind: String, val action: String, val label: String)

    val DEFS = listOf(
        KindDef("charging_on", Intent.ACTION_POWER_CONNECTED, "charger connected"),
        KindDef("charging_off", Intent.ACTION_POWER_DISCONNECTED, "charger disconnected"),
        KindDef("battery_low", Intent.ACTION_BATTERY_LOW, "battery low"),
        KindDef("battery_ok", Intent.ACTION_BATTERY_OKAY, "battery okay again"),
        KindDef("screen_on", Intent.ACTION_SCREEN_ON, "screen turned on"),
        KindDef("screen_off", Intent.ACTION_SCREEN_OFF, "screen turned off"),
        KindDef("wifi_on", "android.net.conn.CONNECTIVITY_CHANGE", "network connectivity changed"),
        KindDef("wifi_off", "android.net.conn.CONNECTIVITY_CHANGE", "network connectivity changed"),
        KindDef("boot", Intent.ACTION_BOOT_COMPLETED, "phone finished booting")
    )

    fun kindOf(action: String, extraOnline: Boolean? = null, extraCharging: Boolean? = null): String? = when (action) {
        Intent.ACTION_POWER_CONNECTED -> "charging_on"
        Intent.ACTION_POWER_DISCONNECTED -> "charging_off"
        Intent.ACTION_BATTERY_LOW -> "battery_low"
        Intent.ACTION_BATTERY_OKAY -> "battery_ok"
        Intent.ACTION_SCREEN_ON -> "screen_on"
        Intent.ACTION_SCREEN_OFF -> "screen_off"
        "android.net.conn.CONNECTIVITY_CHANGE" -> when (extraOnline) {
            true -> "wifi_on"
            false -> "wifi_off"
            else -> null
        }
        Intent.ACTION_BOOT_COMPLETED -> "boot"
        else -> null
    }

    fun validKind(kind: String): Boolean = kind in KINDS

    fun contextLine(kind: String): String =
        "Trigger context: ${DEFS.firstOrNull { it.kind == kind }?.label ?: kind} just happened on the user's phone (now)."

    fun buildTask(t: Trigger): ScheduledTask = ScheduledTask(
        id = genId("trig"),
        title = "⚡ ${t.title.take(40)}",
        prompt = "${contextLine(t.kind)}\nDo exactly this: ${t.prompt}\nKeep it quick and notify the user only if there is something worth seeing."
    )

    fun formatList(triggers: List<Trigger>): String =
        if (triggers.isEmpty()) "No context triggers yet — add one with trigger {action:'add', kind:'charging_on', title:'Evening mode', prompt:'…'}."
        else buildString {
            appendLine("Context triggers:")
            triggers.forEach {
                appendLine("- [${it.id}] ${it.title} · ${it.kind} · cooldown ${it.cooldownMinutes}m · ${if (it.enabled) "ON" else "OFF"}")
                appendLine("  prompt: ${it.prompt.ellipsize(120)}")
            }
        }

    private fun String.ellipsize(n: Int): String = if (length <= n) this else take(n) + "…"

    // ---------------- execution ----------------

    /**
     * Fire every due trigger of this kind as a headless agent cycle
     * (on the app's IO scope; results land as ⚡ conversations).
     */
    fun fire(context: Context, kind: String) {
        val app = context.applicationContext as LimanApplication
        val store = app.container.stores.triggers
        val due = store.due(kind, now())
        if (due.isEmpty()) return
        due.forEach { store.markFired(it.id, now()) }
        app.container.appScope.launch {
            due.forEach { t ->
                runCatching { Scheduler.runTask(context, buildTask(t)) }
                    .onFailure { Scheduler.notify(context, "⚡ Trigger failed", "${t.title}: ${it.message}") }
            }
        }
    }

    /** Register the runtime receivers (screen/battery/connectivity need dynamic registration). */
    fun registerDynamic(context: Context) {
        val actions = listOf(
            Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED,
            Intent.ACTION_BATTERY_LOW, Intent.ACTION_BATTERY_OKAY,
            Intent.ACTION_SCREEN_ON, Intent.ACTION_SCREEN_OFF,
            "android.net.conn.CONNECTIVITY_CHANGE"
        )
        val receiver = LimanReceiver()
        val filter = IntentFilter().apply { actions.forEach { addAction(it) } }
        context.applicationContext.registerReceiver(receiver, filter)
    }
}

/**
 * One receiver for everything: statically declared for BOOT_COMPLETED
 * (manifest), dynamically registered for the rest. Network events are
 * deduped via the trigger cooldown.
 */
class LimanReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val online: Boolean? = if (action == "android.net.conn.CONNECTIVITY_CHANGE") {
            runCatching {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
                cm.activeNetwork != null
            }.getOrNull()
        } else null
        val kind = Triggers.kindOf(action, online) ?: return
        Triggers.fire(context, kind)
    }
}
