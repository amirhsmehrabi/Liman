package com.liman.agent.llm

import com.liman.agent.data.ProviderConfig
import com.liman.agent.data.ProviderKind
import com.liman.agent.util.arr
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.IOException

/**
 * Provider health check + live model catalog:
 * asks each provider's API which models the user's key can actually use,
 * so the user can pick from the real list instead of typing model IDs.
 */
object ModelCatalog {

    sealed class CatalogResult {
        data class Ok(val models: List<String>, val ms: Long) : CatalogResult()
        data class Fail(val error: String, val ms: Long) : CatalogResult()
    }

    suspend fun fetchModels(cfg: ProviderConfig): CatalogResult = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        try {
            val models = when (cfg.kind) {
                ProviderKind.GEMINI -> geminiModels(cfg)
                ProviderKind.ANTHROPIC -> anthropicModels(cfg)
                ProviderKind.OPENAI_COMPATIBLE -> openAiModels(cfg)
                ProviderKind.WEB_CHAT -> listOf("web") // the site's model is whatever it is
                ProviderKind.OPENCODE_FREE -> OpenCodeFreeProvider.fetchFreeModels()
            }
            if (models.isEmpty()) {
                CatalogResult.Fail("Connected, but the API returned no models.", System.currentTimeMillis() - t0)
            } else {
                CatalogResult.Ok(models, System.currentTimeMillis() - t0)
            }
        } catch (t: Throwable) {
            CatalogResult.Fail(t.message?.take(200) ?: t.javaClass.simpleName, System.currentTimeMillis() - t0)
        }
    }

    // ---------------- Gemini ----------------

    private fun geminiModels(cfg: ProviderConfig): List<String> {
        val base = cfg.baseUrl.trim().trimEnd('/').ifBlank { "https://generativelanguage.googleapis.com" }
        val url = "$base/v1beta/models?pageSize=200"
        val req = Request.Builder().url(url)
            .header("x-goog-api-key", cfg.apiKey)
            .get()
            .build()
        Http.toolClient(45).newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}: ${resp.body?.string()?.take(200)}")
            val obj = resp.body?.string()?.toJsonObject() ?: throw IOException("bad JSON")
            val models = obj.arr("models") ?: return emptyList()
            return models.mapNotNull { m ->
                val mo = m as? kotlinx.serialization.json.JsonObject ?: return@mapNotNull null
                val name = mo.str("name")?.removePrefix("models/") ?: return@mapNotNull null
                val methods = mo.arr("supportedGenerationMethods")
                    ?.mapNotNull { (it as? kotlinx.serialization.json.JsonPrimitive)?.content }
                    ?: emptyList()
                if (methods.isEmpty() || "generateContent" in methods) name else null
            }.distinct().sorted()
        }
    }

    // ---------------- Anthropic ----------------

    private fun anthropicModels(cfg: ProviderConfig): List<String> {
        val base = cfg.baseUrl.trim().trimEnd('/').ifBlank { "https://api.anthropic.com" }
        val url = "$base/v1/models?limit=100"
        val req = Request.Builder().url(url)
            .header("x-api-key", cfg.apiKey)
            .header("anthropic-version", "2023-06-01")
            .get()
            .build()
        Http.toolClient(45).newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}: ${resp.body?.string()?.take(200)}")
            val obj = resp.body?.string()?.toJsonObject() ?: throw IOException("bad JSON")
            return obj.arr("data")?.mapNotNull { d ->
                (d as? kotlinx.serialization.json.JsonObject)?.str("id")
            }?.distinct()?.sorted() ?: emptyList()
        }
    }

    // ---------------- OpenAI-compatible ----------------

    private fun openAiModels(cfg: ProviderConfig): List<String> {
        var base = cfg.baseUrl.trim().trimEnd('/')
        if (base.contains("openai.com") && !base.endsWith("/v1") && !base.contains("/v1/")) base += "/v1"
        if (base.endsWith("/chat/completions")) base = base.removeSuffix("/chat/completions")
        if (base.endsWith("/models")) base = base.removeSuffix("/models")
        if (base.isBlank()) base = "https://api.openai.com/v1"
        val req = Request.Builder().url("$base/models")
            .apply { if (cfg.apiKey.isNotBlank()) header("Authorization", "Bearer ${cfg.apiKey}") }
            .get()
            .build()
        Http.toolClient(45).newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}: ${resp.body?.string()?.take(200)}")
            val obj = resp.body?.string()?.toJsonObject() ?: throw IOException("bad JSON")
            return obj.arr("data")?.mapNotNull { d ->
                (d as? kotlinx.serialization.json.JsonObject)?.str("id")
            }?.distinct()?.sorted() ?: emptyList()
        }
    }
}
