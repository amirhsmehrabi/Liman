package com.liman.agent.agent

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.webkit.WebViewClient
import com.liman.agent.llm.Http
import com.liman.agent.llm.LPart
import com.liman.agent.util.uniqueFile
import com.liman.agent.util.now
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

/**
 * read_link: reads the content of a URL.
 *  1. Tries plain HTTP fetch + HTML→text extraction.
 *  2. If the page needs JavaScript (or text extraction fails / comes back
 *     too thin), renders the FULL page in an offscreen WebView and attaches
 *     a screenshot for the vision model to inspect.
 */
object Browse {

    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"

    suspend fun readLink(url: String, mode: String, appContext: Context, workspace: File): ToolOutcome {
        val clean = url.trim()
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
            return ToolOutcome("Only http(s) URLs are allowed.", false)
        }

        if (mode == "screenshot") {
            return runCatching { screenshot(clean, appContext, workspace) }
                .getOrElse { ToolOutcome("Screenshot failed: ${it.message ?: it.toString()}", false) }
        }

        // ---- text attempt ----
        val textResult = runCatching { fetchAsText(clean) }.getOrNull()
        val thin = textResult == null || textResult.second.trim().length < 250
        if (mode != "auto" || !thin) {
            if (textResult != null && textResult.second.isNotBlank()) {
                val (status, text) = textResult
                return ToolOutcome("$status\n\n$text", true)
            }
            if (mode == "text") {
                return ToolOutcome(
                    "Could not extract readable text (${textResult?.first ?: "fetch failed"}). " +
                        "Try mode=\"screenshot\" to render the page with JavaScript and inspect it visually.",
                    false
                )
            }
        }

        // ---- fallback: full-page screenshot via WebView ----
        return runCatching { screenshot(clean, appContext, workspace) }
            .getOrElse { t ->
                ToolOutcome(
                    "read_link failed: text extraction was too thin " +
                        "(${textResult?.first ?: "no fetch"}) and screenshot failed: ${t.message ?: t.toString()}",
                    false
                )
            }
    }

    // ---------------- text mode ----------------

    /** Returns (statusLine, extractedText). */
    private fun fetchAsText(url: String): Pair<String, String> {
        val req = Request.Builder().url(url)
            .header("User-Agent", DESKTOP_UA)
            .header("Accept", "text/html,application/xhtml+xml,application/json,text/plain,*/*")
            .header("Accept-Language", "en-US,en;q=0.9")
            .get()
            .build()
        Http.toolClient(40).newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
            val mime = resp.header("Content-Type") ?: ""
            val bytes = resp.body?.byteStream()?.readBytes()?.copyOf(2_000_000) ?: ByteArray(0)
            val status = "Fetched $url — HTTP ${resp.code}, $mime, ${bytes.size} bytes"
            val body = String(bytes, Charsets.UTF_8)
            val text = when {
                mime.contains("html") || body.trimStart().startsWith("<!DOCTYPE") ||
                        body.trimStart().startsWith("<html") -> htmlReadable(body)

                else -> body
            }
            return Pair(status, text.take(25_000))
        }
    }

    private fun htmlReadable(html: String): String {
        val title = Regex("""<title[^>]*>(.*?)</title>""", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.get(1)?.let { OfficeExtractors.decodeEntities(it) }?.trim()
        val text = OfficeExtractors.htmlToText(html, 25_000).trim()
        return if (!title.isNullOrBlank() && !text.startsWith(title)) "[$title]\n$text" else text
    }

    // ---------------- screenshot mode ----------------

    private suspend fun screenshot(url: String, appContext: Context, workspace: File): ToolOutcome =
        withContext(Dispatchers.Main) {
            val webView = WebView(appContext)
            try {
                webView.settings.javaScriptEnabled = true
                webView.settings.domStorageEnabled = true
                webView.settings.loadWithOverviewMode = true
                webView.settings.useWideViewPort = true
                webView.settings.userAgentString = DESKTOP_UA

                val width = 1080
                webView.layoutParams = android.view.ViewGroup.LayoutParams(width, 1600)

                val loaded = CompletableDeferred<Boolean>()
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, u: String?) {
                        if (!loaded.isCompleted) loaded.complete(true)
                    }
                }

                webView.loadUrl(url)
                val ok = withTimeoutOrNull(25_000) { loaded.await() }
                if (ok != true) throw IOException("page did not finish loading within 25s")
                delay(2500) // let JavaScript render

                // measure real content height, then lay the view out at full size
                val h = measureContentHeight(webView).coerceIn(600, 9000)
                webView.measure(
                    android.view.View.MeasureSpec.makeMeasureSpec(width, android.view.View.MeasureSpec.EXACTLY),
                    android.view.View.MeasureSpec.makeMeasureSpec(h, android.view.View.MeasureSpec.EXACTLY)
                )
                webView.layout(0, 0, width, h)
                delay(400)

                var bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                webView.draw(Canvas(bmp))

                // scale down so the largest side fits vision-model limits
                val maxDim = maxOf(bmp.width, bmp.height)
                if (maxDim > 1568) {
                    val scale = 1568f / maxDim
                    val w2 = (bmp.width * scale).toInt().coerceAtLeast(1)
                    val h2 = (bmp.height * scale).toInt().coerceAtLeast(1)
                    val scaled = Bitmap.createScaledBitmap(bmp, w2, h2, true)
                    bmp.recycle()
                    bmp = scaled
                }

                val bytes = ByteArrayOutputStream().use {
                    bmp.compress(Bitmap.CompressFormat.PNG, 80, it)
                    it.toByteArray()
                }
                bmp.recycle()

                withContext(Dispatchers.IO) {
                    val file = uniqueFile(File(workspace, "downloads"), "page_${now()}.png")
                    file.writeBytes(bytes)
                    val media = LPart.Media(
                        "image/png",
                        android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP),
                        file.relativeToOrNull(workspace)?.toString()?.replace('\\', '/') ?: file.name
                    )
                    ToolOutcome(
                        "Rendered $url with JavaScript and captured a full-page screenshot " +
                            "(page height ${h}px, scaled for vision). Saved to ${media.filename} — attached below.",
                        true,
                        listOf(media)
                    )
                }
            } finally {
                runCatching { webView.stopLoading() }
                runCatching { webView.destroy() }
            }
        }

    private suspend fun measureContentHeight(webView: WebView): Int {
        val height = withTimeoutOrNull(3_000) {
            suspendCancellableCoroutine<Int> { cont ->
                webView.evaluateJavascript(
                    "(function(){return Math.max(document.body.scrollHeight," +
                        "document.documentElement.scrollHeight, document.body.offsetHeight)||1600})()"
                ) { v ->
                    if (cont.isActive) cont.resume(v?.toFloatOrNull()?.toInt() ?: 1600)
                }
            }
        }
        return height ?: 1600
    }
}
