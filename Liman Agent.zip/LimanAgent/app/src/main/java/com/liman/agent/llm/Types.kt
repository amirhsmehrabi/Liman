package com.liman.agent.llm

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

enum class Role { SYSTEM, USER, ASSISTANT, TOOL }

@Serializable
sealed interface LPart {
    @Serializable
    @SerialName("text")
    data class Text(val text: String) : LPart

    /** Inline media (currently images produced by file ingestion / generation). */
    @Serializable
    @SerialName("media")
    data class Media(val mime: String, val b64: String, val filename: String = "") : LPart

    @Serializable
    @SerialName("tool_call")
    data class ToolCallPart(val id: String, val name: String, val argsJson: String) : LPart

    @Serializable
    @SerialName("tool_result")
    data class ToolResultPart(val toolCallId: String, val name: String, val text: String) : LPart
}

@Serializable
data class LlmMessage(val role: Role, val parts: List<LPart>) {
    fun textOnly(): String = parts.filterIsInstance<LPart.Text>().joinToString("") { it.text }
}

@Serializable
data class ToolSpec(
    val name: String,
    val description: String,
    /** JSON schema (object) as a string. */
    val parametersJson: String
)

data class ToolCallData(val id: String, val name: String, val argsJson: String)

data class Usage(val promptTokens: Int = 0, val completionTokens: Int = 0) {
    val total: Int get() = promptTokens + completionTokens
}

data class LlmResult(
    val text: String,
    val toolCalls: List<ToolCallData> = emptyList(),
    val finishReason: String? = null,
    val usage: Usage? = null,
    val providerName: String = "",
    val modelName: String = ""
)

data class GenSettings(
    val temperature: Double = 0.5,
    val maxTokens: Int = 4096,
    val stream: Boolean = true
)

data class LlmRequest(
    val messages: List<LlmMessage>,
    val tools: List<ToolSpec>,
    val gen: GenSettings
)

fun interface ProviderRunner {
    /**
     * Runs one completion. [onDelta] (when streaming) receives
     * (attemptKey, cumulativeTextSoFar) so the UI can render live text and
     * replace it cleanly when a fallback attempt restarts.
     */
    suspend fun complete(req: LlmRequest, onDelta: (suspend (attemptKey: String, text: String) -> Unit)?): LlmResult
}

/**
 * Parses a tool's parametersJson defensively: if the schema is somehow
 * invalid JSON (a single bad spec used to break EVERY provider request),
 * fall back to a plain object schema instead of failing the whole call.
 */
fun safeSchema(parametersJson: String): kotlinx.serialization.json.JsonObject = try {
    kotlinx.serialization.json.Json.parseToJsonElement(parametersJson) as? kotlinx.serialization.json.JsonObject
        ?: fallbackSchema()
} catch (t: Throwable) {
    fallbackSchema()
}

private fun fallbackSchema(): kotlinx.serialization.json.JsonObject =
    kotlinx.serialization.json.buildJsonObject {
        put("type", kotlinx.serialization.json.JsonPrimitive("object"))
        put("properties", kotlinx.serialization.json.buildJsonObject { })
    }


class EmptyResponseException(message: String = "Empty response from model") : Exception(message)

/** The endpoint cannot accept image/multimodal input for this request. */
class VisionUnsupportedException(message: String) : Exception(message)

/** The model name is wrong / not available on this endpoint (e.g. OpenRouter 404). */
class InvalidModelException(message: String) : Exception(message)

/** The request payload itself is rejected (HTTP 400 invalid JSON payload etc). */
class InvalidPayloadException(message: String) : Exception(message)

/**
 * Provider HTTP error. For quota/rate limits (429) the provider fills in what
 * it learned from the error body: how long to wait ([retryAfterMs]) and
 * whether the limit is the free-tier DAILY cap (retrying is then pointless
 * for hours) or a per-minute/per-request cap (a patient retry succeeds).
 */
class HttpProvException(
    val code: Int,
    message: String,
    val retryAfterMs: Long? = null,
    val quotaDaily: Boolean = false,
    val quotaPerMinute: Boolean = false
) : Exception("HTTP $code: $message")

fun isRetryableProviderError(e: Throwable): Boolean = when (e) {
    is java.io.IOException -> true
    is VisionUnsupportedException, is InvalidModelException, is InvalidPayloadException -> false
    is HttpProvException -> e.code == 408 || e.code == 429 || e.code >= 500
    is EmptyResponseException -> true
    else -> false
}

/** True when an error text means "this endpoint can't take images right now". */
fun looksLikeVisionError(msg: String): Boolean {
    val m = msg.lowercase()
    return listOf(
        "image", "multimodal", "inline_data", "inline data", "media type",
        "not support", "unsupported content", "unsupported type", "does not support",
        "visual", "modalit"
    ).any { it in m } && listOf("400", "invalid", "not support", "unsupported", "error", "cannot", "can't").any { it in m }
}

/** True when an error text means "no such model on this endpoint". */
fun looksLikeInvalidModelError(msg: String): Boolean {
    val m = msg.lowercase()
    return ("404" in m) || ("not found" in m) || ("no such model" in m) ||
        ("model" in m && ("deprecat" in m || "not available" in m || "invalid model" in m))
}

/** True when an error text means the request body itself was rejected. */
fun looksLikeInvalidPayloadError(msg: String): Boolean {
    val m = msg.lowercase()
    return ("invalid json payload" in m) || ("invalid request" in m) || ("malformed" in m) ||
        ("bad request" in m) || ("http 400" in m) || ("unable to submit request" in m)
}
