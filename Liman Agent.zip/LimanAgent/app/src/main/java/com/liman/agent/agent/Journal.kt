package com.liman.agent.agent

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v2.23.0 — THE JOURNAL + MORNING BRIEFING.
 *
 * Liman writes its own day-book: everything it did, saw and learned lands
 * in workspace/journal/YYYY-MM-DD.md — human-readable, greppable, agent-
 * searchable. The morning briefing aggregates yesterday+today into one
 * calm notification. This is the feature that makes the agent feel alive:
 * it INITIATES.
 */
object Journal {

    private val DAY = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val TIME = SimpleDateFormat("HH:mm", Locale.US)

    fun dir(workspace: File): File = File(workspace, "journal").apply { mkdirs() }

    fun dayFile(workspace: File, at: Long = System.currentTimeMillis()): File =
        File(dir(workspace), "${DAY.format(Date(at))}.md")

    fun stamp(type: String, text: String, at: Long = System.currentTimeMillis()): String =
        "**${TIME.format(Date(at))}** · ${type.uppercase()} · ${text.replace("\n", " ").trim()}"

    /** Append one journal line (creates the day file with a header if needed). */
    fun append(workspace: File, type: String, text: String, at: Long = System.currentTimeMillis()): File {
        val f = dayFile(workspace, at)
        if (!f.exists()) f.writeText("# Journal — ${DAY.format(Date(at))}\n\n")
        f.appendText("- ${stamp(type, text, at)}\n")
        return f
    }

    data class BriefingFacts(
        val journalToday: String,
        val journalYesterday: String,
        val missionsScheduled: Int,
        val missionsRunSinceYesterday: Int,
        val watchersChanged: List<String>,
        val notificationCounts: Map<String, Int>,
        val urgentNotifications: List<String>
    )

    /**
     * The briefing skeleton the agent enriches with its own summary.
     * Pure: all inputs are strings/numbers gathered by the caller.
     */
    fun buildBriefing(facts: BriefingFacts, at: Long = System.currentTimeMillis()): String = buildString {
        appendLine("# 🌅 Liman briefing — ${DAY.format(Date(at))}")
        appendLine()
        appendLine("## Yesterday in the journal")
        appendLine(facts.journalYesterday.ifBlank { "_(nothing recorded — a quiet day)_" }.trim())
        appendLine()
        appendLine("## Overnight & scheduled")
        appendLine("- Scheduled missions: ${facts.missionsScheduled} (${facts.missionsRunSinceYesterday} ran since yesterday)")
        if (facts.watchersChanged.isNotEmpty()) {
            appendLine("- Watchers that detected changes:")
            facts.watchersChanged.forEach { appendLine("  - $it") }
        }
        appendLine()
        appendLine("## Notification pulse (top apps)")
        if (facts.notificationCounts.isEmpty()) appendLine("_(no notification log — enable the accessibility service for the pulse)_")
        else facts.notificationCounts.entries.sortedByDescending { it.value }.take(8).forEach { (app, n) ->
            appendLine("- $app ×$n")
        }
        if (facts.urgentNotifications.isNotEmpty()) {
            appendLine()
            appendLine("## ⚠ Urgent (matched your urgent rules)")
            facts.urgentNotifications.take(10).forEach { appendLine("- $it") }
        }
        appendLine()
        appendLine("## Today")
        appendLine("_(the agent fills this in: scheduled missions, watchers due, HEARTBEAT items)_")
    }

    /** Parse "NOTIF <app> · <text>" lines out of a demo session log. */
    fun notifLines(demoLogText: String, sinceLine: Int = 0): List<String> =
        demoLogText.lines().drop(sinceLine)
            .filter { it.startsWith("NOTIF ") }
            .map { it.removePrefix("NOTIF ").trim() }
}
