package com.liman.agent.agent

import com.liman.agent.data.SkillMeta
import com.liman.agent.data.Stores
import com.liman.agent.llm.ComboProvider
import com.liman.agent.llm.GenSettings
import com.liman.agent.llm.Http
import com.liman.agent.llm.LlmMessage
import com.liman.agent.llm.LlmRequest
import com.liman.agent.llm.LPart
import com.liman.agent.llm.Role
import com.liman.agent.util.JSON
import com.liman.agent.util.arr
import com.liman.agent.util.genId
import com.liman.agent.util.now
import com.liman.agent.util.sanitizeFileName
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.Request
import java.io.IOException

/**
 * Liman's skill system — the "self-improvement" layer.
 *
 * A skill is a folder with a SKILL.md file (YAML frontmatter + instructions),
 * compatible with Claude Code / Hermes style skill packs. The agent can:
 *  - auto-load relevant skills per request (LLM router picks them)
 *  - load any skill on demand (use_skill)
 *  - search the web + a GitHub registry for new skills (search_skills)
 *  - install skills from a URL (install_skill)
 */
/**
 * Parses a SKILL.md with optional YAML frontmatter.
 * Returns (name, description, body).
 */
fun parseSkillMarkdown(md: String): Triple<String, String, String> {
    var body = md.trim()
    var name = ""
    var description = ""
    if (body.startsWith("---")) {
        val end = body.indexOf("\n---", 4)
        if (end > 0) {
            val fm = body.substring(4, end)
            val rest = body.substring(end + 4).trim()
            if (rest.isNotEmpty() || fm.lines().any { it.contains(':') }) {
                body = rest
                fm.lines().forEach { line ->
                    val idx = line.indexOf(':')
                    if (idx > 0) {
                        val k = line.substring(0, idx).trim().lowercase()
                        var v = line.substring(idx + 1).trim()
                        if (v.length >= 2 && (v.startsWith("\"") && v.endsWith("\"") ||
                                    v.startsWith("'") && v.endsWith("'"))
                        ) v = v.substring(1, v.length - 1)
                        when (k) {
                            "name" -> name = v
                            "description" -> description = v
                        }
                    }
                }
            }
        }
    }
    return Triple(name, description, body)
}

class SkillSystem(private val stores: Stores) {

    data class Candidate(val name: String, val description: String, val url: String, val source: String)

    // ---------------- catalog / instructions ----------------

    fun enabled(): List<SkillMeta> = stores.skills.state.value.filter { it.enabled }

    fun catalogText(): String {
        val skills = enabled()
        if (skills.isEmpty()) return ""
        return skills.joinToString("\n") { m ->
            "- ${m.id}: ${m.description.ifBlank { "(no description)" }.take(200)}"
        }
    }

    fun instructionsFor(ids: List<String>): String {
        val picked = enabled().filter { it.id in ids }
        if (picked.isEmpty()) return "(no matching enabled skills)"
        return picked.joinToString("\n\n") { m ->
            val raw = stores.skills.instructions(m.id) ?: ""
            val (_, _, body) = parseSkillMarkdown(raw)
            "# SKILL: ${m.name}\n${raw.trim().let { md -> if (md.startsWith("---")) body else md }}"
        }
    }

    // ---------------- installation ----------------

    fun installFromMarkdown(name: String, description: String, markdown: String, sourceUrl: String): String {
        val id = (name.ifBlank { "skill" }).sanitizeFileName().replace(' ', '_').lowercase().take(40)
            .ifBlank { "skill" }
        stores.skills.upsert(
            SkillMeta(
                id = id, name = name.ifBlank { id }, description = description,
                sourceUrl = sourceUrl, enabled = true, installedAt = now()
            ),
            markdown
        )
        return id
    }

    suspend fun installFromUrl(url: String): String = withContext(Dispatchers.IO) {
        val rawUrl = githubBlobToRaw(url.trim())
        if (!rawUrl.startsWith("http")) throw IOException("Not a valid URL: $url")
        val md = httpGet(rawUrl, 300_000)
        if (md.isBlank() || md.length < 40) throw IOException("URL did not return skill content")
        val (name, description, _) = parseSkillMarkdown(md)
        val finalName = name.ifBlank {
            rawUrl.substringAfterLast('/').removeSuffix(".md").removeSuffix("SKILL").trim('.').ifBlank { "skill" }
        }
        val id = installFromMarkdown(finalName, description, md, url.trim())
        "Installed skill '$finalName' (id: $id) from ${url.trim()}."
    }

    fun delete(id: String) = stores.skills.delete(id)

    // ---------------- skill auto-router (LLM picks relevant skills) ----------------

    suspend fun pickForRequest(userText: String, combo: ComboProvider): List<String> {
        val catalog = catalogText()
        if (catalog.isBlank()) return emptyList()
        val sys = "You are Liman's skill router. Given a user request and a catalog of installed skills, " +
            "decide which skills (max 3) would genuinely help accomplish the request. " +
            "Only pick clearly relevant skills — an empty list is a fine answer. " +
            "Respond with ONLY a JSON object, no markdown fences: {\"skills\":[\"skill-id\", ...]}"
        val user = "USER REQUEST:\n${userText.take(2000)}\n\nINSTALLED SKILLS:\n$catalog"
        val res = runCatching {
            combo.complete(
                LlmRequest(
                    listOf(
                        LlmMessage(Role.SYSTEM, listOf(LPart.Text(sys))),
                        LlmMessage(Role.USER, listOf(LPart.Text(user)))
                    ),
                    emptyList(),
                    GenSettings(0.0, 200, false)
                )
            ) { _, _ -> }
        }.getOrNull() ?: return emptyList()
        val txt = res.text
        val start = txt.indexOf('{')
        val end = txt.lastIndexOf('}')
        if (start < 0 || end <= start) return emptyList()
        val obj = txt.substring(start, end + 1).toJsonObject() ?: return emptyList()
        val validIds = enabled().map { it.id }.toSet()
        val picked = obj.arr("skills")
            ?.mapNotNull { (it as? JsonPrimitive)?.content }
            ?.filter { it in validIds }
            ?.take(3)
            .orEmpty()
        if (picked.isNotEmpty()) stores.skills.markUsed(picked)
        return picked
    }

    // ---------------- discovery (search the internet for skills) ----------------

    suspend fun searchAndCollect(topic: String): List<Candidate> = withContext(Dispatchers.IO) {
        val out = LinkedHashMap<String, Candidate>()
        // 1) GitHub code/registry search via the public web-search chain
        val queries = listOf(
            "claude agent skill \"$topic\" SKILL.md site:github.com",
            "awesome claude skills $topic",
            "agent skills pack \"$topic\" SKILL.md"
        )
        for (q in queries) {
            runCatching { WebSearch.searchResults(q, 8) }.getOrDefault(emptyList())
                .filter { it.url.contains("github.com", ignoreCase = true) || it.url.endsWith(".md") }
                .forEach { r ->
                    val key = r.url.substringBefore("#")
                    if (out.containsKey(key)) return@forEach
                    val name = r.title.substringBefore("·").trim().take(60)
                    out[key] = Candidate(
                        name = name.ifBlank { r.url.substringAfterLast('/') },
                        description = r.snippet.take(240),
                        url = r.url,
                        source = "web"
                    )
                }
            if (out.size >= 12) break
        }
        // 2) Anthropic's public skills repo as a known-good registry
        runCatching { registryCandidates() }.getOrDefault(emptyList()).forEach { c ->
            out.putIfAbsent(c.url, c)
        }
        out.values.take(15)
    }

    private fun registryCandidates(): List<Candidate> {
        val results = ArrayList<Candidate>()
        val api = "https://api.github.com/repos/anthropics/skills/contents/"
        val body = httpGet(api, 400_000)
        val arr = JSON.parseToJsonElement(body) as? kotlinx.serialization.json.JsonArray ?: return results
        val dirs = arr.mapNotNull { (it as? JsonObject)?.str("name") }
            .filter { !it.startsWith(".") }
        for (d in dirs.take(10)) {
            // try both <dir>/SKILL.md and <dir>/<sub>/SKILL.md one level deep
            val direct = runCatching {
                val md = httpGet(
                    "https://raw.githubusercontent.com/anthropics/skills/main/$d/SKILL.md", 200_000
                )
                if (md.length > 40) {
                    val (n, desc, _) = parseSkillMarkdown(md)
                    Candidate(
                        n.ifBlank { d }, desc.take(240),
                        "https://raw.githubusercontent.com/anthropics/skills/main/$d/SKILL.md",
                        "anthropics/skills"
                    )
                } else null
            }.getOrNull()
            if (direct != null) results.add(direct)
            if (results.size >= 8) break
        }
        return results
    }

    // ---------------- helpers ----------------

    private fun githubBlobToRaw(url: String): String {
        val m = Regex("""^https://github\.com/([^/]+)/([^/]+)/blob/(.+)$""").find(url) ?: return url
        val (org, repo, path) = m.destructured
        return "https://raw.githubusercontent.com/$org/$repo/$path"
    }

    private fun httpGet(url: String, maxBytes: Int): String {
        val req = Request.Builder().url(url)
            .header("User-Agent", "LimanAgent/1.0 (Android)")
            .header("Accept", "text/markdown, text/plain, application/json, */*")
            .get()
            .build()
        Http.toolClient(30).newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("HTTP ${resp.code} for $url")
            val bytes = resp.body?.byteStream()?.readBytes() ?: ByteArray(0)
            return String(bytes.copyOf(minOf(bytes.size, maxBytes)), Charsets.UTF_8)
        }
    }
}
