package com.liman.agent.agent

import com.liman.agent.util.JSON
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * v2.14.0 — HERO MODE.
 *
 * The #1 complaint that made Liman feel like "just a chatbot": the model
 * replies "Ok, I will connect to your Cloudflare and deploy the workers…"
 * and the agent accepts that text as the FINAL answer — the run ends and
 * nothing whatsoever happened in the real world.
 *
 * Two pure helpers close that hole:
 *
 *  1. [shouldForceAction] — detects all-talk replies (announced intentions,
 *     advice that hands the work to the user, walls of explanation where a
 *     real action was commanded). The agent loop rejects them as final
 *     answers and injects [nudge] instead, sending the model back to act.
 *  2. [TextToolCalls.parse] — many free-tier models don't emit native
 *     function calls but WRITE the call as JSON in the text. The loop
 *     rescues those and executes them for real.
 */
object HeroMode {

    // The model ANNOUNCES a future action instead of performing it.
    // v2.28.0: TIGHTENED — "let me know if…", "sure, I can help" and other
    // conversational closers were matching and got simple chats stuck in
    // act-now nudges (cycle after cycle on "hi"). An announcement now needs a
    // concrete ACTION VERB, not just a preamble phrase.
    private val ACTION_VERB = "(connect|create|write|deploy|run|build|make|set|upload|send|fetch|check|use|start|generate|install|update|delete|put|publish|apply|configure|fix|add|remove|test|verify)"
    private val INTENT = listOf(
        Regex("(?i)\\bi (will|'ll|am going to|'m going to|would like to|shall now)( now)?\\s+" + ACTION_VERB),
        Regex("(?i)\\b(let me|allow me)\\s+" + ACTION_VERB),
        Regex("(?i)\\bi can now\\s+" + ACTION_VERB),
        Regex("(?i)\\b(next|now|first)[, ]+(i|we) (will|'ll|can|should)\\s+" + ACTION_VERB),
        // Persian announcements — future tense, present-tense do/build/write, or
        // explicit "now I …". Safe since the conversational guard gates these.
        Regex("خواهم (کرد|ساخت|نوشت|داد|گرفت)|می[‌ ]?کنم|می[‌ ]?سازم|می[‌ ]?نویسم|اجازه بده|الان انجام|الان می")
    )

    // The model gives the USER homework instead of doing the job itself.
    private val ADVICE = listOf(
        Regex("(?i)\\byou (should|need to|have to|must|may want to|can simply|can go)\\b"),
        Regex("(?i)\\b(you|please) (go to|open|visit|log ?in|sign ?up|click|tap|copy|paste|download|install|navigate)\\b"),
        Regex("(?i)\\bfirst,? (open|go|visit|log)\\b"),
        Regex("(?i)\\bstep \\d"),           // step-by-step user instructions
        Regex("(?i)\\bfollow these steps\\b"),
        // Persian advice ("you should… / go to… / click…")
        Regex("باید خودت|برو به|وارد شو|کلیک کن|ذخیره کن|نصب کن|ایجاد کن|مراحل زیر")
    )

    // The user's request is a real-world COMMAND, not a question to answer.
    private val COMMAND = listOf(
        Regex("(?i)\\b(deploy|create|write|build|run|install|fix|make|set ?up|connect|upload|send|delete|remove|download|generate|put|publish|update|clone|push|commit|register|sign ?up|apply|configure|schedule|automate|post)\\b"),
        Regex("بنویس|بساز|انجام|بفرست|بگذار|بذار|نصب|اتصال|وصل|آپلود|دانلود|منتشر|بسازید|کنید| کن")
    )

    // v2.35.0 — FAILURE NARRATIVE: the model ends the run with an essay about
    // its own failed attempts ("nothing was built yet — attempt 1 crashed…")
    // instead of doing the job. On a command task with zero tools that is a
    // stall shape, never a final answer.
    private val FAILURE_NARRATIVE = listOf(
        Regex("(?i)\\bnothing (was )?(built|created|done|executed|achieved|implemented)\\b"),
        Regex("(?i)\\bno (tools|work) (ran|were run|were executed|executed)\\b"),
        Regex("(?i)\\bnothing to show\\b"),
        Regex("(?i)\\bzero tools\\b"),
        Regex("(?i)\\bevery attempt (so far )?(died|failed|crashed)\\b"),
        Regex("(?i)\\battempts? \\d+\\s*[:\u2014-]"),
        Regex("(?i)\\bthat pattern stops now\\b")
    )

private val ENDS_WITH_QUESTION = Regex("[?؟]\\s*$")

    fun isQuestion(text: String): Boolean =
        text.isNotBlank() && ENDS_WITH_QUESTION.containsMatchIn(text.trim())

    fun looksLikeTask(userText: String): Boolean =
        COMMAND.any { it.containsMatchIn(userText) }

    /**
     * Should this assistant reply be REJECTED as the final answer, with the
     * model pushed to actually act? Questions and honest, tool-backed
     * summaries finish normally; announcements, user-homework and
     * explanation-walls on command tasks get one more chance to DO.
     */
    fun shouldForceAction(
        assistantText: String,
        userText: String,
        toolsCalledSoFar: Int,
        cycle: Int
    ): Boolean {
        val t = assistantText.trim()
        if (t.isEmpty()) return false
        if (isQuestion(t)) return false

        // v2.28.0 THE CONVERSATIONAL GUARD — the "hi → 4 cycles" bug:
        // if the user's ask contains no command verb AND nothing has been
        // done yet, this is conversation. A chatty reply is a COMPLETE
        // answer, never a failure. Do not nudge. Do not invent work.
        val commandTask = looksLikeTask(userText)
        if (!commandTask && toolsCalledSoFar == 0) return false

        // 1) "Ok, I will now …" — announced action, executed nothing.
        //    Always a failure, even mid-run after earlier tools.
        if (INTENT.any { it.containsMatchIn(t) }) return true

        // 1b) v2.35.0 — RAW TOOL-CALL MARKUP leaked into the reply: the model
        //     "called" tools by writing XML that nothing executed. That reply
        //     is never a valid final answer.
        if (t.contains("<function_calls", ignoreCase = true) ||
            t.contains("<invoke", ignoreCase = true) ||
            t.contains("</invoke>", ignoreCase = true)
        ) return true

        // 1c) v2.35.0 — FAILURE NARRATIVE: an essay about its own failed
        //     attempts on a command task with zero tools executed.
        if (toolsCalledSoFar == 0 && commandTask &&
            FAILURE_NARRATIVE.any { it.containsMatchIn(t) }
        ) return true

        // 2) Advice / instructions for the user on a command task, no tools yet.
        if (toolsCalledSoFar == 0 && cycle <= 2 && commandTask &&
            ADVICE.any { it.containsMatchIn(t) }
        ) return true

        // 3) A command task answered with a wall of explanation, zero tools,
        //    first cycle — probably generating prose instead of doing.
        if (toolsCalledSoFar == 0 && cycle == 1 && commandTask && t.length > 500) return true

        return false
    }

    /** The "stop talking, start doing" message injected as a user turn. */
    fun nudge(attempt: Int): String = """
        [SYSTEM — EXECUTION MODE, attempt $attempt]
        Your last reply DESCRIBED what you would do (or told the user how to do it) — but you called no tools, so NOTHING has actually happened yet. That is a failure. You are an executor, not an adviser.
        Act NOW, in this very reply, by calling your tools:
        - http_request calls ANY web API with the user's tokens/keys from the conversation as headers (Authorization: Bearer …, X-Auth-Key …). Example — deploying a Cloudflare Worker: PUT https://api.cloudflare.com/client/v4/accounts/{account_id}/workers/scripts/{name} with Content-Type: application/javascript and header "Authorization: Bearer <the user's API token>", the worker code as the body. Verify afterwards with a GET.
        - write_file creates real files; run_code executes REAL python/bash/node programs (write code, run it, read output, fix, rerun).
        - Need a capability you lack? mcp_connect / search_skills / web_search — all by yourself.
        - A required credential is truly missing? ask_user ONE specific question. Otherwise do not ask.
        Iterate until the task is DONE in the real world, then VERIFY the result yourself (re-fetch, re-read, re-run to prove it) and finish with the evidence.
        If the task genuinely needs no tools (pure writing or a simple answer), reply with the complete final result immediately — but never claim you did something you did not.
    """.trimIndent()
}

/**
 * Rescues tool calls that a model WROTE as text instead of emitting native
 * function calls. v2.35.0: understands BOTH shapes —
 *
 *  JSON objects (only known tool names execute, data JSON never runs):
 *   {"name": "http_request", "arguments": {"url": "…"}}
 *   {"tool": "http_request", "args": {"url": "…"}}
 *   {"http_request": {"url": "…"}}                     (action-style)
 *   {"name": "run_code", "arguments": "{\"language\":…}" }  (args as JSON string)
 *
 *  Claude-style XML markup — the shape claude-trained/free models emit when
 *  the endpoint has no native function-calling. Tolerant to the
 *  malformations seen in production (stray closers like </design_tokens>,
 *  missing wrapper, unquoted attributes):
 *   <function_calls>
 *   <invoke name="design_tokens">
 *   <parameter name="action">contract</parameter>
 *   </invoke>
 *   </function_calls>
 *
 *  [parse] keeps the historical signature (calls only). [parseDetailed]
 *  additionally reports unknown tool names and the markup span so the caller
 *  can coach the model ([formatFeedback]) and scrub the garbage from the
 *  visible reply ([redact]).
 */
object TextToolCalls {

    data class Salvage(
        val calls: List<Pair<String, String>>,
        val unknownTools: List<String> = emptyList(),
        val hadMarkup: Boolean = false,
        val xmlSpan: IntRange? = null,
        val jsonBodies: List<String> = emptyList()
    )

    fun parse(text: String, knownTools: Set<String>, maxCalls: Int = 4): List<Pair<String, String>> =
        parseDetailed(text, knownTools, maxCalls).calls

    fun parseDetailed(text: String, knownTools: Set<String>, maxCalls: Int = 6): Salvage {
        val (jsonCalls, jsonBodies) = parseJson(text, knownTools, maxCalls)
        if (jsonCalls.isNotEmpty()) return Salvage(jsonCalls, jsonBodies = jsonBodies)
        return parseXml(text, knownTools, maxCalls)
    }

    /** Removes rescued markup from the text the user sees. */
    fun redact(text: String, s: Salvage): String {
        var out = text
        s.xmlSpan?.let { span ->
            val from = span.first.coerceIn(0, out.length)
            val to = (span.last + 1).coerceIn(0, out.length)
            if (to > from) out = out.removeRange(from, to)
        }
        s.jsonBodies.forEach { body ->
            val i = out.indexOf(body)
            if (i >= 0) out = out.removeRange(i, i + body.length)
        }
        return out.replace("```json", "").replace("```", "").trim()
    }

    /**
     * The coaching message for markup that could not be executed at all —
     * injected as a user turn so the model re-issues the calls natively.
     */
    fun formatFeedback(s: Salvage, validTools: List<String>): String = buildString {
        append("[SYSTEM — TOOL CALL FORMAT ERROR]\n")
        append("Your last reply contained tool calls written as XML markup (<function_calls>/<invoke>/<parameter> tags). ")
        append("That markup is NOT executed and must NEVER appear in your text — it leaks garbage into the user's chat.\n")
        if (s.unknownTools.isNotEmpty()) {
            append("These tool names DO NOT EXIST: ${s.unknownTools.joinToString(", ")}. Never invent tool names.\n")
            val near = s.unknownTools.flatMap { u ->
                validTools.filter { v -> v.contains(u.take(5)) || u.contains(v.take(5)) }.take(2)
            }.distinct()
            if (near.isNotEmpty()) append("Closest real tools: ${near.joinToString(", ")}.\n")
        }
        append("Re-issue the calls NOW through the NATIVE function-call mechanism. ")
        append("Valid tools: ${validTools.take(60).joinToString(", ")}.\n")
        append("If the capability truly does not exist, say so in ONE line and continue the task — but never write tool markup in text again.")
    }

    // ---------------- JSON shape ----------------

    private fun parseJson(text: String, known: Set<String>, maxCalls: Int): Pair<List<Pair<String, String>>, List<String>> {
        if (!text.contains("{")) return emptyList<Pair<String, String>>() to emptyList()
        // code fences only get in the way; the JSON inside is what matters
        val cleaned = text.replace("```json", "\n").replace("```", "\n")
        val calls = mutableListOf<Pair<String, String>>()
        val bodies = mutableListOf<String>()
        var i = 0
        while (i < cleaned.length && calls.size < maxCalls) {
            val start = cleaned.indexOf('{', i)
            if (start < 0) break
            val end = balancedEnd(cleaned, start)
            if (end < 0) break
            val body = cleaned.substring(start, end + 1)
            parseOne(body, known)?.let {
                calls += it
                bodies += body
            }
            i = end + 1
        }
        return calls to bodies
    }

    /** Index of the `}` that balances the `{` at [start], or -1. */
    private fun balancedEnd(s: String, start: Int): Int {
        var depth = 0
        var inStr = false
        var esc = false
        for (j in start until s.length) {
            val c = s[j]
            if (esc) { esc = false; continue }
            when {
                c == '\\' && inStr -> esc = true
                c == '"' -> inStr = !inStr
                !inStr && c == '{' -> depth++
                !inStr && c == '}' -> {
                    depth--
                    if (depth == 0) return j
                }
            }
        }
        return -1
    }

    private fun parseOne(jsonStr: String, known: Set<String>): Pair<String, String>? {
        val el = runCatching { JSON.parseToJsonElement(jsonStr) }.getOrNull() as? JsonObject ?: return null

        val name = el.keys.firstOrNull { it in setOf("name", "tool", "tool_name") }?.let { (el[it] as? JsonPrimitive)?.content }
        if (name != null && name in known) {
            val argsEl = listOf("arguments", "args", "parameters", "input", "arguments_json")
                .firstNotNullOfOrNull { el[it] }
            return name to argsToString(argsEl)
        }

        // action-style: {"http_request": {"url": "…"}}
        for ((k, v) in el) {
            if (k in known && v is JsonObject) return k to v.toString()
        }
        return null
    }

    private fun argsToString(argsEl: kotlinx.serialization.json.JsonElement?): String = when (argsEl) {
        null -> "{}"
        is JsonObject -> argsEl.toString()
        is JsonPrimitive -> {
            // args given as a JSON string: unwrap if it parses as an object
            val inner = runCatching { JSON.parseToJsonElement(argsEl.content) }.getOrNull()
            if (inner is JsonObject) inner.toString() else "{}"
        }
        else -> "{}"
    }

    // ---------------- XML shape (v2.35.0) ----------------

    private val INVOKE_OPEN = Regex("<invoke\\b[^>]*>", RegexOption.IGNORE_CASE)
    private val NAME_ATTR = Regex("\\bname\\s*=\\s*[\"']?([A-Za-z0-9_.\\-:]+)[\"']?", RegexOption.IGNORE_CASE)
    private val PARAM_OPEN = Regex("<param(eter)?\\s+name\\s*=\\s*[\"']?([A-Za-z0-9_.\\-:]+)[\"']?\\s*>", RegexOption.IGNORE_CASE)

    private fun parseXml(text: String, known: Set<String>, maxCalls: Int): Salvage {
        val hasWrapper = text.contains("<function_calls", ignoreCase = true)
        val opens = INVOKE_OPEN.findAll(text).toList()
        if (opens.isEmpty()) {
            return Salvage(
                emptyList(), emptyList(),
                hadMarkup = hasWrapper || text.contains("</invoke>", ignoreCase = true),
                xmlSpan = null
            )
        }

        // Span end = the LAST closing tag of the whole block. Tolerates wrong
        // closers (a stray </design_tokens> instead of </function_calls>): any
        // `</…>` within 80 chars after the last known closer extends the span;
        // with no known closer at all, fall back to the last `</…>` in text.
        val lastKnown = maxOf(
            text.lastIndexOf("</invoke>", ignoreCase = true),
            text.lastIndexOf("</function_calls>", ignoreCase = true),
            text.lastIndexOf("</parameter>", ignoreCase = true)
        )
        var spanEnd = if (lastKnown >= 0) {
            val gt = text.indexOf('>', lastKnown)
            if (gt >= 0) gt + 1 else text.length
        } else -1
        val anyClose = text.lastIndexOf("</")
        if (anyClose >= 0) {
            if (spanEnd < 0) {
                val gt = text.indexOf('>', anyClose)
                spanEnd = if (gt >= 0) gt + 1 else text.length
            } else if (anyClose in spanEnd until spanEnd + 80) {
                val gt = text.indexOf('>', anyClose)
                if (gt >= 0) spanEnd = gt + 1
            }
        }
        if (spanEnd < 0) spanEnd = text.length

        val calls = mutableListOf<Pair<String, String>>()
        val unknown = mutableListOf<String>()
        opens.forEachIndexed { idx, m ->
            val bodyStart = m.range.last + 1
            val bodyEnd = opens.getOrNull(idx + 1)?.range?.first ?: spanEnd
            if (bodyEnd <= bodyStart) return@forEachIndexed
            val name = NAME_ATTR.find(m.value)?.groupValues?.get(1) ?: return@forEachIndexed
            val body = text.substring(bodyStart, bodyEnd.coerceAtMost(text.length))
            val args = StringBuilder("{")
            var first = true
            for (pm in PARAM_OPEN.findAll(body)) {
                val key = pm.groupValues[2]
                val vStart = pm.range.last + 1
                val close = body.indexOf("</param", vStart, ignoreCase = true)
                if (close < 0) continue
                val value = unescapeXml(body.substring(vStart, close).trim())
                if (!first) args.append(",")
                first = false
                args.append(JsonPrimitive(key)).append(':').append(JsonPrimitive(value))
            }
            args.append("}")
            if (name in known) {
                if (calls.size < maxCalls) calls += name to args.toString()
            } else {
                unknown += name
            }
        }
        // span START: cover the <function_calls> wrapper too when present
        val wrapperStart = text.indexOf("<function_calls", ignoreCase = true)
        val spanStart = if (wrapperStart in 0..opens.first().range.first) wrapperStart else opens.first().range.first
        val span = IntRange(spanStart, (spanEnd - 1).coerceAtMost(text.length - 1))
        return Salvage(calls, unknown.distinct(), hadMarkup = true, xmlSpan = span)
    }

    private fun unescapeXml(s: String): String = s
        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&#39;", "'").replace("&amp;", "&")
}
