package com.liman.agent.agent

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec

/**
 * Liman's on-device APK factory.
 *
 * Assembles a real, installable, v1+v2-signed Android APK without any build
 * tools on the phone:
 *
 *  1. Binary AXML AndroidManifest.xml generated from scratch (label,
 *     package, permissions, launcher activity) — no aapt2 needed.
 *  2. A pre-compiled WebView shell classes.dex (embedded asset) that loads
 *     assets/app/index.html — the agent writes the app as HTML/CSS/JS.
 *  3. JAR (v1) + APK Signature Scheme v2 signing implemented from the public
 *     specs with the embedded Liman builder key (debug-key equivalent).
 *  4. A deterministic non-streamed zip: real sizes/CRC in every local header
 *     (NO data descriptors) and 4-byte aligned entry data — streamed zips
 *     are rejected by Android package parsers as "problem parsing the
 *     package" (seen on an Android 10 OEM ROM).
 *
 * Pure JVM code — verified in unit tests with aapt2/apksigner.
 */
object ApkBuilder {

    // ---------------- public API ----------------

    /**
     * @param appLabel   human-visible app name
     * @param files      relative path → bytes; must contain index.html
     *                   (goes into assets/app/)
     * @return signed APK bytes
     */
    fun build(
        appLabel: String,
        packageName: String,
        files: Map<String, ByteArray>,
        classesDex: ByteArray,
        keyPkcs8Der: ByteArray,
        certDer: ByteArray
    ): ByteArray {
        require(files.keys.any { it.endsWith("index.html") }) {
            "no index.html in app files"
        }
        val manifest = AxmlGenerator.manifest(
            packageName = packageName,
            appLabel = appLabel.takeIf { it.isNotBlank() } ?: "Liman App",
            versionName = "1.0"
        )
        val entries = LinkedHashMap<String, ByteArray>()
        entries["AndroidManifest.xml"] = manifest
        entries["classes.dex"] = classesDex
        files.forEach { (path, bytes) ->
            entries["assets/app/${path.removePrefix("/")}"] = bytes
        }
        // v1 (JAR) signing first: digests cover every non-META-INF entry, then the
        // three META-INF files join the zip before the v2 block is computed over
        // the final contents — exactly how apksigner signs with both schemes.
        V1Signer.metaInfEntries(entries, keyPkcs8Der, certDer).forEach { (name, bytes) ->
            entries[name] = bytes
        }
        val zip = ZipKit.zip(entries)
        return V2Signer.sign(zip, keyPkcs8Der, certDer)
    }

    fun packageNameFor(appName: String): String {
        val clean = appName.lowercase()
            .map { c -> if (c.isLetterOrDigit() && c.code < 128) c else '_' }
            .joinToString("")
            .trim('_')
            .ifBlank { "app" }
        val prefix = if (clean.first().isDigit()) "g" else ""
        val hash = Integer.toHexString(appName.hashCode()).let { if (it.startsWith("-")) it.drop(1) else it }
        return "com.liman.app.$prefix$clean.$hash".take(80)
    }
}

// ============================================================
// Binary AndroidManifest.xml (AXML) generator
// ============================================================

internal object AxmlGenerator {

    private const val ANDROID_NS = "http://schemas.android.com/apk/res/android"
    private const val NS_PREFIX = "android"

    // framework attribute resource IDs (verified against android.R.attr)
    private const val ATTR_LABEL = 0x01010001
    private const val ATTR_NAME = 0x01010003
    private const val ATTR_EXPORTED = 0x01010010
    private const val ATTR_MIN_SDK = 0x0101020c
    private const val ATTR_VERSION_CODE = 0x0101021b
    private const val ATTR_VERSION_NAME = 0x0101021c
    private const val ATTR_TARGET_SDK = 0x01010270

    // value types
    private const val TYPE_STRING = 0x03
    private const val TYPE_INT = 0x10
    private const val TYPE_BOOLEAN = 0x12
    private const val NO_INDEX = -1 // 0xFFFFFFFF

    private class Attr(
        val nsUri: String?,          // null = no namespace
        val name: String,
        val rawValue: String?,       // string value (if STRING)
        val type: Int,
        val data: Int
    )

    private class Node(
        val name: String,
        val attrs: List<Attr>,
        val children: List<Node> = emptyList()
    )

    private class Pool {
        val strings = ArrayList<String>()
        private val index = HashMap<String, Int>()

        fun intern(s: String): Int {
            val existing = index[s]
            if (existing != null) return existing
            strings.add(s)
            index[s] = strings.size - 1
            return strings.size - 1
        }

        fun idx(s: String?): Int = if (s == null) NO_INDEX else intern(s)
    }

    fun manifest(packageName: String, appLabel: String, versionName: String): ByteArray {
        val pool = Pool()

        // IMPORTANT: framework attr-name strings are interned FIRST so the
        // resource-map chunk covers indices 0..nAttrNames-1 with no zero
        // entries (mirrors aapt2 output; apksigner's parser is picky here).
        val attrNames = listOf(
            "versionCode", "versionName", "minSdkVersion", "targetSdkVersion",
            "name", "label", "exported"
        )
        attrNames.forEach { pool.intern(it) }
        pool.intern(NS_PREFIX)
        pool.intern(ANDROID_NS)

        fun stringAttr(name: String, value: String) = Attr(ANDROID_NS, name, value, TYPE_STRING, 0)

        val tree = Node(
            "manifest",
            listOf(
                Attr(null, "package", packageName, TYPE_STRING, 0),
                Attr(ANDROID_NS, "versionCode", null, TYPE_INT, 1),
                stringAttr("versionName", versionName)
            ),
            listOf(
                Node(
                    "uses-sdk",
                    listOf(
                        Attr(ANDROID_NS, "minSdkVersion", null, TYPE_INT, 24),
                        Attr(ANDROID_NS, "targetSdkVersion", null, TYPE_INT, 34)
                    )
                ),
                Node(
                    "uses-permission",
                    listOf(stringAttr("name", "android.permission.INTERNET"))
                ),
                Node(
                    "application",
                    listOf(stringAttr("label", appLabel)),
                    listOf(
                        Node(
                            "activity",
                            listOf(
                                stringAttr("name", "com.liman.shell.MainActivity"),
                                Attr(ANDROID_NS, "exported", null, TYPE_BOOLEAN, -1)
                            ),
                            listOf(
                                Node(
                                    "intent-filter",
                                    emptyList(),
                                    listOf(
                                        Node("action", listOf(stringAttr("name", "android.intent.action.MAIN"))),
                                        Node("category", listOf(stringAttr("name", "android.intent.category.LAUNCHER")))
                                    )
                                )
                            )
                        )
                    )
                )
            )
        )

        // intern all remaining strings (attr names, tag names, values, uri, prefix)
        fun internNode(n: Node) {
            pool.intern(n.name)
            n.attrs.forEach { a ->
                pool.intern(a.name)
                if (a.nsUri != null) pool.intern(a.nsUri)
                a.rawValue?.let { pool.intern(it) }
            }
            n.children.forEach { internNode(it) }
        }
        internNode(tree)

        // string-data bytes + offsets (UTF-16LE pool, like aapt2 — apksigner's
        // built-in XML parser fails to read UTF-8 pools)
        val encoded = ArrayList<ByteArray>()
        val offsets = IntArray(pool.strings.size)
        var dataLen = 0
        pool.strings.forEachIndexed { i, s ->
            offsets[i] = dataLen
            val e = encodeUtf16PoolString(s)
            encoded.add(e)
            dataLen += e.size
        }
        val stringPadding = (4 - (dataLen % 4)) % 4
        val stringsStart = 28 + 4 * pool.strings.size
        val poolSize = stringsStart + dataLen + stringPadding

        val poolBytes = ByteArrayOutputStream(poolSize).apply {
            u16(0x0001)                  // RES_STRING_POOL_TYPE
            u16(28)                      // headerSize
            u32(poolSize)
            u32(pool.strings.size)
            u32(0)                       // styleCount
            u32(0)                       // flags: UTF-16
            u32(stringsStart)
            u32(0)                       // stylesStart
            offsets.forEach { u32(it) }
            encoded.forEach { write(it) }
            repeat(stringPadding) { write(0) }
        }.toByteArray()

        // resource map: string index → framework attr id (covers the 7
        // framework attr names interned at indices 0..6 — no zero entries)
        val attrIds = intArrayOf(
            ATTR_VERSION_CODE, ATTR_VERSION_NAME, ATTR_MIN_SDK, ATTR_TARGET_SDK,
            ATTR_NAME, ATTR_LABEL, ATTR_EXPORTED
        )
        val resMap = ByteArrayOutputStream(8 + 4 * attrIds.size).apply {
            u16(0x0180)                  // RES_XML_RESOURCE_MAP
            u16(8)
            u32(8 + 4 * attrIds.size)
            attrIds.forEach { u32(it) }
        }.toByteArray()

        // body chunks
        val body = ByteArrayOutputStream()
        val nsPrefixIdx = pool.idx(NS_PREFIX)
        val nsUriIdx = pool.idx(ANDROID_NS)
        writeNamespace(body, 0x0100, 1, nsPrefixIdx, nsUriIdx)
        var line = 2
        fun writeNode(out: ByteArrayOutputStream, n: Node) {
            val nameIdx = pool.idx(n.name)
            val attrOut = ByteArrayOutputStream()
            n.attrs.forEach { a ->
                val nsIdx = pool.idx(a.nsUri)
                val rawIdx = pool.idx(a.rawValue)
                val dataIdx = if (a.type == TYPE_STRING) rawIdx else a.data
                attrOut.u32(nsIdx)
                attrOut.u32(pool.idx(a.name))
                attrOut.u32(rawIdx)
                attrOut.u16(8)           // typedValue size
                attrOut.u8(0)            // res0
                attrOut.u8(a.type)
                attrOut.u32(dataIdx)
            }
            val attrCount = n.attrs.size
            out.u16(0x0102)              // RES_XML_START_ELEMENT
            out.u16(16)
            out.u32(36 + 20 * attrCount)
            out.u32(line++)
            out.u32(NO_INDEX)            // comment
            out.u32(NO_INDEX)            // element namespace: none (aapt2-style;
                                         // apksigner requires empty ns on uses-sdk)
            out.u32(nameIdx)
            out.u16(20)                  // attributeStart
            out.u16(20)                  // attributeSize
            out.u16(attrCount)
            out.u16(0)                   // idIndex
            out.u16(0)                   // classIndex
            out.u16(0)                   // styleIndex
            out.write(attrOut.toByteArray())
            n.children.forEach { writeNode(out, it) }
            out.u16(0x0103)              // RES_XML_END_ELEMENT
            out.u16(16)
            out.u32(24)
            out.u32(line++)
            out.u32(NO_INDEX)
            out.u32(NO_INDEX)            // element namespace: none
            out.u32(nameIdx)
        }
        writeNode(body, tree)
        writeNamespace(body, 0x0101, line++, nsPrefixIdx, nsUriIdx)

        val totalSize = 8 + poolBytes.size + resMap.size + body.size()
        return ByteArrayOutputStream(totalSize).apply {
            u16(0x0003)                  // RES_XML_TYPE (file header)
            u16(8)
            u32(totalSize)
            write(poolBytes)
            write(resMap)
            write(body.toByteArray())
        }.toByteArray()
    }

    private fun writeNamespace(out: ByteArrayOutputStream, type: Int, line: Int, prefixIdx: Int, uriIdx: Int) {
        out.u16(type)
        out.u16(16)
        out.u32(24)
        out.u32(line)
        out.u32(NO_INDEX)                // comment
        out.u32(prefixIdx)
        out.u32(uriIdx)
    }

    /** UTF-16 string-pool entry: u16 len(utf16 units), utf16le bytes, u16 0. */
    private fun encodeUtf16PoolString(s: String): ByteArray {
        val units = s.length
        require(units < 0x8000) { "string too long for pool: $s" }
        val out = ByteArrayOutputStream(units * 2 + 4)
        out.u16(units)
        for (i in 0 until units) {
            out.u16(s[i].code)
        }
        out.u16(0)
        return out.toByteArray()
    }

    private fun ByteArrayOutputStream.u16(v: Int) {
        write(v and 0xFF)
        write((v shr 8) and 0xFF)
    }

    private fun ByteArrayOutputStream.u32(v: Int) {
        write(v and 0xFF)
        write((v shr 8) and 0xFF)
        write((v shr 16) and 0xFF)
        write((v shr 24) and 0xFF)
    }

    private fun ByteArrayOutputStream.u8(v: Int) {
        write(v and 0xFF)
    }
}

// ============================================================
// ZIP assembly
// ============================================================

internal object ZipKit {

    private const val LOCAL_MAGIC = 0x04034b50
    private const val CENTRAL_MAGIC = 0x02014b50
    private const val EOCD_MAGIC = 0x06054b50
    private const val FLAG_UTF8 = 0x0800
    // FLAG_DATA_DESCRIPTOR (0x0008) is NEVER set — streamed zips are rejected by
    // Android package parsers / OEM installers ("problem parsing the package").

    /**
     * Deterministic, non-streamed zip. Every local header carries the REAL
     * crc / compressed size / uncompressed size; entry data is 4-byte aligned
     * via extra-field padding (what zipalign does).
     */
    fun zip(entries: Map<String, ByteArray>, stored: Set<String> = emptySet()): ByteArray {
        class E(val name: ByteArray, val method: Int, val crc: Long, val cdata: ByteArray, val usize: Int)

        val deflater = java.util.zip.Deflater(java.util.zip.Deflater.DEFAULT_COMPRESSION, true)
        val prepared = ArrayList<E>(entries.size)
        for ((name, data) in entries) {
            val n = name.toByteArray(Charsets.UTF_8)
            val crc = java.util.zip.CRC32().apply { update(data) }.value
            if (name in stored) {
                prepared.add(E(n, 0, crc, data, data.size))
            } else {
                deflater.reset()
                deflater.setInput(data)
                deflater.finish()
                val buf = ByteArrayOutputStream(data.size / 2 + 16)
                val tmp = ByteArray(64 * 1024)
                while (!deflater.finished()) {
                    val r = deflater.deflate(tmp)
                    if (r > 0) buf.write(tmp, 0, r)
                }
                prepared.add(E(n, 8, crc, buf.toByteArray(), data.size))
            }
        }

        val out = ByteArrayOutputStream(64 * 1024)
        val central = ByteArrayOutputStream(16 * 1024)
        val offsets = IntArray(prepared.size)

        prepared.forEachIndexed { idx, e ->
            offsets[idx] = out.size()
            // pad so entry DATA starts at a 4-byte boundary (zipalign semantics)
            val extra = (4 - ((out.size() + 30 + e.name.size) % 4)) % 4

            // ---- local file header (all values REAL — no data descriptor) ----
            out.u32le(LOCAL_MAGIC)
            out.u16le(20)                    // version needed
            out.u16le(FLAG_UTF8)             // flags: UTF-8 only
            out.u16le(e.method)
            out.u16le(0)                     // dos time
            out.u16le(0x21)                  // dos date 1980-01-01
            out.u32le(e.crc.toInt())
            out.u32le(e.cdata.size)
            out.u32le(e.usize)
            out.u16le(e.name.size)
            out.u16le(extra)
            out.write(e.name)
            repeat(extra) { out.write(0) }
            out.write(e.cdata)

            // ---- central directory record (mirrors the local header) ----
            central.u32le(CENTRAL_MAGIC)
            central.u16le(20)                // version made by
            central.u16le(20)                // version needed
            central.u16le(FLAG_UTF8)
            central.u16le(e.method)
            central.u16le(0)
            central.u16le(0x21)
            central.u32le(e.crc.toInt())
            central.u32le(e.cdata.size)
            central.u32le(e.usize)
            central.u16le(e.name.size)
            central.u16le(extra)
            central.u16le(0)                 // comment len
            central.u16le(0)                 // disk number
            central.u16le(0)                 // internal attrs
            central.u32le(0)                 // external attrs
            central.u32le(offsets[idx])
            central.write(e.name)
            repeat(extra) { central.write(0) }
        }

        val cdOffset = out.size()
        out.write(central.toByteArray())
        out.u32le(EOCD_MAGIC)
        out.u16le(0)
        out.u16le(0)
        out.u16le(prepared.size)
        out.u16le(prepared.size)
        out.u32le(central.size())
        out.u32le(cdOffset)
        out.u16le(0)                         // comment len
        return out.toByteArray()
    }

    private fun ByteArrayOutputStream.u16le(v: Int) {
        write(v and 0xFF); write((v shr 8) and 0xFF)
    }

    private fun ByteArrayOutputStream.u32le(v: Int) {
        write(v and 0xFF); write((v shr 8) and 0xFF)
        write((v shr 16) and 0xFF); write((v shr 24) and 0xFF)
    }
}

// ============================================================
// APK Signature Scheme v1 (JAR signing) — OEM-ROM insurance
// ============================================================

/**
 * JAR (v1) signing: MANIFEST.MF + CERT.SF + CERT.RSA (hand-built PKCS#7).
 *
 * v2 alone is fine on stock Android 7.0+, but some OEM installer ROMs
 * pre-check for META-INF signatures and report "There was a problem parsing
 * the package" without them. Both schemes together install everywhere.
 *
 * Pure Kotlin / no BouncyCastle (unavailable on-device): minimal DER encoder
 * + an X.509 walker for the SignerInfo issuer Name and serial. Verified by
 * ApkBuilderTest with apksigner (must report v1 AND v2 true).
 */
internal object V1Signer {

    fun metaInfEntries(
        apkEntries: Map<String, ByteArray>,
        keyPkcs8Der: ByteArray,
        certDer: ByteArray
    ): List<Pair<String, ByteArray>> {
        val sha: (ByteArray) -> ByteArray = { b -> MessageDigest.getInstance("SHA-256").digest(b) }

        // 1. MANIFEST.MF — one SHA-256 section per entry
        val mainSection = Jar.fold(
            "Manifest-Version: 1.0\r\nCreated-By: 1.0 (Liman on-device builder)\r\n\r\n"
        )
        val mf = ByteArrayOutputStream()
        mf.write(mainSection)
        val sections = LinkedHashMap<String, ByteArray>()
        for ((name, data) in apkEntries) {
            val s = Jar.fold("Name: $name\r\nSHA-256-Digest: ${Jar.b64(sha(data))}\r\n\r\n")
            sections[name] = s
            mf.write(s)
        }
        val mfBytes = mf.toByteArray()

        // 2. CERT.SF — whole-manifest + main-attributes digests (attr names exactly
        //    as apksigner's V1 verifier looks them up: <alg>-Digest-Manifest and
        //    <alg>-Digest-Manifest-Main-Attributes) + per-entry section digests
        val sf = ByteArrayOutputStream()
        sf.write(Jar.fold(
            "Signature-Version: 1.0\r\n" +
                "Created-By: 1.0 (Liman on-device builder)\r\n" +
                "SHA-256-Digest-Manifest: ${Jar.b64(sha(mfBytes))}\r\n" +
                "SHA-256-Digest-Manifest-Main-Attributes: ${Jar.b64(sha(mainSection))}\r\n\r\n"
        ))
        for ((name, _) in apkEntries) {
            sf.write(Jar.fold("Name: $name\r\nSHA-256-Digest: ${Jar.b64(sha(sections.getValue(name)))}\r\n\r\n"))
        }
        val sfBytes = sf.toByteArray()

        // 3. CERT.RSA — detached PKCS#7 SignedData over CERT.SF
        val rsa = pkcs7(sfBytes, keyPkcs8Der, certDer)

        return listOf(
            "META-INF/MANIFEST.MF" to mfBytes,
            "META-INF/CERT.SF" to sfBytes,
            "META-INF/CERT.RSA" to rsa
        )
    }

    private fun pkcs7(content: ByteArray, keyDer: ByteArray, certDer: ByteArray): ByteArray {
        val key = KeyFactory.getInstance("RSA")
            .generatePrivate(PKCS8EncodedKeySpec(keyDer))
        val signature = Signature.getInstance("SHA256withRSA").apply {
            initSign(key); update(content)
        }.sign()

        val (issuerTlv, serial) = X509.issuerAndSerial(certDer)

        val signerInfo = Der.seq(
            Der.intVal(1),
            Der.seq(issuerTlv, Der.raw(Der.intBytes(serial))),   // issuerAndSerialNumber
            Der.seq(Der.oid("2.16.840.1.101.3.4.2.1"), Der.nullValue()), // sha-256
            Der.seq(Der.oid("1.2.840.113549.1.1.1"), Der.nullValue()),  // rsaEncryption
            Der.octet(signature)
        )
        val signedData = Der.seq(
            Der.intVal(1),                                        // version
            Der.set(Der.seq(Der.oid("2.16.840.1.101.3.4.2.1"), Der.nullValue())), // digestAlgorithms
            Der.seq(Der.oid("1.2.840.113549.1.7.1")),             // contentInfo: data (detached)
            Der.context(0, certDer),                              // [0] certificates
            Der.set(signerInfo)                                   // signerInfos
        )
        return Der.seq(
            Der.oid("1.2.840.113549.1.7.2"),                      // contentType = signedData
            Der.context(0, signedData)                            // [0] explicit
        )
    }

    /** JAR manifest helpers: base64 + 72-byte line folding. */
    internal object Jar {
        fun b64(bytes: ByteArray): String {
            val table = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
            val sb = StringBuilder(((bytes.size + 2) / 3) * 4)
            var i = 0
            while (i < bytes.size) {
                val b0 = bytes[i].toInt() and 0xFF
                val b1 = if (i + 1 < bytes.size) bytes[i + 1].toInt() and 0xFF else 0
                val b2 = if (i + 2 < bytes.size) bytes[i + 2].toInt() and 0xFF else 0
                sb.append(table[b0 shr 2])
                sb.append(table[(b0 and 0x3) shl 4 or (b1 shr 4)])
                sb.append(if (i + 1 < bytes.size) table[(b1 and 0xF) shl 2 or (b2 shr 6)] else '=')
                sb.append(if (i + 2 < bytes.size) table[b2 and 0x3F] else '=')
                i += 3
            }
            return sb.toString()
        }

        /**
         * JAR spec: no line longer than 72 bytes; continuations start with one
         * space. Folding applies per LOGICAL line — wrapping the raw byte
         * stream mid-line corrupts the attribute grammar and makes jarsigner
         * / apksigner treat the file as unparsable.
         */
        fun fold(raw: String): ByteArray {
            val bytes = raw.toByteArray(Charsets.UTF_8)
            val out = ByteArrayOutputStream(bytes.size + 16)
            var pos = 0
            while (pos < bytes.size) {
                // find the end of this logical line
                var eol = pos
                while (eol < bytes.size &&
                    bytes[eol] != '\r'.code.toByte() && bytes[eol] != '\n'.code.toByte()
                ) eol++
                // emit the line, folded if longer than 72 bytes
                var i = pos
                var first = true
                while (i < eol) {
                    val take = if (first) 72 else 71   // continuation: space + 71
                    val end = minOf(i + take, eol)
                    if (!first) out.write(' '.code)
                    out.write(bytes, i, end - i)
                    i = end
                    first = false
                    if (i < eol) {
                        out.write('\r'.code); out.write('\n'.code)
                    }
                }
                // emit the line's own terminator
                if (eol < bytes.size) {
                    out.write(bytes[eol].toInt())
                    pos = eol + 1
                    if (bytes[eol] == '\r'.code.toByte() &&
                        pos < bytes.size && bytes[pos] == '\n'.code.toByte()
                    ) {
                        out.write(bytes[pos].toInt())
                        pos++
                    }
                } else {
                    pos = eol
                }
            }
            return out.toByteArray()
        }
    }

    /** X.509 DER walker: Certificate → TBS → (serial, issuer Name). */
    internal object X509 {
        fun issuerAndSerial(certDer: ByteArray): Pair<ByteArray, ByteArray> {
            val cert = Der.parseOne(certDer)
            require(cert.tag == 0x30) { "cert not a SEQUENCE" }
            val tbs = cert.childAt(0)
            require(tbs.tag == 0x30) { "tbsCertificate not a SEQUENCE" }
            var i = 0
            var c = tbs.childAt(i)
            if (c.tag == 0xA0) c = tbs.childAt(++i)   // optional [0] version
            require(c.tag == 0x02) { "serialNumber not found" }
            val serial = c.value
            val issuer = tbs.childAt(i + 2)           // skip signature AlgorithmIdentifier
            require(issuer.tag == 0x30) { "issuer Name not found" }
            return Pair(issuer.full, serial)
        }
    }

    // ---------------- minimal DER encoder ----------------

    internal object Der {
        class Node(val tag: Int, val full: ByteArray, val value: ByteArray) {
            fun childAt(index: Int): Node {
                var off = 0
                var seen = -1
                while (off < value.size) {
                    val n = parseOne(value, off)
                    seen++
                    if (seen == index) return n
                    off += n.full.size
                }
                throw IllegalArgumentException("DER child $index out of range")
            }
        }

        fun parseOne(bytes: ByteArray, start: Int = 0): Node {
            val tag = bytes[start].toInt() and 0xFF
            var p = start + 1
            var first = bytes[p].toInt() and 0xFF
            var len: Int
            if (first and 0x80 == 0) {
                len = first
                p += 1
            } else {
                val n = first and 0x7F
                len = 0
                for (k in 1..n) len = (len shl 8) or (bytes[p + k].toInt() and 0xFF)
                p += 1 + n
            }
            return Node(tag, bytes.copyOfRange(start, p + len), bytes.copyOfRange(p, p + len))
        }

        fun tlv(tag: Int, payload: ByteArray): ByteArray {
            val out = ByteArrayOutputStream(payload.size + 6)
            out.write(tag)
            var len = payload.size
            if (len < 0x80) {
                out.write(len)
            } else {
                val lb = ByteArray(4)
                var n = 0
                while (len > 0) { lb[n++] = (len and 0xFF).toByte(); len = len shr 8 }
                out.write(0x80 or n)
                for (k in n - 1 downTo 0) out.write(lb[k].toInt())
            }
            out.write(payload)
            return out.toByteArray()
        }

        fun raw(bytes: ByteArray): ByteArray = bytes
        fun seq(vararg parts: ByteArray): ByteArray = tlv(0x30, join(*parts))
        fun set(vararg parts: ByteArray): ByteArray = tlv(0x31, join(*parts))
        fun context(n: Int, payload: ByteArray): ByteArray = tlv(0xA0 or n, payload)
        fun octet(bytes: ByteArray): ByteArray = tlv(0x04, bytes)
        fun nullValue(): ByteArray = byteArrayOf(0x05, 0x00)

        fun intVal(v: Int): ByteArray =
            intBytes(byteArrayOf((v shr 24).toByte(), (v shr 16).toByte(), (v shr 8).toByte(), v.toByte()))

        fun intBytes(raw4: ByteArray): ByteArray {
            var i = 0
            while (i < raw4.size - 1 && raw4[i].toInt() == 0) i++
            var b = raw4.copyOfRange(i, raw4.size)
            if (b.isNotEmpty() && (b[0].toInt() and 0x80) != 0) b = byteArrayOf(0) + b
            return tlv(0x02, b)
        }

        fun oid(dot: String): ByteArray {
            val parts = dot.split(".").map { it.toLong() }
            val body = ByteArrayOutputStream()
            body.write((parts[0] * 40 + parts[1]).toInt())
            for (i in 2 until parts.size) {
                var v = parts[i]
                val stack = ArrayList<Int>()
                stack.add((v and 0x7F).toInt())
                v = v shr 7
                while (v > 0) { stack.add(((v and 0x7F) or 0x80L).toInt()); v = v shr 7 }
                for (k in stack.indices.reversed()) body.write(stack[k])
            }
            return tlv(0x06, body.toByteArray())
        }

        fun join(vararg parts: ByteArray): ByteArray {
            val out = ByteArrayOutputStream(parts.sumOf { it.size })
            parts.forEach { out.write(it) }
            return out.toByteArray()
        }
    }
}

// ============================================================
// APK Signature Scheme v2 (pure implementation of the public spec)
// ============================================================

internal object V2Signer {

    private const val BLOCK_MAGIC = "APK Sig Block 42"
    private const val V2_BLOCK_ID = 0x7109871a
    private const val RSA_PKCS1_SHA256 = 0x0103
    private const val CHUNK = 1_048_576

    fun sign(zip: ByteArray, keyPkcs8Der: ByteArray, certDer: ByteArray): ByteArray {
        val eocdOff = findEocd(zip) ?: error("EOCD not found")
        val cdOffset = readU32(zip, eocdOff + 16)
        val cdSize = readU32(zip, eocdOff + 12)
        require(cdOffset + cdSize <= eocdOff) { "bad zip structure" }

        val beforeBlock = zip.copyOfRange(0, cdOffset)
        val centralDir = zip.copyOfRange(cdOffset, cdOffset + cdSize)
        val eocd = zip.copyOfRange(eocdOff, zip.size)

        // digest: entries + central directory + EOCD with the CD-offset
        // field replaced by the signing-block offset. The three segments are
        // chunked INDEPENDENTLY (1MB chunks per segment, empty segments
        // contribute nothing), each chunk hashed as (0xa5, u32 len, data),
        // then final = SHA256(0x5a, u32 chunkCount, concat(chunk digests))
        // — byte-for-byte the apksig CHUNKED_SHA256 topology.
        val eocdForDigest = eocd.copyOf()
        writeU32(eocdForDigest, 16, beforeBlock.size)
        val digest = chunkedSha256(beforeBlock, centralDir, eocdForDigest)

        val privateKey = KeyFactory.getInstance("RSA")
            .generatePrivate(PKCS8EncodedKeySpec(keyPkcs8Der))
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(ByteArrayInputStream(certDer))
        val publicKey = cert.publicKey.encoded

        // ---- v2 signer structure (all length-prefixed = uint32 LE) ----
        val digestEntry = ByteArrayOutputStream().apply {
            u32(RSA_PKCS1_SHA256)
            lpInto(this, digest)
        }.toByteArray()
        val digests = lpSeq(digestEntry) // sequence of one entry

        val certificates = lpSeq(certDer)

        // signed data content = digests field + certificates field + additional
        // attributes field (may be EMPTY but its length prefix must exist —
        // apksig's parseSigner reads all three unconditionally; verified
        // against the reference implementation source)
        val signedData = ByteArrayOutputStream().apply {
            write(digests)
            write(certificates)
            u32(0)                     // empty additional-attributes sequence
        }.toByteArray()

        val signature = Signature.getInstance("SHA256withRSA").apply {
            initSign(privateKey)
            update(signedData)
        }.sign()
        val sigEntry = ByteArrayOutputStream().apply {
            u32(RSA_PKCS1_SHA256)
            lpInto(this, signature)
        }.toByteArray()
        val signatures = lpSeq(sigEntry)

        val signer = ByteArrayOutputStream().apply {
            lpInto(this, signedData)
            write(signatures)   // already a self-prefixed sequence (lpSeq)
            lpInto(this, publicKey)
        }.toByteArray()
        val v2Value = lpSeq(signer)

        val pair = ByteArrayOutputStream().apply {
            u64(4L + v2Value.size)
            u32(V2_BLOCK_ID)
            write(v2Value)
        }.toByteArray()

        // size field = pairs + second size field (8) + magic (16) — it excludes
        // only the leading size field itself (verified byte-for-byte against
        // an apksigner-generated reference block)
        val blockSize = pair.size + 24
        val block = ByteArrayOutputStream(blockSize + 8).apply {
            u64(blockSize.toLong())
            write(pair)
            u64(blockSize.toLong())
            write(BLOCK_MAGIC.toByteArray(Charsets.US_ASCII))
        }.toByteArray()

        // final APK: entries + signing block + central directory + EOCD
        // (EOCD's CD offset now points past the signing block)
        val newEocd = eocd.copyOf()
        writeU32(newEocd, 16, beforeBlock.size + block.size)
        val out = ByteArrayOutputStream(zip.size + block.size)
        out.write(beforeBlock)
        out.write(block)
        out.write(centralDir)
        out.write(newEocd)
        return out.toByteArray()
    }

    /**
     * v2 CHUNKED_SHA256: segments are chunked independently (1 MB each, empty
     * segments skipped); each chunk digest = SHA256(0xa5 ‖ u32 len ‖ chunk);
     * final = SHA256(0x5a ‖ u32 chunkCount ‖ concat of all chunk digests).
     */
    private fun chunkedSha256(vararg segments: ByteArray): ByteArray {
        val chunkDigests = ArrayList<ByteArray>()
        for (seg in segments) {
            var i = 0
            while (i < seg.size) {
                val len = minOf(CHUNK, seg.size - i)
                val md = MessageDigest.getInstance("SHA-256")
                md.update(0xA5.toByte())
                md.update(
                    byteArrayOf(
                        (len and 0xFF).toByte(),
                        ((len shr 8) and 0xFF).toByte(),
                        ((len shr 16) and 0xFF).toByte(),
                        ((len shr 24) and 0xFF).toByte()
                    )
                )
                md.update(seg, i, len)
                chunkDigests.add(md.digest())
                i += len
            }
        }
        val md = MessageDigest.getInstance("SHA-256")
        md.update(0x5A.toByte())
        md.update(
            byteArrayOf(
                (chunkDigests.size and 0xFF).toByte(),
                ((chunkDigests.size shr 8) and 0xFF).toByte(),
                ((chunkDigests.size shr 16) and 0xFF).toByte(),
                ((chunkDigests.size shr 24) and 0xFF).toByte()
            )
        )
        chunkDigests.forEach { md.update(it) }
        return md.digest()
    }

    private fun lpSeq(vararg entries: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream()
        entries.forEach { lpInto(bos, it) }
        return lp(bos.toByteArray())
    }

    private fun lp(payload: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(payload.size + 4)
        lpInto(out, payload)
        return out.toByteArray()
    }

    private fun lpInto(out: ByteArrayOutputStream, payload: ByteArray) {
        out.u32(payload.size)
        out.write(payload)
    }

    private fun findEocd(zip: ByteArray): Int? {
        val minOff = (zip.size - 65_557).coerceAtLeast(0)
        var i = zip.size - 22
        while (i >= minOff) {
            if (zip[i].toInt() == 0x50 && zip[i + 1].toInt() == 0x4B && zip[i + 2].toInt() == 0x05 && zip[i + 3].toInt() == 0x06) {
                return i
            }
            i--
        }
        return null
    }

    private fun readU32(b: ByteArray, off: Int): Int =
        (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8) or
            ((b[off + 2].toInt() and 0xFF) shl 16) or ((b[off + 3].toInt() and 0xFF) shl 24)

    private fun writeU32(b: ByteArray, off: Int, v: Int) {
        b[off] = (v and 0xFF).toByte()
        b[off + 1] = ((v shr 8) and 0xFF).toByte()
        b[off + 2] = ((v shr 16) and 0xFF).toByte()
        b[off + 3] = ((v shr 24) and 0xFF).toByte()
    }

    private fun ByteArrayOutputStream.u32(v: Int) {
        write(v and 0xFF)
        write((v shr 8) and 0xFF)
        write((v shr 16) and 0xFF)
        write((v shr 24) and 0xFF)
    }

    private fun ByteArrayOutputStream.u64(v: Long) {
        u32((v and 0xFFFFFFFFL).toInt())
        u32(((v ushr 32) and 0xFFFFFFFFL).toInt())
    }
}
