package com.liman.agent.agent

/**
 * v2.23.0 — NOTIFICATION DIGEST: 60 buzzes → 3 calm, ranked digests.
 *
 * The accessibility service already logs "NOTIF <app> · <text>" lines into
 * demo session logs. The digest collects them since the last digest,
 * groups by app, flags urgent (user's regex rules) and hands the agent a
 * compact markdown digest to deliver at the configured windows.
 * (Honest limit: Android accessibility cannot SUPPRESS other apps'
 * notifications — the digest is additive organization, not blocking.)
 */
object Digest {

    data class NotifLine(val app: String, val text: String) {
        val full: String get() = if (text.isBlank()) app else "$app · $text"
    }

    /** Parse "NOTIF app · text" lines (any prefix/suffix whitespace tolerated). */
    fun parse(lines: List<String>): List<NotifLine> =
        lines.filter { it.isNotBlank() }
            .mapNotNull { l ->
                val l0 = l.trim()
                if (!l0.startsWith("NOTIF")) return@mapNotNull null
                val body = l0.removePrefix("NOTIF").trim()
                if (body.isBlank()) return@mapNotNull null
                val parts = body.split("·", limit = 2)
                if (parts.size == 2) NotifLine(parts[0].trim(), parts[1].trim())
                else NotifLine(parts[0].trim(), "")
            }

    fun groupByApp(lines: List<NotifLine>): Map<String, List<NotifLine>> =
        lines.groupBy { it.app }

    /** Urgent = matches any pattern (regex, case-insensitive) on "app · text". */
    fun urgent(lines: List<NotifLine>, patterns: List<String>): List<NotifLine> {
        val regexes = patterns.mapNotNull { p ->
            runCatching { Regex(p, RegexOption.IGNORE_CASE) }.getOrNull()
        }
        if (regexes.isEmpty()) return emptyList()
        return lines.filter { l -> regexes.any { it.containsMatchIn(l.full) } }
    }

    /**
     * Is a digest window due? A window is due when the current time has
     * passed it today AND the last digest was before that window moment.
     */
    fun windowDue(windows: List<String>, lastDigestAt: Long, nowMs: Long, nowHm: Pair<Int, Int>): Boolean {
        val (h, m) = nowHm
        val nowMinutes = h * 60 + m
        return windows.any { w ->
            val parts = w.split(":")
            val wm = (parts.getOrNull(0)?.toIntOrNull() ?: -1) * 60 + (parts.getOrNull(1)?.toIntOrNull() ?: -2)
            wm in 0..(24 * 60) && nowMinutes >= wm && (nowMs - lastDigestAt) >= 6 * 3600_000L
        }
    }

    /** Compact markdown digest the agent enriches and delivers. */
    fun build(grouped: Map<String, List<NotifLine>>, urgentLines: List<NotifLine>, sinceDesc: String): String = buildString {
        appendLine("## 📡 Notification digest ($sinceDesc)")
        val total = grouped.values.sumOf { it.size }
        appendLine("_$total notification(s) across ${grouped.size} app(s)_")
        appendLine()
        grouped.entries.sortedByDescending { it.value.size }.forEach { (app, lines) ->
            appendLine("**$app ×${lines.size}**")
            // samples: dedupe identical texts, max 3
            lines.map { it.text }.filter { it.isNotBlank() }.distinct().take(3).forEach { appendLine("- $it") }
            appendLine()
        }
        if (urgentLines.isNotEmpty()) {
            appendLine("**⚠ Urgent (matched your rules):**")
            urgentLines.take(8).forEach { appendLine("- ${it.full}") }
        }
    }
}
