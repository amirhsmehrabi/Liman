package com.liman.agent.agent

import com.liman.agent.llm.LlmMessage
import com.liman.agent.util.JSON
import kotlinx.serialization.Serializable
import java.io.File

/**
 * v2.20.0 — RUN CHECKPOINTING (the LangGraph port).
 *
 * LangGraph's standout production feature, quoted from the comparison that
 * motivated this release: *"Checkpointing solves the hardest problem in
 * production agents: resuming after failure without starting over."*
 *
 * On a phone this is not a nice-to-have — the OS kills the app constantly
 * (memory pressure, battery saver, user swipe). Until now a killed run lost
 * its in-flight transcript. Now:
 *
 *  - after EVERY cycle the full run state (goal + message history) is
 *    snapshotted to filesDir/runstate/<convId>.json — exactly LangGraph's
 *    "save the full state + which node ran + what comes next", simplified
 *    to Liman's linear cycle engine;
 *  - any normal exit path (finish / cancel / error / loop-stop) clears the
 *    checkpoint — a surviving checkpoint therefore MEANS "crashed mid-run";
 *  - on reopen, the chat offers RESUME: the checkpoint is rehydrated and
 *    the agent continues from the exact cycle where it died, with an
 *    explicit "do not redo finished work" instruction — the same contract
 *    as Command(resume=...) on the same thread_id.
 */
@Serializable
data class CheckpointData(
    val convId: String,
    val goal: String,
    val cycle: Int,
    val savedAt: Long,
    val messages: List<LlmMessage>
)

object RunCheckpointer {

    private fun fileFor(dir: File, convId: String): File {
        val safe = convId.replace(Regex("[^A-Za-z0-9_-]"), "_").take(80).ifBlank { "conv" }
        return File(dir, "$safe.json")
    }

    fun save(dir: File, cp: CheckpointData) {
        runCatching {
            dir.mkdirs()
            File(dir, "." + fileFor(dir, cp.convId).name + ".tmp").let { tmp ->
                tmp.writeText(JSON.encodeToString(CheckpointData.serializer(), cp))
                val dst = fileFor(dir, cp.convId)
                if (!tmp.renameTo(dst)) {
                    dst.writeText(tmp.readText())
                    tmp.delete()
                }
            }
        }
    }

    fun load(dir: File, convId: String): CheckpointData? = runCatching {
        val f = fileFor(dir, convId)
        if (!f.exists()) return null
        JSON.decodeFromString(CheckpointData.serializer(), f.readText())
    }.getOrNull()

    fun clear(dir: File, convId: String) {
        runCatching { fileFor(dir, convId).delete() }
    }
}
