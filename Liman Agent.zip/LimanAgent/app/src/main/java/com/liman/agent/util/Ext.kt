package com.liman.agent.util

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.random.Random

/** Shared JSON instance: lenient enough for parsing third-party LLM API payloads. */
val JSON: Json = Json {
    ignoreUnknownKeys = true
    isLenient = true
    encodeDefaults = true
    coerceInputValues = true
}

private val PRETTY: Json = Json { prettyPrint = true }

fun now(): Long = System.currentTimeMillis()

fun genId(prefix: String): String {
    val alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    val rnd = List(4) { alphabet.random() }.joinToString("")
    return "$prefix-${now().toString(36)}-$rnd"
}

// ---------- JSON navigation helpers ----------

fun String.toJsonObject(): JsonObject? = runCatching {
    JSON.parseToJsonElement(this) as? JsonObject
}.getOrNull()

fun JsonObject.str(key: String): String? =
    (this[key] as? JsonPrimitive)?.takeIf { it !is JsonNull }?.content

fun JsonObject.bool(key: String): Boolean? =
    (this[key] as? JsonPrimitive)?.takeIf { it !is JsonNull }?.booleanOrNull

fun JsonObject.num(key: String): Double? =
    (this[key] as? JsonPrimitive)?.takeIf { it !is JsonNull }?.doubleOrNull

fun JsonObject.int(key: String): Int? = num(key)?.toInt()
fun JsonObject.long(key: String): Long? = num(key)?.toLong()
fun JsonObject.obj(key: String): JsonObject? = this[key] as? JsonObject
fun JsonObject.arr(key: String): JsonArray? = this[key] as? JsonArray

fun String.prettyJsonOrSelf(): String = runCatching {
    PRETTY.encodeToString(JsonElement.serializer(), JSON.parseToJsonElement(this))
}.getOrDefault(this)

// ---------- Text helpers ----------

fun String.ellipsize(max: Int): String =
    if (length <= max) this else take(max) + "…"

fun String.truncateMiddle(max: Int): String {
    if (length <= max) return this
    val head = max * 2 / 3
    val tail = max - head
    return take(head) + "\n…[truncated ${length - max} chars]…\n" + takeLast(tail)
}

fun estimateTokens(text: String): Int = (text.length + 3) / 4

// ---------- Formatting ----------

fun Long.fmtBytes(): String {
    if (this < 1024) return "$this B"
    val kb = this / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    return "%.1f MB".format(kb / 1024.0)
}

fun Int.fmtBytes(): String = this.toLong().fmtBytes()

private val timeFmt: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM d, HH:mm")

fun Long.fmtTime(): String =
    Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).format(timeFmt)

fun String.sanitizeFileName(): String {
    val cleaned = map { c -> if (c.isLetterOrDigit() || c in "._-() ") c else '_' }
        .joinToString("").trim()
    return ifBlank { "file" }
}

// ---------- File sandbox ----------

/** Returns the file if it is [root] or inside it, else null (prevents path escapes). */
fun File.sandboxChild(root: File): File? = try {
    val r = root.canonicalFile
    val c = this.canonicalFile
    if (c == r || c.path.startsWith(r.path + File.separator)) c else null
} catch (e: Exception) {
    null
}

/** Finds a non-colliding file name inside [dir] (name.jpg, name-1.jpg, …). */
fun uniqueFile(dir: File, name: String): File {
    dir.mkdirs()
    var f = File(dir, name)
    if (!f.exists()) return f
    val base = name.substringBeforeLast('.')
    val ext = name.substringAfterLast('.', "")
    var i = 1
    while (f.exists()) {
        f = File(dir, "$base-$i${if (ext.isNotEmpty()) ".$ext" else ""}")
        i++
    }
    return f
}
