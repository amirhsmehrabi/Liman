package com.liman.agent.agent

import com.liman.agent.data.Conversation
import com.liman.agent.data.Entry

/**
 * v2.23.0 — SELF-IMPROVEMENT LOOP: Liman programs Liman.
 *
 * After missions, `evolve reflect` examines how the agent actually worked
 * (tool stats, failures, recent goals, existing skills) and produces a
 * retrospection directive the SAME agent turn then acts on: draft skills
 * for repeated procedures, propose tool-usage corrections — always with
 * the user's approval before anything is saved. Versioned by skill_store
 * ids; nothing is silent.
 */
object Evolve {

    data class MissionStats(
        val conversations: Int,
        val toolCalls: Int,
        val failures: Int,
        val toolHistogram: Map<String, Int>,
        val topTools: List<String>
    )

    fun stats(convs: List<Conversation>): MissionStats {
        var calls = 0
        var failures = 0
        val hist = HashMap<String, Int>()
        convs.forEach { c ->
            c.entries.forEach { e ->
                if (e is Entry.ToolEntry) {
                    calls++
                    hist[e.tool] = (hist[e.tool] ?: 0) + 1
                    if (!e.ok) failures++
                }
            }
        }
        val top = hist.entries.sortedByDescending { it.value }.take(6).map { "${it.key}×${it.value}" }
        return MissionStats(convs.size, calls, failures, hist, top)
    }

    /**
     * The retrospection directive: returned by the evolve tool so the agent
     * immediately turns it into concrete proposals + ask_user.
     */
    fun retrospection(
        stats: MissionStats,
        recentGoals: List<String>,
        skillNames: List<String>,
        journalToday: String
    ): String = buildString {
        appendLine("RETROSPECTION — analyze yourself and propose improvements (user approves everything):")
        appendLine()
        appendLine("## What you did")
        appendLine("- ${stats.conversations} recent conversation(s), ${stats.toolCalls} tool call(s), ${stats.failures} failure(s)")
        appendLine("- Top tools: ${stats.topTools.joinToString(", ").ifBlank { "—" }}")
        if (recentGoals.isNotEmpty()) {
            appendLine("- Recent goals:")
            recentGoals.take(8).forEach { appendLine("  - $it") }
        }
        if (journalToday.isNotBlank()) {
            appendLine("- Today's journal:")
            journalToday.lines().filter { it.startsWith("- ") }.take(10).forEach { appendLine("  $it") }
        }
        appendLine()
        appendLine("## Existing skills")
        appendLine(skillNames.joinToString(", ").ifBlank { "(none yet)" })
        appendLine()
        appendLine("## Your job now")
        appendLine("1. PROCEDURES: find repeated multi-step patterns in the recent goals — if a pattern occurred ≥2 times and no skill covers it, DRAFT a skill (skill_create) and ask the user before saving.")
        appendLine("2. FAILURES: if ${stats.failures} failures cluster on one tool, explain in one line what to do differently and write it into the draft skill's notes.")
        appendLine("3. HONESTY: if nothing is worth saving, say exactly that — never invent improvements.")
        appendLine("4. Everything user-visible ends with a short summary; ask_user once, batched.")
    }
}
