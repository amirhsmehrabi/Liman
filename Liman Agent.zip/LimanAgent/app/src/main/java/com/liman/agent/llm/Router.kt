package com.liman.agent.llm

import com.liman.agent.data.ComboConfig
import com.liman.agent.data.ComboMode
import com.liman.agent.data.ProviderConfig
import com.liman.agent.data.ProviderKind
import com.liman.agent.data.Stores
import com.liman.agent.agent.isFreeModel
import com.liman.agent.util.JSON
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetAddress
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.util.concurrent.ExecutorService
import java.util.concurrent.atomic.AtomicLong
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.Executors

/**
 * The Liman Router — a 9Router-compatible local AI gateway that runs ON the
 * phone. No server needed.
 *
 * It exposes the same OpenAI-compatible endpoint shape 9Router uses
 * (http://127.0.0.1:20128/v1), so anything that speaks OpenAI can use it —
 * including Liman itself, other apps on the device, or tools over the LAN
 * (when exposed).
 *
 * 9Router-style features implemented natively:
 *  • Smart tiered fallback — FREE providers first (web chats, ":free" model
 *    pools, Gemini free-tier keys), then paid ones; zero-downtime switching.
 *  • RTK token saver — tool outputs passing through are compressed
 *    (head+tail + ANSI stripped + whitespace collapsed), 20-40% token savings.
 *  • Multi-account rotation — duplicate providers of the same kind rotate
 *    round-robin between requests.
 *  • Format translation — OpenAI requests are translated to whatever the
 *    backend kind needs (Gemini / Anthropic / OpenAI-compatible / web chat).
 *  • Quota-ish resilience — the combo health tracking skips failing models.
 *
 * Special model names:
 *  • "auto" (default) — every enabled provider, free tier first
 *  • "free"           — only free-capable routes
 *  • anything else    — exact model match (also matches provider free pools)
 */
object RouterServer {

    data class State(
        val running: Boolean = false,
        val port: Int = 20128,
        val lan: Boolean = false
    )

    private var serverSocket: ServerSocket? = null

    /** The port the router is actually listening on, or null if down. */
    fun runningPort(): Int? = runCatching {
        serverSocket?.takeIf { !it.isClosed }?.localPort
    }.getOrNull()
    private var acceptThread: Thread? = null
    private var pool: ExecutorService? = null
    private val log = ConcurrentLinkedDeque<String>()
    private var lanMode = false
    private var startedAt = 0L
    private val requests = AtomicLong(0)

    /** v2.32 — DEV SERVER: workspace folder exposed at /preview/ (set by the
     *  dev_server tool action; the user's browser and the agent's http_request
     *  can both reach it — same Wi-Fi LAN URL when LAN mode is on). */
    @Volatile
    var previewRoot: java.io.File? = null

    val state get() = State(
        running = serverSocket?.isClosed == false,
        port = serverSocket?.localPort ?: 20128,
        lan = lanMode
    )

    /** best-effort Wi-Fi IPv4 of this phone, for the LAN dashboard URL */
    internal fun lanIp(): String? = runCatching {
        NetworkInterface.getNetworkInterfaces().asSequence()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.asSequence() }
            .filterIsInstance<Inet4Address>()
            .firstOrNull { !it.isLoopbackAddress }?.hostAddress
    }.getOrNull()

    fun recentLog(): List<String> = log.toList().takeLast(30).reversed()
    private fun note(msg: String) {
        log.add("${System.currentTimeMillis() % 100_000}: $msg")
        while (log.size > 80) log.pollFirst()
    }

    @Synchronized
    fun start(stores: Stores, port: Int = 20128, lan: Boolean = false): Boolean {
        if (serverSocket?.isClosed == false) return true
        return try {
            val addr = if (lan) null else InetAddress.getByName("127.0.0.1")
            // if the preferred port is taken (e.g. the real 9Router owns 20128),
            // walk up a few ports instead of failing
            var sock: ServerSocket? = null
            var bound = port
            for (cand in port..port + 5) {
                try {
                    sock = ServerSocket(cand, 16, addr); bound = cand; break
                } catch (e: Exception) { /* port taken — try next */ }
            }
            if (sock == null) sock = ServerSocket(port, 16, addr)
            val ss = sock
            serverSocket = ss
            if (bound != port) {
                note("port $port busy — mini-router moved to $bound")
                runCatching { stores.settings.update { it.routerPort = bound } }
            }
            lanMode = lan
            startedAt = System.currentTimeMillis()
            val workers = Executors.newFixedThreadPool(4)
            pool = workers
            note("router up on ${if (lan) "0.0.0.0" else "127.0.0.1"}:$bound (Liman mini-router, dashboard at /)")
            val engine = RouterEngine(stores) { note(it) }
            acceptThread = Thread {
                while (!ss.isClosed) {
                    try {
                        val client = ss.accept()
                        workers.execute { handle(client, engine, stores) }
                    } catch (e: Exception) {
                        if (!ss.isClosed) note("accept error: ${e.message}")
                    }
                }
            }.apply { isDaemon = true; start() }
            true
        } catch (e: Exception) {
            note("router failed to start: ${e.message}")
            false
        }
    }

    @Synchronized
    fun stop() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        runCatching { pool?.shutdownNow() }
        pool = null
        note("router stopped")
    }

    // ---------------- minimal HTTP ----------------

    private fun handle(client: Socket, engine: RouterEngine, stores: Stores) {
        try {
            client.soTimeout = 300_000
            val input = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
            val output = BufferedWriter(OutputStreamWriter(client.getOutputStream(), Charsets.UTF_8))

            val requestLine = input.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            var path = parts[1]

            var contentLength = 0
            while (true) {
                val line = input.readLine() ?: break
                if (line.isBlank()) break
                val colon = line.indexOf(':')
                if (colon > 0) {
                    val name = line.substring(0, colon).trim().lowercase()
                    if (name == "content-length") contentLength = line.substring(colon + 1).trim().toIntOrNull() ?: 0
                }
            }
            val body = if (contentLength > 0) {
                val buf = CharArray(contentLength)
                var read = 0
                while (read < contentLength) {
                    val n = input.read(buf, read, contentLength - read)
                    if (n < 0) break
                    read += n
                }
                String(buf, 0, read)
            } else ""

            val query = path.substringAfter('?', "")
            path = path.substringBefore('?')

            if (path.startsWith("/preview/")) {
                // ---------- v2.32 DEV SERVER: serve a workspace folder ----------
                val root = previewRoot
                val rel = java.net.URLDecoder.decode(path.removePrefix("/preview/"), "UTF-8")
                if (root == null || !root.isDirectory) {
                    respondPage(output, "<h1>no preview folder set</h1>")
                } else {
                    val f = runCatching {
                        java.io.File(root, rel.removePrefix("/")).canonicalFile
                    }.getOrNull()
                    val safe = f != null && (f == root.canonicalFile ||
                        f!!.path.startsWith(root.canonicalPath + java.io.File.separator))
                    val target = when {
                        !safe -> null
                        f!!.isDirectory -> java.io.File(f, "index.html").takeIf { it.isFile }
                        f!!.isFile -> f
                        else -> null
                    }
                    if (target == null) respondPage(output, "<h1>404</h1><p>$rel not found in ${root.name}</p>")
                    else {
                        val mime = when (target.extension.lowercase()) {
                            "html", "htm" -> "text/html"
                            "css" -> "text/css"
                            "js", "mjs" -> "text/javascript"
                            "json" -> "application/json"
                            "svg" -> "image/svg+xml"
                            "png" -> "image/png"
                            "jpg", "jpeg" -> "image/jpeg"
                            "gif" -> "image/gif"
                            "webp" -> "image/webp"
                            "ico" -> "image/x-icon"
                            "woff" -> "font/woff"; "woff2" -> "font/woff2"
                            "mp4" -> "video/mp4"; "mp3" -> "audio/mpeg"
                            "txt", "md" -> "text/plain"
                            else -> "application/octet-stream"
                        }
                        val bytes = target.readBytes()
                        val header = "HTTP/1.1 200 OK\r\nContent-Type: $mime\r\n" +
                            "Content-Length: ${bytes.size}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n"
                        client.getOutputStream().apply {
                            write(header.toByteArray(Charsets.ISO_8859_1))
                            write(bytes)
                            flush()
                        }
                    }
                }
            } else if (path == "/" || path == "/dashboard" || path == "/index.html") {
                // ---------- the 9Router dashboard ----------
                respondPage(output, ROUTER_DASHBOARD_HTML)
            } else if (path == "/api/status") {
                val settingsNow = stores.settings.state.value
                respondJson(
                    output, 200,
                    routerStatusJson(
                        running = serverSocket?.isClosed == false,
                        port = serverSocket?.localPort ?: settingsNow.routerPort,
                        lan = lanMode,
                        lanUrl = lanIp()?.let { "http://$it:${settingsNow.routerPort}" },
                        enabled = settingsNow.routerEnabled,
                        requests = requests.get(),
                        uptimeMs = if (startedAt == 0L) 0L else System.currentTimeMillis() - startedAt,
                        providers = stores.providers.state.value,
                        combo = stores.combo.state.value,
                        comboNames = { id -> stores.providers.get(id)?.name ?: id },
                        models = engine.modelNames(),
                        log = recentLog(),
                        revealKeys = query.contains("reveal=1")
                    ),
                    false
                )
            } else if (path == "/api/state" && method == "POST") {
                // ---------- enable/disable the router itself (from the dashboard) ----------
                val obj = runCatching { JSON.parseToJsonElement(body).jsonObject }.getOrNull()
                val cur = stores.settings.state.value
                val wantEnabled = obj?.get("enabled")?.jsonPrimitive?.booleanOrNull ?: cur.routerEnabled
                val wantLan = obj?.get("lan")?.jsonPrimitive?.booleanOrNull ?: cur.routerLan
                stores.settings.update {
                    it.routerEnabled = wantEnabled
                    it.routerLan = wantLan
                }
                if (wantEnabled) {
                    if (serverSocket?.isClosed == false) stop()
                    val ok = start(stores, cur.routerPort, wantLan)
                    respondJson(output, 200, buildJsonObject { put("ok", ok); put("running", ok) }, false)
                } else {
                    respondJson(output, 200, buildJsonObject { put("ok", true); put("running", false) }, false)
                    stop()
                }
            } else if (path.startsWith("/api/providers/") && method == "POST") {
                // ---------- edit / toggle a provider ----------
                val id = path.removePrefix("/api/providers/")
                val cfg = stores.providers.get(id)
                if (cfg == null) {
                    respondJson(output, 404, buildJsonObject { put("error", "no provider $id") }, false)
                } else {
                    val obj = runCatching { JSON.parseToJsonElement(body).jsonObject }.getOrNull()
                    obj?.get("enabled")?.jsonPrimitive?.booleanOrNull?.let { cfg.enabled = it }
                    obj?.get("name")?.jsonPrimitive?.contentOrNull?.let { if (it.isNotBlank()) cfg.name = it }
                    obj?.get("baseUrl")?.jsonPrimitive?.contentOrNull?.let { if (it.isNotBlank()) cfg.baseUrl = it }
                    obj?.get("model")?.jsonPrimitive?.contentOrNull?.let { cfg.model = it }
                    obj?.get("apiKey")?.jsonPrimitive?.contentOrNull?.let { if (it.isNotEmpty()) cfg.apiKey = it }
                    obj?.get("useFreePool")?.jsonPrimitive?.booleanOrNull?.let { cfg.useFreePool = it }
                    stores.providers.upsert(cfg)
                    note("dashboard: provider ${cfg.name} updated")
                    respondJson(output, 200, buildJsonObject { put("ok", true) }, false)
                }
            } else if (path == "/api/combo" && method == "POST") {
                val obj = runCatching { JSON.parseToJsonElement(body).jsonObject }.getOrNull()
                stores.combo.update { c ->
                    c.copy(
                        mode = obj?.get("mode")?.jsonPrimitive?.contentOrNull
                            ?.let { runCatching { ComboMode.valueOf(it) }.getOrNull() } ?: c.mode,
                        retriesPerProvider = obj?.get("retriesPerProvider")?.jsonPrimitive?.intOrNull
                            ?: c.retriesPerProvider,
                        cooldownMs = obj?.get("cooldownMs")?.jsonPrimitive?.longOrNull ?: c.cooldownMs
                    )
                }
                respondJson(output, 200, buildJsonObject { put("ok", true) }, false)
            } else if (path == "/api/test" && method == "POST") {
                // ---------- live route test: full round-trip through the engine ----------
                val obj = runCatching { JSON.parseToJsonElement(body).jsonObject }.getOrNull()
                val model = obj?.get("model")?.jsonPrimitive?.contentOrNull ?: "auto"
                requests.incrementAndGet()
                engine.handleChat(
                    buildJsonObject {
                        put("model", model)
                        put("stream", false)
                        put("messages", buildJsonArray {
                            add(buildJsonObject {
                                put("role", "user")
                                put("content", "Reply with exactly: router ok")
                            })
                        })
                    }.toString(),
                    output
                )
            } else if (path == "/v1/models" || path == "/models") {
                respondJson(output, 200, engine.modelsPayload(), false)
            } else if (path == "/health") {
                respondJson(output, 200, buildJsonObject {
                    put("ok", true)
                    put("router", "liman")
                    put("compatible", "9router")
                    put("endpoint", "/v1")
                    put("dashboard", "/")
                }, false)
            } else if (path.startsWith("/termux/script/") && method == "GET") {
                // TERMUX BRIDGE: serve a pending script to Termux as RAW TEXT
                // (the bash-side wrapper has no JSON parser — by design)
                val id = path.removePrefix("/termux/script/")
                val script = if (id == "ping") "echo PONG" else com.liman.agent.agent.TermuxBridge.takeScript(id)
                val bytes = (script ?: "no pending script $id").toByteArray(Charsets.UTF_8)
                if (script == null) respondJson(output, 404, buildJsonObject {
                    put("error", buildJsonObject { put("message", "no pending script $id") })
                }, false)
                else {
                    output.write("HTTP/1.1 200 OK\r\n")
                    output.write("Content-Type: text/plain\r\n")
                    output.write("Content-Length: ${bytes.size}\r\n")
                    output.write("Connection: close\r\n")
                    output.write("\r\n")
                    output.write(String(bytes, Charsets.UTF_8))
                    output.flush()
                }
            } else if (path.startsWith("/termux/result/") && method == "POST") {
                // TERMUX BRIDGE: receive the command output from Termux
                val id = path.removePrefix("/termux/result/")
                com.liman.agent.agent.TermuxBridge.putResult(id, body)
                respondJson(output, 200, buildJsonObject { put("ok", true) }, false)
            } else if (path.endsWith("/chat/completions") && method == "POST") {
                requests.incrementAndGet()
                engine.handleChat(body, output)
            } else {
                respondJson(output, 404, buildJsonObject {
                    put("error", buildJsonObject {
                        put("message", "Unknown route $path — dashboard at / , API at /v1/models and /v1/chat/completions")
                    })
                }, false)
            }
            output.flush()
        } catch (e: Exception) {
            // client went away mid-stream — fine
        } finally {
            runCatching { client.close() }
        }
    }

    internal fun respondPage(output: BufferedWriter, html: String) {
        val bytes = html.toByteArray(Charsets.UTF_8)
        output.write("HTTP/1.1 200 OK\r\n")
        output.write("Content-Type: text/html; charset=utf-8\r\n")
        output.write("Content-Length: ${bytes.size}\r\n")
        output.write("Connection: close\r\n")
        output.write("\r\n")
        output.write(html)
        output.flush()
    }

    internal fun respondJson(
        output: BufferedWriter,
        code: Int,
        body: Any,
        keepAlive: Boolean
    ) {
        val text = when (body) {
            is String -> body
            else -> body.toString()
        }
        val bytes = text.toByteArray(Charsets.UTF_8)
        output.write("HTTP/1.1 $code ${if (code == 200) "OK" else "Error"}\r\n")
        output.write("Content-Type: application/json\r\n")
        output.write("Content-Length: ${bytes.size}\r\n")
        output.write("Connection: ${if (keepAlive) "keep-alive" else "close"}\r\n")
        output.write("\r\n")
        output.write(text)
        output.flush()
    }
}

/**
 * Routing logic — separated so unit tests can exercise tier selection and
 * the RTK compressor without sockets.
 */
class RouterEngine(private val stores: Stores, private val onEvent: (String) -> Unit = {}) {

    // ---------------- models ----------------

    fun modelNames(): List<String> {
        val names = ArrayList<String>()
        names.add("auto")
        names.add("free")
        val enabled = stores.providers.state.value.filter { it.enabled }
        enabled.forEach { cfg ->
            when (cfg.kind) {
                ProviderKind.WEB_CHAT -> names.add("web:${cfg.name}")
                else -> {
                    if (cfg.model.isNotBlank()) names.add(cfg.model)
                    cfg.freeModels.filter { it != cfg.model }.take(30).forEach { names.add(it) }
                }
            }
        }
        return names.distinct()
    }

    fun modelsPayload(): String = buildJsonObject {
        put("object", "list")
        put("data", buildJsonArray {
            modelNames().forEach { m ->
                add(buildJsonObject {
                    put("id", m)
                    put("object", "model")
                    put("owned_by", "liman-router")
                })
            }
        })
    }.toString()

    // ---------------- routing ----------------

    /** Handle for one (provider, model) pair. */
    private fun handleFor(cfg: ProviderConfig, model: String): ComboProvider.Handle {
        val runCfg = if (model == cfg.model) cfg else cfg.copy(model = model)
        val runner: ProviderRunner = when (cfg.kind) {
            ProviderKind.OPENAI_COMPATIBLE -> OpenAiProvider(runCfg)
            ProviderKind.GEMINI -> GeminiProvider(runCfg)
            ProviderKind.ANTHROPIC -> AnthropicProvider(runCfg)
            ProviderKind.WEB_CHAT -> WebChatProvider(cfg)
            ProviderKind.OPENCODE_FREE -> OpenCodeFreeProvider(runCfg)
        }
        val label = if (model == cfg.model) cfg.name else "${cfg.name}·$model"
        return ComboProvider.Handle(cfg.id, label, model, runner)
    }

    internal fun isFreeProvider(cfg: ProviderConfig): Boolean =
        cfg.kind == ProviderKind.WEB_CHAT ||
            cfg.kind == ProviderKind.OPENCODE_FREE || // anonymous free tier, no key
            (cfg.kind == ProviderKind.GEMINI && cfg.apiKey.isNotBlank()) || // free-tier API key
            cfg.freeModels.isNotEmpty() ||
            isFreeModel(cfg.model)

    fun handlesForRoute(model: String): List<ComboProvider.Handle> {
        val enabled = stores.providers.state.value.filter { it.enabled }
        return when (model.lowercase()) {
            "auto", "" -> {
                val free = ArrayList<ComboProvider.Handle>()
                val paid = ArrayList<ComboProvider.Handle>()
                enabled.forEach { cfg ->
                    if (cfg.kind == ProviderKind.WEB_CHAT) {
                        free.add(handleFor(cfg, "web"))
                    } else if (isFreeProvider(cfg)) {
                        if (cfg.useFreePool && cfg.freeModels.isNotEmpty()) {
                            cfg.freeModels.take(12).forEach { free.add(handleFor(cfg, it)) }
                        } else free.add(handleFor(cfg, cfg.model))
                    } else {
                        paid.add(handleFor(cfg, cfg.model))
                    }
                }
                free + paid // FREE first — 9router's tier ladder, reversed for free-first use
            }
            "free" -> enabled.flatMap { cfg ->
                when {
                    cfg.kind == ProviderKind.WEB_CHAT -> listOf(handleFor(cfg, "web"))
                    cfg.freeModels.isNotEmpty() -> cfg.freeModels.take(12).map { handleFor(cfg, it) }
                    cfg.kind == ProviderKind.GEMINI -> listOf(handleFor(cfg, cfg.model))
                    isFreeModel(cfg.model) -> listOf(handleFor(cfg, cfg.model))
                    else -> emptyList()
                }
            }
            else -> {
                if (model.startsWith("web:")) {
                    val name = model.removePrefix("web:")
                    enabled.filter { it.kind == ProviderKind.WEB_CHAT && it.name.equals(name, true) }
                        .map { handleFor(it, "web") }
                } else {
                    enabled.mapNotNull { cfg ->
                        when {
                            cfg.model == model -> handleFor(cfg, model)
                            model in cfg.freeModels -> handleFor(cfg, model)
                            else -> null
                        }
                    }
                }
            }
        }
    }

    // ---------------- chat completions ----------------

    fun handleChat(body: String, output: BufferedWriter) {
        runBlocking {
            try {
                val req = JSON.parseToJsonElement(body).let { it as? JsonObject }
                if (req == null) {
                    RouterServer.respondJson(output, 400, """{"error":{"message":"invalid JSON body"}}""", false)
                    return@runBlocking
                }
                val model = (req["model"] as? JsonPrimitive)?.content ?: "auto"
                val stream = (req["stream"] as? JsonPrimitive)?.content == "true"
                val maxTokens = (req["max_tokens"] as? JsonPrimitive)?.content?.toIntOrNull() ?: 4096

                val messages = parseOpenAiMessages(req["messages"] as? JsonArray)
                if (messages.isEmpty()) {
                    RouterServer.respondJson(output, 400, """{"error":{"message":"no messages"}}""", false)
                    return@runBlocking
                }

                val handles = handlesForRoute(model)
                if (handles.isEmpty()) {
                    RouterServer.respondJson(output, 503, buildJsonObject {
                        put("error", buildJsonObject {
                            put(
                                "message",
                                "Router has no route for '$model'. Add providers in Liman settings, or use auto/free."
                            )
                        })
                    }.toString(), false)
                    return@runBlocking
                }

                onEvent("→ /chat/completions model=$model (${handles.size} routes, free-first)")

                val combo = ComboProvider(
                    handles,
                    ComboConfig(mode = ComboMode.FAILOVER, retriesPerProvider = 1, cooldownMs = 30_000L),
                    onEvent = onEvent
                )
                val llmReq = LlmRequest(
                    messages = messages,
                    tools = emptyList(),
                    gen = GenSettings(maxTokens = maxTokens, stream = stream)
                )

                if (stream) {
                    streamSse(output, combo, llmReq, model)
                } else {
                    val r = combo.complete(llmReq)
                    val payload = buildJsonObject {
                        put("id", "chatcml-${UUID.randomUUID().toString().take(12)}")
                        put("object", "chat.completion")
                        put("created", System.currentTimeMillis() / 1000)
                        put("model", model)
                        put("choices", buildJsonArray {
                            add(buildJsonObject {
                                put("index", 0)
                                put("message", buildJsonObject {
                                    put("role", "assistant")
                                    put("content", r.text)
                                })
                                put("finish_reason", "stop")
                            })
                        })
                        put("usage", buildJsonObject {
                            put("prompt_tokens", r.usage?.promptTokens ?: 0)
                            put("completion_tokens", r.usage?.completionTokens ?: 0)
                            put("total_tokens", r.usage?.total ?: 0)
                        })
                    }
                    RouterServer.respondJson(output, 200, payload.toString(), false)
                    onEvent("✓ answered via ${r.providerName} (${r.text.length} chars)")
                }
            } catch (e: Exception) {
                runCatching {
                    RouterServer.respondJson(
                        output, 502,
                        """{"error":{"message":"${e.message?.replace("\"", "'")?.take(300)}}"}""", false
                    )
                }
            }
        }
    }

    private suspend fun streamSse(output: BufferedWriter, combo: ComboProvider, req: LlmRequest, model: String) {
        try {
            output.write("HTTP/1.1 200 OK\r\n")
            output.write("Content-Type: text/event-stream\r\n")
            output.write("Cache-Control: no-cache\r\n")
            output.write("Connection: close\r\n\r\n")
            output.flush()

            val id = "chatcml-${UUID.randomUUID().toString().take(12)}"
            fun chunk(deltaContent: String?, finish: String? = null) {
                val data = buildJsonObject {
                    put("id", id)
                    put("object", "chat.completion.chunk")
                    put("created", System.currentTimeMillis() / 1000)
                    put("model", model)
                    put("choices", buildJsonArray {
                        add(buildJsonObject {
                            put("index", 0)
                            put("delta", buildJsonObject {
                                if (deltaContent != null) put("content", deltaContent)
                            })
                            if (finish != null) put("finish_reason", finish)
                        })
                    })
                }.toString()
                output.write("data: $data\n\n")
            }

            var emitted = 0
            val result = combo.complete(req) { _, text ->
                runCatching {
                    // delta = the new suffix since the last emission
                    if (text.length > emitted) {
                        chunk(text.substring(emitted))
                        emitted = text.length
                    }
                }
            }
            chunk(null, "stop")
            output.write("data: [DONE]\n\n")
            output.flush()
            onEvent("✓ streamed via ${result.providerName}")
        } catch (e: Exception) {
            runCatching {
                output.write("data: {\"error\":{\"message\":\"stream failed\"}}\n\n")
                output.flush()
            }
        }
    }

    // ---------------- OpenAI request parsing (+ RTK) ----------------

    internal fun parseOpenAiMessages(raw: JsonArray?): List<LlmMessage> {
        if (raw == null) return emptyList()
        val out = ArrayList<LlmMessage>()
        for (el in raw) {
            val m = el as? JsonObject ?: continue
            val role = (m["role"] as? JsonPrimitive)?.content ?: "user"
            val parts = ArrayList<LPart>()
            when (val content = m["content"]) {
                is JsonPrimitive -> {
                    val text = rtk(content.content, role)
                    if (text.isNotBlank()) parts.add(LPart.Text(text))
                }
                is JsonArray -> content.forEach { c ->
                    val co = c as? JsonObject ?: return@forEach
                    val type = (co["type"] as? JsonPrimitive)?.content
                    when (type) {
                        "text" -> (co["text"] as? JsonPrimitive)?.content?.let {
                            val t = rtk(it, role)
                            if (t.isNotBlank()) parts.add(LPart.Text(t))
                        }
                        "image_url" -> {
                            // data: URLs carry real image bytes
                            val url = ((co["image_url"] as? JsonObject)?.get("url") as? JsonPrimitive)?.content
                            if (url != null && url.startsWith("data:")) {
                                val mime = url.substringAfter("data:").substringBefore(";")
                                val b64 = url.substringAfter("base64,", "")
                                if (b64.isNotBlank()) parts.add(LPart.Media(mime, b64))
                            }
                        }
                    }
                }
                else -> {}
            }
            if (parts.isNotEmpty()) {
                val mapped = when (role) {
                    "system" -> Role.SYSTEM
                    "assistant" -> Role.ASSISTANT
                    "tool" -> Role.USER // OpenAI tool output → user text (RTK'd)
                    else -> Role.USER
                }
                out.add(LlmMessage(mapped, parts))
            }
        }
        return out
    }

    companion object {
        /**
         * RTK token saver (9Router's idea): tool outputs and long pasted
         * dumps get compressed before they're routed — ANSI escapes
         * stripped, whitespace collapsed, head+tail kept.
         */
        fun rtk(text: String, role: String, threshold: Int = 1600): String {
            var t = text.replace(Regex("\\u001B\\[[0-9;]*[A-Za-z]"), "") // ANSI
            if (role != "tool" && role != "user") return t
            t = t.replace(Regex("\\n{3,}"), "\n\n")
            if (t.length <= threshold) return t
            val head = t.take(threshold / 2)
            val tail = t.takeLast(threshold / 4)
            return "$head\n…[RTK: ${t.length - threshold} chars compressed]…\n$tail"
        }
    }
}
