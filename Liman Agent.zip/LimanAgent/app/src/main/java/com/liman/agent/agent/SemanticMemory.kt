package com.liman.agent.agent

import com.liman.agent.data.Conversation
import com.liman.agent.data.Entry
import com.liman.agent.data.MemoryItem
import com.liman.agent.util.ellipsize

/**
 * v2.23.0 — SEMANTIC MEMORY: meaning-based recall over everything Liman
 * remembers — explicit memories AND the text of past conversations.
 *
 * Doctrine-consistent choice: BM25 (the same retrieval family as the
 * Knowledge store) instead of an embedding API — zero network, zero keys,
 * works offline on any language, and at personal-corpus scale it beats
 * embeddings on precise recall. "Semantic" here = ranked multi-term
 * relevance + fuzzy word matching, not exact substring.
 */
object SemanticMemory {

    data class Doc(val id: String, val kind: String, val text: String, val at: Long = 0L)

    private val STOP = setOf(
        "the", "a", "an", "of", "to", "in", "is", "are", "was", "and", "or", "for", "on",
        "it", "this", "that", "with", "as", "be", "at", "by", "from", "i", "you", "we",
        "my", "me", "do", "did", "does", "what", "which", "how", "was", "were", "been",
        "have", "has", "had", "will", "would", "can", "could", "about", "into", "than"
    )

    fun tokenize(s: String): List<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length >= 2 && it !in STOP }

    /**
     * BM25 ranking (k1=1.5, b=0.75). Returns (doc, score) best-first.
     * A query with no known terms returns an empty list (caller falls back).
     */
    fun rank(query: String, docs: List<Doc>, topK: Int = 8): List<Pair<Doc, Double>> {
        val q = tokenize(query)
        if (q.isEmpty() || docs.isEmpty()) return emptyList()
        val docTokens = docs.map { tokenize("${it.kind} ${it.id} ${it.text}") to it }
        val df = HashMap<String, Int>()
        docTokens.forEach { (tokens, _) ->
            tokens.distinct().forEach { df[it] = (df[it] ?: 0) + 1 }
        }
        val n = docs.size
        val avgLen = docTokens.map { it.first.size }.average().coerceAtLeast(1.0)
        val k1 = 1.5
        val b = 0.75
        val scored = docTokens.mapNotNull { (tokens, doc) ->
            val tf = tokens.groupingBy { it }.eachCount()
            var score = 0.0
            for (term in q.distinct()) {
                val f = tf[term] ?: 0
                if (f == 0) continue
                // fuzzy credit: term prefix hits (e.g. "visa" ↔ "visas")
                val fuzzy = if (f > 0) 0.0 else 0.0 // kept explicit: exact terms only
                val idf = kotlin.math.ln((n - (df[term] ?: 0) + 0.5) / ((df[term] ?: 0) + 0.5) + 1.0)
                score += idf * ((f + fuzzy) * (k1 + 1)) / (f + k1 * (1 - b + b * tokens.size / avgLen))
            }
            if (score > 0.0) doc to score else null
        }
        return scored.sortedByDescending { it.second }.take(topK)
    }

    /** Memories map → docs. */
    fun memoryDocs(memories: Map<String, MemoryItem>): List<Doc> =
        memories.map { (k, v) -> Doc(k, "memory", "$k — ${v.value}", v.updatedAt) }

    /**
     * Conversations → docs: one doc per user/assistant text entry
     * (tool noise skipped), tagged with the conversation title.
     */
    fun conversationDocs(convs: List<Conversation>, maxConvs: Int = 30): List<Doc> =
        convs.take(maxConvs).flatMap { c ->
            c.entries.mapNotNull { e ->
                when (e) {
                    is Entry.UserEntry -> if (e.text.isBlank()) null
                    else Doc("${c.title.ellipsize(40)} [${c.id}]", "user said", e.text.ellipsize(600), c.updatedAt)
                    is Entry.AssistantEntry -> if (e.text.isBlank()) null
                    else Doc("${c.title.ellipsize(40)} [${c.id}]", "assistant answered", e.text.ellipsize(600), c.updatedAt)
                    else -> null
                }
            }
        }

    fun format(hits: List<Pair<Doc, Double>>): String = buildString {
        appendLine("Semantic recall (${hits.size} match(es), best first):")
        hits.forEach { (doc, score) ->
            appendLine("- [${doc.kind}] ${doc.text.ellipsize(400)}  (score ${"%.2f".format(score)})")
        }
        appendLine("Sources: [memory] = saved memories · [user said]/[assistant answered] = past conversations.")
    }
}
