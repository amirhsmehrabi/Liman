package com.liman.agent.agent

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.liman.agent.llm.LPart
import com.liman.agent.util.sanitizeFileName
import com.liman.agent.util.uniqueFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

/** Android-specific media decoding used by file ingestion. */
object AndroidMedia {

    fun imageDimensions(file: File): Pair<Int, Int>? = try {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) null else opts.outWidth to opts.outHeight
    } catch (t: Throwable) {
        null
    }

    /** Decodes and downscales an image, returning (mime, jpeg bytes). */
    fun decodeImage(file: File, maxDim: Int = 1568, quality: Int = 85): Pair<String, ByteArray>? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDim) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return null
            val scaled = scaleIfNeeded(bmp, maxDim)
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            if (scaled !== bmp) bmp.recycle()
            "image/jpeg" to baos.toByteArray()
        } catch (t: Throwable) {
            null
        }
    }

    fun decodeImageBytes(bytes: ByteArray, maxDim: Int = 1568, quality: Int = 85): Pair<String, ByteArray>? {
        return try {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val scaled = scaleIfNeeded(bmp, maxDim)
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            if (scaled !== bmp) bmp.recycle()
            "image/jpeg" to baos.toByteArray()
        } catch (t: Throwable) {
            null
        }
    }

    private fun scaleIfNeeded(bmp: Bitmap, maxDim: Int): Bitmap {
        val m = maxOf(bmp.width, bmp.height)
        if (m <= maxDim) return bmp
        val ratio = maxDim.toFloat() / m
        return Bitmap.createScaledBitmap(
            bmp,
            (bmp.width * ratio).toInt().coerceAtLeast(1),
            (bmp.height * ratio).toInt().coerceAtLeast(1),
            true
        )
    }

    /** Renders up to [maxPages] PDF pages to JPEGs. Returns (pageCount, images). */
    fun pdfPages(file: File, maxPages: Int = 8, pageWidth: Int = 1000): Pair<Int, List<ByteArray>> = try {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        var renderer: PdfRenderer? = null
        try {
            renderer = PdfRenderer(pfd)
            val count = renderer.pageCount
            val pages = ArrayList<ByteArray>()
            val n = minOf(count, maxPages)
            for (i in 0 until n) {
                val page = renderer.openPage(i)
                try {
                    val scale = pageWidth.toFloat() / page.width
                    val bmp = Bitmap.createBitmap(
                        pageWidth,
                        (page.height * scale).toInt().coerceAtLeast(1),
                        Bitmap.Config.ARGB_8888
                    )
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val baos = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 82, baos)
                    bmp.recycle()
                    pages.add(baos.toByteArray())
                } finally {
                    runCatching { page.close() }
                }
            }
            count to pages
        } finally {
            runCatching { renderer?.close() }
            runCatching { pfd.close() }
        }
    } catch (t: Throwable) {
        -1 to emptyList()
    }

    data class VideoInfo(val width: Int, val height: Int, val durationMs: Long, val frames: List<ByteArray>)

    fun videoInfo(file: File, frameCount: Int = 4, width: Int = 960): VideoInfo = try {
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(file.absolutePath)
            val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val frames = ArrayList<ByteArray>()
            if (dur > 0) {
                for (i in 0 until frameCount) {
                    val tUs = dur * 1000L * (i + 1) / (frameCount + 1)
                    val bmp = mmr.getFrameAtTime(tUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                    val scaled = scaleIfNeeded(bmp, width)
                    val baos = ByteArrayOutputStream()
                    scaled.compress(Bitmap.CompressFormat.JPEG, 80, baos)
                    if (scaled !== bmp) bmp.recycle()
                    frames.add(baos.toByteArray())
                }
            }
            VideoInfo(w, h, dur, frames)
        } finally {
            runCatching { mmr.release() }
        }
    } catch (t: Throwable) {
        VideoInfo(0, 0, 0, emptyList())
    }

    fun audioDurationMs(file: File): Long = try {
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(file.absolutePath)
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            runCatching { mmr.release() }
        }
    } catch (t: Throwable) {
        0L
    }
}

// ============================================================
// Ingestion: turn any file into (text, vision-media) for the model
// ============================================================

val IMAGE_EXTS = setOf("png", "jpg", "jpeg", "webp", "gif", "bmp", "heic", "heif")
val VIDEO_EXTS = setOf("mp4", "mkv", "webm", "mov", "3gp", "avi", "m4v", "flv", "ts")
val AUDIO_EXTS = setOf("mp3", "wav", "m4a", "aac", "ogg", "oga", "flac", "opus", "amr")
val ARCHIVE_EXTS = setOf("zip", "jar", "kmz")
val TEXT_EXTS = setOf(
    "txt", "md", "markdown", "json", "jsonl", "csv", "tsv", "log", "xml", "yml", "yaml",
    "toml", "ini", "conf", "cfg", "properties", "kt", "kts", "java", "py", "js", "ts", "jsx",
    "tsx", "c", "h", "cpp", "hpp", "cs", "go", "rs", "swift", "rb", "php", "sh", "bash",
    "bat", "ps1", "sql", "html", "htm", "css", "scss", "svg", "gradle", "env", "tex",
    "srt", "vtt", "rtf", "ipl", "m3u", "m3u8"
)

class FileIngestor(private val context: Context) {

    data class Ingested(
        val displayName: String,
        val relPath: String,
        val sizeBytes: Long,
        val kindNote: String,
        val text: String?,
        val media: List<LPart.Media>
    )

    /** Copies a SAF uri into workspace/uploads and returns the file. */
    suspend fun importUri(uri: Uri, workspace: File): File? = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            var name: String? = null
            runCatching {
                resolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && c.moveToFirst()) name = c.getString(idx)
                }
            }
            if (name.isNullOrBlank()) name = uri.lastPathSegment?.substringAfterLast('/')?.sanitizeFileName()
            if (name.isNullOrBlank()) name = "shared-file"
            val target = uniqueFile(File(workspace, "uploads"), name!!.sanitizeFileName())
            resolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { input.copyTo(it) }
            } ?: return@withContext null
            target
        } catch (t: Throwable) {
            null
        }
    }

    /** Analyzes a workspace file: extracts text and/or produces vision media parts. */
    suspend fun ingestFile(file: File, workspace: File): Ingested = withContext(Dispatchers.IO) {
        val relPath = file.relativeToOrNull(workspace)?.toString()?.replace('\\', '/') ?: file.name
        val ext = file.extension.lowercase()
        val size = file.length()
        val media = ArrayList<LPart.Media>()
        var text: String? = null
        var note = ext.ifBlank { "file" }

        fun mediaBytes(): Long = media.sumOf { it.b64.length * 3L / 4 }
        fun addImage(bytes: ByteArray, label: String, mime: String = "image/jpeg") {
            if (mediaBytes() + bytes.size > 10_000_000L) return
            media.add(
                LPart.Media(mime, android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP), label)
            )
        }

        when {
            ext in IMAGE_EXTS -> {
                val dims = AndroidMedia.imageDimensions(file)
                val decoded = AndroidMedia.decodeImage(file)
                if (decoded != null) addImage(decoded.second, relPath, decoded.first)
                note = "image${dims?.let { ", ${it.first}×${it.second}" } ?: ""}"
                text = "[image file $relPath — attached as vision input]"
            }

            ext == "pdf" -> {
                val (count, pages) = AndroidMedia.pdfPages(file)
                if (pages.isNotEmpty()) {
                    pages.forEach { addImage(it, "$relPath p${media.size + 1}") }
                    note = "PDF, $count page(s)"
                    text = "[PDF $relPath — ${count} pages; first ${pages.size} rendered as images and attached]"
                } else {
                    note = "PDF (render failed)"
                    text = "[PDF $relPath could not be rendered — it may be corrupted, scanned-only or password-protected.]"
                }
            }

            ext in VIDEO_EXTS -> {
                val info = AndroidMedia.videoInfo(file)
                info.frames.forEach { addImage(it, "$relPath f${media.size + 1}") }
                val durS = info.durationMs / 1000.0
                note = "video ${info.width}×${info.height}, ${"%.1f".format(durS)}s"
                text = "[video file $relPath — ${info.width}×${info.height}, ${"%.1f".format(durS)}s, ${info.frames.size} sample frames attached]"
            }

            ext in AUDIO_EXTS -> {
                val durS = AndroidMedia.audioDurationMs(file) / 1000.0
                note = "audio, ${"%.1f".format(durS)}s"
                text = "[audio file $relPath — ${"%.1f".format(durS)}s. Audio content cannot be heard; if it matters, transcribe it elsewhere and share the text.]"
            }

            ext == "docx" -> {
                text = OfficeExtractors.docx(file); note = "Word document"
            }

            ext == "xlsx" -> {
                text = OfficeExtractors.xlsx(file); note = "Excel workbook"
            }

            ext == "pptx" -> {
                text = OfficeExtractors.pptx(file); note = "PowerPoint"
            }

            ext == "epub" -> {
                text = OfficeExtractors.epub(file); note = "EPUB e-book"
            }

            ext in ARCHIVE_EXTS -> {
                text = OfficeExtractors.zipListing(file); note = "archive"
            }

            ext in setOf("doc", "xls", "ppt") -> {
                text = "[legacy Office binary format (.${ext}) is not directly readable — convert it to .docx/.xlsx or export to PDF and try again.]"
                note = "legacy Office"
            }

            ext in TEXT_EXTS -> {
                text = capText(file.readText(Charsets.UTF_8))
                note = "${ext} text"
            }

            else -> {
                val head = ByteArray(minOf(size, 8192L).toInt())
                if (size > 0) {
                    runCatching {
                        file.inputStream().use { it.read(head) }
                    }
                }
                if (OfficeExtractors.looksLikeText(head)) {
                    text = capText(file.readText(Charsets.UTF_8))
                    note = "text"
                } else {
                    text = OfficeExtractors.hexPreview(head)
                    note = "binary"
                }
            }
        }

        Ingested(file.name, relPath, size, note, text, media)
    }

    private fun capText(s: String, cap: Int = 60_000): String =
        if (s.length <= cap) s else s.take(cap - 60) + "\n…[truncated, ${s.length - cap} more chars]"
}
