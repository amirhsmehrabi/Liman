package com.liman.agent.agent

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import kotlin.math.ceil
import kotlin.math.roundToLong

/**
 * v2.24.0 — THE MP4 RECORDER: turns a deterministic motion.html into a
 * high-quality H.264 MP4, entirely on-device (no Termux, no ffmpeg, no
 * cloud). The same "render frames → encode" idea as Remotion, with the
 * phone's own WebView as the render engine:
 *
 *   for each frame i:  __limanSeek(i/fps)  →  WebView raster  →  YUV420
 *   →  MediaCodec H.264 (bit-exact presentation timestamps)  →  MediaMuxer
 *
 * Determinism contract: the timeline must be a pure function of t
 * (MotionStudio.exportReadiness enforces the law before we roll).
 */
object MotionRecorder {

    data class Params(
        val width: Int = 1920,
        val height: Int = 1080,
        val fps: Int = 30,
        val bitrate: Int = 14_000_000,
        val maxDurationSeconds: Int = 120
    )

    // ---------------- pure helpers (unit-tested) ----------------

    fun frameCount(durationSeconds: Double, fps: Int): Int =
        ceil(durationSeconds * fps - 1e-9).toInt().coerceAtLeast(1)

    fun presentationUs(frame: Int, fps: Int): Long =
        (frame * 1_000_000.0 / fps).roundToLong()

    fun bitrateFor(width: Int, height: Int, fps: Int): Int {
        val pixels = width.toLong() * height
        val base = when {
            pixels >= 1920 * 1080 -> 14_000_000
            pixels >= 1280 * 720 -> 8_000_000
            else -> 4_000_000
        }
        return if (fps >= 50) (base * 1.4).toInt() else base
    }

    /** BT.601 limited-range RGB→YUV (pure math, tested). */
    fun rgbToYuv601(r: Int, g: Int, b: Int): IntArray {
        val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
        val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
        val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
        return intArrayOf(y.coerceIn(0, 255), u.coerceIn(0, 255), v.coerceIn(0, 255))
    }

    /**
     * Fill a MediaCodec input Image (YUV_420_888) from an ARGB bitmap.
     * Handles both planar and semi-planar layouts via pixelStride.
     */
    fun fillYuv420(image: Image, bmp: Bitmap) {
        val w = bmp.width
        val h = bmp.height
        val planes = image.planes
        val yPlane = planes[0]
        val uPlane = planes[1]
        val vPlane = planes[2]
        val yBuf = yPlane.buffer; val uBuf = uPlane.buffer; val vBuf = vPlane.buffer
        val yRow = yPlane.rowStride; val yPix = maxOf(1, yPlane.pixelStride)
        val uRow = uPlane.rowStride; val uPix = maxOf(1, uPlane.pixelStride)
        val vRow = vPlane.rowStride; val vPix = maxOf(1, vPlane.pixelStride)

        val px = IntArray(w)
        // luma
        for (j in 0 until h) {
            bmp.getPixels(px, 0, w, 0, j, w, 1)
            var off = j * yRow
            for (i in 0 until w) {
                val c = px[i]
                val y = ((66 * (c shr 16 and 0xFF) + 129 * (c shr 8 and 0xFF) + 25 * (c and 0xFF) + 128) shr 8) + 16
                yBuf.put(off, y.coerceIn(0, 255).toByte())
                off += yPix
            }
        }
        // chroma (2x2 subsampled)
        val cw = (w + 1) / 2
        val ch = (h + 1) / 2
        for (j in 0 until ch) {
            for (i in 0 until cw) {
                val c0 = bmp.getPixel(i * 2, j * 2)
                val c1 = if (i * 2 + 1 < w) bmp.getPixel(i * 2 + 1, j * 2) else c0
                val c2 = if (j * 2 + 1 < h) bmp.getPixel(i * 2, j * 2 + 1) else c0
                val c3 = if (i * 2 + 1 < w && j * 2 + 1 < h) bmp.getPixel(i * 2 + 1, j * 2 + 1) else c0
                val r = ((c0 shr 16 and 0xFF) + (c1 shr 16 and 0xFF) + (c2 shr 16 and 0xFF) + (c3 shr 16 and 0xFF)) shr 2
                val g = ((c0 shr 8 and 0xFF) + (c1 shr 8 and 0xFF) + (c2 shr 8 and 0xFF) + (c3 shr 8 and 0xFF)) shr 2
                val b = ((c0 and 0xFF) + (c1 and 0xFF) + (c2 and 0xFF) + (c3 and 0xFF)) shr 2
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                uBuf.put(j * uRow + i * uPix, u.coerceIn(0, 255).toByte())
                vBuf.put(j * vRow + i * vPix, v.coerceIn(0, 255).toByte())
            }
        }
    }

    // ---------------- the recorder ----------------

    class RecordResult(val ok: Boolean, val message: String, val outFile: File? = null, val frames: Int = 0)

    suspend fun record(
        context: Context,
        htmlFile: File,
        outFile: File,
        params: Params = Params(),
        onProgress: (frame: Int, total: Int) -> Unit = { _, _ -> }
    ): RecordResult {
        // 1) static determinism gate
        val html = htmlFile.readText()
        MotionStudio.exportReadiness(html)?.let { return RecordResult(false, it) }

        val main = Handler(Looper.getMainLooper())
        var webView: WebView? = null
        try {
            return withContext(Dispatchers.Main) {
                val wv = WebView(context.applicationContext)
                webView = wv
                wv.settings.javaScriptEnabled = true
                wv.settings.mediaPlaybackRequiresUserGesture = false
                wv.settings.allowFileAccess = true
                wv.setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null) // view.draw() must rasterize
                wv.layout(0, 0, params.width, params.height)
                wv.loadUrl(htmlFile.toURI().toString())

                // wait for the composition to declare itself ready
                val ready = withTimeoutOrNull(25_000L) {
                    while (true) {
                        val r = suspendCancellableCoroutine<String?> { cont ->
                            wv.evaluateJavascript("(window.__limanReady === true).toString()") { v ->
                                cont.resumeWith(Result.success(v))
                            }
                        }
                        if (r == "true") break
                        kotlinx.coroutines.delay(150)
                    }
                    true
                }
                if (ready != true) return@withContext RecordResult(false, "motion.html never signaled __limanReady (JS error? check with render_html first).")

                val durStr = suspendCancellableCoroutine<String?> { cont ->
                    wv.evaluateJavascript("window.__limanDuration()") { v -> cont.resumeWith(Result.success(v)) }
                }
                val duration = durStr?.trim('"')?.toDoubleOrNull()
                    ?: return@withContext RecordResult(false, "window.__limanDuration() did not return a number.")
                if (duration <= 0.0 || duration > params.maxDurationSeconds)
                    return@withContext RecordResult(false, "duration $duration s is out of range (0 < d <= ${params.maxDurationSeconds}).")

                val totalFrames = frameCount(duration, params.fps)

                // 2) encoder + muxer (bit-exact timestamps we control)
                val encoder = MediaCodec.createEncoderByType("video/avc")
                val format = MediaFormat.createVideoFormat("video/avc", params.width, params.height).apply {
                    setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                    setInteger(MediaFormat.KEY_BIT_RATE, params.bitrate)
                    setInteger(MediaFormat.KEY_FRAME_RATE, params.fps)
                    setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                }
                encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                encoder.start()

                val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                var trackIndex = -1
                var muxerStarted = false
                val info = MediaCodec.BufferInfo()
                var encodeError: Exception? = null

                // drain on a dedicated thread
                val drainThread = Thread {
                    try {
                        while (true) {
                            val idx = encoder.dequeueOutputBuffer(info, 10_000)
                            when {
                                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                                    trackIndex = muxer.addTrack(encoder.outputFormat)
                                    muxer.start()
                                    muxerStarted = true
                                }
                                idx >= 0 -> {
                                    val buf = encoder.getOutputBuffer(idx)
                                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                                    if (info.size > 0 && muxerStarted && buf != null) {
                                        muxer.writeSampleData(trackIndex, buf, info)
                                    }
                                    encoder.releaseOutputBuffer(idx, false)
                                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                                }
                            }
                        }
                    } catch (e: Exception) {
                        encodeError = e
                    }
                }
                drainThread.start()

                // 3) deterministic frame loop
                val bmp = Bitmap.createBitmap(params.width, params.height, Bitmap.Config.ARGB_8888)
                val canvas = android.graphics.Canvas(bmp)
                var frame = 0
                try {
                    while (frame < totalFrames) {
                        val t = frame.toDouble() / params.fps
                        suspendCancellableCoroutine<Unit> { cont ->
                            wv.evaluateJavascript("window.__limanSeek($t)") { _ -> cont.resumeWith(Result.success(Unit)) }
                        }
                        // one layout/raster beat for the software canvas
                        wv.invalidate()
                        kotlinx.coroutines.delay(12)
                        canvas.drawColor(0xFF000000.toInt())
                        wv.draw(canvas)
                        // feed the encoder with a timestamp WE choose
                        while (true) {
                            val idx = encoder.dequeueInputBuffer(20_000)
                            if (idx >= 0) {
                                val image = encoder.getInputImage(idx)
                                if (image != null) fillYuv420(image, bmp)
                                encoder.queueInputBuffer(
                                    idx, 0, image?.let { (it.width * it.height * 3) / 2 } ?: 0,
                                    presentationUs(frame, params.fps), 0
                                )
                                break
                            }
                        }
                        frame++
                        onProgress(frame, totalFrames)
                    }
                } finally {
                    // signal EOS + drain
                    val idx = encoder.dequeueInputBuffer(60_000)
                    if (idx >= 0) encoder.queueInputBuffer(idx, 0, 0, presentationUs(frame, params.fps), MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    drainThread.join(30_000)
                    if (muxerStarted) {
                        muxer.stop()
                    }
                    muxer.release()
                    encoder.stop()
                    encoder.release()
                }
                encodeError?.let { return@withContext RecordResult(false, "encoder failed: ${it.message}") }
                RecordResult(true, "recorded $frame frame(s)", outFile, frame)
            }
        } catch (e: Exception) {
            return RecordResult(false, "record failed: ${e.message ?: e.toString()}")
        } finally {
            main.post { webView?.destroy() }
        }
    }
}
