package com.liman.agent.agent

/**
 * v2.36.0 — TERMUX CODE RUNNER SCRIPTS.
 *
 * "Fix the termux bridge — the agent must be able to write ANY program,
 * from python to everything else, and run it." This object builds the bash
 * scripts the Termux bridge executes: the source is embedded as a heredoc
 * into `~/agent-workspace`, the interpreter is auto-installed via pkg when
 * missing, the program runs with stdin, and the exit code is echoed back
 * inside a parseable marker.
 *
 * Non-interactive hardening everywhere (CI=1, DEBIAN_FRONTEND=noninteractive,
 * no pagers) per the Termux bridge guide — commands must never hang waiting
 * for a human keypress.
 *
 * Pure Kotlin — unit-tested (TermuxScriptsTest).
 */
object TermuxScripts {

    const val EOF = "__LIMAN_EOF_7Q4X__"
    const val EXIT = "__LIMAN_EXIT_7Q4X__"

    private val ANSI = Regex("\u001B\\[[0-9;?]*[A-Za-z]|\u001B\\][^\u0007]*\u0007|\u001B[()][A-B0-9]")

    data class Runner(
        val ext: String,
        /** auto-install probe: use if present, pkg install if not */
        val probe: String,
        /** the run command (file is always main.<ext> in ~/agent-workspace) */
        val run: String
    )

    fun runnerFor(language: String): Runner? = when (language) {
        "python" -> Runner(
            "py",
            "command -v python >/dev/null 2>&1 || command -v python3 >/dev/null 2>&1 || pkg install -y python",
            "PY=\$(command -v python || command -v python3); \"\$PY\" main.py"
        )
        "node" -> Runner(
            "js",
            "command -v node >/dev/null 2>&1 || pkg install -y nodejs",
            "node main.js"
        )
        "typescript" -> Runner(
            "ts",
            "command -v node >/dev/null 2>&1 || pkg install -y nodejs",
            "npx -y tsx main.ts"
        )
        "c" -> Runner(
            "c",
            "command -v clang >/dev/null 2>&1 || pkg install -y clang",
            "clang main.c -o main.bin && ./main.bin"
        )
        "cpp" -> Runner(
            "cpp",
            "command -v clang++ >/dev/null 2>&1 || pkg install -y clang",
            "clang++ main.cpp -o main.bin && ./main.bin"
        )
        "go" -> Runner(
            "go",
            "command -v go >/dev/null 2>&1 || pkg install -y golang",
            "go run main.go"
        )
        "rust" -> Runner(
            "rs",
            "command -v rustc >/dev/null 2>&1 || pkg install -y rust",
            "rustc main.rs -o main.bin && ./main.bin"
        )
        "ruby" -> Runner("rb", "command -v ruby >/dev/null 2>&1 || pkg install -y ruby", "ruby main.rb")
        "php" -> Runner("php", "command -v php >/dev/null 2>&1 || pkg install -y php", "php main.php")
        "perl" -> Runner("pl", "command -v perl >/dev/null 2>&1 || pkg install -y perl", "perl main.pl")
        "lua" -> Runner("lua", "command -v lua >/dev/null 2>&1 || pkg install -y lua", "lua main.lua")
        "r" -> Runner("R", "command -v Rscript >/dev/null 2>&1 || pkg install -y r-base", "Rscript main.R")
        "java" -> Runner(
            "java",
            "command -v java >/dev/null 2>&1 || pkg install -y openjdk-17",
            // JDK 11+ single-file launcher: compiles and runs ANY class name
            "java main.java"
        )
        "kotlin" -> Runner(
            "kt",
            "command -v kotlinc >/dev/null 2>&1 || pkg install -y kotlin",
            "kotlinc main.kt -include-runtime -d main.jar && java -jar main.jar"
        )
        else -> null
    }

    fun supportedLanguages(): String =
        "python, node, typescript, c, cpp, go, rust, ruby, php, perl, lua, r, java, kotlin"

    /**
     * The full Termux script for one run_code call. Returns null when the
     * language has no runner or the code collides with the heredoc delimiter
     * (caller falls back to the online runner).
     */
    fun runCodeScript(language: String, code: String, stdin: String): String? {
        if (code.contains(EOF)) return null
        val r = runnerFor(language) ?: return null
        val quotedStdin = "'" + stdin.replace("'", "'\\''") + "'"
        return buildString {
            appendLine("export CI=1 DEBIAN_FRONTEND=noninteractive PAGER=cat GIT_PAGER=cat TERM=dumb")
            appendLine("W=\"${'$'}HOME/agent-workspace\"; mkdir -p \"${'$'}W\"; cd \"${'$'}W\"")
            appendLine("cat > 'main.${r.ext}' <<'$EOF'")
            appendLine(code)
            appendLine(EOF)
            appendLine(r.probe)
            if (stdin.isNotBlank()) appendLine("printf '%s' $quotedStdin | ${r.run}")
            else appendLine(r.run)
            appendLine("echo \"$EXIT\$?\"")
        }
    }

    /** Split the bridge output into (body, exitCode). */
    fun parseExit(out: String): Pair<String, Int> {
        val stripped = stripAnsi(out)
        val m = Regex(Regex.escape(EXIT) + "(\\d+)").find(stripped)
        return if (m != null) {
            stripped.substring(0, m.range.first).trim() to (m.groupValues[1].toIntOrNull() ?: 1)
        } else {
            stripped.trim() to 1
        }
    }

    /** Strip ANSI color/escape codes so the model sees clean text. */
    fun stripAnsi(s: String): String = s.replace(ANSI, "")
}
