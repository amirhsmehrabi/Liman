package com.liman.agent.util

/**
 * Tiny i18n layer: EN / FA UI strings + Persian detection.
 *
 * Usage: `val t = Str(lang); t.send` — every screen composes Str from the
 * current settings language. Persian text rendering (RTL) is applied
 * per-message via [isPersian].
 */
class Str(val fa: Boolean) {

    private fun s(en: String, faText: String) = if (fa) faText else en

    // ---- chat ----
    val appTitle get() = s("Liman Agent", "ایجنت لیمان")
    val tagline get() = s(
        "An autonomous AI agent in your pocket.",
        "یک ایجنت هوش‌مصنوعی خودکار در جیب شما."
    )
    val tagline2 get() = s(
        "It plans, uses tools, checks its own work, and never gives up when a provider fails.",
        "برنامه‌ریزی می‌کند، از ابزار استفاده می‌کند، کارش را خودش بررسی می‌کند و هیچ‌وقت تسلیم نمی‌شود."
    )
    val inputHint get() = s("Give Liman a task…", "یک کار به لیمان بده…")
    val workingHint get() = s("Liman is working…", "لیمان در حال کار است…")
    val thinking get() = s("Liman is thinking", "لیمان در حال فکر کردن است")
    val stop get() = s("Stop", "توقف")
    val send get() = s("Send", "ارسال")
    val attach get() = s("Attach files", "پیوست فایل")
    val mic get() = s("Voice input", "ورودی صوتی")
    val workspace get() = s("Workspace", "فضای کار")
    val open get() = s("Open", "باز کردن")
    val view get() = s("View", "مشاهده")
    val share get() = s("Share", "اشتراک")
    val delete get() = s("Delete", "حذف")
    val install get() = s("Install", "نصب")
    val importFile get() = s("Import", "درون‌ریزی")
    val copy get() = s("Copy", "کپی")
    val copied get() = s("Copied", "کپی شد")
    val jumpLatest get() = s("Jump to latest", "رفتن به آخر")
    val readAloud get() = s("Read aloud", "بلندخوانی")
    val welcomeTitle get() = s("Make room for a good idea.", "برای یک ایدهٔ خوب جا باز کن.")
    val welcomeSub get() = s("Draft, explain, and explore ideas with your agent.", "بنویس، توضیح بده و ایده‌ها را با ایجنتت کاوش کن.")
    val attachNext get() = s("Attach to next message", "پیوست به پیام بعدی")
    val addedToMsg get() = s("Added to the next message", "به پیام بعدی اضافه شد")
    val noInstaller get() = s("No installer found", "نصب‌کننده‌ای پیدا نشد")
    val cannotOpen get() = s("Cannot open this file", "نمی‌توان این فایل را باز کرد")
    val noAppOpen get() = s("No app can open this file", "برنامه‌ای برای باز کردن این فایل نیست")
    val fileMenu get() = s("File", "فایل")
    val renameTask get() = s("Rename task", "تغییر نام گفتگو")
    val exportMd get() = s("Export as Markdown", "خروجی Markdown")
    val clearConv get() = s("Clear this conversation", "پاک کردن این گفتگو")
    val task get() = s("Task", "گفتگو")
    val save get() = s("Save", "ذخیره")
    val cancel get() = s("Cancel", "لغو")
    val allow get() = s("Allow", "اجازه")
    val alwaysAllow get() = s("Always", "همیشه")
    val deny get() = s("Deny", "رد")
    val limanAsks get() = s("Liman asks", "لیمان می‌پرسد")
    val answer get() = s("Answer", "پاسخ")
    val skip get() = s("Skip", "رد کردن")
    val allowTool get() = s("Allow this tool?", "اجازهٔ اجرای این ابزار؟")
    val agentWants get() = s("The agent wants to run this tool:", "ایجنت می‌خواهد این ابزار را اجرا کند:")

    // ---- empty state suggestions ----
    val suggestions: List<Pair<String, String>> get() = listOf(
        s("Research the latest news about a topic and summarize with sources",
          "جدیدترین اخبار یک موضوع را پیدا و با منابع خلاصه کن") to "ic_web_search",
        s("Build me a small app and give me the APK",
          "برایم یک اپ کوچک بساز و فایل APK بده") to "ic_build_apk",
        s("Analyze this Excel file and find the top rows by revenue",
          "این فایل اکسل را تحلیل کن و ردیف‌های برتر را پیدا کن") to "ic_read_file",
        s("Generate an image, then critique it yourself",
          "یک تصویر بساز و خودت نقدش کن") to "ic_image_generate"
    )

    // ---- settings ----
    val settings get() = s("Settings", "تنظیمات")
    val language get() = s("Language", "زبان")
    val langSystem get() = s("System default", "پیش‌فرض سیستم")
    val english get() = s("English", "English")
    val persian get() = s("فارسی", "فارسی")
    val permissions get() = s("Permissions", "مجوزها")
    val permissionsDesc get() = s("Control what the agent may do without asking",
        "کنترل اینکه ایجنت بدون اجازه چه کارهایی می‌تواند بکند")
    val allowAlways get() = s("Always allow", "همیشه اجازه")
    val askEveryTime get() = s("Ask every time", "هر بار بپرس")
    val alwaysDeny get() = s("Always deny", "همیشه رد")
    val storageAccess get() = s("Storage access", "دسترسی به فایل‌ها")
    val storageDesc get() = s("Grant folders the agent can read and edit",
        "پوشه‌هایی که ایجنت می‌تواند بخواند و ویرایش کند")
    val grantFolder get() = s("Grant folder access", "اجازهٔ دسترسی به پوشه")
    val noRoots get() = s("No folders granted yet", "هنوز پوشه‌ای اجازه داده نشده")
    val revoke get() = s("Revoke", "لغو دسترسی")
    val userProfile get() = s("User profile", "پروفایل شما")
    val profileDesc get() = s("What Liman has learned about you (editable)",
        "چیزهایی که لیمان دربارهٔ شما یاد گرفته (قابل ویرایش)")
    val profileEmpty get() = s("Nothing yet — the agent learns as you work together",
        "هنوز چیزی نیست — ایجنت همراه کار کردن یاد می‌گیرد")
    val edit get() = s("Edit", "ویرایش")
    val providers get() = s("Providers", "سرویس‌دهنده‌ها")
    val models get() = s("models", "مدل")
    val freeBadge get() = s("FREE", "رایگان")
    val visionBadge get() = s("VISION", "تصویر")
    val searchModels get() = s("Search models…", "جستجوی مدل…")
    val freePool get() = s("Use all free models (auto combo)", "استفاده از همهٔ مدل‌های رایگان (ترکیب خودکار)")
    val freePoolDesc get() = s("Failover across every free model of this provider",
        "جابه‌جایی خودکار بین همهٔ مدل‌های رایگان این سرویس")
    val checkKeyModels get() = s("Check key & list models", "بررسی کلید و فهرست مدل‌ها")
    val remove get() = s("Remove", "حذف")
}

/** True if the text contains Persian/Arabic letters (→ render RTL). */
fun isPersian(text: String): Boolean {
    var arabic = 0
    var latin = 0
    for (c in text) {
        when (c.code) {
            in 0x0600..0x06FF, in 0x0750..0x077F, in 0xFB50..0xFDFF, in 0xFE70..0xFEFF -> arabic++
            in 0x41..0x5A, in 0x61..0x7A -> latin++
        }
    }
    return arabic > 0 && arabic >= latin
}
