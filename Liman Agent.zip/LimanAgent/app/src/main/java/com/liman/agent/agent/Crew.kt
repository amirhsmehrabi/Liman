package com.liman.agent.agent

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * v2.20.0 — CREW RUNS.
 *
 * Ported from two of the 8 reference frameworks:
 *  - **CrewAI** — role-based orchestration: agents defined as team members
 *    (role / goal / backstory), tasks with expected outputs, `context`
 *    chaining (each task sees its teammates' outputs), and processes:
 *    SEQUENTIAL (linear hand-off) vs HIERARCHICAL (a manager agent plans
 *    and delegates dynamically).
 *  - **AutoGen** — conversational team termination conditions:
 *    TextMentionTermination (a worker replies "TERMINATE: reason" → the run
 *    ends) and MaxMessage-style hard caps (max tasks).
 *
 * Plus Agno's third mode: BROADCAST (parallel independent evaluation — all
 * workers get the same goal, outputs merge).
 *
 * Pure planning/parse logic only (unit-testable); execution lives in
 * Tools.execTeamRun and uses Liman's own subagent machinery.
 */
data class CrewRole(
    val role: String,
    val goal: String,
    val backstory: String
)

data class CrewTask(
    val description: String,
    val agent: String?,
    val expectedOutput: String?
)

data class CrewPlan(
    val goal: String,
    val process: String,                 // sequential | broadcast | hierarchical
    val roles: List<CrewRole>,
    val tasks: List<CrewTask>,
    val maxTasks: Int
) {
    /** Match a task's `agent` to a roster role (case-insensitive, either direction). */
    fun roleFor(task: CrewTask): CrewRole? {
        val a = task.agent?.trim()?.lowercase() ?: return null
        if (a.isEmpty()) return null
        return roles.firstOrNull { r ->
            val rn = r.role.trim().lowercase()
            rn.isNotEmpty() && (rn == a || rn.contains(a) || a.contains(rn))
        }
    }
}

object CrewPlanner {

    const val TERMINATE = "TERMINATE"

    fun parse(args: JsonObject): CrewPlan? {
        val goal = args["goal"].strOrNull()?.trim()?.takeIf { it.isNotBlank() } ?: return null
        val tasksJson = args["tasks"] as? JsonArray ?: return null
        val tasks = tasksJson.mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val d = o["description"].strOrNull()?.trim()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            CrewTask(
                description = d.take(2000),
                agent = o["agent"].strOrNull()?.trim()?.takeIf { it.isNotBlank() },
                expectedOutput = o["expected_output"].strOrNull()?.trim()?.takeIf { it.isNotBlank() }?.take(500)
            )
        }
        if (tasks.isEmpty()) return null
        val roles = ((args["roles"] as? JsonArray) ?: emptyList()).mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val r = o["role"].strOrNull()?.trim()?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            CrewRole(
                role = r.take(80),
                goal = o["goal"].strOrNull()?.trim().orEmpty().take(400),
                backstory = o["backstory"].strOrNull()?.trim().orEmpty().take(400)
            )
        }
        val process = (args["process"].strOrNull()?.trim()?.lowercase() ?: "sequential")
            .takeIf { it in setOf("sequential", "broadcast", "hierarchical") } ?: "sequential"
        val maxTasks = (args["max_tasks"].strOrNull()?.toIntOrNull() ?: 6).coerceIn(1, 12)
        return CrewPlan(goal.take(1500), process, roles, tasks.take(24), maxTasks)
    }

    /** The worker brief (CrewAI agent definition + task + chained context). */
    fun brief(plan: CrewPlan, task: CrewTask, context: String): String = buildString {
        appendLine("You are one worker in a crew solving a larger goal. Do YOUR task only.")
        appendLine("CREW GOAL: ${plan.goal}")
        val role = plan.roleFor(task)
        if (role != null) {
            appendLine("YOUR ROLE: ${role.role}")
            if (role.goal.isNotBlank()) appendLine("ROLE GOAL: ${role.goal}")
            if (role.backstory.isNotBlank()) appendLine("BACKSTORY: ${role.backstory}")
        }
        appendLine("YOUR TASK: ${task.description}")
        if (!task.expectedOutput.isNullOrBlank()) appendLine("EXPECTED OUTPUT: ${task.expectedOutput}")
        if (context.isNotBlank()) {
            appendLine("CONTEXT (earlier teammates' outputs — build on them, do NOT redo them):")
            appendLine(context)
        }
        appendLine("RULES: Work independently with your tools. Deliver only your task's output. " +
            "If you truly cannot proceed, reply exactly: TERMINATE: <one-line reason>.")
    }

    /** AutoGen TextMentionTermination: a worker asked to stop the run. */
    fun isTerminate(output: String): Boolean =
        Regex("(^|[^A-Z])TERMINATE(:|\\s|\$)").containsMatchIn(output)

    fun terminateReason(output: String): String {
        val m = Regex("TERMINATE\\s*:\\s*(.+)").find(output) ?: return "worker requested stop"
        return m.groupValues[1].take(200)
    }

    /**
     * HIERARCHICAL mode: parse the manager's execution plan ("one line per
     * step: <agent> :: <task>") into an ordered task list. Falls back to the
     * original order when nothing parses.
     */
    fun parseManagerPlan(planText: String, plan: CrewPlan): List<CrewTask> {
        val lineRe = Regex("^\\s*(?:\\d+[.)]\\s*)?([^:]{1,80}?)\\s*::\\s*(.+?)\\s*$")
        val ordered = mutableListOf<CrewTask>()
        val used = HashSet<Int>()
        planText.lineSequence().forEach { line ->
            val m = lineRe.find(line) ?: return@forEach
            val agent = m.groupValues[1].trim()
            val desc = m.groupValues[2].trim()
            if (desc.length < 4) return@forEach
            // reuse the proposed task whose description matches best, else ad-hoc
            val idx = plan.tasks.indexOfFirst { t ->
                !used.contains(plan.tasks.indexOf(t)) && (
                    t.description.contains(desc.take(40), ignoreCase = true) ||
                        desc.contains(t.description.take(40), ignoreCase = true) ||
                        (t.agent != null && t.agent.contains(agent, true))
                    )
            }
            if (idx >= 0) {
                used += idx
                ordered += plan.tasks[idx]
            } else {
                ordered += CrewTask(description = desc.take(2000), agent = agent.take(80), expectedOutput = null)
            }
        }
        return ordered.ifEmpty { plan.tasks }.take(plan.maxTasks)
    }

    /** The manager brief for hierarchical mode. */
    fun managerBrief(plan: CrewPlan): String = buildString {
        appendLine("You are the MANAGER of a worker crew (CrewAI hierarchical process).")
        appendLine("CREW GOAL: ${plan.goal}")
        appendLine("ROSTER:")
        if (plan.roles.isEmpty()) appendLine("- (generic workers — assign plain descriptions)")
        else plan.roles.forEach { r ->
            appendLine("- ${r.role}" + if (r.goal.isNotBlank()) " — ${r.goal}" else "")
        }
        appendLine("PROPOSED TASKS:")
        plan.tasks.forEachIndexed { i, t -> appendLine("${i + 1}. ${t.description.take(200)}") }
        appendLine("Return ONLY an ordered execution plan, one line per step, max ${plan.maxTasks} lines:")
        appendLine("<agent> :: <task description>")
        appendLine("Rules: use roster roles where they fit; merge or split tasks as the goal requires; each step must be one concrete deliverable. No other text.")
    }

    private fun kotlinx.serialization.json.JsonElement?.strOrNull(): String? =
        (this as? JsonPrimitive)?.content
}
