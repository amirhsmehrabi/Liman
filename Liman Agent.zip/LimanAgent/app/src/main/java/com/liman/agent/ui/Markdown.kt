package com.liman.agent.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.ui.text.withStyle
import com.liman.agent.R
import com.liman.agent.util.isPersian

/**
 * Compact Markdown renderer for chat messages.
 *
 * Supports: # headings, **bold**, *italic*, `inline code`, ``` code blocks
 * with language label + copy button, dash and star bullet lists, 1. ordered lists,
 * > quotes, --- rules, [links](url), ~~strike~~, and simple | tables |
 * (rendered as aligned monospace rows on narrow screens).
 *
 * The parser is pure Kotlin → unit-testable (MarkdownTest).
 */

// ============================================================
// Parser (pure)
// ============================================================

sealed class MdBlock {
    data class Heading(val level: Int, val inline: List<MdSpan>) : MdBlock()
    data class Paragraph(val inline: List<MdSpan>) : MdBlock()
    data class CodeBlock(val lang: String, val code: String) : MdBlock()
    data class BulletList(val items: List<List<MdSpan>>) : MdBlock()
    data class OrderedList(val items: List<List<MdSpan>>) : MdBlock()
    data class Quote(val inline: List<MdSpan>) : MdBlock()
    data class TaskList(val items: List<TaskItem>) : MdBlock()
    data class Rule(val inline: List<MdSpan>) : MdBlock()
    data class Table(val header: List<String>, val rows: List<List<String>>) : MdBlock()
}

sealed class MdSpan {
    data class Plain(val text: String) : MdSpan()
    /** v2.31 — ==highlight== : the important-part marker. */
    data class Highlight(val text: String) : MdSpan()
    data class Bold(val text: String) : MdSpan()
    data class Italic(val text: String) : MdSpan()
    data class Strike(val text: String) : MdSpan()
    data class Code(val text: String) : MdSpan()
    data class Link(val text: String, val url: String) : MdSpan()
}

object MarkdownParser {

    fun parse(md: String): List<MdBlock> {
        val out = ArrayList<MdBlock>()
        val lines = md.replace("\r\n", "\n").split("\n")
        var i = 0
        val para = StringBuilder()

        fun flushPara() {
            val t = para.toString().trim()
            para.clear()
            if (t.isNotEmpty()) out.add(MdBlock.Paragraph(parseInline(t)))
        }

        while (i < lines.size) {
            val raw = lines[i]
            val line = raw.trimEnd()
            val trimmed = line.trim()

            // fenced code block
            if (trimmed.startsWith("```")) {
                flushPara()
                val lang = trimmed.removePrefix("```").trim()
                val body = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) {
                    body.appendLine(lines[i])
                    i++
                }
                i++ // closing fence (or EOF)
                out.add(MdBlock.CodeBlock(lang, body.toString().trimEnd('\n')))
                continue
            }

            // horizontal rule
            if (trimmed matches Regex("(-{3,}|\\*{3,}|_{3,})")) {
                flushPara()
                out.add(MdBlock.Rule(emptyList()))
                i++
                continue
            }

            // heading
            val hm = Regex("^(#{1,6})\\s+(.*)$").find(trimmed)
            if (hm != null) {
                flushPara()
                out.add(MdBlock.Heading(hm.groupValues[1].length, parseInline(hm.groupValues[2])))
                i++
                continue
            }

            // table (| a | b | with a separator row next)
            if (trimmed.startsWith("|") && i + 1 < lines.size &&
                Regex("^\\|?[\\s:|-]+\\|?$").matches(lines[i + 1].trim()) &&
                lines[i + 1].contains("-")
            ) {
                flushPara()
                val header = splitRow(trimmed)
                i += 2
                val rows = ArrayList<List<String>>()
                while (i < lines.size && lines[i].trim().startsWith("|")) {
                    rows.add(splitRow(lines[i].trim()))
                    i++
                }
                out.add(MdBlock.Table(header, rows))
                continue
            }

            // quote
            if (trimmed.startsWith(">")) {
                flushPara()
                val q = StringBuilder()
                while (i < lines.size && lines[i].trim().startsWith(">")) {
                    q.append(lines[i].trim().removePrefix(">").trim()).append(' ')
                    i++
                }
                out.add(MdBlock.Quote(parseInline(q.toString().trim())))
                continue
            }

            // v2.31 — task list (- [ ] / - [x]) — checked-off roadmap items
            if (Regex("^[-*+]\\s+\\[[ xX]\\]\\s+").containsMatchIn(trimmed)) {
                flushPara()
                val items = ArrayList<TaskItem>()
                while (i < lines.size && Regex("^[-*+]\\s+\\[[ xX]\\]\\s+").containsMatchIn(lines[i].trim())) {
                    val m = Regex("^[-*+]\\s+\\[([ xX])\\]\\s+(.*)$").find(lines[i].trim())!!
                    items.add(TaskItem(m.groupValues[1].equals("x", true), parseInline(m.groupValues[2])))
                    i++
                }
                out.add(MdBlock.TaskList(items))
                continue
            }

            // bullet list
            if (Regex("^[-*+]\\s+").containsMatchIn(trimmed)) {
                flushPara()
                val items = ArrayList<List<MdSpan>>()
                while (i < lines.size && Regex("^[-*+]\\s+").containsMatchIn(lines[i].trim())) {
                    items.add(parseInline(Regex("^[-*+]\\s+").replace(lines[i].trim(), "")))
                    i++
                }
                out.add(MdBlock.BulletList(items))
                continue
            }

            // ordered list
            if (Regex("^\\d+[.)]\\s+").containsMatchIn(trimmed)) {
                flushPara()
                val items = ArrayList<List<MdSpan>>()
                while (i < lines.size && Regex("^\\d+[.)]\\s+").containsMatchIn(lines[i].trim())) {
                    items.add(parseInline(Regex("^\\d+[.)]\\s+").replace(lines[i].trim(), "")))
                    i++
                }
                out.add(MdBlock.OrderedList(items))
                continue
            }

            // blank line → paragraph break
            if (trimmed.isEmpty()) {
                flushPara()
                i++
                continue
            }

            para.appendLine(line)
            i++
        }
        flushPara()
        return out
    }

    private fun splitRow(row: String): List<String> =
        row.removePrefix("|").removeSuffix("|").split("|").map { it.trim() }

    /** Inline parsing: `code`, **bold**, *italic*, ~~strike~~, [text](url). */
    fun parseInline(text: String): List<MdSpan> {
        val spans = ArrayList<MdSpan>()
        var i = 0
        val sb = StringBuilder()

        fun flush() {
            if (sb.isNotEmpty()) {
                spans.add(MdSpan.Plain(sb.toString()))
                sb.clear()
            }
        }

        while (i < text.length) {
            val rest = text.substring(i)
            when {
                rest.startsWith("`") -> {
                    val end = text.indexOf('`', i + 1)
                    if (end > i) {
                        flush()
                        spans.add(MdSpan.Code(text.substring(i + 1, end)))
                        i = end + 1
                    } else { sb.append(text[i]); i++ }
                }
                rest.startsWith("==") -> {
                    val end = text.indexOf("==", i + 2)
                    // ==real highlight== only: content non-empty and not
                    // space-padded — "a == b == c" stays literal text
                    val content = if (end > i + 2) text.substring(i + 2, end) else ""
                    if (content.isNotBlank() && !content.startsWith(" ") && !content.endsWith(" ")) {
                        flush()
                        spans.add(MdSpan.Highlight(content))
                        i = end + 2
                    } else { sb.append(text[i]); i++ }
                }
                rest.startsWith("**") || rest.startsWith("__") -> {
                    val marker = rest.substring(0, 2)
                    val end = text.indexOf(marker, i + 2)
                    if (end > i + 1) {
                        flush()
                        spans.add(MdSpan.Bold(text.substring(i + 2, end)))
                        i = end + 2
                    } else { sb.append(text[i]); i++ }
                }
                rest.startsWith("~~") -> {
                    val end = text.indexOf("~~", i + 2)
                    if (end > i + 1) {
                        flush()
                        spans.add(MdSpan.Strike(text.substring(i + 2, end)))
                        i = end + 2
                    } else { sb.append(text[i]); i++ }
                }
                rest.startsWith("*") || rest.startsWith("_") -> {
                    val m = rest[0]
                    if (i + 1 < text.length && !text[i + 1].isWhitespace()) {
                        val end = text.indexOf(m, i + 1)
                        if (end > i + 1) {
                            flush()
                            spans.add(MdSpan.Italic(text.substring(i + 1, end)))
                            i = end + 1
                            continue
                        }
                    }
                    sb.append(text[i]); i++
                }
                rest.startsWith("[") -> {
                    val close = text.indexOf("](", i)
                    if (close > i) {
                        val end = text.indexOf(')', close)
                        if (end > close) {
                            flush()
                            spans.add(MdSpan.Link(text.substring(i + 1, close), text.substring(close + 2, end)))
                            i = end + 1
                            continue
                        }
                    }
                    sb.append(text[i]); i++
                }
                else -> { sb.append(text[i]); i++ }
            }
        }
        flush()
        return spans
    }
}

// ============================================================
// Renderer (Compose)
// ============================================================

@Composable
fun MarkdownText(
    md: String,
    modifier: Modifier = Modifier,
    color: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Unspecified,
    onLink: ((String) -> Unit)? = null
) {
    val blocks = remember(md) { MarkdownParser.parse(md) }
    // v2.26.0: RTL is decided PER BLOCK (see MdBlockView) — a Persian
    // paragraph inside a mostly-English message (or an English paragraph
    // inside a Persian one) now lays out correctly, English words included.
    androidx.compose.foundation.layout.Column(modifier = modifier) {
        blocks.forEach { b -> MdBlockView(b, color, onLink) }
    }
}

data class TaskItem(val checked: Boolean, val spans: List<MdSpan>)

/** Plain text of a span list — used for per-block Persian detection. */
private fun spanText(spans: List<MdSpan>): String = buildString {
    for (s in spans) {
        when (s) {
            is MdSpan.Plain -> append(s.text)
            is MdSpan.Bold -> append(s.text)
            is MdSpan.Highlight -> append(s.text)
            is MdSpan.Italic -> append(s.text)
            is MdSpan.Strike -> append(s.text)
            is MdSpan.Code -> append(' ')
            is MdSpan.Link -> append(s.text)
        }
    }
}

/** Wrap a block in RTL layout when its own text is Persian. */
@Composable
private fun RtlIfPersian(text: String, content: @Composable () -> Unit) {
    if (remember(text) { isPersian(text) }) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { content() }
    } else content()
}

@Composable
private fun MdBlockView(b: MdBlock, color: androidx.compose.ui.graphics.Color, onLink: ((String) -> Unit)?) {
    when (b) {
        is MdBlock.Heading -> {
            // v2.31 — expressive hierarchy: big bold titles, accent under H1/H2
            val style = when (b.level) {
                1 -> MaterialTheme.typography.headlineMedium.copy(fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                2 -> MaterialTheme.typography.titleLarge.copy(fontSize = 20.sp, fontWeight = FontWeight.Bold)
                3 -> MaterialTheme.typography.titleMedium.copy(fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                else -> MaterialTheme.typography.titleMedium.copy(fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            RtlIfPersian(spanText(b.inline)) {
                androidx.compose.foundation.layout.Column {
                    Text(
                        AnnotatedStringFromSpans(b.inline, color, onLink),
                        style = style,
                        color = if (color == androidx.compose.ui.graphics.Color.Unspecified)
                            MaterialTheme.colorScheme.onSurface else color,
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 3.dp)
                    )
                    if (b.level <= 2) {
                        Spacer(Modifier.height(3.dp))
                        androidx.compose.foundation.layout.Box(
                            Modifier
                                .width(if (b.level == 1) 44.dp else 28.dp)
                                .height(3.dp)
                                .background(
                                    MaterialTheme.colorScheme.primary,
                                    RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)
                                )
                        )
                    }
                }
            }
        }
        is MdBlock.Paragraph -> RtlIfPersian(spanText(b.inline)) {
            Text(
                AnnotatedStringFromSpans(b.inline, color, onLink),
                style = MaterialTheme.typography.bodyLarge,
                color = color,
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
            )
        }
        is MdBlock.TaskList -> b.items.forEach { item ->
            RtlIfPersian(spanText(item.spans)) {
                Row(
                    verticalAlignment = androidx.compose.ui.Alignment.Top,
                    modifier = Modifier.fillMaxWidth().padding(start = 2.dp, end = 4.dp, top = 3.dp, bottom = 3.dp)
                ) {
                    val mark = if (item.checked) "✅" else "⬜"
                    Text(mark, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.width(8.dp))
                    val taskStyle = if (item.checked)
                        MaterialTheme.typography.bodyLarge.copy(textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough)
                    else MaterialTheme.typography.bodyLarge
                    Text(
                        AnnotatedStringFromSpans(item.spans, color, onLink),
                        style = taskStyle,
                        color = if (item.checked) MaterialTheme.colorScheme.onSurfaceVariant else color
                    )
                }
            }
        }
        is MdBlock.CodeBlock -> CodeBlockView(b)
        is MdBlock.BulletList -> b.items.forEach {
            RtlIfPersian(spanText(it)) {
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 2.dp, bottom = 2.dp)) {
                    Text("•  ", style = MaterialTheme.typography.bodyLarge, color = androidx.compose.material3.MaterialTheme.colorScheme.primary)
                    Text(AnnotatedStringFromSpans(it, color, onLink), style = MaterialTheme.typography.bodyLarge, color = color)
                }
            }
        }
        is MdBlock.OrderedList -> b.items.forEachIndexed { idx, it ->
            RtlIfPersian(spanText(it)) {
                Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 2.dp, bottom = 2.dp)) {
                    Text("${idx + 1}.  ", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
                    Text(AnnotatedStringFromSpans(it, color, onLink), style = MaterialTheme.typography.bodyLarge, color = color)
                }
            }
        }
        is MdBlock.Quote -> Row(Modifier.height(IntrinsicSize.Min).padding(vertical = 3.dp)) {
            androidx.compose.foundation.layout.Box(
                Modifier
                    .width(3.dp)
                    .fillMaxHeight()
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.6f), RoundedCornerShape(2.dp))
            )
            Spacer(Modifier.width(8.dp))
            RtlIfPersian(spanText(b.inline)) {
                Text(
                    AnnotatedStringFromSpans(b.inline, color, onLink),
                    style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                    color = color
                )
            }
        }
        is MdBlock.Rule -> androidx.compose.material3.HorizontalDivider(
            modifier = Modifier.padding(vertical = 8.dp),
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
        )
        is MdBlock.Table -> {
            val mono = FontFamily.Monospace
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                androidx.compose.foundation.layout.Column(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(8.dp)
                ) {
                    Text(
                        b.header.joinToString("  |  "),
                        fontFamily = mono,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    b.rows.take(30).forEach { r ->
                        Text(r.joinToString("  |  "), fontFamily = mono, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun CodeBlockView(b: MdBlock.CodeBlock) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    Surface(
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.65f),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
    ) {
        androidx.compose.foundation.layout.Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 4.dp, top = 4.dp)
            ) {
                Text(
                    b.lang.ifBlank { "code" },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
                Spacer(Modifier.weight(1f))
                androidx.compose.material3.TextButton(onClick = {
                    clipboard.setText(AnnotatedString(b.code))
                    copied = true
                }) {
                    LimanIcon(
                        if (copied) R.drawable.ic_check else R.drawable.ic_copy,
                        if (copied) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        size = 14
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (copied) "Copied" else "Copy", style = MaterialTheme.typography.labelSmall)
                }
            }
            Text(
                b.code,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.5.sp,
                lineHeight = 19.sp,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp)
                    .padding(bottom = 10.dp)
            )
        }
    }
}

@Composable
private fun AnnotatedStringFromSpans(
    spans: List<MdSpan>,
    baseColor: androidx.compose.ui.graphics.Color,
    onLink: ((String) -> Unit)?
): AnnotatedString {
    // colors must be read in the composable context, not inside the builder
    val codeBg = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
    val linkColor = MaterialTheme.colorScheme.primary
    // v2.31 — ==highlight== : soft accent wash + bolded primary text
    val hlColor = MaterialTheme.colorScheme.primary
    return buildAnnotatedString {
        spans.forEach { sp ->
            when (sp) {
                is MdSpan.Plain -> append(sp.text)
                is MdSpan.Bold -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(sp.text) }
                is MdSpan.Italic -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(sp.text) }
                is MdSpan.Highlight -> withStyle(
                    SpanStyle(
                        color = hlColor,
                        fontWeight = FontWeight.SemiBold,
                        background = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                    )
                ) { append(sp.text) }
                is MdSpan.Strike -> withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough)) { append(sp.text) }
                is MdSpan.Code -> withStyle(
                    SpanStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, background = codeBg)
                ) { append(sp.text) }
                is MdSpan.Link -> {
                    pushStringAnnotation("url", sp.url)
                    withStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)) {
                        append(sp.text)
                    }
                    pop()
                }
            }
        }
    }
}
