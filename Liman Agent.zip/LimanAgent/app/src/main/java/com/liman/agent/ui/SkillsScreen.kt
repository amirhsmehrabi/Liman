package com.liman.agent.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liman.agent.LimanApplication
import com.liman.agent.R
import com.liman.agent.agent.SkillSystem
import com.liman.agent.util.fmtTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 🎯 Skills screen — Liman's self-improvement library.
 * Import, create, search the internet for, install, enable/disable and
 * inspect skills. Skills the agent discovers on its own land here too.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SkillsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = remember { LimanApplication.get(context) }
    val stores = app.container.stores
    val skills by stores.skills.state.collectAsState()
    val scope = rememberCoroutineScope()

    var searchOpen by remember { mutableStateOf(false) }
    var urlOpen by remember { mutableStateOf(false) }
    var createOpen by remember { mutableStateOf(false) }
    var viewing by remember { mutableStateOf<String?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var toast by remember { mutableStateOf<String?>(null) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val md = runCatching {
                    context.contentResolver.openInputStream(uri)?.use { ins ->
                        ins.readBytes().toString(Charsets.UTF_8)
                    }
                }.getOrNull()
                if (md != null && md.length > 10) {
                    val (name, desc, _) = com.liman.agent.agent.parseSkillMarkdown(md)
                    val finalName = name.ifBlank { uri.lastPathSegment?.substringAfterLast('/') ?: "imported skill" }
                    SkillSystem(stores).installFromMarkdown(finalName, desc, md, "file")
                    withContext(Dispatchers.Main) { toast = "Skill '$finalName' imported ✓" }
                } else {
                    withContext(Dispatchers.Main) { toast = "Could not read that file" }
                }
            }
        }
    }

    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    ),
                    navigationIcon = {
                        IconButton(onClick = onBack) { LimanIcon(R.drawable.ic_back, MaterialTheme.colorScheme.onSurface) }
                    },
                    title = { Text("🎯 Skills") }
                )
            }
        ) { pad ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    "Skills are reusable playbooks. Before each task the agent checks this library " +
                        "and auto-loads whatever fits — and it can search the internet for new ones on its own.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { searchOpen = true }) { Text("🔍 Search internet") }
                    OutlinedButton(onClick = { urlOpen = true }) { Text("🌐 From URL") }
                    OutlinedButton(onClick = { createOpen = true }) { Text("✏️ Create") }
                    OutlinedButton(onClick = { filePicker.launch(arrayOf("text/*", "application/*")) }) {
                        Text("📄 Import file")
                    }
                }
            }
            if (skills.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("No skills yet", fontWeight = FontWeight.Bold)
                            Text(
                                "Try “Search internet” with a topic like “pdf reports” or “web scraping” — " +
                                    "Liman will find SKILL.md packs (Claude Code / Hermes compatible) and install them.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            items(skills.size) { i ->
                val s = skills[i]
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    )
                ) {
                    Row(
                        Modifier.padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            Modifier
                                .weight(1f)
                                .padding(end = 6.dp)
                        ) {
                            Text(s.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (s.description.isNotBlank()) {
                                Text(
                                    s.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                buildString {
                                    append(s.sourceUrl.ifBlank { "created locally" }.take(60))
                                    append(" · used ${s.uses}×")
                                    if (s.installedAt > 0) append(" · ${s.installedAt.fmtTime()}")
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                        TextButton(onClick = { viewing = s.id }) { Text("View") }
                        Switch(
                            checked = s.enabled,
                            onCheckedChange = { stores.skills.setEnabled(s.id, it) }
                        )
                        IconButton(onClick = { deleteTarget = s.id }) {
                            Icon(
                                Icons.Filled.Delete, "Delete",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        }

        toast?.let { msg ->
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                LaunchedToast(msg) { toast = null }
            }
        }
    }

    // ---------- search & install dialog ----------
    if (searchOpen) {
        SearchSkillsDialog(
            onDismiss = { searchOpen = false },
            onInstalled = { name ->
                toast = "Skill '$name' installed ✓"
            }
        )
    }

    // ---------- URL install dialog ----------
    if (urlOpen) {
        var url by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var msg by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { urlOpen = false },
            title = { Text("Install skill from URL") },
            text = {
                Column {
                    Text(
                        "Paste a link to a SKILL.md (raw GitHub links work best).",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.size(8.dp))
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        label = { Text("https://…/SKILL.md") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    if (busy) Spacer(Modifier.size(8.dp))
                    if (busy) CircularProgressIndicator(Modifier.size(20.dp))
                    msg?.let {
                        Spacer(Modifier.size(8.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !busy && url.isNotBlank(),
                    onClick = {
                        busy = true
                        msg = null
                        scope.launch(Dispatchers.IO) {
                            val res = runCatching { SkillSystem(stores).installFromUrl(url) }
                            withContext(Dispatchers.Main) {
                                busy = false
                                res.fold(
                                    onSuccess = {
                                        msg = it
                                        url = ""
                                        toast = it
                                        urlOpen = false
                                    },
                                    onFailure = { msg = "✗ ${it.message?.take(160)}" }
                                )
                            }
                        }
                    }
                ) { Text("Install") }
            },
            dismissButton = { TextButton(onClick = { urlOpen = false }) { Text("Cancel") } }
        )
    }

    // ---------- create skill dialog ----------
    if (createOpen) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { createOpen = false },
            title = { Text("Create a skill") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("Skill name") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.size(6.dp))
                    OutlinedTextField(
                        value = desc, onValueChange = { desc = it },
                        label = { Text("Short description (when to use it)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.size(6.dp))
                    OutlinedTextField(
                        value = body, onValueChange = { body = it },
                        label = { Text("Instructions for the agent") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 5
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank() && body.isNotBlank(),
                    onClick = {
                        val md = buildString {
                            appendLine("---")
                            appendLine("name: $name")
                            appendLine("description: $desc")
                            appendLine("---")
                            appendLine()
                            appendLine(body)
                        }
                        SkillSystem(stores).installFromMarkdown(name, desc, md, "created in app")
                        createOpen = false
                        toast = "Skill '$name' created ✓"
                    }
                ) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { createOpen = false }) { Text("Cancel") } }
        )
    }

    // ---------- view skill dialog ----------
    viewing?.let { id ->
        val md = remember(id) { stores.skills.instructions(id) ?: "" }
        AlertDialog(
            onDismissRequest = { viewing = null },
            title = { Text(stores.skills.get(id)?.name ?: id, fontSize = 18.sp) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    MonoBox(md, maxLines = 200)
                }
            },
            confirmButton = { TextButton(onClick = { viewing = null }) { Text("Close") } }
        )
    }

    deleteTarget?.let { id ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete skill?") },
            text = { Text("“${stores.skills.get(id)?.name ?: id}” will be removed.") },
            confirmButton = {
                TextButton(onClick = {
                    stores.skills.delete(id)
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }
}

/** Small helper: auto-dismissing toast text. */
@Composable
fun LaunchedToast(message: String, onDone: () -> Unit) {
    androidx.compose.runtime.LaunchedEffect(message) {
        kotlinx.coroutines.delay(2600)
        onDone()
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.inverseSurface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Text(
            message,
            modifier = Modifier.padding(10.dp),
            color = MaterialTheme.colorScheme.inverseOnSurface,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun SearchSkillsDialog(
    onDismiss: () -> Unit,
    onInstalled: (String) -> Unit
) {
    val context = LocalContext.current
    val app = remember { LimanApplication.get(context) }
    val stores = app.container.stores
    val scope = rememberCoroutineScope()

    var topic by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<List<SkillSystem.Candidate>>(emptyList()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🔍 Find skills on the internet") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("What should the skill help with?") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.size(8.dp))
                Button(
                    enabled = !busy && topic.isNotBlank(),
                    onClick = {
                        busy = true
                        status = "Searching the web + anthropics/skills registry…"
                        results = emptyList()
                        scope.launch(Dispatchers.IO) {
                            val found = runCatching {
                                SkillSystem(stores).searchAndCollect(topic)
                            }.getOrElse { emptyList() }
                            withContext(Dispatchers.Main) {
                                busy = false
                                results = found
                                status = if (found.isEmpty()) {
                                    "Nothing found — try different words, or create the skill yourself."
                                } else {
                                    "${found.size} candidate(s) — tap Install on the best match:"
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (busy) "Searching…" else "Search") }
                if (busy) {
                    Spacer(Modifier.size(8.dp))
                    CircularProgressIndicator(Modifier.size(20.dp))
                }
                status?.let {
                    Spacer(Modifier.size(8.dp))
                    Text(it, style = MaterialTheme.typography.bodySmall)
                }
                results.forEach { c ->
                    Spacer(Modifier.size(6.dp))
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text(c.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            if (c.description.isNotBlank()) {
                                Text(
                                    c.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                c.source + " · " + c.url.take(70),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            var installing by remember { mutableStateOf(false) }
                            TextButton(
                                enabled = !installing,
                                onClick = {
                                    installing = true
                                    scope.launch(Dispatchers.IO) {
                                        val res = runCatching {
                                            SkillSystem(stores).installFromUrl(c.url)
                                        }
                                        withContext(Dispatchers.Main) {
                                            installing = false
                                            res.fold(
                                                onSuccess = {
                                                    onInstalled(c.name)
                                                    onDismiss()
                                                },
                                                onFailure = { status = "✗ ${it.message?.take(140)}" }
                                            )
                                        }
                                    }
                                }
                            ) { Text(if (installing) "Installing…" else "Install") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
