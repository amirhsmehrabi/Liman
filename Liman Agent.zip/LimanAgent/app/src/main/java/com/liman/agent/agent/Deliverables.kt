package com.liman.agent.agent

import java.io.File

/**
 * v2.36.0 — DELIVERABLES.
 *
 * The user's rule: when the agent produces a file — zip, docx, svg, pdf,
 * apk, image, audio… — that file must be embedded in the final output
 * message as a chip the user can download directly, not left buried in the
 * workspace.
 *
 * The Agent snapshots the workspace inventory when a run starts
 * ([inventory]) and, when the run ends, [collect] diffs it against the
 * current state: every NEW or MODIFIED file with a deliverable extension
 * becomes a [Deliverable] attached to the final answer.
 *
 * Pure Kotlin — unit-tested (DeliverablesTest).
 */
object Deliverables {

    /** Extensions worth showing as downloadable output. */
    val EXTS = setOf(
        // archives & apps
        "zip", "apk", "7z", "tar", "gz",
        // documents & data
        "pdf", "docx", "xlsx", "pptx", "csv", "ics", "txt", "md", "json", "xml",
        // design & images
        "svg", "png", "jpg", "jpeg", "webp", "gif", "ico",
        // audio & video
        "mp3", "wav", "m4a", "ogg", "mp4", "webm", "gif",
        // web & code deliverables
        "html", "css", "js", "py", "kt"
    )

    /** Directories/files that are internal state, never deliverables. */
    private val EXCLUDED_SEGMENTS = setOf("journal", "node_modules", "__pycache__", ".venv", "venv")

    data class Artifact(
        /** relative to the app workspace ROOT (filesDir/workspace) */
        val path: String,
        val name: String,
        val sizeBytes: Long
    )

    /** relPath → lastModified, before the run starts. */
    fun inventory(ws: File): Map<String, Long> {
        if (!ws.exists()) return emptyMap()
        val out = HashMap<String, Long>()
        ws.walkTopDown()
            .filter { it.isFile }
            .forEach { f ->
                rel(ws, f)?.let { out[it] = f.lastModified() }
            }
        return out
    }

    /** Files created or modified during the run, newest first, capped. */
    fun collect(
        ws: File,
        before: Map<String, Long>,
        wsRoot: File,
        max: Int = 8,
        maxSizeBytes: Long = 200L * 1024 * 1024
    ): List<Artifact> {
        if (!ws.exists()) return emptyList()
        val fresh = ArrayList<Pair<File, String>>()
        ws.walkTopDown()
            .filter { it.isFile }
            .forEach { f ->
                val rel = rel(ws, f) ?: return@forEach
                if (!isDeliverable(rel, f, maxSizeBytes)) return@forEach
                val was = before[rel]
                if (was == null || f.lastModified() > was) fresh += f to rel
            }
        return fresh
            .sortedByDescending { it.first.lastModified() }
            .take(max)
            .map { (f, rel) ->
                val fromRoot = runCatching {
                    f.canonicalFile.toRelativeString(wsRoot.canonicalFile)
                }.getOrDefault(rel)
                Artifact(fromRoot.replace('\\', '/'), f.name, f.length())
            }
    }

    private fun isDeliverable(relPath: String, f: File, maxSizeBytes: Long): Boolean {
        if (f.length() <= 0 || f.length() > maxSizeBytes) return false
        val segs = relPath.split('/')
        if (segs.any { it.isBlank() || it.startsWith(".") || it in EXCLUDED_SEGMENTS }) return false
        val ext = f.extension.lowercase()
        return ext in EXTS
    }

    private fun rel(ws: File, f: File): String? = runCatching {
        f.relativeTo(ws).toString().replace('\\', '/')
    }.getOrNull()
}
