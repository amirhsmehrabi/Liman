package com.liman.agent.agent

import com.liman.agent.data.McpServerConfig
import android.content.Context
import com.liman.agent.data.ProviderConfig
import com.liman.agent.data.ProviderKind
import com.liman.agent.data.Stores
import com.liman.agent.llm.GeminiProvider
import com.liman.agent.llm.Http
import com.liman.agent.llm.HttpProvException
import com.liman.agent.llm.LPart
import com.liman.agent.llm.ToolCallData
import com.liman.agent.llm.ToolSpec
import com.liman.agent.util.ellipsize
import com.liman.agent.util.JSON
import com.liman.agent.util.JsonRepair
import com.liman.agent.util.fmtBytes
import com.liman.agent.util.fmtTime
import com.liman.agent.util.genId
import com.liman.agent.util.now
import com.liman.agent.util.sanitizeFileName
import com.liman.agent.util.sandboxChild
import com.liman.agent.util.bool
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import com.liman.agent.util.uniqueFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

enum class ToolRisk { SAFE, WRITE, COST }

data class ToolOutcome(
    val text: String,
    val ok: Boolean,
    val media: List<LPart.Media> = emptyList(),
    val ms: Long = 0L
)

/** A tool contributed at runtime (e.g. by an MCP server). */
class DynamicTool(
    val spec: ToolSpec,
    val risk: ToolRisk,
    val run: suspend (kotlinx.serialization.json.JsonObject) -> ToolOutcome
)

class ToolContext(
    val appContext: Context,
    val workspace: File,
    val stores: Stores,
    val providers: List<ProviderConfig>,
    val requestApproval: suspend (ToolCallData) -> Boolean,
    val askUser: suspend (question: String, options: List<String>) -> String,
    val onPromptAnswered: (question: String, answer: String) -> Unit = { _, _ -> },
    val skillSystem: SkillSystem? = null,
    val spawnSubagent: (suspend (objective: String, contextNote: String) -> String)? = null,
    /** MCP / runtime tools — mutable so mcp_connect can add more mid-run. */
    val dynamicTools: MutableList<DynamicTool> = mutableListOf(),
    /** v2.31 — live mission checklist → UI roadmap card. */
    val onMissionState: ((title: String, tasks: List<MissionTask>) -> Unit)? = null
) {
    /** v2.31 — learning-law bookkeeping (the finish nudge reads these). */
    @Volatile var skillCreatedThisRun: Boolean = false
    @Volatile var finishNudgeGiven: Boolean = false
    @Volatile var mutatingToolCalls: Int = 0
}

/**
 * All built-in tool specs, as a top-level function so unit tests can
 * validate every schema is strict-valid JSON (see ToolsSpecTest).
 */
fun builtInToolSpecs(): List<ToolSpec> = listOf(
    ToolSpec(
        "list_files",
        "List files in the agent workspace.",
        """{"type":"object","properties":{"path":{"type":"string","description":"Sub-folder relative to workspace root (default: root)"},"recursive":{"type":"boolean","description":"Recurse into sub-folders"}}}"""
    ),
    ToolSpec(
        "read_file",
        "Read a file from the workspace. Understands text/code, images (attached as vision), PDF (rendered to page images), video (sampled frames), Word/Excel/PowerPoint/EPUB (text extracted), and ZIP archives (list contents, or pass entry to extract a member as text).",
        """{"type":"object","properties":{"name":{"type":"string","description":"File path relative to workspace root"},"entry":{"type":"string","description":"For ZIP archives: the member to extract as text"}},"required":["name"]}"""
    ),
    ToolSpec(
        "write_file",
        "Create (or overwrite) a text file in the workspace.",
        """{"type":"object","properties":{"name":{"type":"string","description":"File path relative to workspace root"},"content":{"type":"string","description":"Full file content"}},"required":["name","content"]}"""
    ),
    ToolSpec(
        "append_file",
        "Append text to a file in the workspace (creates it if missing).",
        """{"type":"object","properties":{"name":{"type":"string"},"content":{"type":"string"}},"required":["name","content"]}"""
    ),
    ToolSpec(
        "edit_file",
        "Replace text inside a workspace file.",
        """{"type":"object","properties":{"name":{"type":"string"},"find":{"type":"string","description":"Exact text to find"},"replace":{"type":"string"},"all":{"type":"boolean","description":"Replace every occurrence (default: first only)"}},"required":["name","find","replace"]}"""
    ),
    ToolSpec(
        "delete_file",
        "Delete a file from the workspace.",
        """{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}"""
    ),
    ToolSpec(
        "http_request",
        "Call ANY web API or site — this is how you take REAL actions outside the chat: deploy (e.g. Cloudflare Workers via PUT to api.cloudflare.com), upload, send, configure, delete — using the user's tokens/keys from the conversation as headers (Authorization: Bearer …). Text responses are returned; binary responses are saved into the workspace (images are also attached as vision input).",
        """{"type":"object","properties":{"url":{"type":"string"},"method":{"type":"string","description":"GET, POST, PUT, PATCH, DELETE or HEAD (default GET)"},"headers":{"type":"object","description":"Extra request headers as a JSON object of header-name to value, for example Accept and Content-Type"},"body":{"type":"string","description":"Request body for POST/PUT/PATCH"},"maxBytes":{"type":"integer","description":"Max bytes to download (default 2000000, max 8000000)"}},"required":["url"]}"""
    ),
    ToolSpec(
        "web_search",
        "Search the web (DuckDuckGo → Bing → Wikipedia fallback chain). Returns titles, URLs and snippets.",
        """{"type":"object","properties":{"query":{"type":"string"},"maxResults":{"type":"integer"}},"required":["query"]}"""
    ),
    ToolSpec(
        "read_link",
        "Read the content of a web link. Extracts readable text (HTML→text, JSON, plain text) with the page title. If the page needs JavaScript or text extraction is too thin, it automatically renders the FULL page in a browser engine and attaches a screenshot for you to inspect visually. Use this for any URL the user mentions or that search results point to.",
        """{"type":"object","properties":{"url":{"type":"string"},"mode":{"type":"string","description":"auto (default), text, or screenshot"}},"required":["url"]}"""
    ),
    ToolSpec(
        "memory_save",
        "Persist an important fact to long-term memory (survives across conversations).",
        """{"type":"object","properties":{"key":{"type":"string"},"value":{"type":"string"}},"required":["key","value"]}"""
    ),
    ToolSpec(
        "memory_recall",
        "Recall facts from long-term memory. Without a query, lists everything.",
        """{"type":"object","properties":{"query":{"type":"string"}},"properties_note":{"type":"string"}}"""
    ),
    ToolSpec(
        "calculator",
        "Evaluate a precise math expression: + - * / % ^, parentheses, sqrt, log, ln, trig, min/max, constants pi/e.",
        """{"type":"object","properties":{"expression":{"type":"string"}},"required":["expression"]}"""
    ),
    ToolSpec(
        "run_js",
        "Run sandboxed JavaScript ON-DEVICE for computation, parsing and data transformation (15s default budget; use print()/console.log for output). No direct network/host access, BUT require('npm-package') downloads pure-JS npm packages on demand and caches them (lodash, dayjs, uuid, mathjs…). Great for exact math, JSON crunching, text processing, quick npm-backed utilities.",
        """{"type":"object","properties":{"code":{"type":"string"},"timeoutMs":{"type":"integer"}},"required":["code"]}"""
    ),
    ToolSpec(
        "run_code",
        "RUN REAL PROGRAMS like a developer — write code, run it, read errors, fix, rerun. Languages: python, bash, node/js, c, c++, java, go, rust, ruby, php, perl, typescript, kotlin, swift, scala, r, haskell. Engines: 'bash' runs ON-DEVICE in a real shell (busybox: awk/sed/grep/tar/wget/find…, cwd = the workspace, can read/write workspace files); 'js' runs on-device like run_js (with npm require()); everything else runs on a FREE ONLINE runner (needs internet, single file + stdin, ~10s CPU, no npm installs there). Pass stdin for input. For multi-file programs, inline the imports or concatenate files first. Iterate until the output is right.",
        """{"type":"object","properties":{"language":{"type":"string","description":"python, bash, js, node, c, cpp, java, go, rust, ruby, php, perl, typescript, kotlin, swift, scala, r, haskell"},"code":{"type":"string","description":"Program source code"},"file":{"type":"string","description":"Alternative to code: workspace path of the program file to run"},"stdin":{"type":"string","description":"Standard input for the program"},"timeoutSeconds":{"type":"integer","description":"Wall-clock budget (default 60 online / 30 device, max 120)"},"engine":{"type":"string","description":"auto (default) | device | online - overrides engine choice where possible"}},"required":["language"]}"""
    ),
    ToolSpec(
        "render_html",
        "YOUR EYES — render a workspace HTML file (or inline HTML) in a real browser engine and get a SCREENSHOT attached as vision input, plus JavaScript console errors and an optional JS probe result. Sibling files in the same folder (css/js/images) are served automatically, so multi-file apps work. Use it to visually VERIFY anything you build (apps, pages, visualizations) and after every fix — look carefully at the screenshot like a human tester and iterate until it is truly correct.",
        """{"type":"object","properties":{"path":{"type":"string","description":"Workspace path of the HTML entry file, e.g. myapp/index.html"},"html":{"type":"string","description":"Alternative: raw HTML to render directly"},"width":{"type":"integer","description":"Viewport width px (default 780)"},"height":{"type":"integer","description":"Viewport height px (default 1600)"},"fullPage":{"type":"boolean","description":"Capture the full scrollable page instead of the viewport"},"waitMs":{"type":"integer","description":"Extra settle time for JS/animations (default 1500)"},"js":{"type":"string","description":"JavaScript to evaluate after load; its JSON-encoded result is returned — great for assertions like document.querySelectorAll('li').length"}}}"""
    ),
    ToolSpec(
        "datetime",
        "Get the current date and time.",
        """{"type":"object","properties":{}}"""
    ),
    ToolSpec(
        "wait",
        "Pause for N milliseconds so the phone/UI/network can settle — e.g. after opening an app, sending a load, or polling a slow endpoint. Max 30000 ms.",
        """{"type":"object","properties":{"ms":{"type":"integer","description":"How long to wait, 100-30000 ms (default 1000)"}},"required":["ms"]}"""
    ),
    ToolSpec(
        "ask_user",
        "Ask the user a clarifying question mid-task. Provide short suggested options when helpful.",
        """{"type":"object","properties":{"question":{"type":"string"},"options":{"type":"array","items":{"type":"string"},"description":"2-4 short suggested answers"}},"required":["question"]}"""
    ),
    ToolSpec(
        "image_generate",
        "Generate an image from a prompt (uses a Gemini or OpenAI-compatible image model). Saved into workspace/generated and attached for inspection.",
        """{"type":"object","properties":{"prompt":{"type":"string"},"filename":{"type":"string"}},"required":["prompt"]}"""
    ),
    ToolSpec(
        "build_apk",
        "Package a self-contained HTML/CSS/JS app into a real, signed, installable Android APK (saved to workspace/generated). The app runs full-screen in a WebView; localStorage and JavaScript work, assets load from the bundled folder, and android.permission.INTERNET is included. IMPORTANT: the app must be fully self-contained (no servers, no CDNs) — write all HTML/CSS/JS files first, test logic with run_js, then build. Note: apps that need native Android code or Play Services cannot be built this way.",
        """{"type":"object","properties":{"name":{"type":"string","description":"App name shown under the launcher icon"},"files":{"type":"array","items":{"type":"string"},"description":"Workspace paths to bundle (files and/or directories; relative paths inside the APK mirror these). One must be an index.html (the entry point)."},"directory":{"type":"string","description":"Alternative to files: bundle everything inside this workspace directory (it must contain index.html)."}},"required":["name"]}"""
    ),
    ToolSpec(
        "finish",
        "End the task with a final summary of what was done and produced.",
        """{"type":"object","properties":{"summary":{"type":"string"}},"required":["summary"]}"""
    ),
    ToolSpec(
        "use_skill",
        "Load the full instructions of an installed skill into context. Check the skill catalog in the system prompt first.",
        """{"type":"object","properties":{"id":{"type":"string","description":"Skill id from the catalog"}},"required":["id"]}"""
    ),
    ToolSpec(
        "search_skills",
        "Search the internet (web + the anthropics/skills registry on GitHub) for relevant agent skills to install. Returns candidates with name, description and source URL.",
        """{"type":"object","properties":{"topic":{"type":"string","description":"What the skill should help with"}},"required":["topic"]}"""
    ),
    ToolSpec(
        "install_skill",
        "Install a skill from a URL (a SKILL.md markdown file, e.g. raw.githubusercontent.com). After installing, load it with use_skill.",
        """{"type":"object","properties":{"url":{"type":"string"}},"required":["url"]}"""
    ),
    ToolSpec(
        "storage_list",
        "List the user's real Android folders granted in Settings (SAF tree roots). With no root argument, lists the granted roots. Then use storage_read/storage_write with a root + relative path to access device files.",
        """{"type":"object","properties":{"root":{"type":"string","description":"Root label or 1-based index from the roots list"},"path":{"type":"string","description":"Sub-folder inside that root (default: top)"}},"required":[]}"""
    ),
    ToolSpec(
        "storage_read",
        "Read a file from the user's real device storage (a folder granted in Settings > Storage access). Text is returned; images are attached as vision input. Use list_files-like storage_list first to find files.",
        """{"type":"object","properties":{"root":{"type":"string"},"path":{"type":"string","description":"File path relative to the root"},"toWorkspace":{"type":"boolean","description":"Also copy the file into the agent workspace (default false)"}},"required":["path"]}"""
    ),
    ToolSpec(
        "storage_write",
        "Write or append a text file in the user's real device storage (a folder granted in Settings). Existing files are overwritten unless append=true.",
        """{"type":"object","properties":{"root":{"type":"string"},"path":{"type":"string"},"content":{"type":"string"},"append":{"type":"boolean"}},"required":["path","content"]}"""
    ),
    ToolSpec(
        "mcp_connect",
        "Connect to an MCP (Model Context Protocol) server at runtime. Lists its tools and makes them callable for the rest of this task as mcp_<server>_<tool>. Use this autonomously when a task needs capabilities you lack.",
        """{"type":"object","properties":{"url":{"type":"string","description":"MCP server URL"},"bearerToken":{"type":"string"},"name":{"type":"string","description":"Short display name for the server"},"persist":{"type":"boolean","description":"Remember this server in Settings for future tasks (default true)"}},"required":["url"]}"""
    ),
    ToolSpec(
        "profile_update",
        "Save or update a durable fact about the user (job, preferences, how they like answers, favorites). Facts persist across chats and are injected into future prompts. Keep values short.",
        """{"type":"object","properties":{"facts":{"type":"object","description":"Object of fact-name to short value, e.g. {\"job\":\"accountant\",\"answer style\":\"concise Persian\"}"}}, "required":["facts"]}"""
    ),
    ToolSpec(
        "mission",
        "Decompose a goal into a checklist you maintain across the task. plan {title, tasks:[{id, goal, criteria}]} · progress {taskId} (mark in_progress) · done {taskId} · update {taskId, status} · show. taskId accepts the exact id, its 1-based index, or the task's goal text.",
        """{"type":"object","properties":{"action":{"type":"string","description":"plan | progress | done | update | show"},"title":{"type":"string"},"tasks":{"type":"array","items":{"type":"object","properties":{"id":{"type":"string"},"goal":{"type":"string"},"criteria":{"type":"string"}}}},"taskId":{"type":"string"},"status":{"type":"string","description":"done | failed | blocked | in_progress"}}}"""
    ),
    ToolSpec(
        "skill_create",
        "SKILL FORGE — distill a just-completed non-trivial success into a reusable skill (numbered, copy-pasteable procedure WITH the gotcha that bit you). After any non-trivial success, save the working procedure so future tasks start smarter. Before any new procedure, use_skill / check the catalog first.",
        """{"type":"object","properties":{"name":{"type":"string"},"description":{"type":"string","description":"One line: when this skill helps"},"instructions":{"type":"string","description":"The full procedure in markdown: numbered steps, exact commands/payloads, and the gotchas"}},"required":["name","description","instructions"]}"""
    ),
    ToolSpec(
        "device",
        "PHONE BRIDGE — interact with the user's Android device: battery status, clipboard read/write, vibrate, post a notification (great for 'tell me when done' and scheduled-mission results), and location (via Termux:API — powers geofencing-lite pipelines).",
        """{"type":"object","properties":{"action":{"type":"string","description":"battery | clipboard_get | clipboard_set | vibrate | notify | location"},"text":{"type":"string","description":"clipboard text or notification body"},"title":{"type":"string","description":"notification title (notify only)"},"provider":{"type":"string","description":"location: gps | network (default) | passive"}},"required":["action"]}"""
    ),
    ToolSpec(
        "schedule",
        "CRON CONTROL — manage RECURRING missions that run as full agent cycles even with the app closed (results land as ⏰ conversations + a notification). Actions: 'list' | 'add' (needs title + prompt + dailyAt 'HH:MM' or everyHours) | 'remove' (needs id). Use this YOURSELF whenever a goal is recurring — e.g. 'every day find job offers and contact the best ones' becomes a daily mission that keeps its state in workspace/campaigns/.",
        """{"type":"object","properties":{"action":{"type":"string","description":"list | add | remove"},"title":{"type":"string"},"prompt":{"type":"string","description":"The full mission prompt the scheduled agent will run (add only)"},"dailyAt":{"type":"string","description":"HH:MM — run daily at this time (add only, if everyHours not set)"},"everyHours":{"type":"integer","description":"Run every N hours instead of daily, 1..168 (add only)"},"activeHours":{"type":"string","description":"HH:MM-HH:MM window when the mission may fire, e.g. 09:00-22:00 — keeps heartbeats out of sleeping hours (add only, optional)"},"id":{"type":"string","description":"Mission id (remove only)"}},"required":["action"]}"""
    ),
    ToolSpec(
        "termux_run",
        "RUN REAL COMMANDS IN THE USER'S TERMUX — the user's full Linux toolbox on this phone: node, npm install, python, git, ssh, ffmpeg, wget, anything pkg can install. The command executes in a real bash in Termux (~ as workdir) and full stdout+stderr comes back. Coding actions: {action:'doctor'} probes the whole dev toolchain (node/python/pip/git/gcc/make… versions + free disk, suggests pkg installs); {action:'dev_server', path:'site'} serves a workspace folder over HTTP for live preview (phone + LAN URLs returned). One-time setup (guide the user once): Termux installed, pkg install curl, allow-external-apps=true in ~/.termux/termux.properties, and the permission granted in Liman Settings → Termux bridge. Prefer this over run_code for node/npm projects, native modules, git, ssh and anything needing real binaries.",
        """{"type":"object","properties":{"command":{"type":"string","description":"Bash command(s) to run in Termux (cwd = ~). Example: 'cd proj && npm install && node app.js'"},"timeoutSeconds":{"type":"integer","description":"Wall-clock budget (default 120, max 600)"}},"required":["command"]}"""
    ),
    ToolSpec(
        "spawn_subagent",
        "Spawn a subagent that independently works on a subtask with its own agent cycle, tools and conversation. Roles: scout (explore+answer one question with evidence), architect (design), builder (implement one task), runner (execute processes), verifier (adversarially re-check acceptance criteria), deployer (deploys), auditor (GO/NO-GO pre-flight). Give a crisp goal + context + constraints + machine-checkable acceptance criteria; it returns Result/Evidence/Side effects/Blockers. Spawn several in the same turn to run subtasks in PARALLEL.",
        """{"type":"object","properties":{"objective":{"type":"string","description":"Complete, self-contained goal for the subagent"},"context":{"type":"string","description":"Key facts, file paths or constraints it needs"},"role":{"type":"string","description":"scout | architect | builder | runner | verifier | deployer | auditor (default builder)"},"constraints":{"type":"array","items":{"type":"string"},"description":"Hard rules, e.g. never print the token, timeout 120s"},"criteria":{"type":"array","items":{"type":"string"},"description":"Acceptance criteria — all must be proven with observed evidence"}},"required":["objective"]}"""
    ),
    ToolSpec(
        "knowledge_add",
        "PRIVATE LIBRARY: ingest a document into your on-device knowledge base (agentic RAG — Agno/RAGFlow style). Content comes from a workspace file path (txt/md/csv/json/html — convert other formats first) OR direct text. Re-adding the same name replaces it. After ingesting, retrieve with knowledge_search and PREFER it over web_search for anything it covers.",
        """{"type":"object","properties":{"name":{"type":"string","description":"Short document name, e.g. 'my-resume' or 'apartment-contract'"},"path":{"type":"string","description":"Workspace file path to ingest (alternative to text)"},"text":{"type":"string","description":"Raw document text to ingest (alternative to path)"}},"required":["name"]}"""
    ),
    ToolSpec(
        "knowledge_search",
        "AGENTIC RETRIEVAL over your private knowledge base: pass 2-4 DIFFERENT phrasings of what you need (multi-query — each is scored, results merge across documents). Returns ranked chunks, each cited as doc#chunk — cite that when you use a passage. ALWAYS try this BEFORE web_search for factual or document questions; use the web only to fill gaps.",
        """{"type":"object","properties":{"queries":{"type":"array","items":{"type":"string"},"description":"2-4 different phrasings of what you need"},"k":{"type":"integer","description":"Max hits (default 6)"}},"required":["queries"]}"""
    ),
    ToolSpec(
        "knowledge_list",
        "List the documents in your private knowledge base.",
        """{"type":"object","properties":{}}"""
    ),
    ToolSpec(
        "knowledge_forget",
        "Remove a document from the knowledge base (by name).",
        """{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}"""
    ),
    ToolSpec(
        "team_run",
        "CREW ORCHESTRATION (CrewAI/AutoGen style): dispatch a whole multi-role crew in ONE call. Define roles (role/goal/backstory) and tasks (description/agent/expected_output). process: 'sequential' = tasks run in order, each seeing earlier outputs (CrewAI context chaining); 'broadcast' = tasks run in PARALLEL on the same goal; 'hierarchical' = a manager subagent first plans the delegation order. A worker that cannot proceed replies 'TERMINATE: reason' and ends the run (AutoGen). Use this instead of many manual spawn_subagent calls whenever work splits into distinct deliverables.",
        """{"type":"object","properties":{"goal":{"type":"string","description":"The overall objective"},"process":{"type":"string","description":"sequential (default) | broadcast | hierarchical"},"roles":{"type":"array","items":{"type":"object","properties":{"role":{"type":"string"},"goal":{"type":"string"},"backstory":{"type":"string"}},"required":["role"]}},"tasks":{"type":"array","items":{"type":"object","properties":{"description":{"type":"string"},"agent":{"type":"string","description":"Role name that should do this task"},"expected_output":{"type":"string"}},"required":["description"]}},"max_tasks":{"type":"integer","description":"Hard cap on executed tasks (default 6, max 12)"}},"required":["goal","tasks"]}"""
    ),
    ToolSpec(
        "github",
        "GITHUB RESEARCH ENGINE — search GitHub repositories (titles, descriptions, READMEs), dive deep into any repo (README, full file tree, individual source files) and USE what you find: adapt the code, run it, build on it. THE DEFAULT FIRST STEP for any coding/project/task: search GitHub before writing from scratch — 300M+ repos already solved most problems. Free without a token (60 req/hr); add a personal access token for 5000/hr. Always honor the repo's license when reusing code.",
        """{"type":"object","properties":{"action":{"type":"string","description":"search (find repos by query+optional language) | research (search + auto-fetch top-3 READMEs — run this FIRST) | readme (full README of owner/repo) | tree (file tree, optional path filter) | file (fetch one source file) | token (save a GitHub PAT for 5000 req/hr)"},"query":{"type":"string"},"repo":{"type":"string","description":"owner/name, e.g. tikv/raft-rs"},"path":{"type":"string"},"branch":{"type":"string","description":"default: the repo's default branch"},"language":{"type":"string","description":"filter by language, e.g. kotlin, python"},"filter":{"type":"string","description":"tree: substring filter for paths"},"limit":{"type":"number","description":"max results 1-30, default 8"},"token":{"type":"string"}},"required":["action"]}"""
    ),
    ToolSpec(
        "watch",
        "WEB WATCHERS — the agent that waits for you. Monitor any URL (price pages, exam results, release notes, stock status, visa slots): Liman fetches it, extracts the watched value (whole text or a regex capture group), and reports only CHANGES. Use with schedule/pipelines for periodic checks ('every 30 min run watch {action:check}') — changed watchers fire a notification.",
        """{"type":"object","properties":{"action":{"type":"string","description":"add | list | remove | check (one by id or all due) | test (dry-run now, no save)"},"name":{"type":"string"},"url":{"type":"string"},"extract":{"type":"string","description":"text (default) or regex"},"pattern":{"type":"string","description":"regex for extract=regex; capture group 1 is watched if present"},"everyMinutes":{"type":"number","description":"minimum re-check interval, default 30"},"id":{"type":"string"}},"required":["action"]}"""
    ),
    ToolSpec(
        "trigger",
        "CONTEXT TRIGGERS — the phone's real-world events become agent work. Kinds: charging_on, charging_off, battery_low, battery_ok, screen_on, screen_off, wifi_on, wifi_off, boot. When a trigger fires (respecting its cooldown) Liman runs the prompt as a full agent cycle and notifies; results also appear as ⚡ conversations. survival (action:'survival') installs the Termux boot kit (wake-lock + crond) so schedules survive reboots.",
        """{"type":"object","properties":{"action":{"type":"string","description":"add | list | remove | survival (install Termux:Boot survival kit)"},"kind":{"type":"string","description":"charging_on|charging_off|battery_low|battery_ok|screen_on|screen_off|wifi_on|wifi_off|boot"},"title":{"type":"string"},"prompt":{"type":"string","description":"what Liman should do when it fires"},"cooldownMinutes":{"type":"number"},"id":{"type":"string"},"startBrainToo":{"type":"boolean","description":"survival: also autostart the local brain on boot"}},"required":["action"]}"""
    ),
    ToolSpec(
        "digest",
        "NOTIFICATION DIGEST — collect the notifications Liman saw (accessibility log), group them by app, flag urgent ones (your regex rules), and deliver 3 calm digests a day instead of drowning in buzzes. Requires the Liman accessibility service (ui tool) to be collecting. Note: Android cannot suppress other apps' notifications — this organizes, it does not block.",
        """{"type":"object","properties":{"action":{"type":"string","description":"config (enable/disable + windows + urgentPatterns) | build (collect + digest + notify + journal, run from a schedule) | status"},"enabled":{"type":"boolean"},"windows":{"type":"array","items":{"type":"string"},"description":"HH:MM list, default 09:00,14:00,20:00"},"urgentPatterns":{"type":"array","items":{"type":"string"},"description":"regex list — matching notifications are flagged urgent"}},"required":["action"]}"""
    ),
    ToolSpec(
        "briefing",
        "JOURNAL + MORNING BRIEFING — Liman's own day-book. note: append anything worth remembering to today's journal (workspace/journal/YYYY-MM-DD.md). write: gather the briefing facts (journal, scheduled missions, watcher changes, notification pulse, urgent items) and return the skeleton for you to enrich and deliver as one calm notification. read: today's journal. A daily briefing schedule seeds itself on first use — the agent INITIATES.",
        """{"type":"object","properties":{"action":{"type":"string","description":"note | write | read"},"text":{"type":"string","description":"note: the journal line"}},"required":["action"]}"""
    ),
    ToolSpec(
        "evolve",
        "SELF-IMPROVEMENT — Liman examines how it actually worked (recent conversations: tool stats, failures, goals, existing skills, today's journal) and returns a retrospection directive. Act on it in the same turn: draft skills for repeated procedures (skill_create + ask_user approval), correct failing tool patterns, or honestly report that nothing needs saving. Never invent improvements.",
        """{"type":"object","properties":{"action":{"type":"string","description":"reflect (analyze and return the retrospection directive) | stats (just the numbers)"}},"required":["action"]}"""
    ),
    ToolSpec(
        "pack",
        "PLUGIN PACKS — export/import Liman setups as ONE zip: skills + pipelines + triggers + watchers. Build a working setup once ('my visa tracker'), export it, share the file; anyone's Liman imports it in seconds (packs live in workspace/packs/).",
        """{"type":"object","properties":{"action":{"type":"string","description":"export | import | list"},"name":{"type":"string"},"skills":{"type":"array","items":{"type":"string"},"description":"export: skill ids to include (default: all)"},"pipelines":{"type":"boolean","description":"export: include pipelines (default true)"},"notes":{"type":"string"},"path":{"type":"string","description":"import: workspace path to a .limanpack.zip"}},"required":["action"]}"""
    ),
    ToolSpec(
        "local_ai",
        "LOCAL BRAIN — a private LLM running INSIDE Termux (llama.cpp, OpenAI-compatible at 127.0.0.1:8085). Zero API keys, fully offline, total privacy — Liman's free out-of-the-box brain (a 0.5B/1.5B model: good for summaries/classification/drafts, not hard reasoning — escalate to the router for that). Actions: setup (one-time: installs llama.cpp + downloads the model ~400MB/1GB), start/stop, status, provider (the exact values to add the provider in Settings → Providers).",
        """{"type":"object","properties":{"action":{"type":"string","description":"setup | start | stop | status | provider"},"size":{"type":"string","description":"setup: '0.5b' (default) or '1.5b'"}},"required":["action"]}"""
    ),
    ToolSpec(
        "ocr",
        "ON-DEVICE OCR — extract text from an image (screenshot, photo, scan, receipt) with tesseract running in Termux. Free and offline after a one-time pkg install (it tells you the command if missing). Works on any image file in the workspace (e.g. a screenshot from the ui tool).",
        """{"type":"object","properties":{"image":{"type":"string","description":"workspace path of the image (png/jpg/webp/bmp)"},"lang":{"type":"string","description":"tesseract language code: eng (default), fas, ara, deu, …"}},"required":["image"]}"""
    ),
    ToolSpec(
        "motion",
        "STORY MOTION STUDIO — cinematic story motion / motion graphics / promo videos on-device, built on the video-shotcraft doctrine (157 shot recipes, energy arc, case-law aesthetic rules). Workflow: plan (returns the full planning doctrine) → create (scaffolds a project with motion.html + storyboard + STUDIO.md handbook) → compose the shots IN motion.html with write_file (deterministic MotionKit: seeded randomness only, entrance three-piece, holds after landing) → verify with render_html → export (frame-perfect 1080p 30fps H.264 MP4, rendered in-app from the deterministic timeline). Deliver BOTH the self-contained HTML (publishable anywhere) and the MP4.",
        """{"type":"object","properties":{"action":{"type":"string","description":"plan (the doctrine brief) | create | list | export"},"name":{"type":"string","description":"project name"},"brief":{"type":"string","description":"create: one-line brief — who/one message/tone"},"durationSeconds":{"type":"number","description":"create: total duration, default 12"},"width":{"type":"number","description":"export: default 1920"},"height":{"type":"number","description":"export: default 1080"},"fps":{"type":"number","description":"export: default 30"}},"required":["action"]}"""
    ),
    ToolSpec(
        "native_apk",
        "NATIVE APK FACTORY — builds REAL Kotlin Android apps compiled on this phone via the Termux toolchain (kotlinc → d8 → aapt2 → zipalign → apksigner). NOT a WebView wrapper: the output is a genuine signed, installable APK of actual Kotlin source code. Actions: 'status' (doctor: probe the toolchain + disk space) | 'setup' (one-time: installs openjdk-17, kotlin, aapt2, apksigner, dx + android.jar — ~265 MB in Termux, ask the user first) | 'scaffold' (creates a real Kotlin project: MainActivity.kt + manifest + theme, plus colors/dimens generated from a design preset) | 'build' (compiles the project in Termux and retrieves the signed APK + sha256 into the workspace) | 'verify' (apksigner verify --print-certs + aapt2 dump badging + sha256 on a built APK). WORKFLOW: propose the app spec (name, package, preset, archetype, screens, permissions+reasons) → user approves → scaffold → edit sources → build → verify → install → confirm launch with the ui tool. The template uses framework APIs only (no Gradle needed). Requires the Termux bridge.",
        """{"type":"object","properties":{"action":{"type":"string","description":"status | setup | scaffold | build | verify"},"name":{"type":"string","description":"App name (scaffold/build — build uses the project folder name or the app name)"},"package":{"type":"string","description":"Optional package id, e.g. com.liman.myapp (scaffold only)"},"description":{"type":"string","description":"What the app does (scaffold — becomes the app's subtitle)"},"preset":{"type":"string","description":"scaffold: design preset id (swiss-minimal | soft-material | dark-terminal | neo-brutalist | glass-aurora) — generates res/values/colors.xml + dimens.xml from the token set"},"permissions":{"type":"array","items":{"type":"string"},"description":"Android permissions, e.g. android.permission.POST_NOTIFICATIONS (scaffold only)"}},"required":["action"]}"""
    ),
    ToolSpec(
        "design_tokens",
        "DESIGN SYSTEM KERNEL — one source of truth for colors/spacing/type/radius, so web prototypes and native apps look identical. The model composes TOKENS, never raw hex/px. Actions: 'contract' (the token law every UI must follow) | 'list' (the 5 presets with vibes and key moves) | 'archetypes' (the 9 layout archetypes — every screen declares one) | 'generate' (writes design/tokens.css + web/kit.css into a project dir for web targets, and returns the Android colors.xml snippet for native scaffolds).",
        """{"type":"object","properties":{"action":{"type":"string","description":"contract | list | archetypes | generate"},"preset":{"type":"string","description":"preset id: swiss-minimal | soft-material | dark-terminal | neo-brutalist | glass-aurora"},"project":{"type":"string","description":"generate: project folder name under the workspace (default: current web project root)"}},"required":["action"]}"""
    ),
    ToolSpec(
        "svg_icon",
        "VECTOR-FIRST ICON PIPELINE — stroke-based 24px icon grammar, zero raster assets. Actions: 'list' (the embedded base icon set) | 'spec' (the icon spec every icon must comply with) | 'get' {name} (returns standalone inline-able SVG) | 'convert' {name | svg} (SVG → Android VectorDrawable XML for res/drawable/, with unsupported features like filters rejected up front instead of producing broken drawables).",
        """{"type":"object","properties":{"action":{"type":"string","description":"list | spec | get | convert"},"name":{"type":"string","description":"icon name from op:list, e.g. arrow-left"},"svg":{"type":"string","description":"convert: raw SVG markup instead of an embedded icon"}},"required":["action"]}"""
    ),
    ToolSpec(
        "search_code",
        "RIPGREP-LITE — regex content search across the workspace (code, configs, docs; node_modules/.git/build skipped). Returns file:line matches with context. THE tool for 'where is X used / defined / mentioned' — pair with repo_map to navigate big projects.",
        """{"type":"object","properties":{"pattern":{"type":"string","description":"Regex, e.g. fun login|signIn"},"glob":{"type":"string","description":"Filename filter with *, e.g. *.kt"},"path":{"type":"string","description":"Sub-folder (default: workspace root)"},"context":{"type":"integer","description":"Context lines around each hit (default 1)"}},"required":["pattern"]}"""
    ),
    ToolSpec(
        "repo_map",
        "CODEBASE INTELLIGENCE (aider-style repo map) — scans the whole project and returns a compact RANKED map: every file with its language, size, imports and definition symbols (classes/functions/types with line numbers), ordered by how referenced they are. How you navigate a large codebase WITHOUT reading every file. Use it FIRST when a coding task touches a project with 3+ files.",
        """{"type":"object","properties":{"path":{"type":"string","description":"Project folder (default: workspace root)"}},"required":[]}"""
    ),
    ToolSpec(
        "code_check",
        "DETERMINISTIC CODE GATE — syntax/structure checks before you call code done: JS/TS via real parse (new Function), JSON parse, Kotlin/Java brace/paren/string balance, Python indent sanity. NEVER claim a file works without this passing (and run_js/run_code for real behavior).",
        """{"type":"object","properties":{"files":{"type":"array","items":{"type":"string"},"description":"Workspace file paths to check"}},"required":["files"]}"""
    ),
    ToolSpec(
        "snapshot",
        "MINI-VCS (git-less undo) — snapshots of the whole workspace you can diff against and restore. Actions: 'create' {label} (zip the workspace) | 'list' | 'diff' {name} (file-level changes vs now) | 'restore' {name} (roll back — the current state is auto-snapshotted first, so undo is itself undoable). CREATE ONE before risky multi-file edits or big refactors.",
        """{"type":"object","properties":{"action":{"type":"string","description":"create | list | diff | restore"},"label":{"type":"string","description":"create: a short label"},"name":{"type":"string","description":"diff/restore: snapshot name from op:list"}},"required":["action"]}"""
    ),
    ToolSpec(
        "patch",
        "SURGICAL MULTI-FILE PATCH — apply several find/replace edits in ONE atomic call, with an automatic workspace snapshot first (rollback via snapshot op:restore) and a per-op report. THE tool for coordinated refactors across files.",
        """{"type":"object","properties":{"ops":{"type":"array","items":{"type":"object","properties":{"file":{"type":"string"},"find":{"type":"string"},"replace":{"type":"string"},"all":{"type":"boolean"}},"required":["file","find","replace"]},"description":"the edits to apply"}},"required":["ops"]}"""
    ),
    ToolSpec(
        "vector_studio",
        "CREATIVE VECTOR ENGINE — taste in vectors, deterministically enforced. RULE 0: you never freehand path data; you RETRIEVE real artwork, COMPOSE kit parts, or GENERATE via deterministic recipes. Actions: 'protocol' (the 3-line INTENT/ROUTE/METHOD plan + route table) | 'direction' (the DIRECTION.md contract — commit to a design direction from the SUBJECT before drawing) | 'recipes' (the 17 deterministic generators with params) | 'recipe_run' {recipe, params…} (deterministic SVG — reproducible, valid, tunable) | 'retrieve' {prefix, name} (real icon from the Iconify API, 300k+ icons — sanitized + license-noted) | 'validate' {svg|path, target} (structural gate: path-data math, budgets, android-vd compatibility) | 'slop' {svg|path} (the Slop Score 0-100 — palette clichés, blob backgrounds, precision noise, viewbox fit… with fixes + nextAction). Chain: validate → slop → render_html → report numbers. 2 failed checks = switch route, never reseed.",
        """{"type":"object","properties":{"action":{"type":"string","description":"protocol | direction | recipes | recipe_run | retrieve | validate | slop"},"recipe":{"type":"string","description":"recipe_run: id from op:recipes, e.g. bg/topo-lines"},"params":{"type":"object","description":"recipe_run: the recipe's params (seed makes it reproducible)"},"prefix":{"type":"string","description":"retrieve: iconify set, e.g. lucide, tabler, si (brand logos)"},"name":{"type":"string","description":"retrieve: icon name, e.g. arrow-left"},"svg":{"type":"string","description":"validate/slop: raw SVG markup instead of a file"},"path":{"type":"string","description":"validate/slop: workspace file path"},"target":{"type":"string","description":"validate: web | android-vd"},"out":{"type":"string","description":"recipe_run/retrieve: save to this workspace path"}},"required":["action"]}"""
    ),
    ToolSpec(
        "nine_router",
        "The user's 9Router server (a self-hosted deployment of github.com/decolua/9router) — combos (fusion / fallback / round-robin model groups) and 40+ providers behind one OpenAI-compatible endpoint. Actions: 'status' (is the server up + provider configured) · 'combos' (fetch the user's COMBOS — the preferred models to use) · 'models' (fetch plain models) · 'open' (open the 9Router dashboard in Chrome) · 'connect' {endpoint, api_key, model} (saves/updates it as the '9Router (my server)' Liman provider — the key comes from the dashboard's API Keys page). Combos are used by passing their name as the model.",
        """{"type":"object","properties":{"action":{"type":"string","description":"status | open | combos | models | connect"},"endpoint":{"type":"string","description":"For connect: the /v1 endpoint (default the user's server)"},"api_key":{"type":"string","description":"For connect/combos/models: the API key from the 9Router dashboard"},"model":{"type":"string","description":"For connect: a combo name (preferred) or a model id"}},"required":["action"]}"""
    ),
    ToolSpec(
        "ui",
        "Drive the user's phone like a human — the droidclaw/agent-device perception→act loop. ALWAYS start with {action:'snapshot'} to SEE the current screen as a compact list of interactive elements with @eN refs (app name + buttons/fields/links), then act: {action:'tap', ref:'@e3'} (or by text/desc), {action:'type', text} (types into the focused field), {action:'scroll', direction:'forward|backward'}, back/home/recents/notifications, {action:'open_app', package}. Re-snapshot after acting to verify what changed (refs expire after each action). The tool warns you when you get STUCK (screen unchanged), REPEAT the same target, or DRIFT (navigate-only) — heed those hints and change approach.",
        """{"type":"object","properties":{"action":{"type":"string","description":"snapshot | tap | type | scroll | back | home | recents | notifications | open_app | record_start | record_stop | record_status"},"ref":{"type":"string","description":"For tap: an @eN ref from the LATEST snapshot"},"text":{"type":"string","description":"For tap: visible label; for type: the text to enter"},"desc":{"type":"string","description":"For tap: content description"},"viewId":{"type":"string","description":"For tap: view id"},"direction":{"type":"string","description":"For scroll: forward | backward"},"package":{"type":"string","description":"For open_app: package name"}},"required":["action"]}"""
    ),
    ToolSpec(
        "tool_forge",
        "TOOL FORGE — build NEW tools yourself (the agent programs itself). create writes a tool (JS sandboxed engine = always available & safe; python engine = real Termux python with pip, needs the bridge), registers it immediately, and you (or later runs) call it by name like any built-in. Contract: js code = body of a function receiving `input`, return the result; python code = reads one JSON object from stdin, prints the result. Use for recurring transforms: 'extract numbers from these PDF reports', 'normalize this CSV', 'parse this API payload'.",
        """{"type":"object","properties":{"action":{"type":"string","description":"create | list | inspect | delete"},"name":{"type":"string","description":"snake_case name, 3-31 chars (create/delete/inspect)"},"description":{"type":"string","description":"What the tool does — becomes its tool description (create)"},"engine":{"type":"string","description":"js (default, sandboxed, always works) | python (real Termux, full power)"},  "params":{"type":"string","description":"JSON schema for the input object, e.g. {\"type\":\"object\",\"properties\":{\"report_path\":{\"type\":\"string\"}},\"required\":[\"report_path\"]}"},"code":{"type":"string","description":"Tool body (see contract in the tool description)"}},"required":["action"]}"""
    ),
    ToolSpec(
        "automation",
        "AUTOMATION ENGINE — standing pipelines that run as full unattended agent cycles (even with the app closed): trigger (daily/interval/manual) + ordered STEPS (fetch/transform/filter/dedupe/output/notify/approval). The transform step is the AI node: translate, summarize, rewrite, classify — insertable between ANY source and ANY output (Telegram→Instagram, web→files, Gmail→Telegram…). create takes name+description+trigger+steps; run executes now; toggle pauses; delete removes. Non-manual pipelines auto-sync onto the scheduler (respecting activeHours). Runs keep state files so nothing repeats — that's the dedupe memory.",
        """{"type":"object","properties":{"action":{"type":"string","description":"list | create | show | run | toggle | delete"},"name":{"type":"string"},"description":{"type":"string","description":"One line: what this automation does"},"trigger":{"type":"object","properties":{"kind":{"type":"string","description":"manual | daily | interval"},"dailyAt":{"type":"string","description":"HH:MM for daily"},"everyMinutes":{"type":"integer","description":"15..1380 for interval (sub-hour watchtowers)"},"everyHours":{"type":"integer","description":"1..168 for interval"},"activeHours":{"type":"string","description":"optional HH:MM-HH:MM gate"}}},"steps":{"type":"array","items":{"type":"object","properties":{"type":{"type":"string","description":"fetch | transform | filter | dedupe | output | notify | approval"},"instruction":{"type":"string","description":"Exactly what to do in this step, with sources/destinations"}},"required":["instruction"]}},"id":{"type":"string","description":"pipeline id (show/run/toggle/delete)"}},"required":["action"]}"""
    ),
    ToolSpec(
        "storage_scan",
        "STORAGE DOCTOR — intelligent investigation of a granted device folder: categorizes everything into SAFE TO DELETE (temp files, exact duplicates) / REVIEW FIRST (apks, archives, old videos, huge files, likely duplicates) / DO NOT TOUCH (documents, recent media, projects), with reclaimable bytes and reasons. Read-only — the report is for the user to approve. Cleanup itself is storage_clean (quarantine + undo).",
        """{"type":"object","properties":{"root":{"type":"string","description":"Granted folder label (default: first granted root; call storage_list with no root to see them)"},"maxFiles":{"type":"integer","description":"Scan cap (default 2500)"}}}"""
    ),
    ToolSpec(
        "storage_clean",
        "UNDOABLE CLEANUP of granted device folders. NEVER deletes directly: quarantine copies the approved files into the workspace vault (manifest with original paths + sha256) and only then removes the originals; undo restores the latest batch. Always show the storage_scan report and get explicit user approval first.",
        """{"type":"object","properties":{"action":{"type":"string","description":"quarantine | undo | status"},"paths":{"type":"array","items":{"type":"string"},"description":"relPaths from the scan report (quarantine)"},"root":{"type":"string","description":"folder label the paths belong to (quarantine)"}},"required":["action"]}"""
    )
)

/**
 * The agent's toolbox. Every tool is sandboxed to the workspace folder;
 * risky tools can require user approval before running.
 */
class ToolRegistry(private val ctx: ToolContext) {

    private val ingestor = FileIngestor(ctx.appContext)

    /** MEGA AGENT: mission decomposition state for the current run. */
    private val mission = MissionTracker()

    private val builtInSpecs: List<ToolSpec> = builtInToolSpecs()

    init {
        // v2.21 — TOOL FORGE: register the agent's self-built tools at run
        // start (never shadowing a built-in)
        runCatching {
            val taken = builtInSpecs.map { it.name }.toSet()
            ToolForge.loadAll(ctx.workspace).forEach { spec ->
                ToolForge.dynamicTool(spec, taken, ctx.appContext, ctx.stores, ctx.workspace)?.let {
                    ctx.dynamicTools += it
                }
            }
        }
    }

    val specs: List<ToolSpec> get() = builtInSpecs + ctx.dynamicTools.map { it.spec }

    private val risk: Map<String, ToolRisk> = mapOf(
        "list_files" to ToolRisk.SAFE, "read_file" to ToolRisk.SAFE, "web_search" to ToolRisk.SAFE,
        "memory_recall" to ToolRisk.SAFE, "memory_save" to ToolRisk.SAFE, "calculator" to ToolRisk.SAFE,
    "datetime" to ToolRisk.SAFE, "run_js" to ToolRisk.SAFE, "render_html" to ToolRisk.SAFE, "finish" to ToolRisk.SAFE, "wait" to ToolRisk.SAFE,
        "run_code" to ToolRisk.WRITE,
        "ask_user" to ToolRisk.SAFE, "read_link" to ToolRisk.SAFE, "use_skill" to ToolRisk.SAFE,
        "search_skills" to ToolRisk.SAFE,
        "write_file" to ToolRisk.WRITE, "append_file" to ToolRisk.WRITE, "edit_file" to ToolRisk.WRITE,
        "delete_file" to ToolRisk.WRITE, "http_request" to ToolRisk.WRITE, "install_skill" to ToolRisk.WRITE,
        "build_apk" to ToolRisk.WRITE, "storage_read" to ToolRisk.SAFE, "mcp_connect" to ToolRisk.WRITE,
        "profile_update" to ToolRisk.SAFE,
        "storage_write" to ToolRisk.WRITE,
        "image_generate" to ToolRisk.COST, "spawn_subagent" to ToolRisk.COST,
        "mission" to ToolRisk.SAFE, "skill_create" to ToolRisk.WRITE, "device" to ToolRisk.WRITE,
        "termux_run" to ToolRisk.WRITE, "nine_router" to ToolRisk.WRITE,
        "schedule" to ToolRisk.WRITE,
        // v2.20.0 SYNTHESIS tools
        "knowledge_search" to ToolRisk.SAFE, "knowledge_list" to ToolRisk.SAFE,
        "knowledge_add" to ToolRisk.WRITE, "knowledge_forget" to ToolRisk.WRITE,
        "team_run" to ToolRisk.COST,
        // v2.21.0 AUTOMATION LAYER
        "storage_scan" to ToolRisk.SAFE, "storage_clean" to ToolRisk.WRITE,
        "tool_forge" to ToolRisk.WRITE, "automation" to ToolRisk.WRITE,
        "ui" to ToolRisk.WRITE, "native_apk" to ToolRisk.WRITE,
        // v2.30.0 APP FACTORY
        "design_tokens" to ToolRisk.WRITE, "svg_icon" to ToolRisk.SAFE,
        "vector_studio" to ToolRisk.WRITE,
        "search_code" to ToolRisk.SAFE, "repo_map" to ToolRisk.SAFE, "code_check" to ToolRisk.SAFE,
        "snapshot" to ToolRisk.WRITE, "patch" to ToolRisk.WRITE,
        // v2.23.0 SUPER AGENT
        "github" to ToolRisk.SAFE, "watch" to ToolRisk.WRITE, "trigger" to ToolRisk.WRITE,
        "digest" to ToolRisk.WRITE, "briefing" to ToolRisk.SAFE, "evolve" to ToolRisk.SAFE,
        "pack" to ToolRisk.WRITE, "local_ai" to ToolRisk.WRITE, "ocr" to ToolRisk.SAFE,
        "motion" to ToolRisk.WRITE
    )

    fun riskOf(name: String): ToolRisk? =
        risk[name] ?: ctx.dynamicTools.firstOrNull { it.spec.name == name }?.risk

    suspend fun execute(call: ToolCallData): ToolOutcome {
        val t0 = now()
        val settings = ctx.stores.settings.state.value

        // per-tool permission policy from Settings > Permissions
        when (settings.toolPolicies[call.name]) {
            "deny" -> return ToolOutcome(
                "[Tool '${call.name}' is disabled by the user (Settings → Permissions). " +
                    "Do not call it again this task; tell the user if it was essential.]", false
            )
        }

        // repair malformed / truncated tool arguments (long tool-heavy runs)
        var repairedNote = ""
        var rawArgs: JsonObject = try {
            val (fixed, wasRepaired) = JsonRepair.repair(call.argsJson)
            if (wasRepaired) repairedNote = " (auto-repaired truncated JSON arguments)"
            fixed.toJsonObject() ?: JsonObject(emptyMap())
        } catch (t: Throwable) {
            JsonObject(emptyMap())
        }
        // v2.24.1: unwrap nested {"arguments":{...}} wrappers (real-world model bug)
        val norm = ArgsNormalizer.normalize(rawArgs)
        val args: JsonObject = norm.args
        if (norm.fixedNote != null && repairedNote.isEmpty()) repairedNote = " (${norm.fixedNote})"

        // v2.29.0 HARDENED HARNESS — deterministic PreToolUse guardrails
        if (!PolicyHooks.allow()) {
            DiagLog.warn("policy", "rate limit: tool flood from ${'$'}{call.name} blocked")
            return ToolOutcome(
                "[Rate limit: more than 90 tool calls in the last minute — the harness paused you as a circuit " +
                    "breaker against runaway loops. Stop, re-read the goal, and continue with FEWER, well-chosen calls.]",
                false, emptyList(), now() - t0
            )
        }
        if (call.name == "termux_run" || call.name == "run_code") {
            val cmdish = args.strAny("command", "cmd", "script", "code", "command_line")
            if (cmdish != null) {
                PolicyHooks.checkCommand(cmdish)?.let { denial ->
                    DiagLog.warn("policy", "blocked destructive pattern in ${'$'}{call.name}: " + PolicyHooks.redact(cmdish.take(120)))
                    return ToolOutcome(denial, false, emptyList(), now() - t0)
                }
            }
        }

        val r = risk[call.name]
        if (r != null && r != ToolRisk.SAFE) ctx.mutatingToolCalls++
        val policyAllows = settings.toolPolicies[call.name] == "allow"
        if (r != null && r != ToolRisk.SAFE && !settings.autoApproveTools &&
            call.name !in settings.alwaysAllowTools && !policyAllows
        ) {
            val approved = ctx.requestApproval(call)
            if (!approved) {
                return ToolOutcome(
                    "[User declined to run '${call.name}'. Adjust your approach or ask what to do.]",
                    false, emptyList(), now() - t0
                )
            }
        }

        val outcome = withContext(Dispatchers.IO) {
            try {
                when (call.name) {
                    "list_files" -> execListFiles(args)
                    "read_file" -> execReadFile(args)
                    "write_file" -> execWriteFile(args)
                    "append_file" -> execAppendFile(args)
                    "edit_file" -> execEditFile(args)
                    "delete_file" -> execDeleteFile(args)
                    "http_request" -> execHttp(args)
                    "web_search" -> execWebSearch(args)
                    "read_link" -> execReadLink(args)
                    "use_skill" -> execUseSkill(args)
                    "search_skills" -> execSearchSkills(args)
                    "install_skill" -> execInstallSkill(args)
                    "spawn_subagent" -> execSpawnSubagent(args)
                    "memory_save" -> execMemorySave(args)
                    "memory_recall" -> execMemoryRecall(args)
                    "calculator" -> execCalculator(args)
                    "run_js" -> execRunJs(args)
                    "run_code" -> execRunCode(args)
                    "render_html" -> execRenderHtml(args)
                    "datetime" -> execDatetime()
                    "wait" -> execWait(args)
                    "ask_user" -> execAskUser(args)
                    "image_generate" -> execImageGenerate(args)
                    "build_apk" -> execBuildApk(args)
                    "storage_list" -> execStorageList(args)
                    "storage_read" -> execStorageRead(args)
                    "storage_write" -> execStorageWrite(args)
                    "mcp_connect" -> execMcpConnect(args)
                    "profile_update" -> execProfileUpdate(args)
                    "mission" -> execMission(args)
                    "skill_create" -> execSkillCreate(args)
                    "device" -> if (args.str("action")?.trim()?.lowercase() == "location") execDeviceLocation(args) else execDevice(args)
                    "termux_run" -> execTermuxRun(args)
                    "schedule" -> execSchedule(args)
                    "knowledge_add" -> execKnowledgeAdd(args)
                    "knowledge_search" -> execKnowledgeSearch(args)
                    "knowledge_list" -> execKnowledgeList()
                    "knowledge_forget" -> execKnowledgeForget(args)
                    "team_run" -> execTeamRun(args)
                    "storage_scan" -> execStorageScan(args)
                    "storage_clean" -> execStorageClean(args)
                    "tool_forge" -> execToolForge(args)
                    "automation" -> execAutomation(args)
                    "ui" -> execUi(args)
                    "native_apk" -> execNativeApk(args)
                    "design_tokens" -> execDesignTokens(args)
                    "svg_icon" -> execSvgIcon(args)
                    "vector_studio" -> execVectorStudio(args)
                    "search_code" -> execSearchCode(args)
                    "repo_map" -> execRepoMap(args)
                    "code_check" -> execCodeCheck(args)
                    "snapshot" -> execSnapshot(args)
                    "patch" -> execPatch(args)
                    "nine_router" -> execNineRouter(args)
                    "github" -> execGithub(args)
                    "watch" -> execWatch(args)
                    "trigger" -> execTrigger(args)
                    "digest" -> execDigest(args)
                    "briefing" -> execBriefing(args)
                    "evolve" -> execEvolve(args)
                    "pack" -> execPack(args)
                    "local_ai" -> execLocalAi(args)
                    "ocr" -> execOcr(args)
                    "motion" -> execMotion(args)
                    "finish" -> {
                        // v2.31 — LEARNING LAW: a substantial build that taught a
                        // repeatable procedure must leave a skill behind. One
                        // nudge per run, then finish passes.
                        if (!ctx.skillCreatedThisRun && !ctx.finishNudgeGiven &&
                            ctx.mutatingToolCalls >= 6 && ctx.skillSystem != null
                        ) {
                            ctx.finishNudgeGiven = true
                            ToolOutcome(
                                "[LEARNING CHECK before finishing: this run made ${ctx.mutatingToolCalls} changes, which " +
                                    "means you worked out a real procedure. If ANY part of it is repeatable (a service setup, " +
                                    "an API flow, a build pipeline, a fix pattern — e.g. how you wired that Telegram/Bale bot), " +
                                    "save it NOW with skill_create {name, description, instructions} so the next task starts " +
                                    "faster and cheaper. If nothing here was genuinely reusable, call finish again and it will pass.]",
                                false
                            )
                        } else ToolOutcome(args.str("summary") ?: "Done.", true)
                    }
                    else -> ctx.dynamicTools.firstOrNull { it.spec.name == call.name }
                        ?.run?.invoke(args)
                        ?: ToolOutcome("Unknown tool '${call.name}'. Available: ${specs.joinToString { it.name }}", false)
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce // run cancelled — never swallow it as a fake tool failure
            } catch (t: Throwable) {
                ToolOutcome("Error: ${t.message ?: t.javaClass.simpleName}", false)
            }
        }
        val noteSuffix = if (repairedNote.isNotEmpty()) "\n[note$repairedNote]" else ""
        // v2.29.0 OUTPUT SHAPING — head+tail + spill the full output to a
        // workspace file the model can read back (never 200 KB into context)
        val shapedText = PolicyHooks.shape(outcome.text) { full ->
            runCatching {
                val dir = java.io.File(ctx.workspace, ".liman-overflow").apply { mkdirs() }
                val f = java.io.File(dir, "overflow-" + System.currentTimeMillis() + "-" + call.name + ".txt")
                f.writeText(full)
                ".liman-overflow/" + f.name
            }.getOrNull()
        }
        var finalOutcome = outcome.copy(ms = now() - t0, text = shapedText + noteSuffix)
        // v2.32.0 LESSONS — failure memory: the SAME tool failing the SAME way
        // twice is a lesson. It lands in .liman-lessons.md (read on every run
        // start) so the mistake is never repeated in a later session.
        if (!finalOutcome.ok) finalOutcome = rememberFailure(call.name, finalOutcome)
        // v2.28.0 Doctor's Log — every tool call lands in the backend log (secrets redacted)
        if (finalOutcome.ok)
            DiagLog.log("tool", PolicyHooks.redact("${call.name} ok ${finalOutcome.ms}ms — ${finalOutcome.text.take(140)}"))
        else
            DiagLog.warn("tool", PolicyHooks.redact("${call.name} FAILED ${finalOutcome.ms}ms — ${finalOutcome.text.take(200)}"))
        return finalOutcome
    }

    /** v2.32 — signature of a failure = tool + first 90 chars of the error text. */
    private fun rememberFailure(tool: String, outcome: ToolOutcome): ToolOutcome {
        val sig = tool + " :: " + outcome.text.take(90).replace("\n", " ")
        val n = (failureCounts[sig] ?: 0) + 1
        failureCounts[sig] = n
        if (n < 2) return outcome
        runCatching {
            val f = java.io.File(ctx.workspace, ".liman-lessons.md")
            val entry = "- [$tool] failed twice the same way: " + outcome.text.take(200).replace("\n", " ") +
                " — next time try a different route BEFORE repeating this."
            if (!f.exists() || !f.readText().contains(entry)) f.appendText(
                (if (f.exists()) "" else "# Liman's own lessons — mistakes to never repeat\n\n") + entry + "\n"
            )
        }
        return outcome.copy(text = outcome.text +
            "\n[LESSON RECORDED: '$tool' now failed this same way $n times — the fix is appended to .liman-lessons.md. STOP repeating this approach; pick a different route.]")
    }
    private val failureCounts = java.util.concurrent.ConcurrentHashMap<String, Int>()

    // ---------------- mega agent tools ----------------

    private fun execMission(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase() ?: return ToolOutcome("Missing 'action'.", false)
        return when (action) {
            "plan" -> {
                val title = args.str("title")?.takeIf { it.isNotBlank() } ?: return ToolOutcome("Missing 'title'.", false)
                val arr = (args["tasks"] as? JsonArray) ?: return ToolOutcome("Missing 'tasks' array.", false)
                val tasks = arr.mapNotNull { el ->
                    val o = el as? JsonObject ?: return@mapNotNull null
                    val id = o.str("id")?.trim() ?: return@mapNotNull null
                    val goal = o.str("goal")?.trim() ?: return@mapNotNull null
                    MissionTask(id, goal, o.str("criteria")?.trim() ?: "")
                }
                if (tasks.isEmpty()) return ToolOutcome("Task list is empty.", false)
                mission.plan(title, tasks)
                // v2.31 — live roadmap card in the chat
                runCatching { ctx.onMissionState?.invoke(title, mission.tasks) }
                ToolOutcome(
                    "Mission plan set. Follow it unless you discover a better approach; update after every task.\n" +
                        mission.render(),
                    true
                )
            }
            "progress", "done", "update" -> {
                val taskId = args.strAny("taskId", "task_id", "id", "task")?.trim()
                    ?: return ToolOutcome(ArgsNormalizer.missingArg("mission", "taskId", args, """{"action":"done","taskId":"<id>"}""") + " Run {action:'show'} to see the plan with its ids.", false)
                val status = when (action) {
                    "progress" -> "in_progress"
                    else -> args.str("status")?.trim()?.lowercase()?.takeIf { it in setOf("done", "failed", "blocked", "in_progress") } ?: "done"
                }
                val resolved = mission.resolveTaskId(taskId)
                    ?: return ToolOutcome(
                        "Unknown task id '$taskId'. Valid ids: [${mission.tasks.joinToString(", ") { it.id }}]. " +
                            "Use one of these exactly (or its 1-based index). Current plan:\n" + mission.render(), false
                    )
                mission.update(resolved.id, status)
                // v2.31 — live roadmap card in the chat
                runCatching { ctx.onMissionState?.invoke(mission.title, mission.tasks) }
                ToolOutcome(mission.render(), true)
            }
            "show" -> ToolOutcome(mission.render(), true)
            else -> ToolOutcome("Unknown action '$action'. Use plan | progress | done | update | show.", false)
        }
    }

    private fun execSkillCreate(args: JsonObject): ToolOutcome {
        val name = args.str("name")?.trim() ?: return ToolOutcome("Missing 'name'.", false)
        val desc = args.str("description")?.trim() ?: return ToolOutcome("Missing 'description'.", false)
        val instructions = args.str("instructions")?.trim() ?: return ToolOutcome("Missing 'instructions'.", false)
        val skillSystem = ctx.skillSystem ?: return ToolOutcome("Skill system unavailable.", false)
        return runCatching {
            val md = buildString {
                appendLine("---")
                appendLine("name: $name")
                appendLine("description: $desc")
                appendLine("---")
                appendLine()
                appendLine(instructions)
            }
            val id = skillSystem.installFromMarkdown(name, desc, md, "")
            ctx.skillCreatedThisRun = true
            ToolOutcome("Skill installed (id: $id). It is now in the catalog and can be auto-loaded or used via use_skill in future tasks.", true)
        }.getOrElse { ToolOutcome("Could not save skill: ${it.message}", false) }
    }

    private fun execDevice(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase() ?: return ToolOutcome("Missing 'action'.", false)
        val context = ctx.appContext
        return runCatching {
            when (action) {
                "battery" -> {
                    val bm = context.getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager
                    val pct = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
                    val charging = bm.isCharging
                    ToolOutcome("Battery: $pct% ${if (charging) "(charging)" else "(on battery)"}", true)
                }
                "clipboard_get" -> {
                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                    ToolOutcome(if (t.isBlank()) "(clipboard empty)" else "Clipboard content:\n$t", true)
                }
                "clipboard_set" -> {
                    val text = args.str("text") ?: return ToolOutcome("Missing 'text'.", false)
                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Liman", text))
                    ToolOutcome("Copied to clipboard.", true)
                }
                "vibrate" -> {
                    val v = context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as android.os.Vibrator
                    if (android.os.Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(400, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                    else @Suppress("DEPRECATION") v.vibrate(400)
                    ToolOutcome("Vibrated.", true)
                }
                "notify" -> {
                    val title = args.str("title")?.takeIf { it.isNotBlank() } ?: "Liman"
                    val text = args.str("text")?.takeIf { it.isNotBlank() } ?: return ToolOutcome("Missing 'text'.", false)
                    com.liman.agent.agent.Scheduler.notify(context, title, text)
                    ToolOutcome("Notification posted.", true)
                }
                "open_url" -> {
                    // v2.32 — WEB OPERATOR: open a URL in the user's browser
                    // (Chrome) — then drive it with the ui tool (a11y snapshot
                    // → tap → type) when no API route exists.
                    val url = args.str("url")?.trim()?.takeIf { it.startsWith("http") }
                        ?: return ToolOutcome("Missing or invalid 'url'.", false)
                    val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                    i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    runCatching { context.startActivity(i) }
                        .onFailure { return ToolOutcome("Could not open browser: ${it.message}", false) }
                    ToolOutcome("Opened in the browser. Take over with the ui tool: {action:'snapshot'} to see the page, tap/type to act. (If the user is watching, tell them what you are doing.)", true)
                }
                else -> ToolOutcome("Unknown action '$action'. Use battery | clipboard_get | clipboard_set | vibrate | notify | open_url.", false)
            }
        }.getOrElse {
            if (it is kotlinx.coroutines.CancellationException) throw it
            ToolOutcome("Device action failed: ${it.message}", false)
        }
    }

    /** The local-router port the Termux bridge rides on (starts it if needed). */
    private fun termuxPort(): Int? {
        val settings = ctx.stores.settings.state.value
        return com.liman.agent.llm.RouterServer.runningPort()
            ?: runCatching {
                if (com.liman.agent.llm.RouterServer.start(ctx.stores, settings.routerPort, settings.routerLan)) settings.routerPort
                else null
            }.getOrNull()
    }

    private suspend fun execTermuxRun(args: JsonObject): ToolOutcome {
        // v2.32 — CODING-AGENT ACTIONS: toolchain doctor + one-command dev server
        when (args.strAny("action", "op")?.trim()?.lowercase()) {
            "doctor" -> return termuxDoctor()
            "dev_server" -> return termuxDevServer(args)
        }
        val command = args.strAny("command", "cmd", "script", "command_line")?.trim()
            ?: return ToolOutcome(ArgsNormalizer.missingArg("termux_run", "command", args, """{"command":"ls -la"}""") + " Or use {action:'doctor'} / {action:'dev_server', path:'site'}.", false)
        val timeoutS = ((args.intOrNull("timeoutSeconds") ?: 120).coerceIn(10, 600))
        // the bridge rides on Liman's local router — make sure it is up
        val port = termuxPort()
            ?: return ToolOutcome(
                "The local router is not running and could not be started (Settings → Local router). " +
                    "The Termux bridge needs it as a transport.", false
            )
        val out = TermuxBridge.run(ctx.appContext, port, command, timeoutS * 1000L)
        val ok = !out.startsWith("Termux is not installed") &&
            !out.startsWith("Liman lacks") &&
            !out.startsWith("Could not send") &&
            !out.startsWith("No response from Termux")
        if (!ok) {
            DiagLog.error("termux", "bridge failure: " + out.take(200))
            return ToolOutcome(out.take(20_000), ok)
        }
        // v2.28.0 DEPENDENCY SELF-HEAL — "command not found" / missing python
        // module no longer dead-ends the run: install the package once and retry.
        val fix = TermuxHeal.diagnose(out)
        if (fix != null) {
            DiagLog.warn("termux", "self-heal: " + fix.missing + " missing → " + fix.installCommand)
            val installOut = TermuxBridge.run(ctx.appContext, port, fix.installCommand, 240_000L)
            val retry = TermuxBridge.run(ctx.appContext, port, command, timeoutS * 1000L)
            val retryOk = !retry.startsWith("No response from Termux") && TermuxHeal.diagnose(retry) == null
            if (retryOk) return ToolOutcome(TermuxHeal.healReport(fix, retry), true)
            return ToolOutcome(
                "🔧 SELF-HEAL attempted: installed '" + fix.missing + "' (" + fix.installCommand + ") but the retry still failed.\n" +
                    "Install output: " + installOut.take(2_000) + "\nRetry output: " + retry.take(18_000), false
            )
        }
        return ToolOutcome(truncateWithFile(out), true)
    }

    /** v2.36 — long command output: keep 20k chars in context, save the
     *  FULL log to a workspace file the agent can read later. */
    private fun truncateWithFile(out: String, cap: Int = 20_000): String {
        if (out.length <= cap) return out
        val f = File(ctx.workspace, "termux-output-${System.currentTimeMillis()}.txt")
        runCatching { f.writeText(out) }
        return out.take(cap) + "\n…(truncated — full output saved to ${f.name}; read it with read_file)"
    }

    private fun execSchedule(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase() ?: return ToolOutcome("Missing 'action'.", false)
        val store = ctx.stores.schedule
        return when (action) {
            "list" -> {
                val all = store.state.value
                if (all.isEmpty()) ToolOutcome("No scheduled missions yet.", true)
                else ToolOutcome(all.joinToString("\n") { t ->
                    val sched = if (t.everyHours > 0) "every ${t.everyHours}h" else "daily ${t.dailyAt}"
                    "- [${t.id}] ${t.title} · $sched · ${if (t.enabled) "enabled" else "OFF"}"
                }, true)
            }
            "add" -> {
                val title = args.str("title")?.trim()?.takeIf { it.isNotBlank() } ?: return ToolOutcome("Missing 'title'.", false)
                val prompt = args.str("prompt")?.trim()?.takeIf { it.isNotBlank() } ?: return ToolOutcome("Missing 'prompt'.", false)
                val everyHours = args.intOrNull("everyHours")?.coerceIn(1, 168) ?: 0
                val dailyAt = args.str("dailyAt")?.trim() ?: "08:00"
                if (everyHours <= 0 && ScheduleLogic.parseHm(dailyAt) == null)
                    return ToolOutcome("Invalid 'dailyAt' — use HH:MM (24h), e.g. 08:30.", false)
                val activeHours = args.str("activeHours")?.trim()?.takeIf { it.isNotEmpty() }
                if (activeHours != null && !Regex("""^\d{1,2}:\d{2}-\d{1,2}:\d{2}$""").matches(activeHours))
                    return ToolOutcome("Invalid 'activeHours' — use HH:MM-HH:MM, e.g. 09:00-22:00.", false)
                val task = com.liman.agent.data.ScheduledTask(
                    id = genId("cron"),
                    title = title, prompt = prompt,
                    dailyAt = if (everyHours > 0) "08:00" else dailyAt,
                    everyHours = everyHours, enabled = true,
                    activeHours = activeHours
                )
                store.upsert(task)
                com.liman.agent.agent.Scheduler.notify(ctx.appContext, "⏰ Mission scheduled", "$title — " + (if (everyHours > 0) "every ${everyHours}h" else "daily $dailyAt"))
                ToolOutcome("Scheduled mission created: [${task.id}] $title (${if (everyHours > 0) "every ${everyHours}h" else "daily $dailyAt"}${if (activeHours != null) ", active $activeHours" else ""}). It runs as a full agent cycle even with the app closed; results appear as ⏰ conversations.", true)
            }
            "remove" -> {
                val id = args.str("id")?.trim() ?: return ToolOutcome("Missing 'id' (call list first).", false)
                if (store.state.value.none { it.id == id }) return ToolOutcome("No scheduled mission with id '$id'.", false)
                store.delete(id)
                ToolOutcome("Removed scheduled mission $id.", true)
            }
            else -> ToolOutcome("Unknown action '$action'. Use list | add | remove.", false)
        }
    }

    // ---------------- v2.23.0 SUPER AGENT TOOLS ----------------

    private fun ghToken(): String? = ctx.stores.tokens.get(GithubResearch.TOKEN_NAME)

    private suspend fun execGithub(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (search | research | readme | tree | file | token).", false)
        val token = ghToken()
        return when (action) {
            "search" -> {
                val q = args.str("query")?.trim().orEmpty()
                if (q.isBlank()) return ToolOutcome("Missing 'query'.", false)
                ToolOutcome(
                    GithubResearch.search(q, args.str("language"), (args.intOrNull("limit") ?: 8).coerceIn(1, 30), token), true
                )
            }
            "research" -> {
                val q = args.str("query")?.trim().orEmpty()
                if (q.isBlank()) return ToolOutcome("Missing 'query'.", false)
                ToolOutcome(GithubResearch.research(q, args.str("language"), token), true)
            }
            "readme" -> {
                val repo = args.str("repo")?.trim().orEmpty()
                ToolOutcome(GithubResearch.readme(repo, token), true)
            }
            "tree" -> {
                val repo = args.str("repo")?.trim().orEmpty()
                ToolOutcome(GithubResearch.tree(repo, args.str("filter"), token), true)
            }
            "file" -> {
                val repo = args.str("repo")?.trim().orEmpty()
                val path = args.str("path")?.trim().orEmpty()
                ToolOutcome(GithubResearch.file(repo, path, args.str("branch").orEmpty(), token), true)
            }
            "token" -> {
                val t = args.str("token")?.trim().orEmpty()
                if (t.isBlank()) return ToolOutcome("Missing 'token' (create a fine-grained PAT at github.com/settings/tokens — no scopes needed for public repos).", false)
                ctx.stores.tokens.set(GithubResearch.TOKEN_NAME, t)
                ToolOutcome("GitHub token saved (raises the limit to 5000 req/hr). It is stored locally and never shown again.", true)
            }
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    private suspend fun execWatch(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (add | list | remove | check | test).", false)
        val store = ctx.stores.watchers
        return when (action) {
            "add" -> {
                val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() } ?: return ToolOutcome("Missing 'name'.", false)
                val url = args.str("url")?.trim()?.takeIf { it.startsWith("http") } ?: return ToolOutcome("Missing/invalid 'url'.", false)
                val extract = args.str("extract")?.trim()?.lowercase() ?: "text"
                if (extract !in setOf("text", "regex")) return ToolOutcome("'extract' must be text or regex.", false)
                val pattern = args.str("pattern")?.trim().orEmpty()
                if (extract == "regex" && pattern.isBlank()) return ToolOutcome("extract=regex needs a 'pattern'.", false)
                if (extract == "regex" && runCatching { Regex(pattern) }.isFailure)
                    return ToolOutcome("Invalid regex pattern.", false)
                val w = com.liman.agent.data.Watcher(
                    id = genId("watch"), name = name, url = url, extract = extract, pattern = pattern,
                    everyMinutes = (args.intOrNull("everyMinutes") ?: 30).coerceIn(5, 1440)
                )
                store.upsert(w)
                ToolOutcome("Watcher added: [${w.id}] '$name' on ${w.url} (${w.extract}${if (pattern.isNotBlank()) " /$pattern/" else ""}, every ${w.everyMinutes}m). Check it on a schedule (schedule/pipeline) with watch {action:'check'}.", true)
            }
            "list" -> {
                val all = store.state.value
                if (all.isEmpty()) ToolOutcome("No watchers yet — add one with watch {action:'add', name:…, url:…}.", true)
                else ToolOutcome(buildString {
                    appendLine("Watchers (${all.size}):")
                    all.forEach {
                        appendLine("- [${it.id}] ${it.name} · ${it.url} · ${it.extract}${if (it.pattern.isNotBlank()) " /${it.pattern}/" else ""} · every ${it.everyMinutes}m · ${if (it.enabled) "ON" else "OFF"} · last: ${it.lastValue.take(60).ifBlank { "—" }}")
                    }
                }, true)
            }
            "remove" -> {
                val id = args.str("id")?.trim() ?: return ToolOutcome("Missing 'id'.", false)
                if (store.get(id) == null) return ToolOutcome("No watcher with id '$id'.", false)
                store.delete(id)
                ToolOutcome("Watcher $id removed.", true)
            }
            "test" -> {
                val url = args.str("url")?.trim()?.takeIf { it.startsWith("http") }
                    ?: return ToolOutcome("Missing/invalid 'url' for a test.", false)
                val extract = args.str("extract")?.trim()?.lowercase() ?: "text"
                val pattern = args.str("pattern")?.trim().orEmpty()
                val probe = com.liman.agent.data.Watcher(id = "probe", name = "probe", url = url, extract = extract, pattern = pattern)
                val r = WatcherEngine.check(probe)
                ToolOutcome("TEST ${probe.url}:\n${if (r.extraction.isNotBlank()) "extracted: ${r.extraction.take(400)}" else r.note}", true)
            }
            "check" -> {
                val id = args.str("id")?.trim()
                val targets = if (id != null) listOfNotNull(store.get(id))
                else store.state.value.filter { it.enabled }
                if (targets.isEmpty()) return ToolOutcome(if (id != null) "No watcher with id '$id'." else "No enabled watchers.", false)
                val nowMs = now()
                val results = mutableListOf<String>()
                var anyChanged = false
                targets.forEach { w ->
                    val r = WatcherEngine.check(w)
                    val first = w.lastValue.isBlank()
                    store.touch(w.id, r.extraction.ifBlank { w.lastValue }, r.changed, nowMs)
                    results += WatcherEngine.formatResult(w, r)
                    if (r.changed) {
                        anyChanged = true
                        Scheduler.notify(ctx.appContext, "🔔 Watcher: ${w.name}", r.extraction.take(200))
                        Journal.append(ctx.workspace, "watcher", "${w.name} changed: ${r.extraction.take(120)}")
                    }
                }
                ToolOutcome(results.joinToString("\n") { it.trim() } + if (anyChanged) "\n(Changes journaled + user notified.)" else "\n(No changes.)", true)
            }
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    private suspend fun execTrigger(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (add | list | remove | survival).", false)
        val store = ctx.stores.triggers
        return when (action) {
            "add" -> {
                val kind = args.str("kind")?.trim()?.lowercase().orEmpty()
                if (!Triggers.validKind(kind)) return ToolOutcome("Invalid 'kind' — use one of: ${Triggers.KINDS.joinToString(", ")}.", false)
                val prompt = args.str("prompt")?.trim()?.takeIf { it.isNotBlank() } ?: return ToolOutcome("Missing 'prompt' (what Liman should do when it fires).", false)
                val title = args.str("title")?.trim()?.takeIf { it.isNotBlank() } ?: kind
                val t = com.liman.agent.data.Trigger(
                    id = genId("trig"), title = title, kind = kind, prompt = prompt,
                    cooldownMinutes = (args.intOrNull("cooldownMinutes") ?: 15).coerceIn(1, 1440)
                )
                store.upsert(t)
                ToolOutcome("Context trigger armed: [${t.id}] '$title' on $kind (cooldown ${t.cooldownMinutes}m). When it fires, Liman runs a full agent cycle with your prompt — results appear as ⚡ conversations + notifications.", true)
            }
            "list" -> ToolOutcome(Triggers.formatList(store.state.value), true)
            "remove" -> {
                val id = args.str("id")?.trim() ?: return ToolOutcome("Missing 'id'.", false)
                if (store.state.value.none { it.id == id }) return ToolOutcome("No trigger with id '$id'.", false)
                store.delete(id)
                ToolOutcome("Trigger $id removed.", true)
            }
            "survival" -> {
                val startBrain = args.bool("startBrainToo") ?: false
                val out = NativeBuilder.bridgeRun(ctx.appContext, ctx.stores, LocalBrain.survivalScript(startBrain), 300)
                val ok = out.contains("LIMAN_SURVIVAL_OK")
                ToolOutcome((if (ok) "SURVIVAL KIT INSTALLED in Termux (wake-lock + crond + boot script).\n" else "Survival setup incomplete:\n") + out.take(4000), ok)
            }
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    private fun execDigest(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (config | build | status).", false)
        val store = ctx.stores.digest
        return when (action) {
            "config" -> {
                val enabled = args.bool("enabled")
                val windows = args.strList("windows")
                val urgent = args.strList("urgentPatterns")
                windows.forEach { w ->
                    if (!Regex("""^[0-9]{1,2}:[0-9]{2}$""").matches(w.trim())) return ToolOutcome("Invalid window '$w' — use HH:MM.", false)
                }
                urgent.forEach { p ->
                    if (runCatching { Regex(p) }.isFailure) return ToolOutcome("Invalid urgent regex '$p'.", false)
                }
                store.update { cfg ->
                    enabled?.let { cfg.enabled = it }
                    if (windows.isNotEmpty()) cfg.windows = windows.map { it.trim() }
                    if (urgent.isNotEmpty()) cfg.urgentPatterns = urgent
                }
                val cfg = store.state.value
                ToolOutcome("Digest config: ${if (cfg.enabled) "ENABLED" else "disabled"} · windows ${cfg.windows.joinToString(", ")} · urgent rules: ${cfg.urgentPatterns.size}. Build digests from a schedule with digest {action:'build'}.", true)
            }
            "build" -> {
                val cfg = store.state.value
                // collect NOTIF lines from all demo session logs since last digest
                val demoDir = File(ctx.workspace, "demo")
                val logs = demoDir.listFiles { f -> f.name.startsWith("session-") && f.name.endsWith(".log") }
                    ?.sortedBy { it.name } ?: emptyList()
                val allLines = logs.flatMap { Journal.notifLines(it.readText()) }
                if (allLines.isEmpty())
                    return ToolOutcome("No notifications collected (need the accessibility service collecting — ui tool). Nothing to digest.", true)
                val recent = if (cfg.lastDigestAt == 0L) allLines.takeLast(200) else allLines.takeLast(400)
                val parsed = Digest.parse(recent)
                val grouped = Digest.groupByApp(parsed)
                val urgentLines = Digest.urgent(parsed, cfg.urgentPatterns)
                val sinceDesc = if (cfg.lastDigestAt == 0L) "first digest" else "since last digest"
                val text = Digest.build(grouped, urgentLines, sinceDesc)
                store.update { it.lastDigestAt = now() }
                Journal.append(ctx.workspace, "digest", "${parsed.size} notifications, ${grouped.size} apps, ${urgentLines.size} urgent")
                if (urgentLines.isNotEmpty())
                    Scheduler.notify(ctx.appContext, "⚠ Urgent notifications", urgentLines.take(3).joinToString("\n") { it.full }.take(300))
                ToolOutcome(text + "\n\nDeliver this digest to the user now (summarize the top items in one message).", true)
            }
            "status" -> {
                val cfg = store.state.value
                val demoDir = File(ctx.workspace, "demo")
                val logs = demoDir.listFiles { f -> f.name.endsWith(".log") }?.size ?: 0
                ToolOutcome("Digest: ${if (cfg.enabled) "ENABLED" else "disabled"} · windows ${cfg.windows.joinToString(", ")} · urgent ${cfg.urgentPatterns.size} rule(s) · last digest ${if (cfg.lastDigestAt == 0L) "never" else cfg.lastDigestAt.fmtTime()} · demo logs: $logs.", true)
            }
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    private fun execBriefing(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (note | write | read).", false)
        return when (action) {
            "note" -> {
                val text = args.str("text")?.trim()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'text' for the journal note.", false)
                val f = Journal.append(ctx.workspace, "note", text)
                ToolOutcome("Journaled: ${text.take(120)}\n(${relPath(f)})", true)
            }
            "write" -> {
                val nowMs = now()
                val yesterdayFile = Journal.dayFile(ctx.workspace, nowMs - 24 * 3600_000L)
                val todayFile = Journal.dayFile(ctx.workspace, nowMs)
                val yesterday = runCatching { yesterdayFile.readText() }.getOrDefault("")
                val today = runCatching { todayFile.readText() }.getOrDefault("")
                val scheduled = ctx.stores.schedule.state.value
                val ranSince = scheduled.count { it.lastRunAt >= nowMs - 24 * 3600_000L }
                val watchersChanged = ctx.stores.watchers.state.value
                    .filter { it.lastChangedAt >= nowMs - 24 * 3600_000L }
                    .map { "${it.name}: ${it.lastValue.take(80)}" }
                // notification pulse from demo logs (last 24h worth of logs by name date)
                val demoDir = File(ctx.workspace, "demo")
                val logs = demoDir.listFiles { f -> f.name.endsWith(".log") }?.sortedBy { it.name } ?: emptyList()
                val notifs = Digest.parse(logs.flatMap { Journal.notifLines(it.readText()) }.takeLast(300))
                val cfg = ctx.stores.digest.state.value
                val urgent = Digest.urgent(notifs, cfg.urgentPatterns)
                val facts = Journal.BriefingFacts(
                    journalToday = today,
                    journalYesterday = yesterday,
                    missionsScheduled = scheduled.count { it.enabled },
                    missionsRunSinceYesterday = ranSince,
                    watchersChanged = watchersChanged,
                    notificationCounts = Digest.groupByApp(notifs).mapValues { it.value.size },
                    urgentNotifications = urgent.map { it.full }
                )
                val skeleton = Journal.buildBriefing(facts, nowMs)
                // seed the daily briefing mission once
                if (scheduled.none { it.title.contains("Morning briefing", ignoreCase = true) }) {
                    ctx.stores.schedule.upsert(
                        com.liman.agent.data.ScheduledTask(
                            id = genId("cron"), title = "🌅 Morning briefing",
                            prompt = "Run the morning briefing: use briefing {action:'write'} to gather the facts, enrich '## Today' with what is actually scheduled (schedule list, watchers due, HEARTBEAT items), then deliver ONE concise briefing message to the user and journal a one-line summary with briefing {action:'note'}.",
                            dailyAt = "08:30", enabled = true
                        )
                    )
                }
                ToolOutcome(skeleton + "\n\nEnrich '## Today' with the schedule/watchers/HEARTBEAT, then deliver the briefing as ONE concise message.", true)
            }
            "read" -> {
                val f = Journal.dayFile(ctx.workspace)
                if (!f.exists()) ToolOutcome("No journal entry for today yet.", true)
                else ToolOutcome("Today's journal:\n" + f.readText().take(4000), true)
            }
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    private fun execEvolve(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase() ?: "reflect"
        val metas = ctx.stores.conversations.state.value
        val convs = metas.take(12).mapNotNull { ctx.stores.conversations.load(it.id) }
        val stats = Evolve.stats(convs)
        if (action == "stats") {
            return ToolOutcome(
                "Recent activity: ${stats.conversations} conversation(s), ${stats.toolCalls} tool call(s), ${stats.failures} failure(s).\nTop tools: ${stats.topTools.joinToString(", ").ifBlank { "—" }}", true
            )
        }
        val goals = metas.take(12).map { it.title }
        val skillNames = ctx.stores.skills.state.value.map { it.name }
        val today = runCatching { Journal.dayFile(ctx.workspace).readText() }.getOrDefault("")
        val directive = Evolve.retrospection(stats, goals, skillNames, today)
        return ToolOutcome(directive, true)
    }

    private fun execPack(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (export | import | list).", false)
        val packsDir = File(ctx.workspace, "packs").apply { mkdirs() }
        return when (action) {
            "list" -> {
                val packs = packsDir.listFiles { f -> f.name.endsWith(".limanpack.zip") } ?: emptyArray()
                if (packs.isEmpty()) ToolOutcome("No packs in workspace/packs/ yet — export one with pack {action:'export', name:…}.", true)
                else ToolOutcome(buildString {
                    appendLine("Packs (${packs.size}):")
                    packs.forEach { f ->
                        val m = Packs.readManifest(f)
                        appendLine("- ${f.name} · ${m?.name ?: "?"} · ${m?.skills?.size ?: 0} skill(s), ${m?.pipelines ?: 0} pipeline(s), ${m?.triggers ?: 0} trigger(s), ${m?.watchers ?: 0} watcher(s)")
                    }
                }, true)
            }
            "export" -> {
                val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() } ?: return ToolOutcome("Missing 'name'.", false)
                val skillIds = args.strList("skills").ifEmpty {
                    ctx.stores.skills.state.value.map { it.id }
                }
                val includePipelines = args.bool("pipelines") ?: true
                val skillsDir = File(ctx.appContext.filesDir, "skills")
                val f = Packs.exportPack(
                    name, packsDir, skillsDir, skillIds,
                    if (includePipelines) ctx.stores.pipelines.state.value else emptyList(),
                    ctx.stores.triggers.state.value,
                    ctx.stores.watchers.state.value,
                    args.str("notes").orEmpty()
                )
                ToolOutcome("Pack exported: ${relPath(f)} (${f.length()} bytes, ${skillIds.size} skill(s), ${if (includePipelines) ctx.stores.pipelines.state.value.size else 0} pipeline(s), ${ctx.stores.triggers.state.value.size} trigger(s), ${ctx.stores.watchers.state.value.size} watcher(s)). Share the file — import it on any Liman with pack {action:'import', path:…}.", true)
            }
            "import" -> {
                val path = args.str("path")?.trim()
                    ?: return ToolOutcome("Missing 'path' (workspace path to a .limanpack.zip).", false)
                val f = if (path.startsWith("/")) File(path) else File(ctx.workspace, path)
                if (!f.isFile) return ToolOutcome("Pack file not found: $path.", false)
                val skillsDir = File(ctx.appContext.filesDir, "skills")
                val existing = ctx.stores.skills.state.value.map { it.id }
                var pipelinesAdded = 0
                var triggersAdded = 0
                var watchersAdded = 0
                val result = Packs.importPack(
                    f, skillsDir, existing,
                    { list ->
                        pipelinesAdded = list.size
                        list.forEach { ctx.stores.pipelines.upsert(it.copy(id = genId("pipe"))) }
                    },
                    { list ->
                        triggersAdded = list.size
                        list.forEach { ctx.stores.triggers.upsert(it.copy(id = genId("trig"))) }
                    },
                    { list ->
                        watchersAdded = list.size
                        list.forEach { ctx.stores.watchers.upsert(it.copy(id = genId("watch"))) }
                    }
                )
                ctx.stores.skills.refresh()
                com.liman.agent.agent.Scheduler.syncPipelines(ctx.appContext)
                ToolOutcome(
                    "Pack imported: ${result.skills} skill(s) added (${result.skillsSkipped} skipped as existing), $pipelinesAdded pipeline(s), $triggersAdded trigger(s), $watchersAdded watcher(s).", true
                )
            }
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    private suspend fun execLocalAi(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (setup | start | stop | status | provider).", false)
        return when (action) {
            "status" -> {
                val out = NativeBuilder.bridgeRun(ctx.appContext, ctx.stores, LocalBrain.statusScript(), 60)
                val running = out.contains("server:RUNNING")
                ToolOutcome("LOCAL BRAIN STATUS:\n" + out.take(2000) + "\n" + LocalBrain.providerHints().let { if (running) "\n$it\n→ add it in Settings → Providers to use the local brain." else "" }, true)
            }
            "setup" -> {
                val size = args.str("size")?.trim() ?: "0.5b"
                val out = NativeBuilder.bridgeRun(ctx.appContext, ctx.stores, LocalBrain.setupScript(size), 600)
                val ok = out.contains("LIMAN_LOCAL_SETUP_OK")
                ToolOutcome((if (ok) "LOCAL BRAIN INSTALLED — start it with local_ai {action:'start'}.\n" else "Setup incomplete:\n") + out.take(6000), ok)
            }
            "start" -> {
                val out = NativeBuilder.bridgeRun(ctx.appContext, ctx.stores, LocalBrain.startScript(), 120)
                val ok = out.contains("LIMAN_LOCAL_AI_RUNNING") || out.contains("ALREADY_RUNNING")
                ToolOutcome((if (ok) "LOCAL BRAIN RUNNING at ${LocalBrain.BASE_URL} (OpenAI-compatible).\n${LocalBrain.providerHints()}\n→ add it in Settings → Providers (model: ${LocalBrain.DEFAULT_MODEL}); pair it with the free cloud providers in a combo so Liman escalates automatically." else "Start failed:\n") + out.take(4000), ok)
            }
            "stop" -> {
                val out = NativeBuilder.bridgeRun(ctx.appContext, ctx.stores, LocalBrain.stopScript(), 60)
                ToolOutcome("Local brain: ${out.trim().take(500)}", true)
            }
            "provider" -> ToolOutcome(
                "Add this provider in Settings → Providers:\n- Kind: OpenAI-compatible\n- Base URL: ${LocalBrain.BASE_URL}\n- API key: liman-local\n- Model: ${LocalBrain.DEFAULT_MODEL}\nThen enable it (alone for full privacy/offline, or first in a combo as the free default with cloud escalation).", true
            )
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    private suspend fun execOcr(args: JsonObject): ToolOutcome {
        val imagePath = args.str("image")?.trim()
            ?: return ToolOutcome("Missing 'image' (workspace path).", false)
        val f = if (imagePath.startsWith("/")) File(imagePath) else File(ctx.workspace, imagePath)
        if (!f.isFile) return ToolOutcome("Image not found: $imagePath.", false)
        if (f.length() > 4_000_000) return ToolOutcome("Image too large (${f.length()} bytes, max 4 MB) — screenshot or downscale it first.", false)
        val lang = args.str("lang")?.trim() ?: "eng"
        val b64 = OcrBridge.encode(f.readBytes())
        val script = OcrBridge.runScript(b64, lang)
        val out = NativeBuilder.bridgeRun(ctx.appContext, ctx.stores, script, 180)
        if (out.contains("tesseract: not found") || out.contains("not installed"))
            return ToolOutcome("tesseract is not installed in Termux yet — run once: termux_run {command:'pkg install -y tesseract'} then retry.", false)
        if (!out.contains("LIMAN_OCR_DONE"))
            return ToolOutcome("OCR failed:\n" + out.take(2000), false)
        val text = out.substringBefore("LIMAN_OCR_DONE")
        if (!OcrBridge.hasText(out)) return ToolOutcome("OCR ran but found no readable text (try a sharper image or another lang: eng, fas, ara, deu…).", true)
        else return ToolOutcome("OCR of ${f.name} ($lang):\n----\n${text.trim().take(6000)}", true)
    }

    /** v2.23 — geofence-lite: termux-location via the bridge (needs Termux:API app). */
    private suspend fun execDeviceLocation(args: JsonObject): ToolOutcome {
        val provider = args.str("provider")?.trim()?.lowercase().takeIf { it in setOf("gps", "network", "passive") } ?: "network"
        val out = NativeBuilder.bridgeRun(
            ctx.appContext, ctx.stores,
            "termux-location -p $provider 2>/dev/null || echo 'TERMUX_API_MISSING'", 90
        )
        if (out.contains("TERMUX_API_MISSING") || out.contains("not installed"))
            return ToolOutcome("termux-location is unavailable — install the Termux:API app (F-Droid/Play) and `pkg install termux-api` in Termux, then retry.", false)
        val lat = Regex(""""latitude"\s*:\s*(-?[0-9.]+)""").find(out)?.groupValues?.get(1)
        val lng = Regex(""""longitude"\s*:\s*(-?[0-9.]+)""").find(out)?.groupValues?.get(1)
        if (lat == null || lng == null) return ToolOutcome("Could not parse location output:\n" + out.take(400), false)
        val acc = Regex(""""accuracy"\s*:\s*([0-9.]+)""").find(out)?.groupValues?.get(1) ?: "?"
        return ToolOutcome(
            "Location (via Termux, provider=$provider): lat $lat, lng $lng (±${acc}m).\n" +
                "Use http_request with Nominatim for reverse geocoding if you need a place name " +
                "(https://nominatim.openstreetmap.org/reverse?lat=$lat&lon=$lng&format=json). " +
                "For geofencing, create a scheduled pipeline that checks this and acts when inside/outside a radius.", true
        )
    }

    // ---------------- v2.24.0 STORY MOTION STUDIO ----------------

    private suspend fun execMotion(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (plan | create | list | export).", false)
        return when (action) {
            "plan" -> ToolOutcome(MotionStudio.planningBrief(), true)
            "create" -> {
                val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'name' for the motion project.", false)
                val brief = args.str("brief")?.trim().orEmpty().ifBlank { "story motion piece" }
                val dur = (args.intOrNull("durationSeconds") ?: 12).coerceIn(3, 120)
                val dir = MotionStudio.create(ctx.workspace, name, brief, dur)
                ToolOutcome(
                    "Motion project ready at ${relPath(dir)}:\n" +
                        "- motion.html — compose HERE with write_file (MotionKit runtime inline; deterministic seek contract)\n" +
                        "- storyboard.md — fill the shot table from the energy arc FIRST\n" +
                        "- ../STUDIO.md — the full handbook: 27 case-law rules, energy arc, shot catalog, MotionKit API\n" +
                        "Next: motion {action:'plan'} if you skipped it, fill the storyboard, then compose motion.html shot by shot. " +
                        "Verify with render_html, then motion {action:'export', name:'${dir.name}'} for the MP4.", true
                )
            }
            "list" -> {
                val projects = MotionStudio.projects(ctx.workspace)
                if (projects.isEmpty()) ToolOutcome("No motion projects yet — motion {action:'create', name:'…', brief:'…'}.", true)
                else ToolOutcome(buildString {
                    appendLine("Motion projects:")
                    projects.forEach {
                        val hasMp4 = File(it, "motion.mp4").exists()
                        appendLine("- ${it.name}${if (hasMp4) " (exported ✓)" else ""}")
                    }
                }, true)
            }
            "export" -> {
                val name = args.str("name")?.trim()
                val dir = MotionStudio.findProject(ctx.workspace, name)
                    ?: return ToolOutcome("No motion project found${if (name != null) " named '$name'" else ""} — create one first.", false)
                val html = File(dir, "motion.html")
                if (!html.isFile) return ToolOutcome("Project ${dir.name} has no motion.html.", false)
                MotionStudio.exportReadiness(html.readText())?.let {
                    return ToolOutcome("EXPORT BLOCKED (fix motion.html first): $it", false)
                }
                val width = (args.intOrNull("width") ?: 1920).coerceIn(640, 1920)
                val height = (args.intOrNull("height") ?: 1080).coerceIn(360, 1080)
                val fps = (args.intOrNull("fps") ?: 30).coerceIn(24, 60)
                val out = File(dir, "motion.mp4")
                Scheduler.notify(ctx.appContext, "🎬 Motion export started", "${dir.name} · ${width}x$height @$fps")
                val started = System.currentTimeMillis()
                val result = MotionRecorder.record(
                    ctx.appContext, html, out,
                    MotionRecorder.Params(width, height, fps, MotionRecorder.bitrateFor(width, height, fps)),
                    onProgress = { frame, total ->
                        if (frame % 30 == 0 || frame == total)
                            Scheduler.notify(ctx.appContext, "🎬 Recording ${dir.name}", "$frame/$total frames")
                    }
                )
                if (!result.ok) return ToolOutcome("MP4 export failed: ${result.message}", false)
                val secs = (System.currentTimeMillis() - started) / 1000
                Journal.append(ctx.workspace, "motion", "exported ${dir.name}.mp4 (${result.frames} frames)")
                Scheduler.notify(ctx.appContext, "🎬 Motion MP4 ready", "${dir.name} · ${out.length() / 1024} KB")
                ToolOutcome(
                    "MOTION MP4 EXPORTED:\n" +
                        "- ${relPath(out)} (${out.length()} bytes, ${result.frames} frames, ${width}x$height @$fps, took ${secs}s)\n" +
                        "- The HTML is independently publishable: ${relPath(html)} (self-contained, plays in any browser)\n" +
                        "Deliver both files to the user. The HTML can also become an app via build_apk on request.", true
                )
            }
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    // ---------------- v2.22.0 NATIVE APK FACTORY ----------------

    /** v2.24.1: poll a background Termux job until its exit marker (short calls, no hangs). */
    private suspend fun pollTermuxJob(maxSeconds: Int, intervalMs: Long = 15_000): String =
        NativeBuilder.pollJob(ctx.appContext, ctx.stores, maxSeconds, intervalMs)

    // ---------------- v2.25.1 9ROUTER (cloud edition) ----------------

    private fun nineBase(args: JsonObject): String =
        args.strAny("endpoint", "url", "base_url")?.trim().orEmpty()
            .ifBlank { NineRouter.savedProvider(ctx.stores)?.baseUrl.orEmpty() }
            .ifBlank { NineRouter.DEFAULT_BASE }

    private suspend fun execNineRouter(args: JsonObject): ToolOutcome {
        val action = args.strAny("action", "action_name", "op")?.trim()?.lowercase()
            ?: return ToolOutcome(
                ArgsNormalizer.missingArg("nine_router", "action", args, """{"action":"status"}""") +
                    " Valid: status | open | combos | models | connect.", false
            )
        val base = nineBase(args)
        return when (action) {
            "status" -> {
                val up = NineRouter.isUp(base)
                val prov = NineRouter.savedProvider(ctx.stores)
                ToolOutcome(buildString {
                    appendLine("9ROUTER STATUS:")
                    appendLine(if (up) "● Server up — ${NineRouter.originOf(base)}" else "○ Server not reachable — ${NineRouter.originOf(base)}")
                    appendLine(
                        if (prov != null) "Liman provider: connected · endpoint ${prov.baseUrl} · model ${prov.model.ifBlank { "(none set — run combos and connect with one)" }}"
                        else "Liman provider: not connected — {action:'connect', api_key:'…', model:'<combo>'}"
                    )
                    append("Dashboard: ${NineRouter.dashboardUrl(base)}")
                }, true)
            }
            "open" -> {
                val opened = NineRouter.openDashboard(ctx.appContext, base)
                ToolOutcome(
                    if (opened) "Opening the 9Router dashboard in Chrome — ${NineRouter.dashboardUrl(base)}"
                    else "Could not open the browser — open ${NineRouter.dashboardUrl(base)} manually.",
                    opened
                )
            }
            "combos", "models" -> {
                val key = args.strAny("api_key", "key", "apikey")?.trim()
                    ?: NineRouter.savedProvider(ctx.stores)?.apiKey.orEmpty()
                if (!NineRouter.isUp(base)) return ToolOutcome("The 9Router server at ${NineRouter.originOf(base)} is not reachable — check the endpoint or {action:'status'}.", false)
                val cat = try {
                    NineRouter.fetchCatalog(base, key)
                } catch (t: Throwable) {
                    return ToolOutcome("Fetching failed: ${t.message}\nIf this is an auth error, create an API key in the dashboard (${NineRouter.dashboardUrl(base)} → API Keys) and pass api_key.", false)
                }
                if (action == "combos") {
                    if (cat.combos.isEmpty())
                        return ToolOutcome("No combos on this server yet — create them in the dashboard (${NineRouter.dashboardUrl(base)} → Combos). Plain models available: ${cat.models.size} ({action:'models'}).", false)
                    ToolOutcome(
                        "${cat.combos.size} COMBOS on your 9Router (a combo = a fusion/fallback/round-robin model group — use its NAME as the model):\n" +
                            cat.combos.joinToString("\n") { "- $it" } +
                            "\n(${cat.models.size} plain models also available)", true
                    )
                } else {
                    if (cat.total == 0) return ToolOutcome("The server listed nothing — connect providers in the dashboard first.", false)
                    ToolOutcome(
                        "${cat.models.size} models (plus ${cat.combos.size} combos — {action:'combos'}):\n" +
                            cat.models.take(120).joinToString("\n") { "- $it" }, true
                    )
                }
            }
            "connect" -> {
                val key = args.strAny("api_key", "key", "apikey")?.trim()
                    ?: return ToolOutcome(ArgsNormalizer.missingArg("nine_router connect", "api_key", args, """{"action":"connect","api_key":"…","model":"<combo>"}""") + " The user copies it from the 9Router dashboard (API Keys page).", false)
                if (!NineRouter.isUp(base)) return ToolOutcome("The 9Router server at ${NineRouter.originOf(base)} is not reachable — check the endpoint first ({action:'status'}).", false)
                val cat = try {
                    NineRouter.fetchCatalog(base, key)
                } catch (t: Throwable) {
                    return ToolOutcome("The key check failed: ${t.message}\nCreate a valid key in the dashboard (${NineRouter.dashboardUrl(base)} → API Keys) and try again.", false)
                }
                if (cat.total == 0) return ToolOutcome("The key works but the server lists no combos/models — connect providers in the dashboard first.", false)
                var model = args.strAny("model", "model_id")?.trim().orEmpty()
                val modelNote = when {
                    model.isEmpty() && cat.combos.isNotEmpty() -> { model = cat.combos.first(); "no model given — defaulted to your first combo '$model'" }
                    model.isEmpty() -> "no model given — pick one with {action:'combos'} / {action:'models'} and connect again"
                    else -> "model '$model'"
                }
                val cfg = NineRouter.ensureProvider(ctx.stores, base, key, model)
                ToolOutcome(
                    buildString {
                        appendLine("9ROUTER CONNECTED AS A LIMAN PROVIDER ✓")
                        appendLine("Provider '${cfg.name}' · endpoint ${cfg.baseUrl} · $modelNote")
                        appendLine("Key verified — ${cat.combos.size} combos + ${cat.models.size} models reachable.")
                        appendLine("It is enabled and appears in Settings → Combo: add it to any Liman combo (failover / round-robin / race).")
                    }, true
                )
            }
            else -> ToolOutcome("Unknown action '$action'. Valid: status | open | combos | models | connect.", false)
        }
    }

    private suspend fun execNativeApk(args: JsonObject): ToolOutcome {
        val action = args.strAny("action", "action_name", "op")?.trim()?.lowercase()
            ?: return ToolOutcome(ArgsNormalizer.missingArg("native_apk", "action", args, """{"action":"status"}""") + " Valid: status | setup | scaffold | build | verify.", false)
        return when (action) {
            "status" -> {
                val out = NativeBuilder.bridgeRun(ctx.appContext, ctx.stores, NativeBuilder.envProbeScript(), 60)
                ToolOutcome(
                    "NATIVE TOOLCHAIN PROBE (Termux):\n" + out.take(2000) + "\n" +
                        "If items are missing, native_apk {action:'setup'} installs everything one-time " +
                        "(~265 MB in Termux: openjdk-17, kotlin, aapt2, apksigner, dx + android.jar). Ask the user before running setup.", true
                )
            }
            "setup" -> {
                // v2.24.1: long installs run as a BACKGROUND job in Termux (the old
                // single-call design timed out as "No response from Termux" while
                // pkg install + a 65 MB download took minutes).
                val launch = NativeBuilder.bridgeRun(
                    ctx.appContext, ctx.stores, NativeBuilder.jobWrap(NativeBuilder.setupScript()), 90
                )
                if (!launch.contains("LIMAN_JOB_LAUNCHED"))
                    return ToolOutcome("Could not launch setup in Termux:\n${launch.take(2000)}", false)
                val log = NativeBuilder.cleanJobLog(pollTermuxJob(maxSeconds = 1200))
                val ok = log.contains("LIMAN_NATIVE_SETUP_OK")
                ToolOutcome(
                    (if (ok) "NATIVE TOOLCHAIN READY — kotlin compiler, build tools, android.jar and debug keystore installed in Termux.\n" else "Setup incomplete — read the log:\n") +
                        log.take(6000), ok
                )
            }
            "scaffold" -> {
                val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'name' for the app.", false)
                val permissions = args.strList("permissions")
                val presetId = args.str("preset")?.trim()?.lowercase()?.takeIf { it.isNotBlank() }
                if (presetId != null && DesignTokens.preset(presetId) == null)
                    return ToolOutcome(
                        "Unknown preset '$presetId'. Valid presets: " +
                            DesignTokens.PRESETS.joinToString(" | ") { it.id } + " (or omit preset for the default neutral theme).", false
                    )
                val dir = NativeBuilder.scaffold(
                    ctx.workspace, name,
                    args.str("package")?.trim()?.takeIf { it.isNotBlank() },
                    args.str("description")?.trim().orEmpty(),
                    permissions,
                    presetId
                )
                ToolOutcome(
                    "REAL Kotlin project scaffolded at ${relPath(dir)}:\n" +
                        "- AndroidManifest.xml (minSdk 24, targetSdk " + NativeBuilder.API_LEVEL + ")" +
                        (if (permissions.isEmpty()) "" else " + ${permissions.size} permission(s)") + "\n" +
                        "- src/…/MainActivity.kt (programmatic UI — extend freely)\n" +
                        "- res/values/themes.xml\n" +
                        (if (presetId != null) "- res/values/colors.xml + dimens.xml — generated from the '$presetId' design preset (brand/surface/on/border tokens + spacing/radius scale — use these R.color./R.dimen. constants, never hardcoded values)\n" else "") +
                        "Next: EDIT the sources with write_file (add activities/services/sensors — framework APIs only, no external libraries), " +
                        "then native_apk {action:'build', name:'${dir.name}'} compiles it natively in Termux and returns the signed APK.", true
                )
            }
            "build" -> {
                val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() } ?: "the only project"
                val root = File(ctx.workspace, "native-projects")
                val dir = root.listFiles()?.firstOrNull {
                    it.isDirectory && (it.name.equals(name, true) || it.name.equals(NativeBuilder.slugify(name), true))
                } ?: root.listFiles()?.firstOrNull { it.isDirectory }
                    ?: return ToolOutcome(
                        "No native project found — create one first: native_apk {action:'scaffold', name:'<app>'} " +
                            "(projects live in workspace/native-projects/).", false
                    )
                val files = NativeBuilder.projectFiles(dir)
                if (files.none { it.first.endsWith("AndroidManifest.xml") })
                    return ToolOutcome("Project at ${relPath(dir)} has no AndroidManifest.xml — broken scaffold? Re-scaffold.", false)
                if (files.none { it.first.endsWith(".kt") && !it.first.endsWith(".java") } && files.none { it.first.endsWith(".java") })
                    return ToolOutcome("Project has no .kt or .java sources under src/ — nothing to compile.", false)

                val launch = NativeBuilder.bridgeRun(
                    ctx.appContext, ctx.stores, NativeBuilder.jobWrap(NativeBuilder.buildScript(dir.name, files)), 90
                )
                if (!launch.contains("LIMAN_JOB_LAUNCHED"))
                    return ToolOutcome("Could not launch the build in Termux:\n${launch.take(2000)}", false)
                val out = pollTermuxJob(maxSeconds = 900)
                val ok = NativeBuilder.parseBuildOk(out)
                if (ok == null) {
                    val clean = NativeBuilder.cleanJobLog(out)
                    return ToolOutcome(
                        ("NATIVE BUILD FAILED — full log (the failing step's real error is in here; fix the sources and rebuild):\n$clean" +
                            NativeBuilder.buildHints(clean)).take(8000), false
                    )
                }
                val (size, md5, tail) = ok
                if (size <= 0) return ToolOutcome("Build reported zero-size APK?\n$out".take(4000), false)
                val chunksNeeded = NativeBuilder.chunkCount(size.toLong())
                if (chunksNeeded > NativeBuilder.maxChunks)
                    return ToolOutcome(
                        "Built and signed OK ($size bytes, md5 $md5) but the APK exceeds the " +
                            "${NativeBuilder.maxChunks * 256}KB transfer ceiling — it remains at ~/liman-native/projects/${dir.name}/app.apk in Termux. " +
                            "Retrieve it with termux_run (e.g. copy to ~/storage/shared) or trim the app.", true
                    )
                // retrieve in 256KB md5-verified chunks
                val chunks = mutableListOf<String>()
                for (i in 0 until chunksNeeded) {
                    val c = NativeBuilder.bridgeRun(
                        ctx.appContext, ctx.stores,
                        NativeBuilder.chunkScript(dir.name, i), 60
                    ).trim()
                    if (c.isBlank() || c.startsWith("No response") || c.startsWith("Termux is not")) {
                        return ToolOutcome("APK chunk ${i + 1}/$chunksNeeded failed to transfer: ${c.take(200)}", false)
                    }
                    chunks += c
                }
                val apkBytes = NativeBuilder.assembleChunks(chunks, md5)
                    ?: return ToolOutcome("APK transfer integrity check failed (md5 mismatch) — retry the build.", false)
                val outDir = File(dir, "build").apply { mkdirs() }
                val apkFile = File(outDir, dir.name + ".apk")
                apkFile.writeBytes(apkBytes)
                val sha256 = java.security.MessageDigest.getInstance("SHA-256")
                    .digest(apkBytes).joinToString("") { "%02x".format(it) }
                Scheduler.notify(ctx.appContext, "📦 Native APK built", "${dir.name}.apk (${apkBytes.size} bytes, signed)")
                ToolOutcome(
                    "NATIVE APK BUILT AND VERIFIED:\n" +
                        "- Real Kotlin compiled on this phone (kotlinc → d8 → aapt2 → apksigner)\n" +
                        "- Signed, signature verified" + (if (tail.isNotBlank()) " ($tail)" else "") + "\n" +
                        "- Size: ${apkBytes.size} bytes · md5 verified end-to-end · sha256 $sha256\n" +
                        "- Saved to: ${relPath(apkFile)}\n" +
                        "To install: the user opens this file (share it, or storage_write it to a granted folder and open from there). " +
                        "AFTER INSTALL (closed-loop verification): ask the user to open it, then use the ui tool ({action:'open_app', package:'…'} + snapshot) to confirm it launched — if it crashes instantly, the fix is usually in the manifest or the Activity's onCreate. " +
                        "After install, save the whole procedure as a skill (skill_create) so future builds start smarter.", true
                )
            }
            "verify" -> {
                // v2.30.0: artifact verification — apksigner certs + aapt2 badging on the
                // built APK in Termux, plus a local sha256 if the workspace copy exists.
                val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() } ?: "the only project"
                val root = File(ctx.workspace, "native-projects")
                val dir = root.listFiles()?.firstOrNull {
                    it.isDirectory && (it.name.equals(name, true) || it.name.equals(NativeBuilder.slugify(name), true))
                } ?: root.listFiles()?.firstOrNull { it.isDirectory }
                    ?: return ToolOutcome("No native project found — nothing to verify.", false)
                val localApk = File(dir, "build/${dir.name}.apk")
                    .takeIf { it.isFile }
                val localSha = localApk?.let {
                    java.security.MessageDigest.getInstance("SHA-256").digest(it.readBytes())
                        .joinToString("") { b -> "%02x".format(b) }
                }
                val remote = NativeBuilder.bridgeRun(
                    ctx.appContext, ctx.stores, NativeBuilder.verifyScript(dir.name), 90
                ).trim()
                if (remote.startsWith("No response") || remote.startsWith("Termux is not"))
                    return ToolOutcome("Could not reach Termux for verification:\n$remote", false)
                val localBlock = if (localApk != null)
                    "\nLOCAL WORKSPACE COPY: ${localApk.name} · ${localApk.length()} bytes · sha256 $localSha"
                else "\nNo local workspace copy (run build first to retrieve one)."
                ToolOutcome(
                    "APK VERIFICATION REPORT for ${dir.name}:\n" +
                        remote.take(2500) + localBlock +
                        "\nChecklist: signature schemes verified (v1/v2/v3), package/launcher activity present in badging, versionCode/Name as intended, permissions minimal. Ship only if all pass.", true
                )
            }
            else -> ToolOutcome("Unknown action '$action'. Use status | setup | scaffold | build | verify.", false)
        }
    }

    // ---------------- v2.30.0 APP FACTORY: design kernel + icon pipeline ----------------

    /** DESIGN SYSTEM KERNEL (blueprint §4): tokens in, CSS/XML out. */
    private fun execDesignTokens(args: JsonObject): ToolOutcome {
        val action = args.strAny("action", "op")?.trim()?.lowercase()
            ?: return ToolOutcome(ArgsNormalizer.missingArg("design_tokens", "action", args, """{"action":"contract"}""") + " Valid: contract | list | archetypes | generate.", false)
        return when (action) {
            "contract" -> ToolOutcome(DesignTokens.contract(), true)
            "list" -> ToolOutcome(
                "DESIGN PRESETS (pick exactly ONE per project — never mix):\n" +
                    DesignTokens.PRESETS.joinToString("\n\n") { p ->
                        "- ${p.id} — ${p.vibe}. Key moves: ${p.keyMoves}"
                    } + "\n\nUse design_tokens {action:'generate', preset:'<id>', project:'<dir>'} to emit the token files.", true
            )
            "archetypes" -> ToolOutcome(
                "LAYOUT ARCHETYPES (every screen declares exactly one):\n" +
                    DesignTokens.ARCHETYPES.joinToString("\n") { "- ${it.first} — ${it.second}" }, true
            )
            "generate" -> {
                val presetId = args.str("preset")?.trim()?.lowercase()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'preset'. Valid: " + DesignTokens.PRESETS.joinToString(" | ") { it.id }, false)
                val css = DesignTokens.tokensCss(presetId)
                    ?: return ToolOutcome("Unknown preset '$presetId'. Valid: " + DesignTokens.PRESETS.joinToString(" | ") { it.id }, false)
                val project = args.str("project")?.trim()?.takeIf { it.isNotBlank() } ?: ""
                val base = if (project.isNullOrBlank()) ctx.workspace
                else File(ctx.workspace, NativeBuilder.slugify(project)).takeIf { it.isDirectory } ?: ctx.workspace
                val designDir = File(base, "design").apply { mkdirs() }
                File(designDir, "tokens.css").writeText(css)
                File(designDir, "kit.css").writeText(DesignTokens.kitCss())
                val androidXml = DesignTokens.androidColorsXml(presetId)!!
                ToolOutcome(
                    "Generated design tokens for preset '$presetId':\n" +
                        "- ${relPath(File(designDir, "tokens.css"))} — CSS custom properties (light+dark via prefers-color-scheme) for web targets\n" +
                        "- ${relPath(File(designDir, "kit.css"))} — the component kit (stack/card/btn/field/badge… compose these classes; extend via CSS vars, never inline styles)\n" +
                        "\nWEB: link both files, use var(--token) everywhere — NO raw hex/px in your CSS (render_html lints for it).\n" +
                        "NATIVE (scaffold with native_apk preset:'$presetId' instead, or paste into res/values/):\n$androidXml", true
                )
            }
            else -> ToolOutcome("Unknown action '$action'. Use contract | list | archetypes | generate.", false)
        }
    }

    /** VECTOR ICON PIPELINE (blueprint §5): embedded set + SVG→VectorDrawable. */
    private fun execSvgIcon(args: JsonObject): ToolOutcome {
        val action = args.strAny("action", "op")?.trim()?.lowercase()
            ?: return ToolOutcome(ArgsNormalizer.missingArg("svg_icon", "action", args, """{"action":"list"}""") + " Valid: list | spec | get | convert.", false)
        return when (action) {
            "list" -> ToolOutcome(
                "EMBEDDED ICON SET (${SvgIcon.ICONS.size} icons, 24px stroke grammar — prefer these over drawing new paths):\n" +
                    SvgIcon.ICONS.keys.sorted().joinToString(" · "), true
            )
            "spec" -> ToolOutcome(SvgIcon.spec(), true)
            "get" -> {
                val name = args.str("name")?.trim()?.lowercase()
                    ?: return ToolOutcome("Missing 'name' (see op:list).", false)
                val svg = SvgIcon.svg(name)
                    ?: return ToolOutcome("No icon '$name'. Use op:list; closest: ${SvgIcon.ICONS.keys.filter { it.contains(name.take(3)) }.take(3).joinToString(" / ").ifBlank { "none" }}.", false)
                ToolOutcome(svg, true)
            }
            "convert" -> {
                val svgText = args.str("svg")?.takeIf { it.isNotBlank() }
                    ?: args.str("name")?.trim()?.lowercase()?.let { SvgIcon.svg(it) }
                    ?: return ToolOutcome("Provide 'name' (embedded icon) or 'svg' (raw SVG markup).", false)
                val outName = args.str("name")?.trim()?.lowercase()?.replace(Regex("[^a-z0-9]+"), "_")
                    ?.trim('_')?.takeIf { it.isNotBlank() } ?: "ic_icon"
                val r = SvgIcon.toVectorDrawable(svgText, outName)
                if (!r.ok)
                    return ToolOutcome(r.error ?: "conversion failed", false)
                ToolOutcome(
                    "VectorDrawable ready — save as res/drawable/${outName}.xml (lowercase_underscore):\n" + r.xml, true
                )
            }
            else -> ToolOutcome("Unknown action '$action'. Use list | spec | get | convert.", false)
        }
    }

    /** CREATIVE VECTOR ENGINE (blueprint Vol. 3): retrieve / generate + verify. */
    private suspend fun execVectorStudio(args: JsonObject): ToolOutcome {
        val action = args.strAny("action", "op")?.trim()?.lowercase()
            ?: return ToolOutcome(ArgsNormalizer.missingArg("vector_studio", "action", args, """{"action":"protocol"}""") + " Valid: protocol | direction | recipes | recipe_run | retrieve | validate | slop.", false)
        return when (action) {
            "protocol" -> ToolOutcome(VectorEngine.protocol(), true)
            "direction" -> ToolOutcome(VectorEngine.directionContract(), true)
            "recipes" -> ToolOutcome(
                "DETERMINISTIC RECIPES (${VectorEngine.recipeIds().size}) — params, not prose; seed = reproducible:\n" +
                    VectorEngine.recipeCatalog() +
                    "\nEvery output: valid viewBox, ≤2 decimals, namespaced ids, currentColor (recolor via CSS/one find-replace).", true
            )
            "recipe_run" -> {
                val recipe = args.str("recipe")?.trim()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'recipe' (see op:recipes).", false)
                val params = HashMap<String, String>()
                (args["params"] as? JsonObject)?.forEach { (k, v) -> params[k] = v.toString().trim().trim('"') }
                // flat params also accepted (recipe_run {recipe, seed, width…})
                args.forEach { (k, v) -> if (k !in setOf("action", "recipe", "params", "out", "op")) params.putIfAbsent(k, v.toString().trim().trim('"')) }
                val r = VectorEngine.runRecipe(recipe, params)
                    ?: return ToolOutcome("Unknown recipe '$recipe'. Use op:recipes.\n${VectorEngine.recipeCatalog()}", false)
                val saved = args.str("out")?.trim()?.takeIf { it.isNotBlank() }?.let { rel ->
                    runCatching {
                        val f = File(ctx.workspace, rel.replace('\\', '/')).sandboxChild(ctx.workspace) ?: return@runCatching null
                        f.parentFile?.mkdirs()
                        f.writeText(r.svg)
                        "\nSaved to $rel."
                    }.getOrNull() ?: "\n(could not save to $rel — returning inline)"
                } ?: ""
                ToolOutcome(
                    "GENERATED '$recipe' (seed=${params["seed"] ?: "4711"} — same seed, same art):\n" +
                        "${r.svg}\n---\nnodes=${r.nodes} bytes=${r.bytes}$saved\n" +
                        "Next: vector_studio {action:'slop', svg:'…'} on it, then render_html to eyeball. Recolor via currentColor.", true
                )
            }
            "retrieve" -> {
                val prefix = args.str("prefix")?.trim()?.takeIf { it.isNotBlank() } ?: "lucide"
                val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'name' (icon name, e.g. arrow-left).", false)
                val r = withContext(Dispatchers.IO) { VectorEngine.retrieve(prefix, name) }
                if (!r.ok) return ToolOutcome("RETRIEVE failed: ${r.note}", false)
                val lic = r.note
                val saved = args.str("out")?.trim()?.takeIf { it.isNotBlank() }?.let { rel ->
                    runCatching {
                        val f = File(ctx.workspace, rel.replace('\\', '/')).sandboxChild(ctx.workspace) ?: return@runCatching null
                        f.parentFile?.mkdirs()
                        f.writeText(r.svg!!)
                        val ledger = File(ctx.workspace, "assets/LEDGER.md")
                        ledger.parentFile?.mkdirs()
                        ledger.appendText("- ${File(rel).name} · iconify:$prefix/$name · license: $lic\n")
                        "\nSaved to $rel (+ license ledger entry in assets/LEDGER.md)."
                    }.getOrNull() ?: ""
                } ?: ""
                ToolOutcome(
                    "RETRIEVED iconify:$prefix/$name (license: $lic):\n${r.svg}$saved\n" +
                        "Sanitized (no scripts/handlers/external refs). Recolor to project tokens; don't mix icon sets.", true
                )
            }
            "validate" -> {
                val svg = resolveSvgInput(args) ?: return ToolOutcome("Provide 'svg' (markup) or 'path' (workspace file).", false)
                val target = args.str("target")?.trim()?.lowercase()?.takeIf { it == "android-vd" } ?: "web"
                ToolOutcome(VectorEngine.validationText(VectorEngine.validate(svg, target)), true)
            }
            "slop" -> {
                val svg = resolveSvgInput(args) ?: return ToolOutcome("Provide 'svg' (markup) or 'path' (workspace file).", false)
                val name = args.str("path")?.trim() ?: ""
                val report = VectorEngine.slopScore(svg, name)
                val verdict = report.verdict
                ToolOutcome(
                    VectorEngine.slopReportText(report) +
                        if (verdict == "slop") "\n⛔ SLOP — you may NOT ship this. ${report.nextAction}" else "", true
                )
            }
            else -> ToolOutcome("Unknown action '$action'. Use protocol | direction | recipes | recipe_run | retrieve | validate | slop.", false)
        }
    }

    /** v2.32 — coding toolchain doctor: what's installed, what to pkg-install. */
    private suspend fun termuxDoctor(): ToolOutcome {
        val port = com.liman.agent.llm.RouterServer.runningPort()
            ?: return ToolOutcome("The local router is not running (Settings → Local router) — the Termux bridge needs it.", false)
        val probe = buildString {
            append("for t in node npm python pip git gcc make curl wget jq ffmpeg; do ")
            append("if command -v \${'$'}t >/dev/null 2>&1; then v=\$(\${'$'}t --version 2>&1 | head -1); echo \"\${'$'}t: \${'$'}v\"; ")
            append("else echo \"\${'$'}t: MISSING\"; fi; done; ")
            append("echo \"disk: \$(df -h ~ | tail -1)\"; echo DOCTOR-DONE")
        }
        val out = TermuxBridge.run(ctx.appContext, port, probe, 60_000L)
        val missing = Regex("(\\w+): MISSING").findAll(out).map { it.groupValues[1] }.toList()
        return ToolOutcome(
            "TERMUX CODING TOOLCHAIN:\n" + out.take(1500) +
                (if (missing.isEmpty()) "\n✅ Everything installed — a full dev box in your pocket."
                else "\nMissing: " + missing.joinToString(", ") + " — install with pkg install " +
                    missing.joinToString(" ") + " (ask the user first; uses their data)."),
            true
        )
    }

    /** v2.32 — dev server: expose a workspace folder over HTTP via the local
     *  router (/preview/) — instant live preview, no Termux, no storage perms. */
    private suspend fun termuxDevServer(args: JsonObject): ToolOutcome {
        val rel = args.str("path")?.trim()?.takeIf { it.isNotBlank() } ?: "."
        val dir = File(ctx.workspace, rel.replace('\\', '/')).sandboxChild(ctx.workspace)
            ?: return ToolOutcome("Invalid 'path'.", false)
        if (!dir.isDirectory) return ToolOutcome("Folder not found: $rel (give the folder containing index.html).", false)
        val settings = ctx.stores.settings.state.value
        val port = com.liman.agent.llm.RouterServer.runningPort()
            ?: runCatching {
                if (com.liman.agent.llm.RouterServer.start(ctx.stores, settings.routerPort, settings.routerLan)) settings.routerPort else null
            }.getOrNull()
            ?: return ToolOutcome("Could not start the local router — enable it in Settings → Local router.", false)
        com.liman.agent.llm.RouterServer.previewRoot = dir
        val lanIp = com.liman.agent.llm.RouterServer.lanIp()
        return ToolOutcome(
            "DEV SERVER LIVE — serving ${rel} at:\n" +
                "- on this phone: http://127.0.0.1:$port/preview/\n" +
                (if (settings.routerLan && lanIp != null)
                    "- on any device on the same Wi-Fi: http://$lanIp:$port/preview/ (give THIS url to the user)\n"
                else "- for other devices: enable 'LAN access' in Settings → Local router, then re-run\n") +
                "Verify it yourself: http_request {url:'http://127.0.0.1:$port/preview/'} (check the HTML served), " +
                "or render_html the index for a screenshot. Tell the user the URL — they can open it in Chrome right now.",
            true
        )
    }

    // ---------------- v2.32.0 CODING AGENT CORE executors ----------------

    private fun execSearchCode(args: JsonObject): ToolOutcome {
        val pattern = args.str("pattern")?.takeIf { it.isNotBlank() }
            ?: return ToolOutcome(ArgsNormalizer.missingArg("search_code", "pattern", args, """{"pattern":"signIn|login"}"""), false)
        val root = args.str("path")?.trim()?.takeIf { it.isNotBlank() }
            ?.let { File(ctx.workspace, it.replace('\\', '/')).sandboxChild(ctx.workspace) }
            ?: ctx.workspace
        if (root == null || !root.isDirectory) return ToolOutcome("Folder not found: ${args.str("path")}", false)
        val hits = CodeCore.search(
            root, pattern, args.str("glob"),
            args.longOrNull("context")?.toInt()?.coerceIn(0, 3) ?: 1
        )
        return ToolOutcome(CodeCore.searchReport(root, hits, pattern), true)
    }

    private fun execRepoMap(args: JsonObject): ToolOutcome {
        val root = args.str("path")?.trim()?.takeIf { it.isNotBlank() }
            ?.let { File(ctx.workspace, it.replace('\\', '/')).sandboxChild(ctx.workspace) }
            ?: ctx.workspace
        if (root == null || !root.isDirectory) return ToolOutcome("Folder not found: ${args.str("path")}", false)
        val map = CodeCore.repoMap(root)
        return ToolOutcome(map.take(6000) + "\n\nNext: read_file the ranked files that matter, search_code for specifics.", true)
    }

    private suspend fun execCodeCheck(args: JsonObject): ToolOutcome {
        val files = (args["files"] as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
            ?: args.strList("files").takeIf { it.isNotEmpty() }
            ?: return ToolOutcome("Missing 'files' array.", false)
        if (files.isEmpty()) return ToolOutcome("'files' is empty.", false)
        val report = StringBuilder()
        var failures = 0
        files.take(12).forEach { rel ->
            val f = File(ctx.workspace, rel.replace('\\', '/')).sandboxChild(ctx.workspace)
            if (f == null || !f.isFile) { report.appendLine("✗ $rel: file not found"); failures++; return@forEach }
            val text = runCatching { f.readText().take(1_000_000) }.getOrNull() ?: run {
                report.appendLine("✗ $rel: unreadable"); failures++; return@forEach
            }
            val problems = ArrayList<String>()
            when (f.extension.lowercase()) {
                "js", "mjs", "cjs", "jsx", "ts", "tsx" -> {
                    // real parse via the on-device JS engine
                    val encoded = JSON.encodeToString(
                        JsonPrimitive.serializer(), JsonPrimitive(text)
                    )
                    val wrapped = "try { new Function(" + encoded +
                        ") } catch(e) { 'SYNTAX_ERROR:' + e.message }"
                    val r = JsSandbox.run(wrapped, 10_000L)
                    if (r.contains("SYNTAX_ERROR:")) problems.add("JS syntax: " + r.substringAfter("SYNTAX_ERROR:").take(120))
                }
                "json" -> CodeCore.CodeCheck.jsonCheck(text)?.let { problems.add(it) }
                "kt", "kts", "java" -> problems.addAll(CodeCore.CodeCheck.structuralCheck(text))
                "py" -> problems.addAll(CodeCore.CodeCheck.pythonIndentCheck(text))
                else -> { report.appendLine("○ $rel: no checker for .${f.extension} (structural skip)"); return@forEach }
            }
            if (problems.isEmpty()) report.appendLine("✓ $rel: checks pass")
            else { failures++; problems.forEach { report.appendLine("✗ $rel: $it") } }
        }
        val verdict = if (failures == 0)
            "ALL CHECKS PASS — still run the code (run_js/run_code) to verify BEHAVIOR, not just syntax."
        else "$failures file(s) FAILED — fix before claiming done."
        return ToolOutcome(report.toString().trim() + "\n" + verdict, failures == 0)
    }

    private fun execSnapshot(args: JsonObject): ToolOutcome {
        val action = args.strAny("action", "op")?.trim()?.lowercase()
            ?: return ToolOutcome(ArgsNormalizer.missingArg("snapshot", "action", args, """{"action":"create","label":"before-refactor"}""") + " Valid: create | list | diff | restore.", false)
        return when (action) {
            "create" -> {
                val (name, count) = CodeCore.Snapshots.create(ctx.workspace, args.str("label") ?: "manual")
                ToolOutcome("SNAPSHOT SAVED: $name ($count files). Restore anytime with snapshot {action:'restore', name:'$name'}; diff with {action:'diff'}.", true)
            }
            "list" -> {
                val l = CodeCore.Snapshots.list(ctx.workspace)
                ToolOutcome(if (l.isEmpty()) "No snapshots yet — create one before risky edits."
                else "SNAPSHOTS (newest first):\n" + l.take(15).joinToString("\n") { "- $it" }, true)
            }
            "diff" -> {
                val name = args.str("name")?.trim() ?: CodeCore.Snapshots.list(ctx.workspace).firstOrNull()
                    ?: return ToolOutcome("No snapshots to diff against.", false)
                ToolOutcome(CodeCore.Snapshots.diff(ctx.workspace, name), true)
            }
            "restore" -> {
                val name = args.str("name")?.trim()
                    ?: return ToolOutcome("Missing 'name' (see op:list).", false)
                ToolOutcome(CodeCore.Snapshots.restore(ctx.workspace, name), true)
            }
            else -> ToolOutcome("Unknown action '$action'. Use create | list | diff | restore.", false)
        }
    }

    private fun execPatch(args: JsonObject): ToolOutcome {
        val arr = (args["ops"] as? JsonArray)
            ?: return ToolOutcome(ArgsNormalizer.missingArg("patch", "ops", args, """{"ops":[{"file":"a.kt","find":"old","replace":"new"}]}"""), false)
        val ops = arr.mapNotNull { el ->
            val o = el as? JsonObject ?: return@mapNotNull null
            val file = o.str("file")?.trim() ?: return@mapNotNull null
            val find = o.str("find") ?: return@mapNotNull null
            val replace = o.str("replace") ?: ""
            CodeCore.PatchOp(file, find, replace, o.bool("all") == true)
        }
        if (ops.isEmpty()) return ToolOutcome("'ops' is empty or malformed — need [{file, find, replace}].", false)
        // safety net first: snapshot so every patch is reversible
        val (snap, _) = CodeCore.Snapshots.create(ctx.workspace, "pre-patch")
        val results = CodeCore.applyPatch(ctx.workspace, ops)
        val ok = results.all { it.error == null }
        return ToolOutcome(
            CodeCore.patchReport(results) + "\n(undo: snapshot {action:'restore', name:'$snap'})", ok
        )
    }

    private fun resolveSvgInput(args: JsonObject): String? {
        args.str("svg")?.takeIf { it.isNotBlank() }?.let { return it }
        val p = args.str("path")?.trim()?.takeIf { it.isNotBlank() } ?: return null
        return runCatching {
            File(ctx.workspace, p.replace('\\', '/')).sandboxChild(ctx.workspace)?.takeIf { it.isFile }?.readText()?.take(200_000)
        }.getOrNull()
    }

    // ---------------- v2.21.0 AUTOMATION LAYER ----------------

    /** UI BRIDGE: demonstration recording + accessibility actions. */
    private suspend fun execUi(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action'.", false)
        return when (action) {
            "record_start" -> {
                if (!DemoService.serviceReady())
                    return ToolOutcome(
                        DemoLog.status(DemoService.serviceReady(), DemoService.recording, DemoService.logFile?.name) + "\n" + DemoServiceCompanionHint, false
                    )
                val f = DemoService.start(ctx.workspace)
                ToolOutcome(
                    "RECORDING the user's demonstration → ${relPath(f)}. They can start now; " +
                        "call ui record_stop when they say they're done, then read the log and distill the procedure.", true
                )
            }
            "record_stop" -> {
                val f = DemoService.stop()
                    ?: return ToolOutcome("No recording was running.", false)
                val summary = runCatching { DemoLog.summarize(f.readText()) }.getOrDefault("(log unreadable)")
                ToolOutcome(
                    "Recording stopped → ${relPath(f)}.\nDISTILLED PROCEDURE (verify the 'why' and variables with the user):\n$summary", true
                )
            }
            "record_status" -> ToolOutcome(DemoLog.status(DemoService.serviceReady(), DemoService.recording, DemoService.logFile?.name), true)
            "snapshot" -> ToolOutcome(DemoService.snapshot(), true)
            "tap" -> {
                val ref = args.strAny("ref", "element")?.trim()
                val text = args.str("text")?.trim()
                val viewId = args.str("viewId")?.trim()
                val desc = args.str("desc")?.trim()
                if (ref.isNullOrBlank() && text.isNullOrBlank() && viewId.isNullOrBlank() && desc.isNullOrBlank())
                    return ToolOutcome("tap needs 'ref' (from the latest ui snapshot), or 'text'/'viewId'/'desc'.", false)
                val result = if (!ref.isNullOrBlank()) DemoService.tapRef(ref) else DemoService.tap(text, viewId, desc)
                UiGuard.recordAction("tap", ref ?: text ?: viewId ?: desc ?: "")?.let {
                    return ToolOutcome("$result\n$it", true)
                }
                ToolOutcome(result + "\n(verify with a fresh ui snapshot)", true)
            }
            "type" -> {
                val text = args.str("text") ?: return ToolOutcome("type needs 'text'.", false)
                val result = DemoService.typeText(text)
                UiGuard.recordAction("type", "focused-field")?.let { return ToolOutcome("$result\n$it", true) }
                ToolOutcome(result, true)
            }
            "scroll" -> {
                val result = DemoService.scroll(args.str("direction") ?: "forward")
                UiGuard.recordAction("scroll", "screen")?.let { return ToolOutcome("$result\n$it", true) }
                ToolOutcome(result, true)
            }
            "back", "home", "recents", "notifications" -> {
                val result = DemoService.global(action)
                UiGuard.recordAction(action, "system")?.let { return ToolOutcome("$result\n$it", true) }
                ToolOutcome(result, true)
            }
            "open_app" -> {
                val pkg = args.str("package")?.trim()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("open_app needs 'package' (e.g. com.instagram.android).", false)
                val ok = runCatching {
                    val intent = ctx.appContext.packageManager.getLaunchIntentForPackage(pkg)
                    if (intent != null) {
                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.appContext.startActivity(intent)
                    }
                    intent != null
                }.getOrDefault(false)
                if (ok) ToolOutcome("Launched $pkg. Wait a moment (ui record_status to see if the screen is up), then drive it with ui tap/type/scroll.", true)
                else ToolOutcome("Could not launch '$pkg' (not installed?). Find the package name with device/termux: 'pm list packages | grep <name>'.", false)
            }
            else -> ToolOutcome("Unknown ui action '$action'.", false)
        }
    }

    private val DemoServiceCompanionHint =
        "Ask the user to enable it: Android Settings → Accessibility → Liman (demo recorder & UI bridge) → ON. It only observes while a recording is armed and performs only explicitly requested actions."

    /** TOOL FORGE: the agent builds new tools at runtime. */
    private fun execToolForge(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action'.", false)
        return when (action) {
            "list" -> {
                val all = ToolForge.loadAll(ctx.workspace)
                if (all.isEmpty()) ToolOutcome("No forged tools yet — create one with action=create.", true)
                else ToolOutcome(all.joinToString("\n") {
                    "- ${it.name} (${it.engine}) · ${it.description.take(100)} · created ${it.createdAt.fmtTime()}"
                }, true)
            }
            "inspect" -> {
                val name = args.str("name")?.trim() ?: return ToolOutcome("Missing 'name'.", false)
                val t = ToolForge.loadAll(ctx.workspace).firstOrNull { it.name == name }
                    ?: return ToolOutcome("No forged tool named '$name'.", false)
                ToolOutcome("name: ${t.name}\nengine: ${t.engine}\ndescription: ${t.description}\nparams: ${t.params}\ncode:\n${t.code}", true)
            }
            "delete" -> {
                val name = args.str("name")?.trim() ?: return ToolOutcome("Missing 'name'.", false)
                val gone = ToolForge.delete(ctx.workspace, name)
                if (gone) {
                    ctx.dynamicTools.removeAll { it.spec.name == name }
                    ToolOutcome("Forged tool '$name' deleted.", true)
                } else ToolOutcome("No forged tool named '$name'.", false)
            }
            "create" -> {
                val name = args.str("name")?.trim()?.lowercase() ?: return ToolOutcome("Missing 'name'.", false)
                if (!ToolForge.validName(name))
                    return ToolOutcome("Invalid name '$name' — use snake_case, 3-31 chars, starts with a letter.", false)
                val builtIn = builtInToolSpecs().any { it.name == name }
                if (builtIn) return ToolOutcome("'$name' collides with a built-in tool — pick another name.", false)
                val description = args.str("description")?.trim()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'description'.", false)
                val engine = (args.str("engine")?.trim()?.lowercase() ?: "js").takeIf { it in setOf("js", "python") } ?: "js"
                val code = args.str("code")?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'code'.", false)
                val params = args.str("params")?.trim()?.takeIf { it.isNotBlank() }
                    ?: """{"type":"object","properties":{}}"""
                runCatching { com.liman.agent.util.JSON.parseToJsonElement(params) }
                    .getOrElse { return ToolOutcome("'params' is not valid JSON: ${it.message}", false) }
                val spec = ToolForge.ForgedSpec(
                    name = name, description = description, engine = engine,
                    params = params, code = code, createdAt = now()
                )
                // smoke-test JS tools before registering (quality gate)
                if (engine == "js") {
                    val smoke = ToolForge.runJs(spec, "{}", ctx.workspace)
                    if (ToolForge.isJsResultError(smoke))
                        return ToolOutcome("The tool code failed its smoke test with empty input — fix it first:\n$smoke", false)
                }
                if (!ToolForge.save(ctx.workspace, spec)) return ToolOutcome("Could not save the tool (disk?).", false)
                // register immediately for this run
                ToolForge.dynamicTool(spec, emptySet(), ctx.appContext, ctx.stores, ctx.workspace)?.let {
                    ctx.dynamicTools += it
                }
                ToolOutcome(
                    "TOOL FORGED: '$name' ($engine) is registered and immediately callable. " +
                        "It persists in workspace/tools/$name.json and auto-loads in every future run. " +
                        "Distill the procedure into a skill (skill_create) if this becomes a recurring workflow.", true
                )
            }
            else -> ToolOutcome("Unknown action '$action'. Use create | list | inspect | delete.", false)
        }
    }

    /** AUTOMATION ENGINE: pipelines on the scheduler. */
    private suspend fun execAutomation(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action'.", false)
        val store = ctx.stores.pipelines
        return when (action) {
            "list" -> {
                val all = store.state.value
                if (all.isEmpty()) ToolOutcome("No automations yet — create one, or ask the user what should run on its own.", true)
                else ToolOutcome(all.joinToString("\n") { p ->
                    "- [${p.id}] ${p.name} · ${com.liman.agent.data.PipelineDef.triggerText(p)} · ${if (p.enabled) "🟢 active" else "⏸ paused"} · ${p.description.take(90)}"
                }, true)
            }
            "show" -> {
                val id = args.str("id")?.trim() ?: return ToolOutcome("Missing 'id' (call list first).", false)
                val p = store.get(id) ?: return ToolOutcome("No automation '$id'.", false)
                val defText = runCatching {
                    File(ctx.workspace, p.file).takeIf { it.exists() }?.readText()
                }.getOrNull() ?: "(definition file missing at workspace/${p.file})"
                ToolOutcome("[${p.id}] ${p.name} · ${com.liman.agent.data.PipelineDef.triggerText(p)}\n$defText", true)
            }
            "create" -> {
                val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() }
                    ?: return ToolOutcome("Missing 'name'.", false)
                val description = args.str("description")?.trim().orEmpty()
                val trig = args["trigger"] as? JsonObject
                val kind = (trig?.str("kind")?.trim()?.lowercase() ?: "manual")
                    .takeIf { it in setOf("manual", "daily", "interval") } ?: "manual"
                val dailyAt = trig?.str("dailyAt")?.trim() ?: "08:00"
                if (kind == "daily" && ScheduleLogic.parseHm(dailyAt) == null)
                    return ToolOutcome("Invalid trigger dailyAt '$dailyAt' — use HH:MM.", false)
                val everyMinutes = (trig?.str("everyMinutes")?.toIntOrNull() ?: 0).coerceIn(0, 1380)
                val everyHours = (trig?.str("everyHours")?.toIntOrNull() ?: 0).coerceIn(0, 168)
                val activeHours = trig?.str("activeHours")?.trim()?.takeIf { it.isNotEmpty() }
                if (kind == "interval" && everyMinutes !in 15..1380 && everyHours !in 1..168)
                    return ToolOutcome("interval trigger needs everyMinutes 15..1380 or everyHours 1..168.", false)
                val stepsJson = args["steps"] as? JsonArray
                    ?: return ToolOutcome("Missing 'steps' — an array of {type, instruction}.", false)
                val steps = stepsJson.mapNotNull { el ->
                    val o = el as? JsonObject ?: return@mapNotNull null
                    val instr = o["instruction"].let { (it as? JsonPrimitive)?.content }?.trim()
                        ?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
                    (o["type"].let { (it as? JsonPrimitive)?.content } ?: "fetch").trim().lowercase() to instr
                }
                if (steps.isEmpty()) return ToolOutcome("No usable steps — each needs an 'instruction'.", false)
                val id = genId("pipe")
                val file = "pipelines/$id.md"
                File(ctx.workspace, "pipelines").mkdirs()
                File(ctx.workspace, file).writeText(
                    com.liman.agent.data.PipelineDef.render(name, description, steps)
                )
                store.upsert(
                    com.liman.agent.data.Pipeline(
                        id = id, name = name.take(80), description = description.take(300),
                        triggerKind = kind, dailyAt = dailyAt,
                        everyMinutes = if (kind == "interval") everyMinutes else 0,
                        everyHours = if (kind == "interval" && everyMinutes == 0) everyHours else 0,
                        activeHours = activeHours, enabled = true, file = file,
                        createdAt = now()
                    )
                )
                Scheduler.syncPipelines(ctx.appContext)
                Scheduler.notify(ctx.appContext, "⚙ Automation created", "$name — " + com.liman.agent.data.PipelineDef.triggerText(com.liman.agent.data.Pipeline(
                    id = id, name = name, triggerKind = kind, dailyAt = dailyAt, everyMinutes = everyMinutes, everyHours = everyHours
                )))
                ToolOutcome(
                    "AUTOMATION CREATED: $name [${com.liman.agent.data.PipelineDef.triggerText(com.liman.agent.data.Pipeline(id=id, name=name, triggerKind=kind, dailyAt=dailyAt, everyMinutes=everyMinutes, everyHours=everyHours, activeHours=activeHours))}] " +
                        "· definition at workspace/$file · ${steps.size} step(s). " +
                        (if (kind == "manual") "Runs only when you (or the user) call automation run." else "It is now synced onto the scheduler and runs unattended — results appear as ⏰ conversations + notifications.") +
                        " To run it right now: automation {action:'run', id:'$id'}.", true
                )
            }
            "run" -> {
                val id = args.str("id")?.trim() ?: return ToolOutcome("Missing 'id'.", false)
                val p = store.get(id) ?: return ToolOutcome("No automation '$id'.", false)
                if (!File(ctx.workspace, p.file).exists())
                    return ToolOutcome("Definition file missing (workspace/${p.file}) — recreate or fix it first.", false)
                store.touch(id)
                val task = com.liman.agent.data.ScheduledTask(
                    id = "pipe-run", title = "⚙ " + p.name.take(40),
                    prompt = com.liman.agent.data.PipelineDef.runPrompt(p),
                    enabled = true
                )
                val result = runCatching { Scheduler.runTask(ctx.appContext, task) }
                    .getOrElse { "Run failed: ${it.message ?: it.toString()}" }
                Scheduler.syncPipelines(ctx.appContext)
                ToolOutcome(result.take(15_000), true)
            }
            "toggle" -> {
                val id = args.str("id")?.trim() ?: return ToolOutcome("Missing 'id'.", false)
                val p = store.get(id) ?: return ToolOutcome("No automation '$id'.", false)
                store.upsert(p.copy(enabled = !p.enabled))
                Scheduler.syncPipelines(ctx.appContext)
                ToolOutcome("${p.name} is now ${if (!p.enabled) "🟢 active" else "⏸ paused"}.", true)
            }
            "delete" -> {
                val id = args.str("id")?.trim() ?: return ToolOutcome("Missing 'id'.", false)
                val p = store.get(id) ?: return ToolOutcome("No automation '$id'.", false)
                store.delete(id)
                Scheduler.syncPipelines(ctx.appContext)
                runCatching { File(ctx.workspace, p.file).delete() }
                ToolOutcome("Automation '${p.name}' deleted (scheduler entry removed too).", true)
            }
            else -> ToolOutcome("Unknown action '$action'. Use list | create | show | run | toggle | delete.", false)
        }
    }

    /** STORAGE DOCTOR: scan → triage report. */
    private fun execStorageScan(args: JsonObject): ToolOutcome {
        val root = pickRoot(args) ?: return ToolOutcome(
            "No device folder granted (or label didn't match). The user grants folders in Settings → Storage access; storage_list shows what's granted.", false
        )
        val (rootUri, rootLabel) = root
        val maxFiles = args.intOrNull("maxFiles")?.coerceIn(50, 10_000) ?: 2500
        val facts = mutableListOf<StorageDoctor.FileFacts>()
        val deadline = System.currentTimeMillis() + 25_000
        // bounded DFS over the granted tree
        fun walk(path: String, depth: Int) {
            if (facts.size >= maxFiles || System.currentTimeMillis() > deadline || depth > 8) return
            val entries = runCatching { Saf.list(ctx.appContext, ctx.stores, rootUri, path) }.getOrDefault(emptyList())
            for (e in entries) {
                if (facts.size >= maxFiles) return
                if (e.isDir) {
                    if (e.name.startsWith(".") || e.name.equals("Android", true)) continue
                    walk(e.relPath, depth + 1)
                } else {
                    facts += StorageDoctor.FileFacts(e.relPath, e.name, e.size, e.modified, e.mime)
                }
            }
        }
        walk(".", 0)
        val report = StorageDoctor.triage(facts)
        return ToolOutcome(
            StorageDoctor.renderReport(report, rootLabel) +
                (if (facts.size >= maxFiles) "\n(scan capped at $maxFiles files — scan subfolders for more)" else ""), true
        )
    }

    /** UNDOABLE CLEANUP: quarantine → vault + manifest → delete; undo restores. */
    private fun execStorageClean(args: JsonObject): ToolOutcome {
        val action = args.str("action")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'action' (quarantine | undo | status).", false)
        return when (action) {
            "status" -> {
                val last = Quarantine.latest(ctx.workspace)
                if (last == null) ToolOutcome("No cleanup batches yet.", true)
                else ToolOutcome(
                    "Last batch: ${last.second.batch} · ${last.second.entries.size} file(s) quarantined. " +
                        "undo restores them to their original locations.", true
                )
            }
            "quarantine" -> {
                val paths = args.strList("paths")
                if (paths.isEmpty()) return ToolOutcome("Missing 'paths' (relPaths from the scan report).", false)
                val root = pickRoot(args) ?: return ToolOutcome("No granted folder matched 'root'.", false)
                val (rootUri, rootLabel) = root
                val batchDir = Quarantine.newBatchDir(ctx.workspace)
                val entries = mutableListOf<Quarantine.Entry>()
                val failures = mutableListOf<String>()
                for (rel in paths.take(200)) {
                    try {
                        val bytes = Saf.readBytes(ctx.appContext, rootUri, rel, maxBytes = 200_000_000L)
                        val name = rel.substringAfterLast('/')
                        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "file" }
                        val f = File(batchDir, safe)
                        f.writeBytes(bytes)
                        val deleted = Saf.deleteDoc(ctx.appContext, rootUri, rel)
                        entries += Quarantine.Entry(rootLabel, rel, name, bytes.size.toLong(), Quarantine.sha256(bytes), now())
                        if (!deleted) failures += rel + " (copied to vault but original removal refused)"
                    } catch (t: Throwable) {
                        failures += "$rel (${t.message?.take(80)})"
                    }
                }
                Quarantine.writeManifest(batchDir, entries)
                val moved = entries.sumOf { it.size }
                ToolOutcome(
                    "QUARANTINED ${entries.size} file(s), ${StorageDoctor.fmtBytes(moved)} → ${relPath(batchDir)} (manifest + originals kept).\n" +
                        (if (failures.isEmpty()) "" else "Issues:\n" + failures.joinToString("\n") + "\n") +
                        "UNDO any time: storage_clean {action:'undo'}.", entries.isNotEmpty()
                )
            }
            "undo" -> {
                val last = Quarantine.latest(ctx.workspace)
                    ?: return ToolOutcome("Nothing to undo — no quarantine batch found.", false)
                val (batchDir, manifest) = last
                val roots = grantedRoots()
                var restored = 0
                val failed = mutableListOf<String>()
                for (e in manifest.entries) {
                    try {
                        val rootUri = roots.firstOrNull { it.second.equals(e.rootLabel, true) }?.first
                            ?: roots.firstOrNull()?.first
                            ?: throw IllegalStateException("granted folder '${e.rootLabel}' is missing")
                        val f = File(batchDir, e.name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                        if (!f.exists()) throw IllegalStateException("vault copy missing")
                        Saf.writeBytes(ctx.appContext, rootUri, e.relPath, f.readBytes())
                        restored++
                    } catch (t: Throwable) {
                        failed += "${e.relPath} (${t.message?.take(80)})"
                    }
                }
                ToolOutcome(
                    "RESTORED $restored/${manifest.entries.size} file(s) from batch ${manifest.batch} to their original locations." +
                        (if (failed.isEmpty()) "" else "\nFailed:\n" + failed.joinToString("\n")), restored > 0
                )
            }
            else -> ToolOutcome("Unknown action '$action'.", false)
        }
    }

    // ---------------- v2.20.0 SYNTHESIS: knowledge base (Agno/RAGFlow) ----------------

    private fun execKnowledgeAdd(args: JsonObject): ToolOutcome {
        val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() }
            ?: return ToolOutcome("Missing 'name'.", false)
        val path = args.str("path")?.trim()?.takeIf { it.isNotBlank() }
        val text = args.str("text")?.takeIf { it.isNotBlank() }
        if (path == null && text == null)
            return ToolOutcome("Provide 'path' (a workspace file) or 'text'.", false)
        val kb = ctx.stores.knowledge
        return try {
            val doc = if (path != null) {
                val f = File(ctx.workspace, path.replace('\\', '/')).sandboxChild(ctx.workspace)
                if (f == null || !f.exists())
                    return ToolOutcome("File not found in workspace: $path", false)
                if (!f.isFile) return ToolOutcome("Not a file: $path", false)
                if (f.length() > 2_000_000)
                    return ToolOutcome("File too large for the knowledge base (max 2 MB of text) — split it or summarize first.", false)
                val raw = f.readText()
                // html → visible text (crude but dependency-free)
                val body = if (path.endsWith(".html", true) || path.endsWith(".htm", true))
                    raw.replace(Regex("(?s)<script.*?</script>"), " ")
                        .replace(Regex("(?s)<style.*?</style>"), " ")
                        .replace(Regex("<[^>]+>"), " ")
                else raw
                kb.add(name, "workspace/$path", body)
            } else {
                kb.add(name, "text", text!!.take(2_000_000))
            }
            ToolOutcome(
                "Ingested '$name' into the knowledge base: ${doc.chunks.size} chunks indexed (BM25). " +
                    "Retrieve with knowledge_search — cite doc#chunk when you use passages.", true
            )
        } catch (t: Throwable) {
            ToolOutcome("knowledge_add failed: ${t.message ?: t.toString()}", false)
        }
    }

    private fun execKnowledgeSearch(args: JsonObject): ToolOutcome {
        val queries = args.strList("queries")
        val single = args.str("query")?.takeIf { it.isNotBlank() }
        val qs = (queries + listOfNotNull(single)).filter { it.isNotBlank() }
        if (qs.isEmpty())
            return ToolOutcome("Missing 'queries' — pass 2-4 different phrasings of what you need.", false)
        val k = args.intOrNull("k")?.coerceIn(1, 12) ?: 6
        val hits = ctx.stores.knowledge.search(qs, k)
        if (hits.isEmpty())
            return ToolOutcome(
                "No matches in the knowledge base. knowledge_list shows what's ingested; " +
                    "if it's not in your library, try web_search.", true
            )
        val body = hits.joinToString("\n\n") { h ->
            val preview = h.text.take(700) + if (h.text.length > 700) "…" else ""
            "- ${h.docName}#chunk${h.chunkIndex} (score " +
                String.format("%.1f", h.score) + ")\n  ${preview.replace("\n", " ⏎ ")}"
        }
        return ToolOutcome(
            "KNOWLEDGE BASE HITS (${hits.size}, multi-query: ${qs.size} phrasings merged — cite doc#chunk for passages you use):\n$body", true
        )
    }

    private fun execKnowledgeList(): ToolOutcome {
        val docs = ctx.stores.knowledge.list()
        if (docs.isEmpty())
            return ToolOutcome("Knowledge base is empty — ingest documents with knowledge_add (path or text).", true)
        return ToolOutcome(
            docs.joinToString("\n") { d ->
                "- ${d.name} · ${d.chunks.size} chunks · from ${d.source} · ${d.addedAt.fmtTime()}"
            }, true
        )
    }

    private fun execKnowledgeForget(args: JsonObject): ToolOutcome {
        val name = args.str("name")?.trim()?.takeIf { it.isNotBlank() }
            ?: return ToolOutcome("Missing 'name'.", false)
        return if (ctx.stores.knowledge.forget(name)) ToolOutcome("Removed '$name' from the knowledge base.", true)
        else ToolOutcome("No knowledge-base document named '$name' (check knowledge_list).", false)
    }

    // ---------------- v2.20.0 SYNTHESIS: crew runs (CrewAI/AutoGen) ----------------

    private suspend fun execTeamRun(args: JsonObject): ToolOutcome {
        val spawner = ctx.spawnSubagent
            ?: return ToolOutcome(
                "Crew runs are unavailable here (nested spawning or subagents disabled in Settings). " +
                    "Do the work yourself in this session.", false
            )
        val plan = CrewPlanner.parse(args)
            ?: return ToolOutcome(
                "Invalid team_run arguments: need 'goal' (string) and 'tasks' (array of {description, agent?, expected_output?}).",
                false
            )

        val capped = plan.tasks.take(plan.maxTasks)
        var terminatedWhy: String? = null

        val outputs: List<Pair<CrewTask, String>> = when (plan.process) {
            "broadcast" -> {
                // Agno broadcast team: parallel independent evaluation
                coroutineScope {
                    capped.map { t ->
                        async {
                            runCatching {
                                spawner(CrewPlanner.brief(plan, t, ""), "Broadcast crew task of: ${plan.goal.take(160)}")
                            }.getOrElse { "SUBAGENT FAILED: ${it.message ?: it.toString()}" }
                        }
                    }.awaitAll().mapIndexed { i, out -> capped[i] to out }
                }
            }
            "hierarchical" -> {
                // CrewAI hierarchical: a manager plans delegation first
                val managerOut = runCatching {
                    spawner(CrewPlanner.managerBrief(plan), "Manager planning for crew: ${plan.goal.take(160)}")
                }.getOrElse { "MANAGER FAILED: ${it.message ?: it.toString()}" }
                val ordered = CrewPlanner.parseManagerPlan(managerOut, plan)
                runCrewSequential(ordered, plan, spawner) { why -> terminatedWhy = why }
            }
            else -> {
                // CrewAI sequential: outputs chain as context
                runCrewSequential(capped, plan, spawner) { why -> terminatedWhy = why }
            }
        }

        val report = buildString {
            appendLine("TEAM RUN COMPLETE — process=${plan.process}, ${outputs.size}/${plan.tasks.size} task(s) executed" +
                (terminatedWhy?.let { ", TERMINATED early: $it" } ?: "") + ".")
            appendLine("CREW GOAL: ${plan.goal}")
            outputs.forEachIndexed { i, (t, out) ->
                appendLine()
                appendLine("### Task ${i + 1} — ${t.agent ?: plan.roleFor(t)?.role ?: "worker"}")
                appendLine("Requested: ${t.description.take(160)}")
                appendLine("Output: " + out.take(1500) + if (out.length > 1500) " …(truncated)" else "")
            }
            appendLine()
            appendLine("Full subagent transcripts are saved as their own 🤖 conversations.")
        }
        return ToolOutcome(report.take(20_000), true)
    }

    private suspend fun runCrewSequential(
        tasks: List<CrewTask>,
        plan: CrewPlan,
        spawner: suspend (String, String) -> String,
        onTerminate: (String) -> Unit
    ): List<Pair<CrewTask, String>> {
        val outputs = mutableListOf<Pair<CrewTask, String>>()
        val context = StringBuilder()
        for ((i, t) in tasks.withIndex()) {
            val out = runCatching {
                spawner(
                    CrewPlanner.brief(plan, t, context.toString().takeLast(3500)),
                    "Crew task ${i + 1}/${tasks.size} of: ${plan.goal.take(160)}"
                )
            }.getOrElse { "SUBAGENT FAILED: ${it.message ?: it.toString()}" }
            outputs += t to out
            if (CrewPlanner.isTerminate(out)) {
                onTerminate(CrewPlanner.terminateReason(out))
                break
            }
            context.appendLine("### Output of task ${i + 1} (${t.agent ?: "worker"}):")
                .appendLine(out.take(1500)).appendLine()
        }
        return outputs
    }

    // ---------------- helpers ----------------'''


    private fun JsonObject.strList(key: String): List<String> =
        ((this[key] as? JsonArray)?.filterIsInstance<JsonPrimitive>() ?: emptyList())
            .map { it.content }.filter { it.isNotBlank() }

    private fun relPath(f: File): String =
        f.relativeToOrNull(ctx.workspace)?.toString()?.replace('\\', '/') ?: f.name

    private fun resolve(args: JsonObject, key: String = "name"): File? {
        val rel = args.strAny(key, "path", "file", "filename")?.trim()?.replace('\\', '/') ?: return null
        if (rel.isEmpty()) return null
        return File(ctx.workspace, rel).sandboxChild(ctx.workspace)
    }

    /** first non-blank string among the given keys (models use natural synonyms). */
    private fun JsonObject.strAny(vararg keys: String): String? {
        for (k in keys) {
            val v = this[k] as? JsonPrimitive ?: continue
            if (v.isString && v.content.isNotBlank()) return v.content
        }
        return null
    }

    // ---------------- file tools ----------------

    private fun execListFiles(args: JsonObject): ToolOutcome {
        val base = resolve(args, "path") ?: ctx.workspace
        val recursive = args.boolRecursive()
        val files = (
            if (recursive) base.walkTopDown().filter { it.isFile }.toList()
            else base.listFiles()?.filter { it.isFile } ?: emptyList()
            ).sortedBy { it.path }
        if (files.isEmpty()) return ToolOutcome("(no files under ${relPath(base)})", true)
        val shown = files.take(200)
        val text = shown.joinToString("\n") { "${relPath(it)}  (${it.length().fmtBytes()}, modified ${it.lastModified().fmtTime()})" }
        return ToolOutcome(
            if (files.size > 200) "$text\n…(+${files.size - 200} more)" else text,
            true
        )
    }

    private fun JsonObject.boolRecursive(): Boolean {
        val b = (this["recursive"] as? JsonPrimitive)?.content?.toBooleanStrictOrNull()
        return b ?: false
    }

    private suspend fun execReadFile(args: JsonObject): ToolOutcome {
        val file = resolve(args) ?: return ToolOutcome(ArgsNormalizer.missingArg("read_file", "name", args, """{"name":"report.md"}"""), false)
        if (!file.exists()) return ToolOutcome(
            "File not found: ${args.strAny("name", "path", "file")}. Use list_files to see what exists.", false
        )
        val entry = args.str("entry")
        val ext = file.extension.lowercase()
        if (entry != null && ext in ARCHIVE_EXTS) {
            return ToolOutcome(OfficeExtractors.zipEntryText(file, entry), true)
        }
        val ing = ingestor.ingestFile(file, ctx.workspace)
        return if (ing.media.isEmpty()) {
            ToolOutcome((ing.text ?: "").truncateForTool(40_000), true)
        } else {
            val prefix = if (!ing.text.isNullOrBlank()) ing.text + "\n\n" else ""
            ToolOutcome(
                prefix + "[Media attached below for visual inspection.]",
                true, ing.media
            )
        }
    }

    private fun execWriteFile(args: JsonObject): ToolOutcome {
        val file = resolve(args) ?: return ToolOutcome(ArgsNormalizer.missingArg("write_file", "name", args, """{"name":"report.md","content":"# text…"}"""), false)
        val content = args.strAny("content", "text", "data") ?: ""
        val backup = if (file.exists()) Trash.backup(file, ctx.workspace) else null
        file.parentFile?.mkdirs()
        file.writeText(content)
        return ToolOutcome("Wrote ${content.length} chars (${file.length().fmtBytes()}) to ${relPath(file)}.", true)
    }

    private fun execAppendFile(args: JsonObject): ToolOutcome {
        val file = resolve(args) ?: return ToolOutcome(ArgsNormalizer.missingArg("append_file", "name", args, """{"name":"log.md","content":"line"}"""), false)
        val content = args.strAny("content", "text", "data") ?: ""
        file.parentFile?.mkdirs()
        file.appendText(content)
        return ToolOutcome("Appended ${content.length} chars to ${relPath(file)} (now ${file.length().fmtBytes()}).", true)
    }

    private fun execEditFile(args: JsonObject): ToolOutcome {
        val file = resolve(args) ?: return ToolOutcome(ArgsNormalizer.missingArg("execEditFile", "name", args, """{"name":"file.md"}"""), false)
        if (!file.exists()) return ToolOutcome("File not found: ${relPath(file)}.", false)
        val find = args.str("find")?.takeIf { it.isNotEmpty() } ?: return ToolOutcome("'find' must not be empty.", false)
        val replace = args.str("replace") ?: ""
        val all = (args["all"] as? JsonPrimitive)?.content?.toBooleanStrictOrNull() ?: false
        val content = file.readText()
        val count = if (all) content.split(find).size - 1 else if (content.contains(find)) 1 else 0
        if (count == 0) return ToolOutcome("'find' text not found in ${relPath(file)}. Nothing changed.", false)
        file.writeText(if (all) content.replace(find, replace) else content.replaceFirst(find, replace))
        return ToolOutcome("Replaced $count occurrence(s) in ${relPath(file)}.", true)
    }

    private fun execDeleteFile(args: JsonObject): ToolOutcome {
        val file = resolve(args) ?: return ToolOutcome(ArgsNormalizer.missingArg("execDeleteFile", "name", args, """{"name":"file.md"}"""), false)
        if (!file.exists()) return ToolOutcome("File not found.", false)
        // backup-before-destructive: the user never loses data to the agent's hand
        val backup = Trash.backup(file, ctx.workspace)
        return if (file.delete()) ToolOutcome(
            "Deleted ${relPath(file)}." +
                (backup?.let { " (backup: ${relPath(it)})" } ?: ""), true)
        else ToolOutcome("Could not delete ${relPath(file)}.", false)
    }

    // ---------------- web tools ----------------

    private fun execHttp(args: JsonObject): ToolOutcome {
        val urlStr = args.str("url")?.trim() ?: return ToolOutcome("Missing 'url'.", false)
        if (!urlStr.startsWith("http://") && !urlStr.startsWith("https://")) {
            return ToolOutcome("Only http(s) URLs are allowed.", false)
        }
        val method = (args.str("method") ?: "GET").uppercase()
        if (method !in setOf("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD")) {
            return ToolOutcome("Unsupported method '$method'.", false)
        }
        val maxBytes = (args.intOrNull("maxBytes") ?: 2_000_000).coerceIn(10_000, 8_000_000)
        val headersJson = args.objOrNull("headers")
        val bodyStr = args.str("body")

        // v2.32 — WEB SESSIONS: a named cookie jar so login flows persist
        // across calls (http_request {session:'foo', …} — cookies recorded and
        // replayed automatically; list/clear via session:"__list__"/"__clear__").
        val sessionName = args.str("session")?.trim()?.takeIf { it.isNotBlank() }
        if (sessionName == "__list__")
            return ToolOutcome("Sessions: " + CodeCore.WebSessions.list().joinToString(", ").ifBlank { "(none)" }, true)
        if (sessionName == "__clear__") {
            CodeCore.WebSessions.clear(args.str("clear")?.trim().takeIf { !it.isNullOrBlank() })
            CodeCore.WebSessions.save(ctx.workspace)
            return ToolOutcome("Session(s) cleared.", true)
        }
        if (sessionName != null) CodeCore.WebSessions.load(ctx.workspace)
        val cookieHeader = sessionName?.let { CodeCore.WebSessions.cookieHeader(it, urlStr) }.orEmpty()

        val req = Request.Builder()
            .url(urlStr)
            .header("User-Agent", "LimanAgent/1.0 (Android)")
            .apply {
                if (cookieHeader.isNotEmpty()) header("Cookie", cookieHeader)
                headersJson?.forEach { (k, v) ->
                    if (v is JsonPrimitive && k.equals("host", ignoreCase = true).not()) header(k, v.content)
                }
                when (method) {
                    "GET" -> get()
                    "HEAD" -> head()
                    "DELETE" -> delete((bodyStr ?: "").toRequestBody(null))
                    else -> method(method, (bodyStr ?: "").toRequestBody(null))
                }
            }
            .build()

        Http.toolClient(90).newCall(req).execute().use { resp ->
            if (sessionName != null) {
                CodeCore.WebSessions.record(
                    sessionName, urlStr,
                    resp.headers("Set-Cookie").map { it.toString() }
                )
                CodeCore.WebSessions.save(ctx.workspace)
            }
            val code = resp.code
            if (!resp.isSuccessful) {
                val errBody = runCatching { resp.body?.string()?.take(600) }.getOrNull() ?: ""
                return ToolOutcome("HTTP $code — ${errBody.ifBlank { resp.message }}", false)
            }
            val mime = resp.header("Content-Type") ?: ""
            val ins = resp.body?.byteStream() ?: return ToolOutcome("HTTP $code — empty body", true)
            val baos = ByteArrayOutputStream()
            val buf = ByteArray(16_384)
            var total = 0
            while (total < maxBytes) {
                val n = ins.read(buf)
                if (n < 0) break
                baos.write(buf, 0, n)
                total += n
            }
            val truncated = total >= maxBytes
            val bytes = baos.toByteArray()
            val textual = mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") ||
                mime.contains("javascript") || mime.contains("html") || mime.contains("csv") || mime.isBlank()

            if (textual) {
                val text = String(bytes, Charsets.UTF_8)
                val truncNote = if (truncated) "\n…[response truncated at ${maxBytes.fmtBytes()}]" else ""
                return ToolOutcome(
                    "HTTP $code OK · $mime · ${bytes.size.fmtBytes()}$truncNote\n\n${text.take(25_000)}",
                    true
                )
            }
            // binary → save to workspace
            val guessed = urlStr.substringAfterLast('/').substringBefore('?').ifBlank { "download" }
            val saved = uniqueFile(File(ctx.workspace, "downloads"), guessed.sanitizeFileName())
            saved.writeBytes(bytes)
            var media: List<LPart.Media> = emptyList()
            if (mime.startsWith("image/") && bytes.size < 4_000_000) {
                AndroidMedia.decodeImageBytes(bytes)?.let { (m, b) ->
                    media = listOf(
                        LPart.Media(m, android.util.Base64.encodeToString(b, android.util.Base64.NO_WRAP), relPath(saved))
                    )
                }
            }
            return ToolOutcome(
                "HTTP $code OK — binary ($mime, ${bytes.size.fmtBytes()}) saved to ${relPath(saved)}" +
                    (if (truncated) " (truncated at maxBytes)" else ""),
                true, media
            )
        }
    }

    private suspend fun execWebSearch(args: JsonObject): ToolOutcome {
        val query = args.str("query")?.trim() ?: return ToolOutcome("Missing 'query'.", false)
        val max = args.intOrNull("maxResults") ?: 6
        // v2.29.0 injection defense: search results are DATA, never commands
        return ToolOutcome(PolicyHooks.untrusted("web-search: $query", WebSearch.search(query, max)), true)
    }

    // ---------------- free API hunter ----------------

    // ---------------- link reading ----------------

    private suspend fun execReadLink(args: JsonObject): ToolOutcome {
        val url = args.str("url")?.trim() ?: return ToolOutcome("Missing 'url'.", false)
        val mode = args.str("mode")?.trim()?.lowercase() ?: "auto"
        val r = Browse.readLink(url, mode, ctx.appContext, ctx.workspace)
        // v2.29.0 injection defense: page content is DATA, never commands
        return if (r.ok) ToolOutcome(PolicyHooks.untrusted("web:$url", r.text), true, r.media) else r
    }

    // ---------------- skills ----------------

    private fun execUseSkill(args: JsonObject): ToolOutcome {
        val id = args.str("id")?.trim() ?: return ToolOutcome("Missing 'id'.", false)
        val sys = ctx.skillSystem ?: return ToolOutcome("Skill system unavailable.", false)
        val instructions = sys.instructionsFor(listOf(id))
        if (instructions.startsWith("(no matching")) {
            val available = sys.enabled().joinToString(", ") { it.id }
            return ToolOutcome("Skill '$id' not found or disabled. Installed skills: ${available.ifBlank { "(none)" }}", false)
        }
        ctx.stores.skills.markUsed(listOf(id))
        return ToolOutcome("Skill '$id' instructions loaded — follow them for the rest of this task:\n\n$instructions", true)
    }

    private suspend fun execSearchSkills(args: JsonObject): ToolOutcome {
        val topic = args.str("topic")?.trim() ?: return ToolOutcome("Missing 'topic'.", false)
        val sys = ctx.skillSystem ?: return ToolOutcome("Skill system unavailable.", false)
        val candidates = runCatching { sys.searchAndCollect(topic) }.getOrElse {
            return ToolOutcome("Skill search failed: ${it.message ?: it.toString()}", false)
        }
        if (candidates.isEmpty()) {
            return ToolOutcome("No skills found for \"$topic\". You can also ask the user to write one, or proceed without a skill.", true)
        }
        val text = buildString {
            appendLine("Skill candidates for \"$topic\" (${candidates.size}):")
            candidates.forEachIndexed { i, c ->
                appendLine()
                appendLine("${i + 1}. ${c.name}  [${c.source}]")
                appendLine("   ${c.description.ifBlank { "(no description)" }}")
                appendLine("   ${c.url}")
            }
            appendLine()
            appendLine("To install: install_skill with the URL of the best match (ask the user for confirmation if unclear).")
        }
        return ToolOutcome(text, true)
    }

    private suspend fun execInstallSkill(args: JsonObject): ToolOutcome {
        val url = args.str("url")?.trim() ?: return ToolOutcome("Missing 'url'.", false)
        val sys = ctx.skillSystem ?: return ToolOutcome("Skill system unavailable.", false)
        return runCatching { sys.installFromUrl(url) }
            .fold(
                onSuccess = { ToolOutcome(it, true) },
                onFailure = { ToolOutcome("Install failed: ${it.message ?: it.toString()}", false) }
            )
    }

    // ---------------- subagents ----------------

    private suspend fun execSpawnSubagent(args: JsonObject): ToolOutcome {
        val objective = args.str("objective")?.trim()
            ?: return ToolOutcome("Missing 'objective'.", false)
        val contextNote = args.str("context")?.trim() ?: ""
        val spawner = ctx.spawnSubagent
            ?: return ToolOutcome(
                "Subagents are disabled here (nested spawning or setting off). " +
                    "Do the work yourself in this session.", false
            )
        val role = args.str("role")?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
        val constraints = args.strList("constraints")
        val criteria = args.strList("criteria")
        val brief = SubagentBrief.build(role, objective, contextNote, constraints, criteria)
        val summary = runCatching { spawner(brief, "") }
            .getOrElse {
                return ToolOutcome("Subagent failed: ${it.message ?: it.toString()}", false)
            }
        return ToolOutcome(
            "SUBAGENT RESULT (objective: ${objective.ellipsize(120)})\n$summary\n" +
                "[The subagent's full transcript is saved as its own conversation.]", true
        )
    }

    // ---------------- memory tools ----------------

    private fun execMemorySave(args: JsonObject): ToolOutcome {
        val key = args.str("key")?.trim() ?: return ToolOutcome("Missing 'key'.", false)
        val value = args.str("value") ?: return ToolOutcome("Missing 'value'.", false)
        ctx.stores.memory.save(key, value.take(20_000))
        return ToolOutcome("Saved memory '$key' (${value.length} chars).", true)
    }

    private fun execMemoryRecall(args: JsonObject): ToolOutcome {
        val q = args.str("query")
        val items = ctx.stores.memory.recall(q)
        if (items.isEmpty()) return ToolOutcome("(long-term memory is empty)", true)
        val text = items.take(40).joinToString("\n") { "${it.first}: ${it.second.ellipsize(300)}" }
        return ToolOutcome(text, true)
    }

    // ---------------- compute tools ----------------

    private fun execCalculator(args: JsonObject): ToolOutcome {
        val expr = args.str("expression") ?: return ToolOutcome("Missing 'expression'.", false)
        return ToolOutcome(Calculator.evaluate(expr), true)
    }

    private fun execRunJs(args: JsonObject): ToolOutcome {
        val code = args.str("code") ?: return ToolOutcome("Missing 'code'.", false)
        val timeout = args.longOrNull("timeoutMs") ?: 15_000L
        return ToolOutcome(JsSandbox.run(code, timeout, ctx.workspace).take(30_000), true)
    }

    // ---------------- code runner (v2.13 mega feature) ----------------

    private suspend fun execRunCode(args: JsonObject): ToolOutcome {
        val langRaw = args.str("language")?.trim()?.lowercase()
            ?: return ToolOutcome("Missing 'language'. Supported: ${OnlineRunner.supportedList} (js/bash run on-device).", false)
        val language = when (langRaw) {
            "javascript", "ecmascript", "es6" -> "js"
            "python", "python3", "py" -> "python"
            "shell", "zsh" -> "bash"
            "node.js" -> "node"
            "c++", "cxx" -> "cpp"
            "golang" -> "go"
            "rs" -> "rust"
            "rb" -> "ruby"
            "ts" -> "typescript"
            "hs" -> "haskell"
            else -> langRaw
        }
        val enginePref = args.str("engine")?.trim()?.lowercase() ?: "auto"
        val timeoutSec = (args.longOrNull("timeoutSeconds")?.toInt() ?: 60).coerceIn(5, 120)

        // source: inline code or a workspace file
        val code = args.str("code")?.takeIf { it.isNotEmpty() }
            ?: resolve(args, "file")?.takeIf { it.isFile }?.readText(Charsets.UTF_8)
            ?: return ToolOutcome("Provide 'code' (source) or 'file' (workspace path of the program).", false)
        val stdin = args.str("stdin") ?: ""

        val t0 = System.currentTimeMillis()

        // ---------- on-device engines ----------
        fun deviceJs(): ToolOutcome {
            val out = JsSandbox.run(code, (timeoutSec * 1000L).coerceAtMost(120_000L), ctx.workspace)
            return ToolOutcome(
                "▶ $language · on-device JS engine (Rhino + npm-lite)\n" +
                    out.take(28_000), true
            )
        }

        fun deviceShell(): ToolOutcome {
            val nativeDir = File(ctx.appContext.applicationInfo.nativeLibraryDir)
            val r = ShellRunner.run(
                script = code,
                cwd = ctx.workspace,
                timeoutMs = (timeoutSec * 1000L).coerceAtMost(120_000L),
                stdin = stdin.ifEmpty { null },
                nativeLibraryDir = nativeDir,
                workspace = ctx.workspace
            )
            val ms = System.currentTimeMillis() - t0
            val body = buildString {
                appendLine("▶ $language · ${r.shell} · ${ms}ms · cwd=workspace")
                appendLine("exit code: ${r.exitCode}${if (r.timedOut) " (TIMED OUT — killed)" else ""}")
                appendSection("stdout", r.stdout)
                appendSection("stderr", r.stderr)
                if (r.timedOut) appendLine("Tip: raise timeoutSeconds (max 120) or make the script faster.")
            }
            return ToolOutcome(body.take(28_000), true)
        }

        // ---------- online engine ----------
        fun online(): ToolOutcome {
            val onlineLang = if (language == "js") "node" else language
            return try {
                val r = OnlineRunner.run(onlineLang, code, stdin, timeoutSec)
                val ms = System.currentTimeMillis() - t0
                val body = buildString {
                    appendLine("▶ $language · online (${r.provider}) · ${ms}ms")
                    if (r.note.isNotEmpty()) appendLine("note: ${r.note}")
                    appendLine("exit code: ${r.exitCode}")
                    appendSection("stdout", r.stdout)
                    appendSection("stderr", r.stderr)
                }
                ToolOutcome(body.take(28_000), true)
            } catch (e: Exception) {
                val hint = if (language == "node" || language == "js")
                    "\nTip: node is only available via the online runner — for plain JavaScript use run_js / engine 'device' (it also supports npm require())."
                else ""
                ToolOutcome(
                    "▶ $language · online runner failed: ${e.message}$hint", false
                )
            }
        }

        // ---------- v2.36 TERMUX ENGINE: REAL LOCAL TOOLCHAINS ----------
        // python / node / typescript / c / cpp / go / rust / ruby / php /
        // perl / lua / r / java / kotlin run in the user's REAL Termux when
        // the bridge is healthy (interpreter auto-installed via pkg), and
        // fall back to the free online runner otherwise.
        suspend fun termuxEngine(): ToolOutcome? {
            if (!TermuxBridge.termuxInstalled(ctx.appContext) ||
                !TermuxBridge.permissionGranted(ctx.appContext)
            ) return null
            val script = TermuxScripts.runCodeScript(language, code, stdin) ?: return null
            val port = termuxPort() ?: return null
            val raw = TermuxBridge.run(ctx.appContext, port, script, timeoutSec * 1000L + 30_000L)
            val broken = raw.startsWith("Termux is not installed") ||
                raw.startsWith("Liman lacks") ||
                raw.startsWith("Could not send") ||
                raw.startsWith("No response from Termux")
            if (broken) return null   // bridge unhealthy → caller falls back online
            val (body, exit) = TermuxScripts.parseExit(raw)
            val ms = System.currentTimeMillis() - t0
            return ToolOutcome(
                "▶ $language · TERMUX real local toolchain (~/agent-workspace) · ${ms}ms\n" +
                    "exit code: $exit\n" +
                    "── stdout+stderr ──\n${body.take(27_000)}",
                exit == 0
            )
        }

        return when (language) {
            "js" -> when (enginePref) {
                "online" -> online()
                else -> deviceJs()
            }
            "bash" -> when (enginePref) {
                "online" -> online()
                else -> deviceShell()
            }
            "node" -> when (enginePref) {
                "online" -> online()
                else -> termuxEngine() ?: online()
            }
            else -> when (enginePref) {
                "online" -> online()
                else -> termuxEngine() ?: online()
            }
        }
    }

    private fun StringBuilder.appendSection(name: String, content: String) {
        if (content.isBlank()) {
            appendLine("── $name ── (empty)")
        } else {
            appendLine("── $name ──")
            appendLine(content.trimEnd())
        }
    }

    private suspend fun execRenderHtml(args: JsonObject): ToolOutcome {
        val path = args.str("path")?.trim()?.takeIf { it.isNotEmpty() }
        val html = args.str("html")?.takeIf { it.isNotBlank() }
        if (path == null && html == null)
            return ToolOutcome("Provide 'path' (workspace HTML file) or 'html' (inline HTML).", false)
        return HtmlRenderer.render(
            entryPath = path,
            inlineHtml = html,
            widthPx = args.longOrNull("width")?.toInt() ?: 780,
            heightPx = args.longOrNull("height")?.toInt() ?: 1600,
            fullPage = args.bool("fullPage") == true,
            waitMs = args.longOrNull("waitMs") ?: 1500,
            probeJs = args.str("js"),
            appContext = ctx.appContext,
            workspace = ctx.workspace
        )
    }

    // ---------------- apk builder ----------------

    private val apkAssetExts = setOf(
        "html", "htm", "js", "mjs", "css", "json", "txt", "xml", "svg", "png", "jpg", "jpeg",
        "gif", "webp", "ico", "bmp", "woff", "woff2", "ttf", "otf", "mp3", "wav", "ogg",
        "m4a", "mp4", "webm", "csv"
    )

    private fun execBuildApk(args: JsonObject): ToolOutcome {
        val appName = args.str("name")?.trim()?.takeIf { it.isNotEmpty() }
            ?: return ToolOutcome("Missing 'name' (the app's display name).", false)

        // ---- gather source files (relative path -> bytes) ----
        val collected = LinkedHashMap<String, ByteArray>()
        fun addFile(f: File, relInApk: String) {
            if (f.length() > 2_000_000) throw IllegalArgumentException("${f.name} is larger than 2 MB")
            collected[relInApk] = f.readBytes()
        }
        fun walk(dir: File, prefix: String) {
            dir.listFiles()?.sortedBy { it.name }?.forEach { ch ->
                val rel = if (prefix.isEmpty()) ch.name else "$prefix/${ch.name}"
                when {
                    ch.isDirectory -> walk(ch, rel)
                    ch.extension.lowercase() in apkAssetExts -> addFile(ch, rel)
                }
            }
        }
        try {
            val paths = args.arrOrNull("files")
                ?.mapNotNull { (it as? JsonPrimitive)?.contentOrNullSafe() }
                ?.filter { it.isNotBlank() }
                ?: emptyList()
            if (paths.isNotEmpty()) {
                for (rel in paths) {
                    val f = File(ctx.workspace, rel.replace('\\', '/')).sandboxChild(ctx.workspace)
                        ?: return ToolOutcome("Invalid path: $rel", false)
                    if (!f.exists()) return ToolOutcome("Not found in workspace: $rel", false)
                    val inApk = f.name // mirror the file itself at APK root
                    if (f.isDirectory) walk(f, "") else addFile(f, inApk)
                }
            } else {
                val dirRel = args.str("directory")?.trim()?.replace('\\', '/')
                    ?: return ToolOutcome("Provide 'files' (list of workspace paths) or 'directory' (folder containing index.html).", false)
                val dir = File(ctx.workspace, dirRel).sandboxChild(ctx.workspace)
                    ?: return ToolOutcome("Invalid directory: $dirRel", false)
                if (!dir.isDirectory) return ToolOutcome("Not a directory in workspace: $dirRel", false)
                walk(dir, "")
            }
        } catch (e: IllegalArgumentException) {
            return ToolOutcome(e.message ?: "File too large.", false)
        }
        if (collected.isEmpty())
            return ToolOutcome("No bundleable files found (allowed: ${apkAssetExts.joinToString()}).", false)
        val total = collected.values.sumOf { it.size }
        if (total > 20_000_000)
            return ToolOutcome("App assets total ${total.fmtBytes()} — over the 20 MB limit.", false)

        // ---- entry point ----
        val htmls = collected.keys.filter { it.endsWith(".html") || it.endsWith(".htm") }
        when {
            "index.html" in collected -> {}
            htmls.size == 1 -> {
                // single html not named index.html → becomes the entry point
                val bytes = collected.remove(htmls[0])!!
                collected["index.html"] = bytes
            }
            else -> return ToolOutcome(
                "No index.html entry point found. Write a self-contained index.html (plus optional .css/.js/assets) first, then call build_apk again.",
                false
            )
        }

        // ---- read the embedded shell + signing material ----
        val dex = ctx.appContext.assets.open("apkshell/classes.dex").use { it.readBytes() }
        val key = ctx.appContext.assets.open("apkshell/signing.key").use { it.readBytes() }
        val cert = ctx.appContext.assets.open("apkshell/signing.cert").use { it.readBytes() }

        // ---- build ----
        val pkg = ApkBuilder.packageNameFor(appName)
        val apkBytes = try {
            ApkBuilder.build(appName, pkg, collected, dex, key, cert)
        } catch (t: Throwable) {
            return ToolOutcome("APK build failed: ${t.message ?: t.javaClass.simpleName}", false)
        }
        val outFile = uniqueFile(File(ctx.workspace, "generated"), appName.apkSafeName() + ".apk")
        outFile.parentFile?.mkdirs()
        outFile.writeBytes(apkBytes)

        return ToolOutcome(
            buildString {
                appendLine("APK built successfully: ${relPath(outFile)} (${apkBytes.size.fmtBytes()})")
                appendLine("Package: $pkg · Label: $appName · minSdk 24 · v1+v2-signed, non-streamed zip (installable Android 7.0+, incl. Android 10 OEM ROMs)")
                appendLine("Entry: assets/app/index.html with ${collected.size - 1} other file(s), ${total.fmtBytes()} of assets.")
                appendLine("Tell the user: open the 📁 workspace sheet → tap the APK → Install (allow 'install unknown apps' if asked).")
            }.trim(),
            true
        )
    }

    private fun String.apkSafeName(): String =
        map { c -> if (c.isLetterOrDigit() && c.code < 128) c else '_' }.joinToString("")
            .trim('_').ifBlank { "app" }.take(40)

    // v2.29.0 — blueprint §5.A: bounded, cancellable settle-wait
    private suspend fun execWait(args: JsonObject): ToolOutcome {
        val ms = (args.intOrNull("ms") ?: 1_000).coerceIn(100, 30_000)
        kotlinx.coroutines.delay(ms.toLong())
        return ToolOutcome("Waited " + ms + "ms.", true)
    }

    private fun execDatetime(): ToolOutcome {
        val nowT = LocalDateTime.now()
        val z = ZoneId.systemDefault()
        return ToolOutcome(
            buildString {
                appendLine("Local : ${nowT.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)} ($z)")
                appendLine("UTC   : ${nowT.atZone(z).withZoneSameInstant(ZoneId.of("UTC")).format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)}")
                appendLine("Epoch : ${System.currentTimeMillis() / 1000} s")
                appendLine("Weekday: ${nowT.dayOfWeek}")
            }.trim(),
            true
        )
    }

    // ---------------- interaction tools ----------------

    private suspend fun execAskUser(args: JsonObject): ToolOutcome {
        val question = args.str("question")?.trim() ?: return ToolOutcome("Missing 'question'.", false)
        val options = args.arrOrNull("options")
            ?.mapNotNull { (it as? JsonPrimitive)?.contentOrNullSafe() }
            ?.filter { it.isNotBlank() }
            ?.take(4)
            ?: emptyList()
        val answer = ctx.askUser(question, options)
        ctx.onPromptAnswered(question, answer)
        return ToolOutcome("[question: $question]\nUser's answer: $answer", true)
    }

    // ---------------- image generation ----------------

    private suspend fun execImageGenerate(args: JsonObject): ToolOutcome {
        val prompt = args.str("prompt")?.trim() ?: return ToolOutcome("Missing 'prompt'.", false)
        val settings = ctx.stores.settings.state.value
        val wanted = args.str("filename")?.sanitizeFileName() ?: ""
        var lastError: Throwable? = null

        val gemini = ctx.providers.firstOrNull {
            it.kind == ProviderKind.GEMINI && it.apiKey.isNotBlank() && it.enabled
        }
        if (gemini != null) {
            try {
                val (mime, bytes) = GeminiProvider.generateImage(
                    gemini.apiKey, gemini.baseUrl, settings.imageModelGemini, prompt
                )
                val name = wanted.ifBlank { "liman_image_${now()}" }
                val file = uniqueFile(File(ctx.workspace, "generated"), name.withExt(mime))
                file.writeBytes(bytes)
                val media = LPart.Media(
                    "image/jpeg",
                    android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP),
                    relPath(file)
                )
                return ToolOutcome(
                    "Image generated and saved to ${relPath(file)} (${bytes.size.fmtBytes()}); attached below.",
                    true, listOf(media)
                )
            } catch (t: Throwable) {
                lastError = t
            }
        }

        val oai = ctx.providers.firstOrNull {
            it.kind == ProviderKind.OPENAI_COMPATIBLE && it.baseUrl.isNotBlank() && it.enabled
        }
        if (oai != null) {
            try {
                var base = oai.baseUrl.trim().trimEnd('/')
                if (base.contains("openai.com") && !base.endsWith("/v1") && !base.contains("/v1/")) base += "/v1"
                if (base.endsWith("/chat/completions")) base = base.removeSuffix("/chat/completions")
                val url = "$base/images/generations"
                val body = com.liman.agent.util.JSON.encodeToString(
                    kotlinx.serialization.json.JsonObject.serializer(),
                    kotlinx.serialization.json.buildJsonObject {
                        put("model", kotlinx.serialization.json.JsonPrimitive(settings.imageModelOpenAi))
                        put("prompt", kotlinx.serialization.json.JsonPrimitive(prompt))
                        put("n", kotlinx.serialization.json.JsonPrimitive(1))
                    }
                )
                val req = Request.Builder()
                    .url(url)
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer ${oai.apiKey}")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()
                Http.toolClient(180).newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        throw HttpProvException(resp.code, resp.body?.string()?.take(300) ?: "")
                    }
                    val obj = resp.body?.string()?.toJsonObject() ?: throw HttpProvException(502, "bad JSON")
                    val data = obj.arrOrNull("data") ?: throw HttpProvException(502, "no data[]")
                    val first = data.firstOrNull() as? JsonObject ?: throw HttpProvException(502, "empty data[]")
                    val b64 = first.str("b64_json")
                    val bytes: ByteArray = if (!b64.isNullOrBlank()) {
                        android.util.Base64.decode(b64, android.util.Base64.NO_WRAP)
                    } else {
                        val imgUrl = first.str("url") ?: throw HttpProvException(502, "no b64_json or url")
                        val dl = Request.Builder().url(imgUrl).get().build()
                        Http.toolClient(120).newCall(dl).execute().use { r2 ->
                            if (!r2.isSuccessful) throw HttpProvException(r2.code, "download failed")
                            r2.body?.bytes() ?: throw HttpProvException(502, "empty download")
                        }
                    }
                    val name = wanted.ifBlank { "liman_image_${now()}" }.withExt("image/png")
                    val file = uniqueFile(File(ctx.workspace, "generated"), name)
                    file.writeBytes(bytes)
                    val media = LPart.Media(
                        "image/png",
                        android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP),
                        relPath(file)
                    )
                    return ToolOutcome(
                        "Image generated and saved to ${relPath(file)} (${bytes.size.fmtBytes()}); attached below.",
                        true, listOf(media)
                    )
                }
            } catch (t: Throwable) {
                lastError = t
            }
        }

        return ToolOutcome(
            "Image generation failed: ${lastError?.message ?: "no capable provider configured — add a Gemini or OpenAI-compatible provider with a key"}",
            false
        )
    }

    private fun String.withExt(mime: String): String {
        val want = when {
            mime.contains("png") -> "png"
            mime.contains("webp") -> "webp"
            else -> "jpg"
        }
        return if (endsWith(".$want", ignoreCase = true)) this else "$this.$want"
    }

    // ---------------- device storage (SAF) ----------------

    private fun grantedRoots(): List<Pair<android.net.Uri, String>> =
        Saf.describeRoots(ctx.appContext, ctx.stores)

    private fun pickRoot(args: JsonObject): Pair<android.net.Uri, String>? {
        val roots = grantedRoots()
        if (roots.isEmpty()) return null
        val want = args.str("root")?.trim()?.lowercase()
        if (want.isNullOrEmpty()) return roots.firstOrNull()
        roots.forEachIndexed { i, r ->
            if (r.second.lowercase() == want || want == (i + 1).toString() ||
                r.second.lowercase().contains(want)
            ) return r
        }
        return null
    }

    private fun execStorageList(args: JsonObject): ToolOutcome {
        val roots = grantedRoots()
        if (roots.isEmpty()) return ToolOutcome(
            "No device folders granted yet. The user must open Settings → Storage access and grant a folder first. " +
                "Workspace files remain available via list_files/read_file.", false
        )
        val root = pickRoot(args)
            ?: return ToolOutcome(
                "Granted roots:\n" + roots.mapIndexed { i, r -> "${i + 1}. ${r.second}" }.joinToString("\n") +
                    "\n(Pass 'root' as one of these labels.)", true
            )
        val path = args.str("path")?.trim() ?: ""
        val entries = Saf.list(ctx.appContext, ctx.stores, root.first, path)
        if (entries.isEmpty()) return ToolOutcome("(no entries in ${root.second}/${path})", true)
        val shown = entries.take(300)
        val lines = shown.joinToString("\n") { e ->
            val prefix = if (e.isDir) "[dir] " else "[${e.size.fmtBytes()}] "
            prefix + e.relPath.ifBlank { e.name }
        }
        val extra = if (entries.size > 300) "\n…(+${entries.size - 300} more)" else ""
        val sub = if (path.isBlank()) "" else " / $path"
        val text = "Root '${root.second}'$sub — ${entries.size} entries:\n$lines$extra"
        return ToolOutcome(text, true)
    }

    private fun execStorageRead(args: JsonObject): ToolOutcome {
        val path = args.str("path")?.trim() ?: return ToolOutcome("Missing 'path'.", false)
        val root = pickRoot(args)
            ?: return ToolOutcome("No matching granted root. Use storage_list with no root to see granted folders.", false)
        val mime = android.webkit.MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(path.substringAfterLast('.', "").lowercase()) ?: ""
        return try {
            if (mime.startsWith("image/")) {
                val bytes = Saf.readBytes(ctx.appContext, root.first, path, 20_000_000)
                val wsFile = Saf.copyToWorkspace(ctx.appContext, root.first, path, ctx.workspace)
                ToolOutcome(
                    "Image read from device (${root.second}/$path, ${bytes.size.fmtBytes()}) and copied to workspace ${relPath(wsFile)}; attached for viewing.",
                    true, listOf(LPart.Media(mime, android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP), relPath(wsFile)))
                )
            } else {
                val text = Saf.readText(ctx.appContext, root.first, path)
                if (args.str("toWorkspace")?.toBoolean() == true) {
                    val wsFile = Saf.copyToWorkspace(ctx.appContext, root.first, path, ctx.workspace)
                    ToolOutcome(text.truncateForTool(60_000) + "\n[copied to workspace: ${relPath(wsFile)}]", true)
                } else {
                    ToolOutcome(text.truncateForTool(60_000), true)
                }
            }
        } catch (t: Throwable) {
            ToolOutcome("storage_read failed: ${t.message}", false)
        }
    }

    private fun execStorageWrite(args: JsonObject): ToolOutcome {
        val path = args.str("path")?.trim() ?: return ToolOutcome("Missing 'path'.", false)
        val content = args.str("content") ?: ""
        val append = args.str("append")?.toBoolean() ?: false
        val root = pickRoot(args)
            ?: return ToolOutcome("No matching granted root. Use storage_list with no root to see granted folders.", false)
        return try {
            Saf.writeText(ctx.appContext, root.first, path, content, append)
            ToolOutcome("Wrote ${content.length} chars to ${root.second}/$path${if (append) " (appended)" else ""}.", true)
        } catch (t: Throwable) {
            ToolOutcome("storage_write failed: ${t.message}", false)
        }
    }

    // ---------------- runtime MCP ----------------

    private fun execMcpConnect(args: JsonObject): ToolOutcome {
        val url = args.str("url")?.trim() ?: return ToolOutcome("Missing 'url'.", false)
        if (!url.startsWith("http")) return ToolOutcome("URL must start with http(s).", false)
        val name = args.str("name")?.trim().takeUnless { it.isNullOrEmpty() }
            ?: url.removePrefix("https://").removePrefix("http://").substringBefore('/').take(24)
        val bearer = args.str("bearerToken") ?: ""
        val persist = args.str("persist")?.toBoolean() ?: true
        return try {
            val client = McpClient(url, bearer)
            client.initialize()
            val tools = client.listTools()
            if (tools.isEmpty()) return ToolOutcome("Connected to '$name' but it exposes no tools.", true)
            var added = 0
            tools.forEach { t ->
                val toolName = ("mcp_" + name.filter { it.isLetterOrDigit() }.lowercase() +
                    "_" + t.name.filter { it.isLetterOrDigit() }.lowercase()).take(60)
                ctx.dynamicTools += DynamicTool(
                    ToolSpec(toolName, ("[MCP $name] " + t.description).take(900), t.inputSchemaJson),
                    if (t.readOnly) ToolRisk.SAFE else ToolRisk.WRITE
                ) { a ->
                    val r = client.callTool(t.name, a)
                    ToolOutcome(r.text, !r.isError, r.media)
                }
                added++
            }
            if (persist) {
                ctx.stores.mcp.upsert(
                    McpServerConfig(
                        id = "mcp_" + name.filter { it.isLetterOrDigit() }.lowercase().take(20) + "_" + now(),
                        name = name, url = url, bearerToken = bearer, enabled = true
                    )
                )
            }
            ToolOutcome(
                "Connected to MCP server '$name' — $added tools now callable: " +
                    ctx.dynamicTools.takeLast(added).joinToString { it.spec.name }, true
            )
        } catch (t: Throwable) {
            ToolOutcome("mcp_connect failed: ${t.message?.take(300)}", false)
        }
    }

    // ---------------- user profile ----------------

    private fun execProfileUpdate(args: JsonObject): ToolOutcome {
        val facts = args.objOrNull("facts") ?: return ToolOutcome("Missing 'facts' object.", false)
        if (facts.isEmpty()) return ToolOutcome("(empty facts — nothing to save)", true)
        val updates = LinkedHashMap<String, String>()
        facts.forEach { (k, v) ->
            val value = ((v as? JsonPrimitive)?.contentOrNullSafe() ?: v.toString()).take(400)
            if (value.isNotBlank()) updates[k.take(60)] = value
        }
        if (updates.isEmpty()) return ToolOutcome("(no non-empty facts)", true)
        ctx.stores.settings.update { st ->
            val merged = st.profile + updates
            st.copy(
                profile = if (merged.size > 48)
                    merged.entries.drop(merged.size - 48).associate { it.key to it.value }
                else merged
            )
        }
        return ToolOutcome(
            "Profile updated. Now knows:\n" + updates.entries.joinToString("\n") { "  ${it.key}: ${it.value}" }, true
        )
    }

    // ---------------- arg helpers ----------------

    private fun JsonObject.objOrNull(key: String): JsonObject? = this[key] as? JsonObject

    private fun JsonObject.arrOrNull(key: String): kotlinx.serialization.json.JsonArray? =
        this[key] as? kotlinx.serialization.json.JsonArray

    private fun JsonObject.intOrNull(key: String): Int? =
        (this[key] as? JsonPrimitive)?.content?.toIntOrNull()

    private fun JsonObject.longOrNull(key: String): Long? =
        (this[key] as? JsonPrimitive)?.content?.toLongOrNull()

    private fun JsonPrimitive.contentOrNullSafe(): String? =
        if (this === kotlinx.serialization.json.JsonNull) null else this.content

    private fun String.truncateForTool(max: Int): String {
        val s = this
        return if (s.length <= max) s else s.take(max - 80) + "\n…[truncated, ${s.length - max} more chars]"
    }
}
