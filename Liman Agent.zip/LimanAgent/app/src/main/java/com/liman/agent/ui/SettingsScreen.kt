package com.liman.agent.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.liman.agent.LimanApplication
import com.liman.agent.R
import com.liman.agent.agent.McpClient
import com.liman.agent.agent.Saf
import com.liman.agent.agent.buildCombo
import com.liman.agent.agent.isFreeModel
import com.liman.agent.agent.looksVisionCapable
import com.liman.agent.data.AgentSettings
import com.liman.agent.data.ComboMode
import com.liman.agent.data.Entry
import com.liman.agent.data.McpServerConfig
import com.liman.agent.data.ProviderConfig
import com.liman.agent.data.ProviderKind
import com.liman.agent.data.PROVIDER_PRESETS
import com.liman.agent.data.ReviewMode
import com.liman.agent.data.ScheduledTask
import com.liman.agent.agent.TermuxBridge
import com.liman.agent.agent.NineRouter
import com.liman.agent.data.presetById
import com.liman.agent.gateway.TelegramGatewayService
import com.liman.agent.llm.AnthropicProvider
import com.liman.agent.llm.RouterEngine
import com.liman.agent.llm.RouterServer
import com.liman.agent.llm.WebChatProvider
import com.liman.agent.llm.GenSettings
import com.liman.agent.llm.GeminiProvider
import com.liman.agent.llm.LlmMessage
import com.liman.agent.llm.ModelCatalog
import com.liman.agent.llm.LlmRequest
import com.liman.agent.llm.LPart
import com.liman.agent.llm.OpenAiProvider
import com.liman.agent.llm.OpenCodeFreeProvider
import com.liman.agent.llm.ProviderRunner
import com.liman.agent.llm.ProviderStats
import com.liman.agent.llm.Role
import com.liman.agent.util.Str
import com.liman.agent.util.ellipsize
import com.liman.agent.util.genId
import com.liman.agent.util.isPersian
import com.liman.agent.util.now
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val ALL_TOOLS = listOf(
    "list_files", "read_file", "write_file", "append_file", "edit_file", "delete_file",
    "http_request", "web_search", "read_link", "memory_save", "memory_recall", "calculator", "run_js",
    "datetime", "ask_user", "image_generate", "build_apk", "render_html", "use_skill", "search_skills", "install_skill",
    "spawn_subagent", "finish", "storage_list", "storage_read", "storage_write", "mcp_connect", "profile_update"
)

/** Tools with side effects / costs — candidates for the permissions manager. */
private val RISKY_TOOLS = listOf(
    "write_file", "append_file", "edit_file", "delete_file", "http_request", "image_generate",
    "build_apk", "install_skill", "spawn_subagent", "storage_write", "mcp_connect"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = remember { LimanApplication.get(context) }
    val stores = app.container.stores

    val providers by stores.providers.state.collectAsState()
    val combo by stores.combo.state.collectAsState()
    val settings by stores.settings.state.collectAsState()
    val stats by ProviderStats.stats.collectAsState()
    val scope = rememberCoroutineScope()

    var editing by remember { mutableStateOf<ProviderConfig?>(null) }
    var deleteTarget by remember { mutableStateOf<ProviderConfig?>(null) }
    var editingMcp by remember { mutableStateOf<McpServerConfig?>(null) }
    var deleteMcpTarget by remember { mutableStateOf<McpServerConfig?>(null) }
    var editingProfile by remember { mutableStateOf(false) }

    val enabledProviders = providers.filter { it.enabled }

    // language
    val fa = when (settings.language) {
        "fa" -> true
        "en" -> false
        else -> java.util.Locale.getDefault().language == "fa"
    }
    val t = remember(fa) { Str(fa) }

    // notification permission (scheduled missions results, Android 13+)
    val notifLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
    ) { }

    // SAF folder grant launcher
    val treeLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }
            Saf.addRoot(stores, uri)
        }
    }

    androidx.compose.runtime.CompositionLocalProvider(LocalStr provides t) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                ),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        LimanIcon(R.drawable.ic_back, MaterialTheme.colorScheme.onSurface)
                    }
                },
                title = { Text(t.settings) }
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ================= PROVIDERS =================
            item {
                SectionHeader(t.providers, "LLM backends Liman can think with", R.drawable.ic_bot)
                providers.forEach { p ->
                    val stat = stats[p.id]
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            Modifier.padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name.ifBlank { "(unnamed)" }, fontWeight = FontWeight.SemiBold)
                                Text(
                                    "${kindLabel(p.kind)} · ${p.model.ifBlank { "no model" }}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (stat != null) {
                                    Text(
                                        "${stat.calls} calls · ${stat.failures} failed" +
                                            (if (stat.lastLatencyMs > 0) " · last ${stat.lastLatencyMs} ms" else "") +
                                            (if (stat.lastError.isNotBlank()) " · ⚠ ${stat.lastError.take(50)}" else ""),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (stat.failures > 0) MaterialTheme.colorScheme.error
                                        else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Switch(
                                checked = p.enabled,
                                onCheckedChange = { stores.providers.upsert(p.copy(enabled = it)) }
                            )
                            IconButton(onClick = { editing = p }) { Icon(Icons.Filled.Edit, "Edit") }
                            IconButton(onClick = { deleteTarget = p }) {
                                Icon(Icons.Filled.Delete, "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                if (providers.isEmpty()) {
                    Text(
                        "No providers yet. Add Gemini (free API key), OpenRouter, Claude, Groq, " +
                            "a local Ollama, or any OpenAI-compatible endpoint.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.size(4.dp))
                Button(
                    onClick = {
                        editing = ProviderConfig(
                            id = genId("prov"),
                            name = "",
                            presetId = "gemini",
                            kind = ProviderKind.GEMINI,
                            baseUrl = "https://generativelanguage.googleapis.com",
                            model = "gemini-2.5-flash"
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("＋ Add provider") }
            }

            // ================= COMBO =================
            item {
                SectionHeader("Combo", "Chain providers so a failure never stops the agent", R.drawable.ic_bolt)
                if (enabledProviders.isEmpty()) {
                    Text("Add and enable at least one provider first.", style = MaterialTheme.typography.bodySmall)
                } else {
                    val selected = combo.providerIds.mapNotNull { id ->
                        enabledProviders.firstOrNull { it.id == id }
                    }
                    val unselected = enabledProviders.filter { p -> selected.none { it.id == p.id } }

                    ModeChips(combo.mode) { m -> stores.combo.update { it.copy(mode = m) } }
                    Text(
                        when (combo.mode) {
                            ComboMode.FAILOVER -> "Failover — try in order; on failure switch to the next"
                            ComboMode.ROUND_ROBIN -> "Round-robin — rotate the starting provider each request"
                            ComboMode.RACE -> "Race — query all at once, first success wins (uses tokens on all)"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.size(8.dp))
                    if (selected.isEmpty()) {
                        Text(
                            "Combo empty → all enabled providers in list order are used.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    selected.forEachIndexed { i, p ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                            )
                        ) {
                            Row(
                                Modifier.padding(start = 12.dp, end = 2.dp, top = 4.dp, bottom = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${i + 1}.", fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(8.dp))
                                Text(p.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                IconButton(
                                    enabled = i > 0,
                                    onClick = {
                                        stores.combo.update { c ->
                                            val ids = c.providerIds.toMutableList()
                                            if (i > 0 && i < ids.size) {
                                                java.util.Collections.swap(ids, i - 1, i)
                                                c.copy(providerIds = ids)
                                            } else c
                                        }
                                    }
                                ) { Icon(Icons.Filled.KeyboardArrowUp, "Up") }
                                IconButton(
                                    enabled = i < selected.size - 1,
                                    onClick = {
                                        stores.combo.update { c ->
                                            val ids = c.providerIds.toMutableList()
                                            if (i + 1 < ids.size) {
                                                java.util.Collections.swap(ids, i, i + 1)
                                                c.copy(providerIds = ids)
                                            } else c
                                        }
                                    }
                                ) { Icon(Icons.Filled.KeyboardArrowDown, "Down") }
                                IconButton(onClick = {
                                    stores.combo.update { c ->
                                        c.copy(providerIds = c.providerIds - p.id)
                                    }
                                }) { Icon(Icons.Filled.Close, "Remove") }
                            }
                        }
                    }
                    if (unselected.isNotEmpty()) {
                        Text("Add to combo:", style = MaterialTheme.typography.labelMedium)
                        ToolChipFlow(unselected.map { it.name to it.name }) { name ->
                            val p = unselected.firstOrNull { it.name == name } ?: return@ToolChipFlow
                            stores.combo.update { c -> c.copy(providerIds = c.providerIds + p.id) }
                        }
                    }
                    Spacer(Modifier.size(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Retries per provider: ", style = MaterialTheme.typography.bodyMedium)
                        OutlinedButton(onClick = {
                            stores.combo.update { it.copy(retriesPerProvider = (it.retriesPerProvider - 1).coerceAtLeast(1)) }
                        }) { Text("−") }
                        Text(
                            " ${combo.retriesPerProvider} ",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        OutlinedButton(onClick = {
                            stores.combo.update { it.copy(retriesPerProvider = (it.retriesPerProvider + 1).coerceAtMost(5)) }
                        }) { Text("＋") }
                    }
                    Spacer(Modifier.size(6.dp))
                    Text(
                        runCatching { buildCombo(stores, {}) }.getOrNull()?.describe() ?: "",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ================= MCP =================
            item {
                SectionHeader("MCP servers", "Model Context Protocol — plug in external tool servers", R.drawable.ic_mcp_connect)
                val mcpServers by stores.mcp.state.collectAsState()
                mcpServers.forEach { s ->
                    McpServerRow(
                        server = s,
                        onEdit = { editingMcp = s },
                        onDelete = { deleteMcpTarget = s },
                        onToggle = { stores.mcp.upsert(s.copy(enabled = it)) }
                    )
                }
                if (mcpServers.isEmpty()) {
                    Text(
                        "Connect any MCP server with an HTTP endpoint and its tools become " +
                            "first-class Liman tools (mcp_server_tool). Remote servers do the work; " +
                            "Liman decides when to call them.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.size(4.dp))
                Button(
                    onClick = {
                        editingMcp = McpServerConfig(id = genId("mcp"), name = "", url = "")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("＋ Add MCP server") }
            }

            // ================= TERMUX BRIDGE =================
            item {
                SectionHeader("🐚 Termux bridge", "Run REAL node/npm/python/git commands in your Termux, driven by Liman", null)
                val installed = TermuxBridge.termuxInstalled(context)
                val granted = TermuxBridge.permissionGranted(context)
                val termuxPermLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                    androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
                ) { }
                Text(
                    buildString {
                        appendLine(if (installed) "✅ Termux installed" else "❌ Termux not installed (get it from F-Droid)")
                        appendLine(if (granted) "✅ RUN_COMMAND permission granted" else "❌ RUN_COMMAND permission missing")
                        append("ℹ️ Router transport: Settings → Local router must be ON")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(6.dp))
                if (installed && !granted) {
                    Button(onClick = {
                        runCatching { termuxPermLauncher.launch(TermuxBridge.RUN_COMMAND_PERMISSION) }
                    }) { Text("Grant permission") }
                    Spacer(Modifier.size(6.dp))
                }
                Text(
                    "One-time setup in Termux:\n" +
                        "pkg install curl\n" +
                        "mkdir -p ~/.termux && echo \"allow-external-apps = true\" >> ~/.termux/termux.properties && termux-reload-settings\n" +
                        "Then ask Liman anything that needs real npm/node/python — it will call termux_run.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // ================= SCHEDULED MISSIONS =================
            item {
                SectionHeader("⏰ Scheduled missions", "Cron for your agent — briefings, watchtowers, self-checks, any recurring job", null)

                // v2.31 — RELIABILITY: Doze kills periodic work on many phones;
                // the exemption is what makes cron actually cron.
                runCatching {
                    val pm = context.getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
                    val exempt = pm.isIgnoringBatteryOptimizations(context.packageName)
                    if (!exempt) {
                        Text(
                            "⚠️ Battery optimization is ON for Liman — Android may delay or kill scheduled missions. " +
                                "Exempt Liman once and cron runs on time (it only affects scheduling, not battery use).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.size(6.dp))
                        Button(onClick = {
                            runCatching {
                                context.startActivity(android.content.Intent(
                                    android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                    android.net.Uri.parse("package:" + context.packageName)
                                ))
                            }.onFailure {
                                runCatching {
                                    context.startActivity(android.content.Intent(
                                        android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS
                                    ))
                                }
                            }
                        }) { Text("⚡ Exempt Liman from battery optimization") }
                        Spacer(Modifier.size(8.dp))
                    }
                }

                val schedule by stores.schedule.state.collectAsState()
                var editingTask by remember { mutableStateOf<ScheduledTask?>(null) }

                schedule.forEach { task ->
                    val scheduleText = if (task.everyHours > 0) "every ${task.everyHours}h"
                                       else "daily ${task.dailyAt}"
                    SettingSwitch(
                        "${task.title}  ·  $scheduleText",
                        task.prompt.ellipsize(90),
                        task.enabled
                    ) { v -> stores.schedule.upsert(task.copy(enabled = v)) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { editingTask = task }) { Text("Edit") }
                        TextButton(onClick = { stores.schedule.delete(task.id) }) { Text("Delete") }
                    }
                }
                Button(
                    onClick = {
                        // notifications carry the results on Android 13+
                        if (android.os.Build.VERSION.SDK_INT >= 33) {
                            runCatching {
                                context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                            }.getOrNull()?.takeIf { it != android.content.pm.PackageManager.PERMISSION_GRANTED }?.let {
                                notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }
                        editingTask = ScheduledTask(id = com.liman.agent.util.genId("cron"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("＋ Add scheduled mission") }

                editingTask?.let { task ->
                    var title by remember(task.id) { mutableStateOf(task.title) }
                    var prompt by remember(task.id) { mutableStateOf(task.prompt) }
                    var dailyAt by remember(task.id) { mutableStateOf(task.dailyAt) }
                    var everyHours by remember(task.id) { mutableStateOf(if (task.everyHours > 0) task.everyHours.toString() else "") }
                    AlertDialog(
                        onDismissRequest = { editingTask = null },
                        title = { Text("Scheduled mission") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true)
                                OutlinedTextField(value = prompt, onValueChange = { prompt = it }, label = { Text("Prompt (a full agent mission)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                                OutlinedTextField(value = dailyAt, onValueChange = { dailyAt = it }, label = { Text("Daily at (HH:MM)") }, singleLine = true)
                                OutlinedTextField(value = everyHours, onValueChange = { everyHours = it }, label = { Text("…or every N hours (blank = daily mode)") }, singleLine = true)
                                Text(
                                    "Runs even with the app closed (WorkManager). Examples: daily 08:00 briefing · every 2h watch a page for changes and notify · weekly self-check of all providers.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                if (prompt.isNotBlank()) {
                                    val hours = everyHours.trim().toIntOrNull()?.coerceIn(1, 168) ?: 0
                                    stores.schedule.upsert(
                                        task.copy(
                                            title = title.ifBlank { "Mission" },
                                            prompt = prompt,
                                            dailyAt = if (hours > 0) task.dailyAt else dailyAt.ifBlank { "08:00" },
                                            everyHours = hours,
                                            enabled = true
                                        )
                                    )
                                }
                                editingTask = null
                            }) { Text("Save") }
                        },
                        dismissButton = { TextButton(onClick = { editingTask = null }) { Text("Cancel") } }
                    )
                }
            }

            // ================= TELEGRAM =================
            item {
                SectionHeader("Telegram gateway", "Run Liman as your private Telegram bot", R.drawable.ic_send)
                val telegram by stores.telegram.state.collectAsState()
                var tgBusy by remember { mutableStateOf(false) }
                OutlinedTextField(
                    value = telegram.botToken,
                    onValueChange = { t -> stores.telegram.update { it.botToken = t } },
                    label = { Text("Bot token (from @BotFather)") },
                    placeholder = { Text("123456:ABC-DEF…") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.size(6.dp))
                SettingSwitch(
                    "Gateway enabled",
                    "Runs a foreground service — message your bot from anywhere",
                    telegram.enabled
                ) { v ->
                    if (v && telegram.botToken.isBlank()) {
                        // need a token first
                    } else {
                        stores.telegram.update { it.enabled = v }
                        if (v) TelegramGatewayService.start(context)
                        else TelegramGatewayService.stop(context)
                    }
                }
                SettingSwitch(
                    "Auto-approve remote tools",
                    "Allow file writes / HTTP / costs from Telegram without confirmation",
                    telegram.autoApproveRemote
                ) { v -> stores.telegram.update { it.autoApproveRemote = v } }
                Spacer(Modifier.size(6.dp))
                Text("Pairing", style = MaterialTheme.typography.titleSmall)
                Text(
                    "To link a chat, send this code to your bot in Telegram:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "/start ${telegram.pairingCode}",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                if (telegram.allowedChatIds.isNotEmpty()) {
                    Text(
                        "Paired chats: ${telegram.allowedChatIds.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    TextButton(onClick = {
                        stores.telegram.update { it.allowedChatIds = emptyList() }
                    }) { Text("Unpair all chats") }
                }
            }

            // ================= AGENT =================
            item {
                SectionHeader("Agent behavior", "The cycle engine", R.drawable.ic_bot)
                SettingSwitch("Stream responses", "Live token streaming (disable for picky endpoints)", settings.streaming) { v ->
                    stores.settings.update { it.streaming = v }
                }
                SettingSwitch("Smart compaction", "Summarize old context when the budget is exceeded", settings.smartCompaction) { v ->
                    stores.settings.update { it.smartCompaction = v }
                }
                SettingSwitch("Speak answers (TTS)", "Read final answers aloud", settings.ttsEnabled) { v ->
                    stores.settings.update { it.ttsEnabled = v }
                }
                SettingSwitch("Auto-load skills", "A router picks relevant installed skills for every prompt", settings.skillsAutoLoad) { v ->
                    stores.settings.update { it.skillsAutoLoad = v }
                }
                SettingSwitch("Subagents", "Let the agent spawn parallel sub-agents for big projects", settings.subagentsEnabled) { v ->
                    stores.settings.update { it.subagentsEnabled = v }
                }
                Spacer(Modifier.size(8.dp))

                Text("Creativity engine", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "STANDARD" to "Standard",
                        "BALANCED" to "Balanced",
                        "CREATIVE" to "Creative",
                        "GENIUS" to "Genius"
                    ).forEach { (level, label) ->
                        FilterChip(
                            selected = settings.creativity == level,
                            onClick = { stores.settings.update { it.creativity = level } },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }
                Text(
                    when (settings.creativity) {
                        "CREATIVE" -> "Generates several approaches, picks the most promising, questions assumptions."
                        "GENIUS" -> "First-principles decomposition, inversion (‘how would this fail?’), cross-domain analogies, and per-cycle self-challenge."
                        "STANDARD" -> "Direct, practical, no extra flourishes."
                        else -> "Practical, with a fresh angle when the task benefits from one."
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(10.dp))

                Text("Self-review after finishing", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = settings.reviewMode == ReviewMode.OFF,
                        onClick = { stores.settings.update { it.reviewMode = ReviewMode.OFF } },
                        label = { Text("Off") }
                    )
                    FilterChip(
                        selected = settings.reviewMode == ReviewMode.REPORT,
                        onClick = { stores.settings.update { it.reviewMode = ReviewMode.REPORT } },
                        label = { Text("Report") }
                    )
                    FilterChip(
                        selected = settings.reviewMode == ReviewMode.ITERATE,
                        onClick = { stores.settings.update { it.reviewMode = ReviewMode.ITERATE } },
                        label = { Text("Report + iterate") }
                    )
                }
                Text(
                    "Report: the reviewer scores the work and lists issues. " +
                        "Iterate: an incomplete verdict sends the agent back to fix them.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(10.dp))

                Text("Max cycles: ${settings.maxCycles}", style = MaterialTheme.typography.titleSmall)
                androidx.compose.material3.Slider(
                    value = settings.maxCycles.toFloat(),
                    onValueChange = { stores.settings.update { s -> s.maxCycles = it.toInt().coerceIn(1, 50) } },
                    valueRange = 1f..50f
                )
                Spacer(Modifier.size(6.dp))
                NumberField("Max output tokens", settings.maxOutputTokens) { v ->
                    stores.settings.update { it.maxOutputTokens = v.coerceIn(256, 64_000) }
                }
                NumberField("Context budget (tokens, ~4 chars each)", settings.contextBudgetTokens) { v ->
                    stores.settings.update { it.contextBudgetTokens = v.coerceIn(2_000, 1_000_000) }
                }
                NumberField("Run token ceiling (0 = off)", settings.runTokenCeiling) { v ->
                    stores.settings.update { it.runTokenCeiling = v.coerceIn(0, 5_000_000) }
                }
                Spacer(Modifier.size(10.dp))

                Text("Tool approval", style = MaterialTheme.typography.titleSmall)
                SettingSwitch(
                    "Auto-approve everything (YOLO)",
                    "Skip confirmation dialogs for file writes, HTTP and image generation",
                    settings.autoApproveTools
                ) { v -> stores.settings.update { it.autoApproveTools = v } }
                Text(
                    "Always allowed without asking:",
                    style = MaterialTheme.typography.labelMedium
                )
                ToolChipFlow(
                    ALL_TOOLS.map { tl -> (tl) to tl },
                    iconFor = { toolIconRes(it) }
                ) { t ->
                    stores.settings.update { s ->
                        s.alwaysAllowTools =
                            if (s.alwaysAllowTools.contains(t)) s.alwaysAllowTools - t
                            else s.alwaysAllowTools + t
                    }
                }
                Spacer(Modifier.size(10.dp))
                Text("Image generation models", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = settings.imageModelGemini,
                    onValueChange = { stores.settings.update { s -> s.imageModelGemini = it } },
                    label = { Text("Gemini image model") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = settings.imageModelOpenAi,
                    onValueChange = { stores.settings.update { s -> s.imageModelOpenAi = it } },
                    label = { Text("OpenAI-compatible image model") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.size(10.dp))
                OutlinedTextField(
                    value = settings.systemPromptExtra,
                    onValueChange = { stores.settings.update { s -> s.systemPromptExtra = it } },
                    label = { Text("Extra system prompt (persona, rules…)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
            }

            // ================= LANGUAGE =================
            item {
                SectionHeader(t.language, "App language / زبان برنامه", R.drawable.ic_translate)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        "system" to t.langSystem, "en" to t.english, "fa" to t.persian
                    ).forEach { (v, label) ->
                        FilterChip(
                            selected = settings.language == v,
                            onClick = { stores.settings.update { it.language = v } },
                            label = { Text(label) }
                        )
                    }
                }
                Text(
                    "فارسی: پیام‌ها و پاسخ‌های فارسی راست‌چین و با فونت وزیرمتن نمایش داده می‌شوند.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // ================= PERMISSIONS =================
            item {
                SectionHeader(t.permissions, t.permissionsDesc, R.drawable.ic_shield)
                RISKY_TOOLS.forEach { tool ->
                    val policy = settings.toolPolicies[tool] ?: "ask"
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                    ) {
                        LimanIcon(toolIconRes(tool), MaterialTheme.colorScheme.primary, size = 17)
                        Spacer(Modifier.width(10.dp))
                        Text(tool, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(
                                "allow" to t.allowAlways, "ask" to t.askEveryTime, "deny" to t.alwaysDeny
                            ).forEach { (v, label) ->
                                FilterChip(
                                    selected = policy == v,
                                    onClick = {
                                        stores.settings.update { st ->
                                            st.copy(
                                                toolPolicies = if (v == "ask") st.toolPolicies - tool
                                                else st.toolPolicies + (tool to v)
                                            )
                                        }
                                    },
                                    label = { Text(label, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // ================= STORAGE ACCESS =================
            item {
                SectionHeader(t.storageAccess, t.storageDesc, R.drawable.ic_storage_list)
                var rootLabels by remember { mutableStateOf<List<Pair<android.net.Uri, String>>>(emptyList()) }
                LaunchedEffect(settings.storageRoots) {
                    rootLabels = withContext(Dispatchers.IO) { Saf.describeRoots(context, stores) }
                }
                val roots = rootLabels
                roots.forEach { (uri, label) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Row(
                            Modifier.padding(start = 14.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LimanIcon(R.drawable.ic_folder, MaterialTheme.colorScheme.primary, size = 18)
                            Spacer(Modifier.width(10.dp))
                            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            TextButton(onClick = { Saf.removeRoot(stores, uri) }) { Text(t.revoke) }
                        }
                    }
                }
                if (roots.isEmpty()) {
                    Text(
                        t.noRoots,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.size(4.dp))
                Button(onClick = { treeLauncher.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                    LimanIcon(R.drawable.ic_folder, MaterialTheme.colorScheme.onPrimary, size = 17)
                    Spacer(Modifier.width(8.dp))
                    Text(t.grantFolder)
                }
                Text(
                    "The agent can then list, read and edit files in the granted folders only (storage_list / storage_read / storage_write tools).",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // ================= USER PROFILE =================
            item {
                SectionHeader(t.userProfile, t.profileDesc, R.drawable.ic_person)
                if (settings.profile.isEmpty()) {
                    Text(
                        t.profileEmpty,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    settings.profile.entries.take(10).forEach { (k, v) ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                            LimanIcon(R.drawable.ic_check, MaterialTheme.colorScheme.primary, size = 13)
                            Spacer(Modifier.width(8.dp))
                            Text("$k: ", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            DirectionalText(v, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    if (settings.profile.size > 10) {
                        Text("… +${settings.profile.size - 10} more", style = MaterialTheme.typography.labelSmall)
                    }
                    TextButton(onClick = { editingProfile = true }) { Text(t.edit) }
                }
            }

            // ================= LOCAL ROUTER (9Router-compatible) =================
            item {
                SectionHeader(
                    "Local router (mini)",
                    "Liman's built-in mini-router on port 20129 — free models, no server needed. Your REAL 9Router (combos, 40+ providers) connects as the '9Router (my server · combos)' provider above",
                    R.drawable.ic_bot
                )
                val routerRunning = remember { mutableStateOf(RouterServer.state.running) }
                LaunchedEffect(Unit) { routerRunning.value = RouterServer.state.running }

                SettingSwitch(
                    "Run router on this phone",
                    "OpenAI-compatible endpoint at http://127.0.0.1:${settings.routerPort}/v1 — " +
                        "free routes first (web chats, :free pools, Gemini free key), auto-fallback, RTK token saver. " +
                        "Any app or CLI on the device can use it; Liman can use it as a provider.",
                    routerRunning.value
                ) { v ->
                    if (v) RouterServer.start(stores, settings.routerPort, settings.routerLan)
                    else RouterServer.stop()
                    routerRunning.value = v
                    stores.settings.update { it.routerEnabled = v }
                }
                NumberField("Port", settings.routerPort) { v ->
                    stores.settings.update { it.routerPort = v.coerceIn(1024, 65535) }
                }
                SettingSwitch(
                    "Start automatically with the app",
                    "The router boots whenever Liman opens (when enabled above)",
                    settings.routerEnabled
                ) { v -> stores.settings.update { it.routerEnabled = v } }
                SettingSwitch(
                    "Expose on the LAN (0.0.0.0)",
                    "Other devices on your Wi-Fi can use http://<your-ip>:${settings.routerPort}/v1 — only on trusted networks",
                    settings.routerLan
                ) { v -> stores.settings.update { it.routerLan = v } }
                Spacer(Modifier.size(6.dp))
                val ctx = LocalContext.current
                Button(
                    onClick = {
                        // the dashboard means "I want the router" — boot it if needed
                        if (!RouterServer.state.running) {
                            RouterServer.start(stores, settings.routerPort, settings.routerLan)
                            stores.settings.update { it.routerEnabled = true }
                            routerRunning.value = RouterServer.state.running
                        }
                        runCatching {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("http://127.0.0.1:${settings.routerPort}/"))
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    LimanIcon(R.drawable.ic_http_request, MaterialTheme.colorScheme.onPrimary, size = 17)
                    Spacer(Modifier.width(8.dp))
                    Text("Open 9Router dashboard in browser")
                }
                Text(
                    "Dashboard link: http://127.0.0.1:${settings.routerPort}/ — providers, API keys, endpoints, test routes, live log",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (routerRunning.value) {
                    Spacer(Modifier.size(4.dp))
                    val models = remember(providers) { RouterEngine(stores).modelNames() }
                    Text(
                        "● Running — http://127.0.0.1:${settings.routerPort}/v1 · ${models.size} routes: " +
                            models.take(12).joinToString(", ") + if (models.size > 12) " …" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        "Special models: auto (all routes, free-first) · free (free routes only) · any exact model name",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        "Turn it on to serve free models to any OpenAI-compatible tool on this phone — no server, no key.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.size(4.dp))
                Button(onClick = {
                    stores.providers.upsert(
                        ProviderConfig(
                            id = genId("prov"),
                            name = "Liman Router",
                            presetId = "limanrouter",
                            kind = ProviderKind.OPENAI_COMPATIBLE,
                            baseUrl = "http://127.0.0.1:${settings.routerPort}/v1",
                            apiKey = "local",
                            model = "auto",
                            enabled = true
                        )
                    )
                }, modifier = Modifier.fillMaxWidth()) {
                    LimanIcon(R.drawable.ic_bolt, MaterialTheme.colorScheme.onPrimary, size = 17)
                    Spacer(Modifier.width(8.dp))
                    Text("Add router as Liman provider")
                }
            }

            // ================= ABOUT =================
            item {
                SectionHeader("About Liman", "", R.drawable.ic_anchor)
                Text(
                    "Liman Agent 1.0 — an autonomous agent for Android.\n\n" +
                        "Cycle: ORIENT → PLAN → [THINK → ACT → OBSERVE] → VERIFY → FINISH\n\n" +
                        "It reads files (PDF/Word/Excel/HTML/images/video…), browses, searches, computes, " +
                        "writes files, generates images, remembers across chats, asks you questions, " +
                        "reviews its own work, and fails over between providers mid-task.\n\n" +
                        "All tools are sandboxed to the app workspace. API keys stay on your device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    editing?.let { cfg ->
        ProviderEditorDialog(
            initial = cfg,
            onSave = { stores.providers.upsert(it); editing = null },
            onDismiss = { editing = null }
        )
    }

    deleteTarget?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete provider?") },
            text = { Text("“${p.name}” will be removed from the combo as well.") },
            confirmButton = {
                TextButton(onClick = {
                    stores.providers.delete(p.id)
                    stores.combo.update { it.copy(providerIds = it.providerIds - p.id) }
                    deleteTarget = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }

    editingMcp?.let { m ->
        McpEditorDialog(
            initial = m,
            onSave = { stores.mcp.upsert(it); editingMcp = null },
            onDismiss = { editingMcp = null }
        )
    }

    deleteMcpTarget?.let { m ->
        AlertDialog(
            onDismissRequest = { deleteMcpTarget = null },
            title = { Text("Delete MCP server?") },
            text = { Text("“${m.name}” and its tools will be disconnected.") },
            confirmButton = {
                TextButton(onClick = {
                    stores.mcp.delete(m.id)
                    deleteMcpTarget = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteMcpTarget = null }) { Text("Cancel") } }
        )
    }

    // ---------- profile editor ----------
    if (editingProfile) {
        ProfileEditorDialog(
            profile = settings.profile,
            onSave = { newProfile ->
                stores.settings.update { it.copy(profile = newProfile) }
                editingProfile = false
            },
            onDismiss = { editingProfile = false }
        )
    }
    }
}

@Composable
private fun ProfileEditorDialog(
    profile: Map<String, String>,
    onSave: (Map<String, String>) -> Unit,
    onDismiss: () -> Unit
) {
    var items by remember { mutableStateOf(profile.entries.map { it.key to it.value }.toMutableList()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("User profile") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                items.forEachIndexed { i, (k, v) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = k,
                            onValueChange = { nk -> items[i] = nk.take(60) to items[i].second },
                            label = { Text("key") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(Modifier.width(6.dp))
                        OutlinedTextField(
                            value = v,
                            onValueChange = { nv -> items[i] = items[i].first to nv.take(400) },
                            label = { Text("value") },
                            modifier = Modifier.weight(1.4f),
                            singleLine = true
                        )
                        IconButton(onClick = { items.removeAt(i) }) {
                            Icon(Icons.Filled.Close, "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Spacer(Modifier.size(6.dp))
                TextButton(onClick = { items.add("" to "") }) { Text("＋ Add fact") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(items.filter { it.first.isNotBlank() && it.second.isNotBlank() }.toMap())
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ============================================================
// pieces
// ============================================================

private fun kindLabel(kind: ProviderKind): String = when (kind) {
    ProviderKind.GEMINI -> "Gemini · key only"
    ProviderKind.ANTHROPIC -> "Claude · key only"
    ProviderKind.OPENAI_COMPATIBLE -> "OpenAI-compatible"
    ProviderKind.WEB_CHAT -> "Web chat · no API key"
    ProviderKind.OPENCODE_FREE -> "OpenCode Free · no key, no account"
}

@Composable
private fun SectionHeader(title: String, subtitle: String, icon: Int? = null) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                LimanIcon(icon, MaterialTheme.colorScheme.primary, size = 19)
                Spacer(Modifier.width(8.dp))
            }
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
        if (subtitle.isNotBlank()) {
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.size(6.dp))
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun NumberField(label: String, value: Int, onChange: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { t ->
            text = t.filter { it.isDigit() }.take(7)
            text.toIntOrNull()?.let(onChange)
        },
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ToolChipFlow(
    items: List<Pair<String, String>>,
    iconFor: ((String) -> Int)? = null,
    onClick: (String) -> Unit
) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { (label, id) ->
            FilterChip(
                selected = false,
                onClick = { onClick(id) },
                label = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (iconFor != null) {
                            LimanIcon(iconFor(id), MaterialTheme.colorScheme.onSurfaceVariant, size = 13)
                            Spacer(Modifier.width(4.dp))
                        }
                        Text(label, fontSize = 11.sp)
                    }
                }
            )
        }
    }
}

@Composable
private fun ModeChips(current: ComboMode, onSelect: (ComboMode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(
            ComboMode.FAILOVER to "Failover",
            ComboMode.ROUND_ROBIN to "Round-robin",
            ComboMode.RACE to "Race"
        ).forEach { (mode, label) ->
            FilterChip(selected = current == mode, onClick = { onSelect(mode) }, label = { Text(label) })
        }
    }
}

// ============================================================
// MCP server row + editor
// ============================================================

@Composable
private fun McpServerRow(
    server: McpServerConfig,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        )
    ) {
        Row(
            Modifier.padding(start = 14.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(server.name.ifBlank { "(unnamed)" }, fontWeight = FontWeight.SemiBold)
                Text(
                    server.url.take(60),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Switch(checked = server.enabled, onCheckedChange = onToggle)
            IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, "Edit") }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, "Delete", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun McpEditorDialog(
    initial: McpServerConfig,
    onSave: (McpServerConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var cfg by remember { mutableStateOf(initial) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("MCP server") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = cfg.name,
                    onValueChange = { cfg = cfg.copy(name = it) },
                    label = { Text("Name (e.g. filesystem, search)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.size(8.dp))
                OutlinedTextField(
                    value = cfg.url,
                    onValueChange = { cfg = cfg.copy(url = it) },
                    label = { Text("HTTP endpoint URL (…/mcp or /sse)") },
                    placeholder = { Text("https://example.com/mcp") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.size(8.dp))
                OutlinedTextField(
                    value = cfg.bearerToken,
                    onValueChange = { cfg = cfg.copy(bearerToken = it) },
                    label = { Text("Bearer token (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.size(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Enabled", Modifier.weight(1f))
                    Switch(checked = cfg.enabled, onCheckedChange = { cfg = cfg.copy(enabled = it) })
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = !testing && cfg.url.isNotBlank(),
                        onClick = {
                            testing = true
                            testMsg = null
                            scope.launch(Dispatchers.IO) {
                                val res = runCatching {
                                    val client = McpClient(cfg.url.trim(), cfg.bearerToken.trim())
                                    client.initialize()
                                    client.listTools()
                                }
                                withContext(Dispatchers.Main) {
                                    testing = false
                                    testMsg = res.fold(
                                        onSuccess = { tools ->
                                            "✓ Connected — ${tools.size} tools: " +
                                                tools.joinToString(", ") { it.name }.take(200)
                                        },
                                        onFailure = { "✗ ${it.message?.take(200) ?: it.javaClass.simpleName}" }
                                    )
                                }
                            }
                        }
                    ) { Text(if (testing) "Testing…" else "Test connection") }
                    Spacer(Modifier.weight(1f))
                    Button(
                        onClick = {
                            onSave(cfg.copy(name = cfg.name.ifBlank { "MCP server" }, url = cfg.url.trim()))
                        }
                    ) { Text("Save") }
                }
                testMsg?.let {
                    Spacer(Modifier.size(8.dp))
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (it.startsWith("✓")) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ============================================================
// Provider editor
// ============================================================

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun ProviderEditorDialog(
    initial: ProviderConfig,
    onSave: (ProviderConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var cfg by remember { mutableStateOf(initial) }
    var testMsg by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val preset = presetById(cfg.presetId)
    var modelPicker by remember { mutableStateOf<List<String>?>(null) }
    var comboIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var catalogMsg by remember { mutableStateOf<String?>(null) }
    var loadingModels by remember { mutableStateOf(false) }
    var modelQuery by remember { mutableStateOf("") }
    var showLogin by remember { mutableStateOf(false) }
    var showSelectors by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        androidx.compose.material3.Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Provider setup", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Close") }
                }
                Spacer(Modifier.size(10.dp))

                Text("Preset", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PROVIDER_PRESETS.forEach { p ->
                        FilterChip(
                            selected = cfg.presetId == p.id,
                            onClick = {
                                cfg = cfg.copy(
                                    presetId = p.id,
                                    kind = p.kind,
                                    baseUrl = p.baseUrl,
                                    model = p.defaultModel
                                )
                                testMsg = null
                            },
                            label = { Text(p.title, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        )
                    }
                }
                Text(
                    preset.keyHint,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.size(10.dp))

                OutlinedTextField(
                    value = cfg.name,
                    onValueChange = { cfg = cfg.copy(name = it) },
                    label = { Text("Display name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.size(8.dp))

                OutlinedTextField(
                    value = cfg.apiKey,
                    onValueChange = { cfg = cfg.copy(apiKey = it) },
                    label = { Text(if (preset.needsKey) "API key" else "API key (optional)") },
                    placeholder = { Text(if (preset.needsKey) preset.keyHint else "leave empty for local") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.size(8.dp))

                OutlinedTextField(
                    value = cfg.baseUrl,
                    onValueChange = { cfg = cfg.copy(baseUrl = it) },
                    label = {
                        Text(
                            when (cfg.kind) {
                                ProviderKind.OPENAI_COMPATIBLE -> "Base URL (…/v1)"
                                ProviderKind.WEB_CHAT -> "Website URL (the chat page, e.g. https://chatgpt.com)"
                                else -> "Endpoint (advanced, optional)"
                            }
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                if (cfg.presetId == NineRouter.PRESET_ID) {
                    Spacer(Modifier.size(8.dp))
                    val ctx9 = LocalContext.current
                    Button(
                        onClick = { NineRouter.openDashboard(ctx9, cfg.baseUrl) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LimanIcon(R.drawable.ic_open, MaterialTheme.colorScheme.onPrimary, size = 17)
                        Spacer(Modifier.width(8.dp))
                        Text("Open 9Router dashboard in Chrome")
                    }
                    Spacer(Modifier.size(4.dp))
                    Text(
                        "Your 9Router server — manage providers, API keys and combos in the dashboard. Combos (fusion / fallback / round-robin) are fetched below and used as the model.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (cfg.kind == ProviderKind.OPENCODE_FREE) {
                    Spacer(Modifier.size(6.dp))
                    Text(
                        "Free anonymous tier — no API key, no account, nothing to paste. " +
                            "Muse free models answer directly; the list self-updates via the " +
                            "Free Catalog (auto-sync). Shared public pool: busy moments " +
                            "are retried automatically with backoff.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (cfg.kind == ProviderKind.WEB_CHAT) {
                    Spacer(Modifier.size(6.dp))
                    Text(
                        "Web chat mode: Liman drives this site's own chat in a real browser session — " +
                            "no API key. Log in once below (cookies are remembered). " +
                            "The site's model answers; no tool calling, no images.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.size(6.dp))
                    Button(onClick = { showLogin = true }, modifier = Modifier.fillMaxWidth()) {
                        LimanIcon(R.drawable.ic_open, MaterialTheme.colorScheme.onPrimary, size = 17)
                        Spacer(Modifier.width(8.dp))
                        Text("Open & log in")
                    }
                    Spacer(Modifier.size(4.dp))
                    TextButton(onClick = { showSelectors = !showSelectors }) {
                        Text(if (showSelectors) "Hide site selectors" else "Site selectors (if automation misses)")
                    }
                    if (showSelectors) {
                        OutlinedTextField(
                            value = cfg.webInputSel,
                            onValueChange = { cfg = cfg.copy(webInputSel = it) },
                            label = { Text("Input CSS selector (optional)") },
                            placeholder = { Text("e.g. #prompt-textarea") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Spacer(Modifier.size(6.dp))
                        OutlinedTextField(
                            value = cfg.webSendSel,
                            onValueChange = { cfg = cfg.copy(webSendSel = it) },
                            label = { Text("Send button CSS selector (optional)") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        Spacer(Modifier.size(6.dp))
                        OutlinedTextField(
                            value = cfg.webResponseSel,
                            onValueChange = { cfg = cfg.copy(webResponseSel = it) },
                            label = { Text("Answer element CSS selector (optional)") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                    }
                }
                Spacer(Modifier.size(8.dp))

                OutlinedTextField(
                    value = cfg.model,
                    onValueChange = { cfg = cfg.copy(model = it) },
                    label = { Text("Model name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                if (preset.models.isNotEmpty()) {
                    Text("Suggestions:", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        preset.models.forEach { m ->
                            FilterChip(
                                selected = cfg.model == m,
                                onClick = { cfg = cfg.copy(model = m) },
                                label = { Text(m, fontSize = 11.sp) }
                            )
                        }
                    }
                }
                Spacer(Modifier.size(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Enabled", Modifier.weight(1f))
                    Switch(checked = cfg.enabled, onCheckedChange = { cfg = cfg.copy(enabled = it) })
                }
                Spacer(Modifier.size(6.dp))

                Spacer(Modifier.size(6.dp))
                val nine = cfg.presetId == NineRouter.PRESET_ID
                OutlinedButton(
                    enabled = !loadingModels,
                    onClick = {
                        loadingModels = true
                        catalogMsg = null
                        scope.launch(Dispatchers.IO) {
                            if (nine) {
                                // 9Router: fetch COMBOS (owned_by "combo" in /v1/models) + models
                                val t0 = System.currentTimeMillis()
                                val outcome = runCatching {
                                    NineRouter.fetchCatalog(cfg.baseUrl, cfg.apiKey)
                                }
                                withContext(Dispatchers.Main) {
                                    loadingModels = false
                                    outcome.onSuccess { cat ->
                                        comboIds = cat.combos.toSet()
                                        catalogMsg = if (cat.combos.isEmpty() && cat.models.isEmpty())
                                            "✗ Connected, but the server listed no combos/models — check the key or connect providers in the dashboard"
                                        else
                                            "✓ ${cat.combos.size} combos + ${cat.models.size} models (${System.currentTimeMillis() - t0} ms) — combos first, tap one to use it"
                                        modelPicker = cat.all()
                                        if (cfg.model.isBlank() && cat.combos.isNotEmpty()) {
                                            cfg = cfg.copy(model = cat.combos.first())
                                        }
                                    }.onFailure { t ->
                                        catalogMsg = "✗ ${t.message ?: t.javaClass.simpleName}"
                                        modelPicker = null
                                    }
                                }
                            } else {
                                val result = ModelCatalog.fetchModels(cfg)
                                withContext(Dispatchers.Main) {
                                    loadingModels = false
                                    when (result) {
                                        is ModelCatalog.CatalogResult.Ok -> {
                                            comboIds = emptySet()
                                            catalogMsg = "✓ ${result.models.size} models available (${result.ms} ms) — pick one below"
                                            modelPicker = result.models
                                            // remember the free ones for the free-combo option
                                            val free = result.models.filter { isFreeModel(it) }
                                            if (free.isNotEmpty()) cfg = cfg.copy(freeModels = free)
                                        }

                                        is ModelCatalog.CatalogResult.Fail -> {
                                            catalogMsg = "✗ ${result.error}"
                                            modelPicker = null
                                        }
                                    }
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        when {
                            loadingModels && nine -> "Checking key & fetching combos…"
                            loadingModels -> "Checking key & loading models…"
                            nine -> "🔎 Check key & fetch my combos"
                            else -> "🔎 Check key & list available models"
                        }
                    )
                }
                catalogMsg?.let {
                    Spacer(Modifier.size(6.dp))
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (it.startsWith("✓")) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error
                    )
                }
                modelPicker?.let { modelsRaw ->
                    Spacer(Modifier.size(6.dp))
                    val models = remember(modelsRaw, modelQuery) {
                        if (modelQuery.isBlank()) modelsRaw
                        else modelsRaw.filter { it.contains(modelQuery.trim(), ignoreCase = true) }
                    }
                    val freeCount = modelsRaw.count { isFreeModel(it) }
                    Text(
                        if (comboIds.isNotEmpty()) "Live list (${models.size}/${modelsRaw.size}) — ⚡ combos first, tap to use:"
                        else "Live model list (${models.size}/${modelsRaw.size}) — tap to use:",
                        style = MaterialTheme.typography.labelMedium
                    )
                    Spacer(Modifier.size(4.dp))
                    OutlinedTextField(
                        value = modelQuery,
                        onValueChange = { modelQuery = it },
                        label = { Text("Search models…") },
                        placeholder = { Text("e.g. free, vision, flash") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    if (freeCount > 0) {
                        Spacer(Modifier.size(6.dp))
                        SettingSwitch(
                            "Use all free models (auto combo)",
                            "Failover across all $freeCount free models of this provider — zero cost",
                            cfg.useFreePool
                        ) { v -> cfg = cfg.copy(useFreePool = v) }
                    }
                    Spacer(Modifier.size(4.dp))
                    LazyColumn(Modifier.heightIn(max = 260.dp)) {
                        items(models.size) { i ->
                            val m = models[i]
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { cfg = cfg.copy(model = m) }
                                    .padding(vertical = 7.dp, horizontal = 4.dp)
                            ) {
                                if (m in comboIds) {
                                    Text(
                                        "⚡ combo",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(end = 6.dp)
                                    )
                                }
                                Text(
                                    m,
                                    fontSize = 13.sp,
                                    fontWeight = if (m == cfg.model) FontWeight.Bold else FontWeight.Normal,
                                    color = if (m == cfg.model) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (isFreeModel(m)) {
                                    Badge("FREE", com.liman.agent.ui.theme.LimanExtras.Free)
                                    Spacer(Modifier.width(4.dp))
                                }
                                if (looksVisionCapable(m)) {
                                    Badge("VISION", com.liman.agent.ui.theme.LimanExtras.Vision)
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.size(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            testing = true
                            testMsg = null
                            scope.launch {
                                val t0 = now()
                                val result = withContext(Dispatchers.IO) {
                                    runCatching {
                                        runnerFor(cfg).complete(
                                            LlmRequest(
                                                listOf(
                                                    LlmMessage(
                                                        Role.USER,
                                                        listOf(LPart.Text("Reply with exactly: OK"))
                                                    )
                                                ),
                                                emptyList(),
                                                GenSettings(0.0, 64, false)
                                            ),
                                            null
                                        )
                                    }
                                }
                                testing = false
                                testMsg = result.fold(
                                    onSuccess = { r ->
                                        "✓ OK · ${now() - t0} ms · “${r.text.take(50).ifBlank { "(empty)" }}”"
                                    },
                                    onFailure = {
                                        "✗ ${it.message?.take(180) ?: it.javaClass.simpleName}"
                                    }
                                )
                            }
                        },
                        enabled = !testing
                    ) { Text(if (testing) "Testing…" else "Test connection") }
                    Spacer(Modifier.weight(1f))
                    Button(
                        onClick = {
                            onSave(
                                cfg.copy(
                                    name = cfg.name.ifBlank {
                                        presetById(cfg.presetId).title.substringBefore(" (")
                                    }
                                )
                            )
                        }
                    ) { Text("Save") }
                }
                testMsg?.let {
                    Spacer(Modifier.size(8.dp))
                    Text(
                        it,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (it.startsWith("✓")) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.error
                    )
                }
                Spacer(Modifier.size(24.dp))

                if (showLogin && cfg.baseUrl.startsWith("http")) {
                    WebChatLoginDialog(url = cfg.baseUrl, onDone = { showLogin = false })
                }
            }
        }
    }
}

/**
 * In-app browser for web-chat login (v2.12.1 rewrite).
 *
 * What was broken before (user: "press login → black page"):
 *  1. OAuth popups (Login with Google etc.) were created INVISIBLE —
 *     onCreateWindow built an off-screen WebView, so after tapping the
 *     site's login button the user stared at a dead black screen.
 *  2. The WebView sat on the dark app surface with no background of its
 *     own — slow loads and blocked pages looked like a black void.
 *  3. No progress, no page title, no error handling, no back button —
 *     any hiccup looked like a crash.
 *
 * Now: the popup is ATTACHED and visible on top of the page, the browser
 * area is white with a real progress bar + live page title, load errors
 * get a readable error card with Retry / Open-in-Chrome, and system Back
 * closes the popup → navigates back → closes the dialog (in that order).
 * Cookies are flushed on close so WebChatProvider picks the session up.
 */
@Composable
private fun WebChatLoginDialog(url: String, onDone: () -> Unit) {
    var loginDetected by remember { mutableStateOf(false) }
    var pageTitle by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var inPopup by remember { mutableStateOf(false) }
    val siteHost = remember(url) { runCatching { Uri.parse(url).host }.getOrNull() }
    val context = LocalContext.current

    // plain holder (no recomposition churn) for the view references
    val holder = remember {
        object {
            var frame: android.widget.FrameLayout? = null
            var main: android.webkit.WebView? = null
            var popup: android.webkit.WebView? = null
        }
    }

    fun detachPopup() {
        val p = holder.popup ?: return
        holder.popup = null
        inPopup = false
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            runCatching {
                holder.frame?.removeView(p)
                p.stopLoading()
                p.removeAllViews()
                p.destroy()
            }
        }
    }

    // system Back: close popup → go back in history → close the dialog
    androidx.activity.compose.BackHandler(enabled = true) {
        when {
            holder.popup != null -> detachPopup()
            holder.main?.canGoBack() == true -> holder.main?.goBack()
            else -> onDone()
        }
    }

    fun applyWebSettings(wv: android.webkit.WebView, ctx: android.content.Context) {
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            // popups/new windows must work for OAuth ("Login with Google")
            setSupportMultipleWindows(true)
            setJavaScriptCanOpenWindowsAutomatically(true)
            // normalize the UA: strip the WebView token so Google treats this
            // as a normal Chrome mobile tab and does not block the login
            userAgentString = android.webkit.WebSettings.getDefaultUserAgent(ctx).replace("; wv", "")
            // system font scaling can break site layouts — pin it
            textZoom = 100
            // never let Android 10-13 force-dark invert the page (black-on-black)
            @Suppress("DEPRECATION")
            if (android.os.Build.VERSION.SDK_INT in 29..33) {
                forceDark = android.webkit.WebSettings.FORCE_DARK_OFF
            }
        }
        // a real white browser surface — no black void while pages load
        wv.setBackgroundColor(android.graphics.Color.WHITE)
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
    }

    fun statusLine(): String = when {
        errorMsg != null -> "Couldn't load the page — check your connection"
        inPopup -> "Finish the sign-in that just opened"
        loading -> "Loading… " + progress + "%"
        loginDetected -> "✓ Logged in — you can press Done"
        else -> "Sign in incl. Google — the session stays inside Liman"
    }

    Dialog(onDismissRequest = onDone, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    LimanIcon(R.drawable.ic_mcp_connect, MaterialTheme.colorScheme.primary, size = 18)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (pageTitle.isNotBlank()) pageTitle else ("Log in — " + (siteHost ?: "site")),
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            statusLine(),
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                loginDetected -> MaterialTheme.colorScheme.primary
                                errorMsg != null -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                    Button(onClick = onDone) { Text("Done") }
                }
                if (loading && errorMsg == null) {
                    androidx.compose.material3.LinearProgressIndicator(
                        progress = { (progress.coerceIn(0, 100)) / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                errorMsg?.let { err ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            err,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        Row {
                            OutlinedButton(onClick = {
                                errorMsg = null
                                loading = true
                                progress = 0
                                holder.main?.reload()
                            }) { Text("Retry") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = {
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                            }) { Text("Open in Chrome") }
                        }
                    }
                }

                AndroidView(
                    factory = { ctx ->
                        android.widget.FrameLayout(ctx).apply {
                            setBackgroundColor(android.graphics.Color.WHITE)
                            holder.frame = this

                            val wv = android.webkit.WebView(ctx)
                            applyWebSettings(wv, ctx)
                            wv.webViewClient = object : android.webkit.WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    v: android.webkit.WebView,
                                    r: android.webkit.WebResourceRequest
                                ): Boolean {
                                    val scheme = r.url.scheme?.lowercase() ?: return false
                                    // http(s) ALWAYS stays in-app — bouncing to Chrome
                                    // is exactly what broke Google login before
                                    if (scheme == "http" || scheme == "https") return false
                                    return try {
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, r.url)); true
                                    } catch (e: Exception) { true }
                                }

                                override fun onPageStarted(
                                    v: android.webkit.WebView, loaded: String, favicon: android.graphics.Bitmap?
                                ) {
                                    loading = true
                                    progress = 0
                                    errorMsg = null
                                }

                                override fun onPageFinished(v: android.webkit.WebView, loaded: String) {
                                    loading = false
                                    val h = runCatching { Uri.parse(loaded).host }.getOrNull()
                                    if (siteHost != null && h == siteHost) {
                                        val cookies = android.webkit.CookieManager.getInstance()
                                            .getCookie(loaded)
                                        if (!cookies.isNullOrBlank()) loginDetected = true
                                    }
                                }

                                override fun onReceivedError(
                                    v: android.webkit.WebView,
                                    request: android.webkit.WebResourceRequest,
                                    error: android.webkit.WebResourceError
                                ) {
                                    // only a MAIN FRAME failure is "the page is broken";
                                    // sub-frame errors are normal site noise
                                    if (request.isForMainFrame) {
                                        loading = false
                                        errorMsg = "Page failed to load: " +
                                            (error.description?.toString() ?: "network error") +
                                            " (" + error.errorCode + ")"
                                    }
                                }
                            }
                            wv.webChromeClient = object : android.webkit.WebChromeClient() {
                                override fun onProgressChanged(v: android.webkit.WebView, p: Int) {
                                    progress = p
                                    if (p >= 100) loading = false
                                }

                                override fun onReceivedTitle(v: android.webkit.WebView, title: String?) {
                                    if (!title.isNullOrBlank()) pageTitle = title
                                }

                                // THE fix: OAuth/new-window pages are ATTACHED and
                                // visible, on top of the main page — no invisible
                                // WebView, no dead black screen.
                                override fun onCreateWindow(
                                    view: android.webkit.WebView,
                                    isDialog: Boolean,
                                    isUserGesture: Boolean,
                                    resultMsg: android.os.Message
                                ): Boolean {
                                    val popup = android.webkit.WebView(ctx)
                                    applyWebSettings(popup, ctx)
                                    popup.webViewClient = object : android.webkit.WebViewClient() {
                                        override fun shouldOverrideUrlLoading(
                                            v: android.webkit.WebView,
                                            r: android.webkit.WebResourceRequest
                                        ): Boolean {
                                            val scheme = r.url.scheme?.lowercase() ?: return false
                                            // stay INSIDE the visible popup so the
                                            // whole OAuth flow happens on screen
                                            if (scheme == "http" || scheme == "https") return false
                                            return try {
                                                ctx.startActivity(Intent(Intent.ACTION_VIEW, r.url)); true
                                            } catch (e: Exception) { true }
                                        }

                                        override fun onPageFinished(v: android.webkit.WebView, loaded: String) {
                                            val h = runCatching { Uri.parse(loaded).host }.getOrNull()
                                            if (siteHost != null && h == siteHost) {
                                                // landed back on the site → session cookie
                                                // is in the shared jar
                                                loginDetected = true
                                                android.os.Handler(android.os.Looper.getMainLooper()).post {
                                                    detachPopup()
                                                    holder.main?.reload()
                                                }
                                            }
                                        }
                                    }
                                    popup.webChromeClient = object : android.webkit.WebChromeClient() {
                                        override fun onCloseWindow(window: android.webkit.WebView) {
                                            detachPopup()
                                        }
                                    }
                                    holder.popup = popup
                                    inPopup = true
                                    addView(
                                        popup,
                                        android.widget.FrameLayout.LayoutParams(
                                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                            android.view.ViewGroup.LayoutParams.MATCH_PARENT
                                        )
                                    )
                                    val transport = resultMsg.obj as android.webkit.WebView.WebViewTransport
                                    transport.webView = popup
                                    resultMsg.sendToTarget()
                                    return true
                                }
                            }
                            holder.main = wv
                            addView(
                                wv,
                                android.widget.FrameLayout.LayoutParams(
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            )
                            wv.loadUrl(url)
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                )
            }
        }
    }

    // release the WebViews + persist cookies, so the login really survives
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose {
            runCatching {
                holder.frame?.removeAllViews()
                holder.main?.stopLoading()
                holder.main?.destroy()
                holder.popup?.stopLoading()
                holder.popup?.destroy()
                android.webkit.CookieManager.getInstance().flush()
            }
        }
    }
}

private fun runnerFor(cfg: ProviderConfig): ProviderRunner = when (cfg.kind) {
    ProviderKind.OPENAI_COMPATIBLE -> OpenAiProvider(cfg)
    ProviderKind.GEMINI -> GeminiProvider(cfg)
    ProviderKind.ANTHROPIC -> AnthropicProvider(cfg)
    ProviderKind.WEB_CHAT -> WebChatProvider(cfg)
    ProviderKind.OPENCODE_FREE -> OpenCodeFreeProvider(cfg)
}

@Composable
private fun Badge(label: String, color: Color) {
    androidx.compose.material3.Surface(
        color = color.copy(alpha = 0.16f),
        contentColor = color,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp)
    ) {
        Text(
            label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
        )
    }
}
