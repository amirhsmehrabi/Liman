package com.liman.agent.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.liman.agent.LimanApplication
import com.liman.agent.agent.Agent
import com.liman.agent.agent.FileIngestor
import com.liman.agent.data.Conversation
import com.liman.agent.data.Entry
import com.liman.agent.data.Roadmap
import com.liman.agent.data.RoadmapEngine
import com.liman.agent.data.RoadmapTask
import com.liman.agent.agent.MissionTask
import com.liman.agent.agent.TaskTitles
import com.liman.agent.agent.buildCombo
import com.liman.agent.llm.GenSettings
import com.liman.agent.llm.LlmMessage
import com.liman.agent.llm.LlmRequest
import com.liman.agent.llm.LPart
import com.liman.agent.llm.Role
import com.liman.agent.llm.ToolCallData
import com.liman.agent.util.fmtBytes
import com.liman.agent.util.now
import com.liman.agent.util.sanitizeFileName
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ChatViewModel(app: Application, val convId: String) :
    AndroidViewModel(app), Agent.AgentHost {

    private val container = LimanApplication.get(app).container
    private val stores = container.stores
    private val ingestor = FileIngestor(app)

    val settings = stores.settings.state
    val providers = stores.providers.state

    private val _conversation = MutableStateFlow<Conversation?>(null)
    val conversation: StateFlow<Conversation?> = _conversation

    private val _entries = MutableStateFlow<List<Entry>>(emptyList())
    val entries: StateFlow<List<Entry>> = _entries

    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running

    private val _streamTick = MutableStateFlow<Agent.StreamTick?>(null)
    val streamTick: StateFlow<Agent.StreamTick?> = _streamTick

    /** Live heartbeat the UI renders so it's always clear the agent is alive. */
    data class RunStatusState(
        val phase: String = "",
        val waiting: Boolean = false,
        val startedAt: Long = 0L,
        val lastActivityAt: Long = 0L
    )

    private val _runStatus = MutableStateFlow(RunStatusState())
    val runStatus: StateFlow<RunStatusState> = _runStatus

    private val _pendingApproval = MutableStateFlow<PendingApproval?>(null)
    val pendingApproval: StateFlow<PendingApproval?> = _pendingApproval

    // ---------------- v2.33.0 FLUID CANVAS ----------------

    /** Messages typed while a run is active — they steer/queue instead of blocking. */
    private val _pendingSteers = MutableStateFlow<List<String>>(emptyList())
    val pendingSteers: StateFlow<List<String>> = _pendingSteers

    /** The contextual LIVE PREVIEW pane — docks only for coding tasks
     *  (render_html screenshots, dev_server URL). Null = no pane. */
    data class LivePreviewState(
        val imagePath: String?,   // absolute path to the latest render screenshot
        val url: String?,         // dev_server / preview URL if served
        val label: String,        // what is being previewed
        val ts: Long = now()
    )

    private val _livePreview = MutableStateFlow<LivePreviewState?>(null)
    val livePreview: StateFlow<LivePreviewState?> = _livePreview

    private val _pendingPrompt = MutableStateFlow<PendingPrompt?>(null)
    val pendingPrompt: StateFlow<PendingPrompt?> = _pendingPrompt

    data class PendingImport(val name: String, val relPath: String, val size: Long)

    private val _pendingImports = MutableStateFlow<List<PendingImport>>(emptyList())
    val pendingImports: StateFlow<List<PendingImport>> = _pendingImports

    /** v2.20 — LangGraph crash-resume: goal of a run killed mid-flight (null = none). */
    private val _interruptedGoal = MutableStateFlow<String?>(null)
    val interruptedGoal: StateFlow<String?> = _interruptedGoal

    data class PendingApproval(val call: ToolCallData, val deferred: CompletableDeferred<Boolean>)
    data class PendingPrompt(val question: String, val options: List<String>, val deferred: CompletableDeferred<String>)

    private val entryChannel = Channel<Entry>(Channel.UNLIMITED)
    private var conv: Conversation? = null
    private var runJob: Job? = null

    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false

    init {
        // share-intent handoff
        container.pendingImports.remove(convId)?.let { list ->
            _pendingImports.value = list.map {
                PendingImport(File(it).name, it, File(ws, it).length())
            }
        }
        val draft = container.pendingDrafts.remove(convId) ?: ""

        // a surviving checkpoint = the app died mid-run in this conversation
        runCatching {
            com.liman.agent.agent.RunCheckpointer.load(container.stores.runstate, convId)
        }.getOrNull()?.let { cp ->
            _interruptedGoal.value = cp.goal.take(140).ifBlank { "interrupted run" }
        }
        viewModelScope.launch {
            conv = stores.conversations.load(convId) ?: Conversation(convId)
            _conversation.value = conv
            _entries.value = conv?.entries ?: emptyList()
            if (draft.isNotBlank()) _draft.value = draft
        }
        viewModelScope.launch {
            for (e in entryChannel) {
                val c = conv ?: continue
                c.entries = c.entries + e
                c.updatedAt = now()
                _entries.value = c.entries
                _conversation.value = c
                stores.conversations.save(c)
                if (e is Entry.AssistantEntry && e.text.isNotBlank() &&
                    stores.settings.state.value.ttsEnabled
                ) {
                    speak(e.text)
                }
            }
        }
    }

    private val _draft = MutableStateFlow("")

    fun consumeDraft(): String {
        val d = _draft.value
        _draft.value = ""
        return d
    }

    // ---------------- v2.31: per-chat workspace ----------------

    /** The folder this chat's files live in (own folder for new chats, root for legacy). */
    val ws: File
        get() = if (conv?.ownWorkspace == true) stores.chatWorkspace(convId) else container.workspace

    /** Files across ALL workspaces (the root tree — for the + menu picker). */
    fun listAllWorkspaces(max: Int = 300): List<File> =
        container.workspace.walkTopDown().filter { it.isFile }.sortedByDescending { it.lastModified() }
            .take(max).toList()

    /** Copy any root-workspace file into THIS chat's workspace (uploads/) and stage it. */
    fun importFromAllWorkspaces(relPath: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val src = File(container.workspace, relPath.replace('\\', '/'))
            if (!src.isFile) return@launch
            val dir = File(ws, "uploads").apply { mkdirs() }
            val dst = File(dir, src.name)
            runCatching { src.copyTo(dst, overwrite = true) }
            val rel = dst.relativeToOrNull(ws)?.toString()?.replace('\\', '/') ?: dst.name
            _pendingImports.value = _pendingImports.value + PendingImport(dst.name, rel, dst.length())
        }
    }

    // ---------------- v2.31 (v2.36: plan/build mode removed) ----------------

    override fun onMissionState(title: String, tasks: List<MissionTask>) {
        val c = conv ?: return
        // LIVE mission checklist card — progress only; the plan/build mode is
        // gone, the agent plans by doing.
        c.roadmap = RoadmapEngine.fromMission(title, tasks).let { r ->
            r.status = "accepted"; r
        }
        c.updatedAt = now()
        _conversation.value = c
        viewModelScope.launch { stores.conversations.save(c) }
    }

    // ---------------- v2.31: quick model/provider switch ----------------

    /**
     * Switch the chat to one provider (and optionally one of its models).
     * The combo becomes that single member — tap the header again to go back
     * to the full failover team via the same sheet ("All providers").
     */
    fun switchProvider(providerId: String?, model: String?): String {
        if (providerId == null) {
            val all = stores.providers.state.value.filter { it.enabled }.map { it.id }
            if (all.isEmpty()) return "No enabled providers"
            stores.combo.update { it.copy(providerIds = all, mode = com.liman.agent.data.ComboMode.FAILOVER) }
            return "All providers (failover team)"
        }
        val p = stores.providers.get(providerId) ?: return "Provider not found"
        if (model != null && model.isNotBlank() && model != p.model) {
            p.model = model
            stores.providers.upsert(p)
        }
        stores.combo.update { it.copy(providerIds = listOf(p.id), mode = com.liman.agent.data.ComboMode.FAILOVER) }
        return "${p.name} · ${p.model.ifBlank { "(default model)" }}"
    }

    // ---------------- actions ----------------

    fun attach(uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            uris.forEach { uri ->
                val f = runCatching { ingestor.importUri(uri, ws) }.getOrNull()
                if (f != null) {
                    val rel = f.relativeToOrNull(ws)?.toString()?.replace('\\', '/')
                        ?: f.name
                    _pendingImports.value = _pendingImports.value + PendingImport(f.name, rel, f.length())
                }
            }
        }
    }

    fun removeImport(relPath: String) {
        _pendingImports.value = _pendingImports.value.filter { it.relPath != relPath }
    }

    /** Stage an existing workspace file to be attached to the next message. */
    fun addImport(relPath: String) {
        val f = File(ws, relPath)
        if (f.exists()) {
            _pendingImports.value = _pendingImports.value +
                PendingImport(f.name, relPath.replace('\\', '/'), f.length())
        }
    }

    fun deleteWorkspaceFile(f: File) {
        runCatching {
            val rel = f.relativeToOrNull(ws)?.toString() ?: return
            if (rel.startsWith("uploads/") || rel.startsWith("generated/") ||
                rel.startsWith("downloads/") || f.parentFile == ws
            ) {
                f.delete()
            }
        }
    }

    fun send(text: String) {
        if (_running.value) { queueSteer(text); return }
        val imports = _pendingImports.value
        if (text.isBlank() && imports.isEmpty()) return
        runJob = viewModelScope.launch {
            _running.value = true
            _interruptedGoal.value = null
            _streamTick.value = null
            _runStatus.value = RunStatusState(
                phase = "Starting…", startedAt = now(), lastActivityAt = now()
            )
            try {
                val c = conv ?: return@launch
                if (stores.providers.state.value.none { it.enabled }) {
                    postEntry(
                        Entry.NoteEntry(
                            "No provider configured. Open Settings → Providers and add one " +
                                "(Gemini needs just a free API key: aistudio.google.com/apikey).",
                            "error"
                        )
                    )
                    return@launch
                }
                val ingested = withContext(Dispatchers.IO) {
                    imports.mapNotNull { pi ->
                        val f = File(ws, pi.relPath)
                        if (f.exists()) runCatching { ingestor.ingestFile(f, ws) }.getOrNull()
                        else null
                    }
                }
                _pendingImports.value = emptyList()

                // v2.36 — AI TASK NAMING: instant heuristic placeholder now,
                // creative 2-3 word AI title right after the first run.
                val autoTitle = if (c.title == "New task" || c.title.isBlank()) {
                    val t = TaskTitles.heuristic(text).ifBlank { "Files task" }
                    c.title = t
                    _conversation.value = c
                    t
                } else null

                val agent = Agent(getApplication(), stores, this@ChatViewModel)
                agent.run(c, text, ingested)

                // v2.36 — replace the placeholder with the model's own name
                if (autoTitle != null && c.title == autoTitle) {
                    val ai = runCatching { generateTitle(text) }.getOrNull()
                    if (!ai.isNullOrBlank()) {
                        c.title = ai
                        _conversation.value = c
                        stores.conversations.save(c)
                    }
                }
            } catch (ce: CancellationException) {
                postEntry(Entry.NoteEntry("Stopped by user.", "warn"))
            } catch (t: Throwable) {
                postEntry(Entry.NoteEntry("Unexpected error: ${t.message ?: t.toString()}", "error"))
            } finally {
                _running.value = false
                _streamTick.value = null
                // v2.33 — steering queue: the moment the run finishes, the
                // oldest steered message fires automatically.
                val queued = _pendingSteers.value.firstOrNull()
                if (queued != null && runJob?.isCancelled != true) {
                    _pendingSteers.value = _pendingSteers.value.drop(1)
                    kotlinx.coroutines.delay(400)
                    send(queued)
                }
                _runStatus.value = RunStatusState()
                _pendingApproval.value?.let { it.deferred.complete(false) }
                _pendingApproval.value = null
                _pendingPrompt.value?.let { it.deferred.complete("(run ended)") }
                _pendingPrompt.value = null
                conv?.let { stores.conversations.save(it) }
            }
        }
    }

    /** v2.20 — resume a run that was killed mid-flight (LangGraph checkpoint). */
    fun resumeInterrupted() {
        if (_running.value) return
        runJob = viewModelScope.launch {
            _running.value = true
            _interruptedGoal.value = null
            _streamTick.value = null
            _runStatus.value = RunStatusState(
                phase = "Resuming interrupted run…", startedAt = now(), lastActivityAt = now()
            )
            try {
                val c = conv ?: return@launch
                if (stores.providers.state.value.none { it.enabled }) {
                    postEntry(
                        Entry.NoteEntry(
                            "No provider configured. Open Settings → Providers and add one.",
                            "error"
                        )
                    )
                    return@launch
                }
                val agent = Agent(getApplication(), stores, this@ChatViewModel)
                agent.run(c, "", emptyList(), resume = true)
            } catch (ce: CancellationException) {
                postEntry(Entry.NoteEntry("Stopped by user.", "warn"))
            } catch (t: Throwable) {
                postEntry(Entry.NoteEntry("Unexpected error: ${t.message ?: t.toString()}", "error"))
            } finally {
                _running.value = false
                _streamTick.value = null
                _runStatus.value = RunStatusState()
                _pendingApproval.value?.let { it.deferred.complete(false) }
                _pendingApproval.value = null
                _pendingPrompt.value?.let { it.deferred.complete("(run ended)") }
                _pendingPrompt.value = null
                conv?.let { stores.conversations.save(it) }
            }
        }
    }

    /** User declines recovery — drop the checkpoint. */
    fun dismissInterrupted() {
        _interruptedGoal.value = null
        runCatching { com.liman.agent.agent.RunCheckpointer.clear(container.stores.runstate, convId) }
    }

    fun stop() {
        runJob?.cancel()
    }

    /** v2.33 — a message sent mid-run becomes a steer chip; it auto-sends the
     *  moment the current run finishes (and the user can cancel it with ✕). */
    fun queueSteer(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        _pendingSteers.value = _pendingSteers.value + t
    }

    fun removeSteer(index: Int) {
        val cur = _pendingSteers.value
        if (index in cur.indices) _pendingSteers.value = cur.filterIndexed { i, _ -> i != index }
    }

    fun dismissPreview() { _livePreview.value = null }

    /** postEntry hook: feed the contextual live-preview pane. */
    private fun observeForPreview(e: Entry) {
        if (e !is Entry.ToolEntry || !e.ok) return
        when (e.tool) {
            "render_html" -> {
                val shot = Regex("Screenshot saved to (\\S+)").find(e.result)?.groupValues?.get(1)
                val label = Regex("Rendered (\\S+|inline HTML)").find(e.result)?.groupValues?.get(1) ?: "HTML"
                _livePreview.value = LivePreviewState(
                    imagePath = shot?.let { java.io.File(ws, it).absolutePath },
                    url = _livePreview.value?.url,
                    label = label
                )
            }
            "dev_server" -> {
                val url = Regex("http://[0-9.]+:[0-9]+/preview/").find(e.result)?.value
                _livePreview.value = _livePreview.value?.copy(url = url)
                    ?: LivePreviewState(null, url, "dev server")
            }
        }
    }

    fun respondApproval(allow: Boolean, alwaysAllow: Boolean) {
        val pa = _pendingApproval.value ?: return
        if (allow && alwaysAllow) {
            stores.settings.update { s ->
                if (!s.alwaysAllowTools.contains(pa.call.name)) {
                    s.alwaysAllowTools = s.alwaysAllowTools + pa.call.name
                }
            }
        }
        pa.deferred.complete(allow)
        _pendingApproval.value = null
    }

    fun answerPrompt(text: String) {
        val pp = _pendingPrompt.value ?: return
        pp.deferred.complete(text.ifBlank { "(no answer)" })
        _pendingPrompt.value = null
    }

    fun skipPrompt() {
        val pp = _pendingPrompt.value ?: return
        pp.deferred.complete("(user skipped the question)")
        _pendingPrompt.value = null
    }

    /**
     * v2.36 — one cheap LLM call: a creative 2-3 word name for the task
     * (the conversation title is never the raw first prompt anymore).
     */
    private suspend fun generateTitle(goal: String): String? = runCatching {
        val combo = buildCombo(stores, { })
        val res = combo.complete(
            LlmRequest(
                listOf(
                    LlmMessage(Role.SYSTEM, listOf(LPart.Text(TaskTitles.SYSTEM))),
                    LlmMessage(Role.USER, listOf(LPart.Text(TaskTitles.userPrompt(goal))))
                ),
                emptyList(),
                GenSettings(0.2, 48, false)
            )
        ) { _, _ -> }
        TaskTitles.clean(res.text)
    }.getOrNull()

    fun rename(title: String) {
        conv?.let {
            it.title = title.trim().ifBlank { "Task" }
            _conversation.value = it
            viewModelScope.launch { stores.conversations.save(it) }
        }
    }

    fun clearConversation() {
        conv?.let {
            it.entries = emptyList()
            it.llmMessages = emptyList()
            it.updatedAt = now()
            _entries.value = emptyList()
            _conversation.value = it
            viewModelScope.launch { stores.conversations.save(it) }
        }
    }

    fun listWorkspace(): List<File> =
        ws.walkTopDown().filter { it.isFile }.sortedByDescending { it.lastModified() }
            .take(200).toList()

    fun importToWorkspace(uris: List<Uri>, onDone: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            uris.forEach { uri -> runCatching { ingestor.importUri(uri, ws) } }
            withContext(Dispatchers.Main) { onDone() }
        }
    }

    fun exportMarkdown(uri: Uri): String {
        val c = conv ?: return ""
        val md = buildString {
            appendLine("# ${c.title}")
            appendLine()
            appendLine("_Exported from Liman Agent · ${now()}_")
            appendLine()
            c.entries.forEach { e ->
                when (e) {
                    is Entry.UserEntry -> {
                        appendLine("## 🧑 User")
                        appendLine(e.text)
                        if (e.attachments.isNotEmpty()) appendLine("_Files: ${e.attachments.joinToString(", ")}_")
                    }

                    is Entry.AssistantEntry -> {
                        appendLine("## ⚡ Liman (${e.model}, cycle ${e.cycle})")
                        appendLine(e.text)
                    }

                    is Entry.ToolEntry -> {
                        appendLine("**🔧 ${e.tool}** (cycle ${e.cycle}, ${e.ms} ms, ${if (e.ok) "ok" else "FAILED"})")
                        appendLine("```")
                        appendLine("args: ${e.argsJson}")
                        appendLine("result: ${e.result.ellipsize(3000)}")
                        appendLine("```")
                    }

                    is Entry.NoteEntry -> appendLine("> _${e.text}_")
                    is Entry.ReviewEntry -> appendLine("> 🔍 **Review ${e.score}/10 (${e.verdict})**: ${e.critique}")
                    is Entry.PromptEntry -> appendLine("> 💬 **${e.question}** → ${e.answer}")
                    is Entry.SubagentEntry -> {
                        appendLine("### 🤖 Subagent (${e.status})")
                        appendLine("**Objective:** ${e.objective}")
                        if (e.summary.isNotBlank()) appendLine(e.summary)
                    }

                    is Entry.FileEntry -> {
                        appendLine("### 📎 Files ready to download")
                        e.files.forEach { appendLine("- ${it.name} (${it.sizeBytes.fmtBytes()})") }
                    }
                }
                appendLine()
            }
        }
        return runCatching {
            getApplication<Application>().contentResolver.openOutputStream(uri)?.use { os ->
                os.write(md.toByteArray(Charsets.UTF_8))
            }
            "Exported ✓"
        }.getOrElse { "Export failed: ${it.message}" }
    }

    fun ensureTts() {
        if (tts != null) return
        runCatching {
            tts = TextToSpeech(getApplication()) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        }
    }

    // ---------------- AgentHost ----------------

    override fun postEntry(e: Entry) {
        _runStatus.value = _runStatus.value.copy(lastActivityAt = now())
        runCatching { observeForPreview(e) }
        entryChannel.trySend(e)
    }

    override fun onStreamTick(tick: Agent.StreamTick?) {
        if (tick != null) {
            _runStatus.value = _runStatus.value.copy(lastActivityAt = now())
        }
        _streamTick.value = tick
    }

    override fun onStatus(phase: String, waiting: Boolean) {
        _runStatus.value = _runStatus.value.copy(
            phase = phase, waiting = waiting, lastActivityAt = now()
        )
    }

    /** Serializes approval dialogs so parallel tools/subagents queue up nicely. */
    private val approvalMutex = Mutex()
    private val askMutex = Mutex()

    override suspend fun requestApproval(call: ToolCallData): Boolean = approvalMutex.withLock {
        val d = CompletableDeferred<Boolean>()
        _runStatus.value = _runStatus.value.copy(
            phase = "⏸ Waiting for your approval — “${call.name}” (see the dialog)",
            waiting = true
        )
        _pendingApproval.value = PendingApproval(call, d)
        try {
            d.await()
        } finally {
            if (_pendingApproval.value?.deferred === d) _pendingApproval.value = null
        }
    }

    override suspend fun askUser(question: String, options: List<String>): String = askMutex.withLock {
        val d = CompletableDeferred<String>()
        _runStatus.value = _runStatus.value.copy(
            phase = "💬 Liman needs your answer — (see the dialog)",
            waiting = true
        )
        _pendingPrompt.value = PendingPrompt(question, options, d)
        try {
            d.await()
        } finally {
            if (_pendingPrompt.value?.deferred === d) _pendingPrompt.value = null
        }
    }

    override fun speak(text: String) {
        if (!ttsReady) return
        runCatching {
            tts?.stop()
            tts?.speak(text.take(1500), TextToSpeech.QUEUE_FLUSH, null, "liman")
        }
    }

    override fun onCleared() {
        runJob?.cancel()
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        super.onCleared()
    }

    private fun String.ellipsize(n: Int): String = if (length <= n) this else take(n) + "…"

    fun shareFileIntent(file: File): Intent? {
        val context = getApplication<Application>()
        return runCatching {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }.getOrNull()
    }

    /** Opens the system package installer for a workspace .apk built by the agent. */
    fun installApkIntent(file: File): Intent? {
        val context = getApplication<Application>()
        return runCatching {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }.getOrNull()
    }

    /** Opens any workspace file with the best matching external app (viewer). */
    fun openFileIntent(file: File): Intent? {
        val context = getApplication<Application>()
        return runCatching {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            val mime = when (file.extension.lowercase()) {
                "pdf" -> "application/pdf"
                "png" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                "gif" -> "image/gif"
                "webp" -> "image/webp"
                "bmp" -> "image/bmp"
                "svg" -> "image/svg+xml"
                "mp3" -> "audio/mpeg"
                "wav" -> "audio/wav"
                "ogg" -> "audio/ogg"
                "m4a" -> "audio/mp4"
                "mp4" -> "video/mp4"
                "webm" -> "video/webm"
                "txt", "md", "log" -> "text/plain"
                "csv" -> "text/csv"
                "json" -> "application/json"
                "html", "htm" -> "text/html"
                "xml" -> "application/xml"
                "apk" -> "application/vnd.android.package-archive"
                else -> "*/*"
            }
            Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }.getOrNull()
    }

    fun suggestFileName(): String =
        "liman-${(conv?.title ?: "chat").sanitizeFileName()}.md"
}
