package com.liman.agent.agent

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v2.28.0 — THE DOCTOR'S LOG.
 *
 * The user asked for a LOG BUTTON that captures what Liman actually did in
 * the backend — cycles, provider calls, tool calls, bridge errors — and
 * exports it as a Markdown report you can hand back for repair.
 *
 * In-memory ring buffer, cheap to write, thread-safe, never touches disk
 * until export. Wired into: Agent loop, tool dispatch, Termux bridge,
 * scheduler.
 */
object DiagLog {

    enum class Level { DEBUG, INFO, WARN, ERROR }

    data class Event(
        val ts: Long,
        val level: Level,
        val tag: String,
        val msg: String
    )

    const val MAX_EVENTS = 800
    const val MAX_MSG = 400
    private val buf = ArrayDeque<Event>()
    private var sessionStart: Long = System.currentTimeMillis()
    private var runCount = 0

    /** set once from LimanApplication.onCreate (AGP 8 ships no BuildConfig by default) */
    var appVersion: String = "unknown"

    // ============================================================
    // v2.34.0 — THE PERMANENT CODE LOG.
    //
    // Everything that happens in the app is ALSO appended to disk as a
    // plain code log built for debugging:
    //   logs/diag-YYYY-MM-DD.log    — every event, one line each
    //   logs/errors-YYYY-MM-DD.log  — WARN + ERROR only (the fast lane)
    //   logs/crash-<ts>.log         — full uncaught-exception stacks
    // Files rotate per DAY (multiple files, one per day), are NEVER
    // auto-deleted, and each line is capped so a chatty tool result can
    // never blow up storage. `dir` is set from LimanApplication.onCreate.
    // ============================================================
    @Volatile
    var dir: java.io.File? = null
    private val io = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "liman-diaglog").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }
    }
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val lineFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    private fun persist(level: Level, tag: String, msg: String) {
        val root = dir ?: return
        io.execute {
            runCatching {
                val day = dayFmt.format(Date())
                val line = "${lineFmt.format(Date())} ${level.name.padEnd(5)} [$tag] ${msg.replace('\n', ' ')}\n"
                java.io.File(root, "diag-$day.log").appendText(line)
                if (level == Level.WARN || level == Level.ERROR) {
                    java.io.File(root, "errors-$day.log").appendText(line)
                }
            }
        }
    }

    /** Full uncaught-exception stack → its own crash file (never cleaned). */
    fun installCrashHandler() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                val root = dir ?: return@runCatching
                java.io.File(root, "crash-${System.currentTimeMillis()}.log").writeText(
                    buildString {
                        appendLine("thread: ${t.name}")
                        appendLine("version: $appVersion")
                        appendLine("android: ${android.os.Build.VERSION.SDK_INT} (${android.os.Build.VERSION.RELEASE}) ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                        appendLine()
                        appendLine(android.util.Log.getStackTraceString(e))
                    }
                )
            }
            previous?.uncaughtException(t, e)
        }
    }

    /** Human summary for the Log screen: where the permanent files live. */
    fun permanentLogInfo(): String {
        val root = dir ?: return "permanent logs disabled"
        val files = root.listFiles()?.filter { it.extension == "log" }?.sortedByDescending { it.name } ?: emptyList()
        val kb = files.sumOf { it.length() } / 1024
        return "permanent code logs: ${files.size} file(s), ${kb} KB — ${root.absolutePath} (never auto-cleaned; one diag-*/errors-*/crash-* file per day/crash)"
    }

    fun newSession() {
        synchronized(buf) {
            sessionStart = System.currentTimeMillis()
            buf.clear()
            log("diag", "session started (v$appVersion)", Level.DEBUG)
        }
    }

    fun log(tag: String, msg: String, level: Level = Level.INFO) {
        val clean = msg.take(MAX_MSG).replace('\n', ' ')
        synchronized(buf) {
            buf.addLast(Event(System.currentTimeMillis(), level, tag.take(24), clean))
            while (buf.size > MAX_EVENTS) buf.removeFirst()
        }
        persist(level, tag.take(24), clean)
    }

    fun error(tag: String, msg: String) = log(tag, msg, Level.ERROR)
    fun warn(tag: String, msg: String) = log(tag, msg, Level.WARN)

    /** Notable runs (agent conversations) get their own counter for the report header. */
    fun noteRun() {
        synchronized(buf) { runCount++ }
    }

    fun snapshot(): List<Event> = synchronized(buf) { buf.toList() }

    fun clear() = synchronized(buf) { buf.clear(); runCount = 0; sessionStart = System.currentTimeMillis() }

    fun counts(): Map<Level, Int> = synchronized(buf) {
        buf.groupingBy { it.level }.eachCount()
    }

    private fun fmt(ts: Long): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(ts))

    /**
     * The exportable Markdown report — everything the "backend doctor" needs:
     * header (version, device, session length, counts), then every event.
     */
    fun toMarkdown(): String = synchronized(buf) {
        val events = buf.toList()
        val mins = (System.currentTimeMillis() - sessionStart) / 60000
        buildString {
            appendLine("# Liman diagnostic report")
            appendLine()
            appendLine("- **App version:** $appVersion")
            appendLine("- **Exported:** ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            appendLine("- **Session length:** $mins min · **agent runs:** $runCount · **events:** ${events.size}")
            appendLine("- **Android:** ${android.os.Build.VERSION.SDK_INT} (${android.os.Build.VERSION.RELEASE}) · ${android.os.Build.MANUFACTURER ?: "?"} ${android.os.Build.MODEL ?: ""}".trimEnd())
            val c = events.groupingBy { it.level }.eachCount()
            appendLine("- **Levels:** ${Level.entries.joinToString(" · ") { l -> "${l.name}: ${c[l] ?: 0}" }}")
            appendLine()
            appendLine("## What happened in the backend")
            appendLine()
            appendLine("```")
            appendLine("time          lvl   tag            message")
            events.forEach { e ->
                appendLine("${fmt(e.ts)}  ${e.level.name.padEnd(5)} ${e.tag.padEnd(14)} ${e.msg}")
            }
            appendLine("```")
            appendLine()
            appendLine("## Errors and warnings only")
            appendLine()
            events.filter { it.level == Level.ERROR || it.level == Level.WARN }.let { bad ->
                if (bad.isEmpty()) appendLine("_None — clean session._")
                else bad.forEach { e -> appendLine("- **${fmt(e.ts)} ${e.level.name}** `${e.tag}` — ${e.msg}") }
            }
            appendLine()
            appendLine("---")
            appendLine("_Generated by Liman → Log button → Export. Attach this file when reporting a problem._")
        }
    }
}
