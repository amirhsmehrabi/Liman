package com.liman.agent.util

/**
 * Repairs truncated / polluted JSON emitted by models after very long
 * tool-heavy runs. Strategy:
 *
 *  1. strip code fences, control chars and trailing commas
 *  2. if parse succeeds → return as-is
 *  3. prefix-truncate: walk right-to-left over candidate cut points
 *     (last ',' / '}' / ']') and try to close the JSON by balancing all
 *     open braces / brackets and terminating dangling strings/keys.
 *
 * Returns null when nothing sensible can be recovered.
 */
object JsonRepair {

    fun repairOrNull(raw: String): String? {
        var s = raw.trim()
        if (s.startsWith("```")) {
            s = s.removePrefix("```json").removePrefix("```JSON")
                .removePrefix("```").substringBefore("```")
        }
        s = s.trim('\uFEFF', ' ', '\n', '\r', '\t')
        if (s.isEmpty()) return null
        if (tryParse(s)) return s

        // Candidate cut points: characters where truncation may have happened.
        val cutIdx = ArrayList<Int>()
        for (i in s.length - 1 downTo 0) {
            val c = s[i]
            if (c == ',' || c == '}' || c == ']' || c == '"' || c == '{' || c == '[') {
                cutIdx.add(i)
                if (cutIdx.size >= 400) break // keep bounded
            }
        }
        for (cut in cutIdx) {
            val attempt = close(s.substring(0, cut + 1)) ?: continue
            if (tryParse(attempt)) return attempt
        }
        return null
    }

    /** Tries repairs; on success returns (json, repaired?) — repaired flag notes a fix happened. */
    fun repair(raw: String): Pair<String, Boolean> {
        val cleaned = raw.trim()
        if (tryParse(cleaned)) return cleaned to false
        val fixed = repairOrNull(raw)
        return if (fixed != null) fixed to true else cleaned to false
    }

    // ----------------------------------------------------------------

    private fun tryParse(s: String): Boolean {
        if (s.isEmpty()) return false
        return try {
            JSON.parseToJsonElement(s)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Balance open structure of [frag] and return a candidate closed JSON,
     * or null when the fragment cannot plausibly be closed (e.g. nothing at all).
     */
    private fun close(frag: String): String? {
        val stack = ArrayDeque<Char>()
        var inString = false
        var escape = false
        var i = 0
        while (i < frag.length) {
            val c = frag[i]
            if (inString) {
                if (escape) escape = false
                else when (c) {
                    '\\' -> escape = true
                    '"' -> inString = false
                }
            } else {
                when (c) {
                    '"' -> inString = true
                    '{' -> stack.addLast('{')
                    '[' -> stack.addLast('[')
                    '}', ']' -> if (stack.isNotEmpty()) stack.removeLast()
                }
            }
            i++
        }

        var out = frag
        // if we stopped inside a string, terminate it
        if (inString) out += "\""

        // drop a dangling key ("name": ) waiting for a value → give it empty string
        out = out.trimEnd()
        if (out.endsWith(":")) out += " \"\""
        else if (out.endsWith(",")) out = out.dropLast(1)

        // if last non-ws char is '{' or '[' without content that's fine too
        while (stack.isNotEmpty()) {
            out += when (stack.removeLast()) {
                '{' -> '}'
                else -> ']'
            }
        }
        return out.ifEmpty { null }
    }
}
