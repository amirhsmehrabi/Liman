package com.liman.agent.agent

import java.io.File

/**
 * v2.35.0 — THE RUN LEDGER + PERIODIC PERFORMANCE AUDIT (Hermes-style:
 * "performance auditing every 15 tasks").
 *
 * Every finished run is one TSV line in `filesDir/agent-run-ledger.tsv`
 * (timestamp · outcome · cycles · tool calls). On every 15th run the ledger
 * compiles itself into a PERFORMANCE AUDIT that surfaces in the chat: success
 * rate, spin-outs (loop / cycle-cap deaths), average tool calls — plus blunt
 * advice. The user sees the agent grading itself; the lessons loop
 * ([RunLessons]) feeds the fixes back into later runs.
 *
 * Pure Kotlin — unit-tested (RunLessonsLedgerTest).
 */
object RunLedger {

    data class Audit(
        val runs: Int,
        val completed: Int,
        val loops: Int,
        val caps: Int,
        val avgToolCalls: Int
    ) {
        val failRatePct: Int = if (runs > 0) ((runs - completed) * 100 / runs) else 0

        val headline: String = "📈 PERFORMANCE AUDIT — run #$runs (every 15 runs Liman grades itself)"

        val body: String
            get() = buildString {
                append("Completed: $completed/$runs (${100 - failRatePct}%) · ")
                append("spin-outs (loop/cap): ${loops + caps} · ")
                append("avg tool calls: $avgToolCalls\n")
                if (failRatePct >= 40) {
                    append("⚠ $failRatePct% of runs end without completing — add a second provider to the combo (Settings → Providers) and check the Doctor's Log.\n")
                }
                if (loops + caps >= 4) {
                    append("⚠ Runs keep dying by spinning — the Progress Auditor now breaks loops mid-run, and failed runs leave lessons in .liman-lessons.md automatically.\n")
                }
                if (avgToolCalls < 3) {
                    append("⚠ Very few tool calls per run — if tasks feel talk-only: malformed text/XML tool calls are now auto-repaired and coached, check the Doctor's Log for 'salvage'.\n")
                }
                if (failRatePct < 40 && loops + caps < 4 && avgToolCalls >= 3) {
                    append("Shape looks healthy — keep giving it real work.\n")
                }
            }
    }

    private const val FILE = "agent-run-ledger.tsv"

    /**
     * Record one finished run; returns the compiled [Audit] when this was the
     * 15th run (every 15th run thereafter), else null.
     */
    fun record(dir: File, reason: String, cycles: Int, toolCalls: Int, at: Long = System.currentTimeMillis()): Audit? {
        val f = File(dir, FILE)
        f.appendText("$at\t$reason\t$cycles\t$toolCalls\n")
        val rows = f.readLines().filter { it.isNotBlank() }
        val n = rows.size
        if (n == 0 || n % 15 != 0) return null
        val parsed = rows.map { it.split('\t') }
        val reasonOf = { cols: List<String> -> cols.getOrNull(1).orEmpty() }
        val completed = parsed.count { reasonOf(it) == "completed" }
        val loops = parsed.count { reasonOf(it) == "loop" }
        val caps = parsed.count { reasonOf(it) in setOf("max_cycles", "run_ceiling") }
        val calls = parsed.sumOf { it.getOrNull(3)?.toIntOrNull() ?: 0 }
        return Audit(n, completed, loops, caps, calls / n)
    }
}
