package com.liman.agent.agent

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject

/**
 * v2.24.1 — THE RELIABILITY PATCH.
 *
 * Real-world bug (user-reported, confirmed in chat logs): many models —
 * especially free-tier ones — wrap their tool arguments in an extra layer:
 *
 *   {"arguments": {"command": "ls"}}        instead of   {"command": "ls"}
 *   {"parameters": {"name": "a.md", ...}}   instead of   {"name": "a.md", ...}
 *
 * Strict tools then answer "Missing 'command' / 'name' / 'action'" and the
 * agent burns cycles retrying. This normalizer unwraps those wrappers (and
 * double-encoded JSON strings) BEFORE dispatch, so every tool sees flat
 * arguments no matter how the model serialized them.
 */
object ArgsNormalizer {

    private val WRAPPER_KEYS = listOf(
        "arguments", "parameters", "params", "args", "input", "tool_input",
        "tool_arguments", "function_call", "function"
    )

    data class Result(val args: JsonObject, val fixedNote: String?)

    fun normalize(args: JsonObject): Result {
        var current = args
        var note: String? = null
        var depth = 0
        while (depth < 3) {
            val unwrapped = unwrapOne(current) ?: break
            current = unwrapped
            note = note ?: "arguments were nested (wrapped in an extra layer) — auto-unwrapped; send FLAT arguments next time, e.g. {\"name\":\"file.md\",\"content\":\"…\"}"
            depth++
        }
        // string-encoded args: {"arguments": "{\"command\":\"ls\"}"} handled above;
        // also a top-level single string that parses to an object (rare, cheap to check)
        if (note == null && current.size == 1) {
            val only = current.entries.first()
            if (only.key !in WRAPPER_KEYS && only.value is JsonPrimitive && (only.value as JsonPrimitive).isString) {
                val inner = parseObjectOrNull((only.value as JsonPrimitive).content)
                if (inner != null) {
                    current = inner
                    note = "arguments arrived as a JSON-encoded string — auto-parsed"
                }
            }
        }
        return Result(current, note)
    }

    private fun unwrapOne(args: JsonObject): JsonObject? {
        for (key in WRAPPER_KEYS) {
            val v = args[key] ?: continue
            when (v) {
                is JsonObject -> {
                    if (v.isEmpty()) continue
                    // merge: inner object wins; keep other non-wrapper top-level scalars
                    val merged = LinkedHashMap<String, kotlinx.serialization.json.JsonElement>(v)
                    args.forEach { (k, ev) ->
                        if (k != key && k !in WRAPPER_KEYS && !merged.containsKey(k)) merged[k] = ev
                    }
                    return JsonObject(merged)
                }
                is JsonPrimitive -> if (v.isString) {
                    val inner = parseObjectOrNull(v.content) ?: continue
                    if (inner.isEmpty()) continue
                    return inner
                }
                else -> {} // arrays/nulls can't be wrappers — leave as-is
            }
        }
        return null
    }

    private fun parseObjectOrNull(s: String): JsonObject? = runCatching {
        Json.parseToJsonElement(s.trim()).jsonObject
    }.getOrNull().takeIf { it !is kotlinx.serialization.json.JsonNull }

    /**
     * The MISSING-ARG TEACHER: when a required key is absent, the error must
     * SHOW what keys actually arrived and the correct flat shape — so even a
     * weak model recovers in exactly one retry.
     */
    fun missingArg(tool: String, wanted: String, args: JsonObject, example: String): String {
        val keys = if (args.isEmpty()) "(none — arguments arrived empty or unparsable)"
        else args.keys.joinToString(", ")
        return "Missing '$wanted' for $tool. You sent these keys: [$keys]. " +
            "Send FLAT arguments in ONE object — $example. " +
            "Do NOT nest them inside \"arguments\" or \"parameters\"."
    }
}

/**
 * v2.24.1 — light-task detection: a short, single-obvious-action prompt must
 * NOT pay for a planning pass or a self-review round. The user's complaint:
 * "write an md report of our chat" ran a full 8-step plan. Now it runs
 * write_file + finish, done.
 */
object TaskHeuristics {

    private val MULTI_STEP_MARKERS = listOf(
        "build", "create an app", "make an app", "project", "research", "analyze",
        "compare", "automate", "pipeline", "schedule", "migrate", "refactor",
        "scrape", "monitor", "design", "implement", "architect", "step by step",
        "گزارش کامل", "بساز", "پروژه", "automtion", "workflow"
    )

    /** true when the prompt is short and obviously single-action. */
    fun isSimpleTask(prompt: String): Boolean {
        val p = prompt.trim()
        if (p.length > 260) return false
        val lower = p.lowercase()
        val markers = MULTI_STEP_MARKERS.count { lower.contains(it) }
        if (markers >= 2) return false
        // a big ask inside a short sentence still needs a plan — even with 0 markers,
        // app/apk/automation asks are projects (word boundaries: "happy" ≠ "app")
        val heavyWord = Regex("\\b(app|apps|apk|apks|automation|automate|automating)\\b")
        if (markers <= 1 && heavyWord.containsMatchIn(lower)) return false
        return true
    }
}
