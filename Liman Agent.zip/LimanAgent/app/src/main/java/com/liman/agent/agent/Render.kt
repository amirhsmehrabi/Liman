package com.liman.agent.agent

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.liman.agent.llm.LPart
import com.liman.agent.util.now
import com.liman.agent.util.uniqueFile
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.coroutines.resume

/**
 * render_html: Liman's self-verification eyes.
 *
 * Renders a workspace HTML file (or inline HTML) in an offscreen WebView —
 * with all sibling files served automatically so multi-file apps with
 * relative CSS/JS/assets work — then:
 *   • captures a screenshot attached to the conversation as VISION input,
 *   • collects JavaScript console output / errors,
 *   • optionally evaluates a JS probe expression and returns its value.
 *
 * This powers the mandatory BUILD → VERIFY → REVIEW → FIX loop: the agent
 * can literally look at what it built and iterate until it truly works.
 */
object HtmlRenderer {

    private const val HOST = "https://liman.local/"
    private const val DESKTOP_UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    /** Resolves [child] under [base], refusing any path-traversal escape. */
    internal fun resolveWithin(base: File, child: String): File? {
        val cleaned = child.replace('\\', '/').removePrefix("/")
        if (cleaned.isBlank() || cleaned.split('/').any { it == ".." }) return null
        val baseCanon = runCatching { base.canonicalFile }.getOrNull() ?: return null
        val f = runCatching { File(baseCanon, cleaned).canonicalFile }.getOrNull() ?: return null
        return if (f == baseCanon || f.path.startsWith(baseCanon.path + File.separator)) f else null
    }

    internal fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "js", "mjs" -> "text/javascript"
        "css" -> "text/css"
        "json" -> "application/json"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "bmp" -> "image/bmp"
        "ico" -> "image/x-icon"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        "ttf" -> "font/ttf"
        "otf" -> "font/otf"
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "ogg" -> "audio/ogg"
        "mp4" -> "video/mp4"
        "webm" -> "video/webm"
        "txt" -> "text/plain"
        "csv" -> "text/csv"
        "xml" -> "application/xml"
        else -> "application/octet-stream"
    }

    /**
     * v2.30.0 — LIVE DOM AUDIT (blueprint §9, machine-detectable defects):
     * tap targets <44px, horizontal overflow, missing alt, h1 count, and
     * computed contrast ratios. Returns a compact LIMAN_AUDIT|k=v|… line.
     */
    private const val AUDIT_JS = """
        (function(){
          function lum(c){var m=c.match(/\d+(\.\d+)?/g);if(!m||m.length<3)return null;
            function f(v){v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4)}
            return 0.2126*f(+m[0])+0.7152*f(+m[1])+0.0722*f(+m[2]);}
          function bgOf(el){var e=el;while(e){var c=getComputedStyle(e).backgroundColor;
            if(c&&c!=='rgba(0, 0, 0, 0)'&&c!=='transparent')return c;e=e.parentElement}return 'rgb(255, 255, 255)'}
          var tapFail=0,tapEx=[],lowC=[],clickN=0;
          document.querySelectorAll('a,button,[role=button],[onclick],input,select,textarea').forEach(function(el){
            var r=el.getBoundingClientRect();if(r.width===0&&r.height===0)return;clickN++;
            if(r.width<44||r.height<44){tapFail++;if(tapEx.length<4)tapEx.push(el.tagName+' "'+((el.textContent||el.getAttribute('aria-label')||'').trim().slice(0,16))+'" '+Math.round(r.width)+'x'+Math.round(r.height));}});
          var els=document.querySelectorAll('p,li,label,td,th,h1,h2,h3,h4,h5,button,a,span'),n=0;
          for(var i=0;i<els.length&&n<150;i++){var el=els[i],t=(el.textContent||'').trim();if(!t)continue;n++;
            var cs=getComputedStyle(el),fg=lum(cs.color),bg=lum(bgOf(el));if(fg==null||bg==null)continue;
            var ratio=(Math.max(fg,bg)+0.05)/(Math.min(fg,bg)+0.05);
            var big=parseFloat(cs.fontSize)>=24||(parseFloat(cs.fontSize)>=18.66&&parseInt(cs.fontWeight,10)>=700);
            if(ratio<(big?3:4.5)&&lowC.length<4)lowC.push('"'+t.slice(0,18)+'" '+ratio.toFixed(2)+':1');}
          var imgNoAlt=0;document.querySelectorAll('img').forEach(function(i){if(!i.hasAttribute('alt'))imgNoAlt++;});
          return 'LIMAN_AUDIT|clickable='+clickN+'|tapTargetFail='+tapFail+(tapEx.length?'|tap: '+tapEx.join(', '):'')
            +'|hOverflow='+(document.scrollingElement.scrollWidth>innerWidth+1)
            +'|h1Count='+document.querySelectorAll('h1').length+'|imgNoAlt='+imgNoAlt
            +(lowC.length?'|lowContrast: '+lowC.join(', '):'');
        })()
    """

    suspend fun render(
        entryPath: String?,
        inlineHtml: String?,
        widthPx: Int,
        heightPx: Int,
        fullPage: Boolean,
        waitMs: Long,
        probeJs: String?,
        appContext: Context,
        workspace: File
    ): ToolOutcome = withContext(Dispatchers.Main) {
        val width = widthPx.coerceIn(320, 1600)
        val height = heightPx.coerceIn(320, 4000)

        val entryFile: File?
        val baseDir: File
        var inline: String? = null
        when {
            !entryPath.isNullOrBlank() -> {
                entryFile = resolveWithin(workspace, entryPath)
                    ?: return@withContext ToolOutcome("Invalid or missing workspace path: $entryPath", false)
                if (!entryFile.isFile)
                    return@withContext ToolOutcome("Not a file in workspace: $entryPath", false)
                baseDir = entryFile.parentFile ?: workspace
            }
            !inlineHtml.isNullOrBlank() -> {
                entryFile = null
                baseDir = workspace
                inline = inlineHtml
            }
            else -> return@withContext ToolOutcome("Provide 'path' (workspace HTML file) or 'html' (inline HTML).", false)
        }

        val console = ArrayList<String>()
        val loaded = CompletableDeferred<Boolean>()
        val webView = WebView(appContext)
        try {
            webView.settings.javaScriptEnabled = true
            webView.settings.domStorageEnabled = true
            webView.settings.loadWithOverviewMode = true
            webView.settings.useWideViewPort = true
            webView.settings.userAgentString = DESKTOP_UA

            webView.webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(msg: ConsoleMessage?): Boolean {
                    msg ?: return false
                    val level = when (msg.messageLevel()) {
                        ConsoleMessage.MessageLevel.ERROR -> "error"
                        ConsoleMessage.MessageLevel.WARNING -> "warn"
                        else -> "log"
                    }
                    if (console.size < 40) {
                        console.add("[$level] ${msg.sourceId()?.substringAfterLast('/') ?: "?"}:${msg.lineNumber()} ${msg.message()}")
                    }
                    return true
                }
            }

            webView.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: WebResourceRequest?
                ): WebResourceResponse? {
                    val path = request?.url?.path?.removePrefix("/") ?: return null
                    // inline mode serves the raw HTML at the root
                    if (inline != null && (path.isEmpty() || path == "index.html")) {
                        return WebResourceResponse("text/html", "utf-8", inline.byteInputStream())
                    }
                    val f = resolveWithin(baseDir, path) ?: return notFound()
                    if (!f.isFile) return notFound()
                    val mime = mimeFor(f.name)
                    return runCatching {
                        WebResourceResponse(
                            mime,
                            if (mime.startsWith("text/") || mime.contains("json") || mime.contains("xml") || mime.contains("javascript")) "utf-8" else null,
                            f.inputStream()
                        )
                    }.getOrNull() ?: notFound()
                }

                override fun onPageFinished(view: WebView?, u: String?) {
                    loaded.complete(true)
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: android.webkit.WebResourceError?
                ) {
                    if (request?.isForMainFrame == true && console.size < 40) {
                        console.add("[error] main frame failed: ${request.url?.path ?: ""}")
                    }
                }
            }

            webView.layoutParams = android.view.ViewGroup.LayoutParams(width, height)
            val target =
                if (entryFile != null) HOST + entryFile.name
                else HOST + "index.html"
            webView.loadUrl(target)

            val ok = withTimeoutOrNull(25_000) { loaded.await() }
            if (ok != true) return@withContext ToolOutcome(
                "Page did not finish loading within 25s — likely a broken reference or a script that never settles.",
                false
            )
            delay(waitMs.coerceIn(200, 10_000))

            // measure + layout
            val h = if (fullPage) {
                val measured = withTimeoutOrNull(3_000) {
                    suspendCancellableCoroutine<Int> { cont ->
                        webView.evaluateJavascript(
                            "(function(){return Math.max(document.body.scrollHeight," +
                                "document.documentElement.scrollHeight, document.body.offsetHeight)||0})()"
                        ) { v -> if (cont.isActive) cont.resume(v?.toFloatOrNull()?.toInt() ?: 0) }
                    }
                } ?: 0
                if (measured > 0) measured.coerceIn(height, 8000) else height
            } else height

            webView.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(width, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(h, android.view.View.MeasureSpec.EXACTLY)
            )
            webView.layout(0, 0, width, h)
            delay(300)

            // optional JS probe BEFORE the screenshot (so probe-triggered state shows in it)
            val probeResult = if (!probeJs.isNullOrBlank()) {
                withTimeoutOrNull(4_000) {
                    suspendCancellableCoroutine<String> { cont ->
                        webView.evaluateJavascript(probeJs) { v ->
                            if (cont.isActive) cont.resume(v ?: "null")
                        }
                    }
                } ?: "probe timed out"
            } else null

            var bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            webView.draw(Canvas(bmp))

            // v2.30.0: live DOM audit (tap targets / overflow / contrast) — runs on
            // the settled page, after the screenshot draw, via the same JS channel.
            val auditResult = withTimeoutOrNull(4_000) {
                suspendCancellableCoroutine<String> { cont ->
                    webView.evaluateJavascript(AUDIT_JS) { v ->
                        if (cont.isActive) cont.resume(v ?: "null")
                    }
                }
            }
            val maxDim = maxOf(bmp.width, bmp.height)
            if (maxDim > 1568) {
                val scale = 1568f / maxDim
                val scaled = Bitmap.createScaledBitmap(
                    bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true
                )
                bmp.recycle()
                bmp = scaled
            }
            val bytes = ByteArrayOutputStream().use {
                bmp.compress(Bitmap.CompressFormat.PNG, 85, it)
                it.toByteArray()
            }
            bmp.recycle()

            withContext(Dispatchers.IO) {
                val file = uniqueFile(File(workspace, "generated"), "render_${now()}.png")
                file.parentFile?.mkdirs()
                file.writeBytes(bytes)
                val rel = file.relativeToOrNull(workspace)?.toString()?.replace('\\', '/') ?: file.name
                val media = LPart.Media(
                    "image/png",
                    android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP),
                    rel
                )
                val errors = console.filter { it.startsWith("[error]") || it.startsWith("[warn]") }
                val consoleBlock = when {
                    errors.isNotEmpty() -> "⚠ ${errors.size} problem(s) in console:\n" + errors.take(12).joinToString("\n")
                    console.isNotEmpty() -> "Console is quiet: ${console.size} message(s), no errors."
                    else -> "Console: no messages."
                }
                val probeBlock = probeResult?.let { "\nProbe result: $it" } ?: ""
                // v2.30.0: audit + static lint blocks (deterministic UI quality gates)
                val htmlSource = inline ?: runCatching { entryFile?.readText() }.getOrNull() ?: ""
                val auditBlock = formatAudit(auditResult)
                val lintBlock = UiLint.report(UiLint.lint(htmlSource, singleFileBytes = entryFile?.length() ?: 0))
                ToolOutcome(
                    buildString {
                        appendLine("Rendered ${entryPath ?: "inline HTML"} at ${width}×${h}px.")
                        appendLine(consoleBlock)
                        append(probeBlock)
                        appendLine()
                        if (auditBlock.isNotEmpty()) { appendLine(auditBlock); appendLine() }
                        if (lintBlock.isNotEmpty()) { appendLine(lintBlock); appendLine() }
                        append("Screenshot saved to $rel — attached below. Inspect it like a human tester: layout, content, colors, broken images, error text. If anything is wrong, fix the code and render again.")
                    }.trim(),
                    true,
                    listOf(media)
                )
            }
        } finally {
            runCatching { webView.stopLoading() }
            runCatching { webView.destroy() }
        }
    }

    private fun notFound(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), "".byteInputStream())

    /**
     * Renders the AUDIT_JS result (a JSON-quoted "LIMAN_AUDIT|k=v|…" string)
     * into a readable verdict block. Pure fun — unit-testable.
     */
    internal fun formatAudit(rawJsResult: String?): String {
        if (rawJsResult == null) return "" // audit didn't run/timed out — stay quiet
        val s = rawJsResult.trim().removeSurrounding("\"")
            .replace("\\\"", "\"").replace("\\n", " ").replace("\\\\", "\\")
        if (!s.contains("LIMAN_AUDIT")) return ""
        val parts = s.split("|").drop(1).map { it.trim() }.filter { it.isNotEmpty() }
        val map = HashMap<String, String>()
        val notes = ArrayList<String>()
        parts.forEach {
            val idx = it.indexOf('=')
            if (idx > 0) map[it.substring(0, idx)] = it.substring(idx + 1) else notes.add(it)
        }
        val tapNote = notes.firstOrNull { it.startsWith("tap:") }
        val contrastNote = notes.firstOrNull { it.startsWith("lowContrast") }
        val problems = ArrayList<String>()
        (map["tapTargetFail"]?.toIntOrNull() ?: 0).let {
            if (it > 0) problems.add("$it tap target(s) under 44px${tapNote?.let { n -> " ($n)" } ?: ""}")
        }
        if (map["hOverflow"] == "true") problems.add("horizontal overflow — something is wider than the viewport")
        (map["imgNoAlt"]?.toIntOrNull() ?: 0).let { if (it > 0) problems.add("$it <img> without alt") }
        (map["h1Count"]?.toIntOrNull() ?: 1).let { if (it != 1) problems.add("h1 count = $it (exactly one per page)") }
        contrastNote?.let { problems.add("low contrast text: ${it.removePrefix("lowContrast:").trim()}") }
        return if (problems.isEmpty())
            "LIVE DOM AUDIT: ✅ clean — ${map["clickable"] ?: "?"} interactive elements, tap targets ≥44px, no overflow, contrast OK."
        else buildString {
            append("LIVE DOM AUDIT: ⚠ ${problems.size} problem(s):")
            problems.take(6).forEach { append("\n- $it") }
            append("\nFix these — they are objective quality gates (44px targets, WCAG ≥4.5:1 body / ≥3:1 large, no h-scroll).")
        }
    }
}
