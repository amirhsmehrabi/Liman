package com.liman.agent.agent

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import com.liman.agent.llm.RouterServer
import com.liman.agent.util.genId
import kotlinx.coroutines.delay
import java.util.concurrent.ConcurrentHashMap

/**
 * v2.17.0 — THE TERMUX BRIDGE.
 *
 * "Can Liman run npm code or connect to Termux?" — now it can REALLY
 * connect: Liman sends an actual command into the user's Termux (the
 * com.termux.RUN_COMMAND intent, the same mechanism Tasker uses) and gets
 * the full stdout/stderr back. That unlocks REAL node, npm install,
 * python, git, ssh, ffmpeg — the user's whole Termux toolbox — driven by
 * the agent, all on-device.
 *
 * Transport (no shared filesystem between apps on Android):
 *   1. Liman registers the script in memory and serves it from its own
 *      local router: GET /termux/script/{id}
 *   2. Liman sends RUN_COMMAND to Termux, which runs:
 *      curl -s SCRIPT_URL | bash 2>&1 |
 *        curl -s -X POST --data-binary @- RESULT_URL
 *   3. Termux POSTs the output back: POST /termux/result/{id}
 *   4. The tool awaits the result and returns it to the agent.
 *
 * One-time setup on the Termux side:
 *   pkg install curl
 *   echo "allow-external-apps = true" >> ~/.termux/termux.properties
 *   termux-reload-settings
 * And grant Liman the RUN_COMMAND permission (Settings → Termux bridge).
 */
object TermuxBridge {

    const val TERMUX_PACKAGE = "com.termux"
    const val RUN_COMMAND_PERMISSION = "com.termux.permission.RUN_COMMAND"
    private const val RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
    const val TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash"
    const val TERMUX_HOME = "/data/data/com.termux/files/home"

    class Pending(val id: String, val script: String, val createdAt: Long = System.currentTimeMillis())

    private val scripts = ConcurrentHashMap<String, Pending>()
    private val results = ConcurrentHashMap<String, String>()

    // ---------------- setup status ----------------

    fun termuxInstalled(context: Context): Boolean = runCatching {
        context.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
        true
    }.getOrDefault(false)

    fun permissionGranted(context: Context): Boolean =
        Build.VERSION.SDK_INT < 23 ||
            context.checkSelfPermission(RUN_COMMAND_PERMISSION) == PackageManager.PERMISSION_GRANTED

    /** Human-readable setup steps for whatever is missing. */
    fun setupInstructions(context: Context): String = buildString {
        appendLine("TERMUX BRIDGE SETUP:")
        if (!termuxInstalled(context)) {
            appendLine("1. Install Termux (F-Droid release recommended) on this phone.")
        }
        appendLine("2. In Termux run: pkg install curl")
        appendLine("3. In Termux run: mkdir -p ~/.termux && echo \"allow-external-apps = true\" >> ~/.termux/termux.properties && termux-reload-settings")
        if (!permissionGranted(context)) {
            appendLine("4. Grant the RUN_COMMAND permission: Liman Settings → Termux bridge → Grant permission (shown only if Termux is installed).")
        }
        appendLine("Then call termux_run again — the command will execute in your real Termux with node/npm/python/git/ssh available.")
    }

    // ---------------- transport (unit tested) ----------------

    fun putScript(id: String, script: String) {
        // cap the pending maps so a broken run can't leak memory
        if (scripts.size > 32) scripts.entries.removeIf { System.currentTimeMillis() - it.value.createdAt > 600_000 }
        scripts[id] = Pending(id, script)
    }

    fun takeScript(id: String): String? = scripts.remove(id)?.script

    fun putResult(id: String, output: String) {
        results[id] = output
    }

    fun peekResult(id: String): String? = results.remove(id)

    /** Poll until Termux POSTs the result (or timeout). */
    suspend fun awaitResult(id: String, timeoutMs: Long): String? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            peekResult(id)?.let { return it }
            delay(250)
        }
        return null
    }

    /**
     * The command Termux executes — PURE BASH, zero external dependencies
     * (curl is NOT in the Termux bootstrap; depending on it was the v1 bug:
     * the command died silently and Liman waited forever). Bash's built-in
     * /dev/tcp does the HTTP: fetch the script, run it, POST output back.
     */
    fun wrapperCommand(port: Int, id: String): String = """
        set -- $port $id
        exec 3<>/dev/tcp/127.0.0.1/${'$'}1 || exit 1
        printf 'GET /termux/script/%s HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n' "${'$'}2" >&3
        while IFS= read -r __h <&3; do [ "${'$'}__h" = $'\r' ] && break; done
        __script=${'$'}(cat <&3); exec 3<&-
        __out=${'$'}(printf '%s' "${'$'}__script" | bash 2>&1)
        exec 4<>/dev/tcp/127.0.0.1/${'$'}1 || exit 1
        __len=${'$'}(printf '%s' "${'$'}__out" | wc -c)
        printf 'POST /termux/result/%s HTTP/1.0\r\nHost: 127.0.0.1\r\nContent-Type: text/plain\r\nContent-Length: %s\r\nConnection: close\r\n\r\n' "${'$'}2" "${'$'}__len" >&4
        printf '%s' "${'$'}__out" >&4
        exec 4<&-
    """.trim().trimIndent().replace("\n", "\n")

    // ---------------- execution ----------------

    /**
     * Fire the RUN_COMMAND intent at Termux. Returns null on success or a
     * readable error explaining exactly what is missing.
     */
    fun send(context: Context, port: Int, id: String): String? {
        if (!termuxInstalled(context)) return "Termux is not installed on this phone.\n" + setupInstructions(context)
        if (!permissionGranted(context)) return "Liman lacks the RUN_COMMAND permission.\n" + setupInstructions(context)
        return runCatching {
            val intent = Intent("com.termux.RUN_COMMAND").apply {
                setClassName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
                putExtra("com.termux.RUN_COMMAND_PATH", TERMUX_BASH)
                putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", wrapperCommand(port, id)))
                putExtra("com.termux.RUN_COMMAND_WORKDIR", TERMUX_HOME)
                // run without opening a terminal session (automation mode)
                putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            }
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
            null
        }.getOrElse { "Could not send the command to Termux (${it.message}). Is allow-external-apps = true set in ~/.termux/termux.properties?\n" + setupInstructions(context) }
    }

    /**
     * Full round-trip used by the tool: ping first (fast, crisp diagnosis),
     * then register script, dispatch, await. Returns stdout+stderr or a
     * readable failure with a paste-ready self-test.
     */
    suspend fun run(context: Context, port: Int, script: String, timeoutMs: Long): String {
        // 0) connectivity probe — distinguishes "bridge broken" from
        //    "command produced no output" in seconds
        if (send(context, port, "ping") == null) {
            val pong = awaitResult("ping", 5_000)
            if (pong == null) return diagnostics(port)
        }
        // v2.36 — NON-INTERACTIVE HARDENING: commands must never hang waiting
        // for a human keypress (pkg -y, no pagers, no dialogs, stdin closed).
        val hardened = "export CI=1 DEBIAN_FRONTEND=noninteractive PAGER=cat GIT_PAGER=cat TERM=dumb\n" + script
        val id = genId("tx")
        putScript(id, hardened)
        send(context, port, id)?.let { return it }
        val out = awaitResult(id, timeoutMs)
        // v2.36 — ANSI color codes are noise for the model; strip them.
        return out?.let { TermuxScripts.stripAnsi(it) } ?: diagnostics(port)
    }

    private fun diagnostics(port: Int): String = buildString {
        appendLine("No response from Termux. The bridge talks to Termux via the RUN_COMMAND intent and pure-bash /dev/tcp — nothing to install in Termux except the config below. Most likely causes, in order:")
        appendLine("1. 'allow-external-apps = true' missing in ~/.termux/termux.properties (Termux silently ignores external commands without it — no error comes back). Open Termux ONCE and run:")
        appendLine("   mkdir -p ~/.termux && echo \"allow-external-apps = true\" >> ~/.termux/termux.properties && termux-reload-settings")
        appendLine("2. Android 12+ freezes Termux in the background: Settings → Apps → Termux → Battery → Unrestricted, then open Termux once.")
        appendLine("2b. Android 12+ 'phantom process killer' kills Termux child processes mid-run (long installs/builds die with no error). Disable it once from a PC: adb shell device_config put activity_manager max_phantom_processes 2147483647 — or keep commands shorter than ~2 min.")
        appendLine("3. Liman's RUN_COMMAND permission: Liman Settings → Termux bridge → Grant permission.")
        appendLine("SELF-TEST you can paste directly into Termux (no permissions involved):")
        appendLine("   bash -c '" + selfTest(port) + "'")
        appendLine("If the self-test prints PONG, the transport works and the issue is permissions/config; if it hangs, the router is not reachable on 127.0.0.1:$port (Settings → Local router → ON).")
    }

    /** The same pure-bash transport, inlined for a user-pasteable self-test. */
    fun selfTest(port: Int): String = wrapperCommand(port, "ping")
}
