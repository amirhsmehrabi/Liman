package com.liman.agent.llm

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebView
import com.liman.agent.data.ProviderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * Web-to-API bridge: drives ANY website chatbot (ChatGPT web, Gemini web,
 * Poe, DeepSeek, an internal company bot…) as if it were a normal LLM
 * provider — no API key needed.
 *
 * How it works: a real Android WebView keeps a logged-in browser session
 * (cookies + localStorage persist between runs). To send a message, Liman
 * injects the prompt into the site's own input box, clicks its send button,
 * and watches the DOM until a fresh answer appears and stops growing.
 *
 * v2.13.1 — answer detection rewritten after "no new answer appeared on
 * chat.deepseek.com within 45 s": selector-only detection missed DeepSeek's
 * `ds-markdown` answer blocks entirely. Detection is now three-layered:
 *   1. per-site selector count (ChatGPT/Gemini/Claude/Poe/DeepSeek/… + custom)
 *   2. whole-document text growth beyond the typed prompt (works everywhere)
 *   3. "input was cleared + ≥5 post-send DOM mutations" (catches short
 *      answers that add almost no text, like the connection test's "OK")
 * plus send verification (readback), a rescue re-send, and a diagnostics
 * string in every timeout so failures are debuggable from the chat alone.
 *
 * Why it's hard to block: this IS a real browser with the device's real
 * fingerprint and user-agent, running the site's own JavaScript like a
 * human user would. One request at a time, natural delays.
 *
 * Limitations (honest): no function calling / tools, no image input
 * (raises VisionUnsupportedException so the agent can continue text-only),
 * speed depends on the site, and exotic editors may need custom selectors
 * (overridable per provider in Settings).
 */
object WebChatHost {
    @Volatile
    var appContext: Context? = null
}

/** Decodes the JSON-ish string Android's evaluateJavascript returns. */
internal fun decodeJs(v: String?): String? {
    if (v == null || v == "null") return null
    var s = v.trim()
    if (s.startsWith("\"") && s.endsWith("\"") && s.length >= 2) {
        s = s.substring(1, s.length - 1)
            .replace("\\r", "")
            .replace("\\n", "\n")
            .replace("\\t", "\t")
            .replace("\\\"", "\"")
            .replace("\\'", "'")
            .replace("\\\\", "\\")
    }
    return s
}

class WebChatProvider(private val cfg: ProviderConfig) : ProviderRunner {

    companion object {
        /** One live WebView session per provider id — login + cookies survive. */
        private val sessions = ConcurrentHashMap<String, WebSession>()

        internal fun sessionFor(cfg: ProviderConfig): WebSession =
            sessions.getOrPut(cfg.id) { WebSession(cfg) }

        // ---------------- JS heuristics (pure strings, unit-testable) ----------------

        private fun selLit(customSel: String?): String =
            customSel?.takeIf { it.isNotBlank() }?.let { "'${it.replace("'", "\\'")}'" } ?: "null"

        private fun jsStr(s: String): String =
            s.replace("\\", "\\\\").replace("'", "\\'")
                .replace("\n", "\\n").replace("\r", "")

        internal fun typeJs(customSel: String?, text: String): String {
            return """
(function(){
  function findInput(custom){
    if(custom){ try { var e0=document.querySelector(custom); if(e0) return e0; } catch(x){} }
    var cands=[].slice.call(document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]'));
    var vis=cands.filter(function(e){
      var r=e.getBoundingClientRect();
      var st=getComputedStyle(e);
      return r.width>80&&r.height>16&&st.visibility!=='hidden'&&st.display!=='none';
    });
    vis.sort(function(a,b){
      var ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();
      return rb.width*rb.height-ra.width*rb.height;
    });
    return vis[0]||cands[0]||null;
  }
  var el=findInput(${selLit(customSel)});
  if(!el) return 'NO_INPUT';
  el.focus();
  var text='${jsStr(text)}';
  if(el.tagName==='TEXTAREA'||el.tagName==='INPUT'){
    // 1) execCommand('insertText') fires a REAL (trusted) input event — React
    //    composers like DeepSeek's #chat-input only enable Send on those
    try{ el.select(); }catch(x){}
    var okc=false;
    try{ okc=document.execCommand('insertText',false,text); }catch(x){}
    if(!okc||String(el.value)!==text){
      // 2) fallback: native value setter + synthetic input/change events
      var proto=el.tagName==='TEXTAREA'?window.HTMLTextAreaElement.prototype:window.HTMLInputElement.prototype;
      var d=Object.getOwnPropertyDescriptor(proto,'value');
      if(d&&d.set){ d.set.call(el,text); } else { el.value=text; }
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
    }
  }else{
    el.focus();
    document.execCommand('selectAll',false,null);
    document.execCommand('insertText',false,text);
  }
  return 'TYPED';
})()
""".trim()
        }

        internal fun sendJs(customSel: String?): String {
            return """
(function(){
  function visible(b){ var r=b.getBoundingClientRect(); return r.width>0&&r.height>0; }
  function ok(b){ return visible(b)&&b.getAttribute('aria-disabled')!=='true'&&!b.disabled; }
  function findInput(custom){
    if(custom){ try { var e0=document.querySelector(custom); if(e0) return e0; } catch(x){} }
    var cands=[].slice.call(document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]'));
    var vis=cands.filter(function(e){
      var r=e.getBoundingClientRect();
      var st=getComputedStyle(e);
      return r.width>80&&r.height>16&&st.visibility!=='hidden'&&st.display!=='none';
    });
    vis.sort(function(a,b){
      var ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();
      return rb.width*rb.height-ra.width*rb.height;
    });
    return vis[0]||cands[0]||null;
  }
  function findSend(custom){
    if(custom){ try{ var b0=document.querySelector(custom); if(b0) return b0; }catch(x){} }
    var sels=[
      'button[data-testid*="send"]','[data-testid*="send"]',
      'button[aria-label*="send" i]','[role="button"][aria-label*="send" i]',
      'button[class*="send"]','[role="button"][class*="send"]',
      'button[type="submit"]','form button'
    ];
    for(var i=0;i<sels.length;i++){
      try{
        var list=[].slice.call(document.querySelectorAll(sels[i])).filter(ok);
        if(list.length) return list[list.length-1];
      }catch(x){}
    }
    // DeepSeek-style composer: the send control is a div[role="button"] (NOT a
    // <button>!) at the right end of the input's row. Scan role="button"
    // elements near the input and click the RIGHTMOST enabled one.
    var input=findInput(null);
    if(input){
      var ir=input.getBoundingClientRect();
      var near=[].slice.call(document.querySelectorAll('[role="button"],button')).filter(function(b){
        if(b===input) return false;
        var r=b.getBoundingClientRect();
        if(r.width===0||r.height===0) return false;
        var sameRow=Math.abs((r.top+r.height/2)-(ir.top+ir.height/2))<130;
        var rightSide=r.left>=ir.right-200;
        return sameRow&&rightSide;
      });
      if(near.length){
        var en=near.filter(function(b){ return b.getAttribute('aria-disabled')!=='true'&&!b.disabled; });
        var pool=en.length?en:near;
        pool.sort(function(a,b){ return b.getBoundingClientRect().right-a.getBoundingClientRect().right; });
        return pool[0];
      }
    }
    var all=[].slice.call(document.querySelectorAll('button')).filter(function(b){
      var r=b.getBoundingClientRect();
      return visible(b)&&!b.disabled&&r.top>innerHeight*0.5;
    });
    return all.length?all[all.length-1]:null;
  }
  var b=findSend(${selLit(customSel)});
  if(b){ b.click(); return 'SENT'; }
  return 'NO_SEND';
})()
""".trim()
        }

        internal fun enterJs(customSel: String?): String {
            return """
(function(){
  function findInput(custom){
    if(custom){ try{ var e0=document.querySelector(custom); if(e0) return e0; }catch(x){} }
    var cands=[].slice.call(document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]'));
    var vis=cands.filter(function(e){
      var r=e.getBoundingClientRect();
      var st=getComputedStyle(e);
      return r.width>80&&r.height>16&&st.visibility!=='hidden'&&st.display!=='none';
    });
    vis.sort(function(a,b){
      var ra=a.getBoundingClientRect(),rb=b.getBoundingClientRect();
      return rb.width*rb.height-ra.width*rb.height;
    });
    return vis[0]||cands[0]||null;
  }
  var el=findInput(${selLit(customSel)});
  if(!el) return 'NO_INPUT';
  el.focus();
  ['keydown','keypress','keyup'].forEach(function(t){
    el.dispatchEvent(new KeyboardEvent(t,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
  });
  var f=el.closest('form');
  if(f){ try{ f.requestSubmit?f.requestSubmit():f.submit(); }catch(x){} }
  return 'ENTER';
})()
""".trim()
        }

        /**
         * Installs a MutationObserver that counts DOM mutations. Called twice:
         * once before typing (baseline) and once right before clicking send,
         * so mutations caused by typing itself don't count as answer activity.
         */
        internal fun armJs(): String {
            return """
(function(){
  try{ if(window.__limanObs) window.__limanObs.disconnect(); }catch(x){}
  window.__limanCap={changes:0,lastChangeAt:0};
  try{
    window.__limanObs=new MutationObserver(function(muts){
      window.__limanCap.changes+=muts.length;
      window.__limanCap.lastChangeAt=Date.now();
    });
    window.__limanObs.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
  }catch(x){}
  return 'ARMED';
})()
""".trim()
        }

        /**
         * One poll: 'selCount|bodyLen|changes|inputState|lastChangeAgeMs|href'
         *  - selCount: how many answer-ish blocks the selector chain finds
         *  - bodyLen: document.body.innerText length (textarea values excluded)
         *  - changes: DOM mutations since the last armJs()
         *  - inputState: chars in the chat input, or -1 none, -2 login page
         */
        internal fun pollJs(customSel: String?): String {
            return """
(function(){
  var sels=[${customSel?.takeIf { it.isNotBlank() }?.let { "'${it.replace("'", "\\'")}'," } ?: ""}'[data-message-author-role="assistant"]','[class*="ds-markdown"]','[class*="model-response"] [class*="markdown"]','[data-testid="assistant-message"]','[class*="response-container"]','[class*="message-content"]','[class*="msg-content"]','.markdown','[class*="prose"]'];
  var best=0;
  for(var i=0;i<sels.length;i++){
    try{ var n=document.querySelectorAll(sels[i]).length; if(n>best) best=n; }catch(x){}
  }
  var bodyLen=0;
  try{ bodyLen=(document.body.innerText||'').length; }catch(x){}
  var cap=window.__limanCap||{changes:0,lastChangeAt:0};
  // inputState: same finder logic as typeJs (largest visible first) so every
  // step agrees on WHICH element is the chat input; -1 none, -2 login page
  var inputState=-1;
  try{
    var cands=[].slice.call(document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]'));
    if(!cands.length){
      inputState=document.querySelector('input[type="password"]')?-2:-1;
    }else{
      var vis=cands.filter(function(e){
        var r=e.getBoundingClientRect();
        var st=getComputedStyle(e);
        return r.width>80&&r.height>16&&st.visibility!=='hidden'&&st.display!=='none';
      });
      var el=vis[0]||cands[0];
      inputState=el.value!==undefined?String(el.value).length:(el.textContent||'').length;
    }
  }catch(x){}
  var age=cap.lastChangeAt>0?(Date.now()-cap.lastChangeAt):-1;
  return best+'|'+bodyLen+'|'+(cap.changes||0)+'|'+inputState+'|'+age+'|'+location.href.slice(-70);
})()
""".trim()
        }

        /**
         * Extracts the newest answer. Selector chain first (walking from the
         * END, skipping anything that still contains our prompt — that's the
         * user echo), then a generic fallback: the last visible leaf-ish text
         * block on the page that doesn't contain the prompt or the input box.
         */
        internal fun extractJs(customSel: String?, promptPrefix: String): String {
            val p = if (promptPrefix.length > 80) promptPrefix.substring(0, 80) else promptPrefix
            return """
(function(){
  var p='${jsStr(p)}';
  function txt(e){ return (e.innerText||'').trim(); }
  var sels=[${customSel?.takeIf { it.isNotBlank() }?.let { "'${it.replace("'", "\\'")}'," } ?: ""}'[data-message-author-role="assistant"]','[class*="ds-markdown"]','[class*="model-response"] [class*="markdown"]','[data-testid="assistant-message"]','[class*="response-container"]','[class*="message-content"]','[class*="msg-content"]','.markdown','[class*="prose"]'];
  for(var i=0;i<sels.length;i++){
    try{
      var list=[].slice.call(document.querySelectorAll(sels[i]));
      for(var j=list.length-1;j>=0;j--){
        var t=txt(list[j]);
        if(t.length>=20&&(!p||t.indexOf(p)<0)) return t;
      }
    }catch(x){}
  }
  var all=[].slice.call(document.querySelectorAll('div,article,section,li,blockquote,pre'));
  for(var k=all.length-1;k>=0;k--){
    var e=all[k];
    var r=e.getBoundingClientRect();
    if(r.width===0||r.height===0) continue;
    if(e.querySelector('textarea,[contenteditable="true"],[role="textbox"],input[type="password"]')) continue;
    var t=txt(e);
    if(t.length<40||t.length>25000) continue;
    if(p&&t.indexOf(p)>=0) continue;
    var kids=e.querySelectorAll('div,article,section,li,blockquote,pre');
    var leafish=true;
    for(var m=0;m<kids.length;m++){ if(txt(kids[m]).length>t.length*0.8){ leafish=false; break; } }
    if(!leafish) continue;
    return t;
  }
  return '';
})()
""".trim()
        }
    }

    override suspend fun complete(
        req: LlmRequest,
        onDelta: (suspend (String, String) -> Unit)?
    ): LlmResult {
        if (cfg.baseUrl.isBlank()) {
            throw InvalidPayloadException("Web chat provider '${cfg.name}' has no URL — set it in Settings → Providers.")
        }
        // web chats can't receive image files through automation; only the
        // outgoing prompt matters, so check the LAST user message only
        val lastUser = req.messages.lastOrNull { it.role == Role.USER }
        if (lastUser?.parts?.any { it is LPart.Media } == true) {
            throw VisionUnsupportedException(
                "Web chat '${cfg.name}' can't receive image files through browser automation — continuing without them."
            )
        }
        val prompt = lastUser?.parts?.filterIsInstance<LPart.Text>()?.joinToString("\n") { it.text }
            ?: throw InvalidPayloadException("Nothing to send.")

        val session = sessionFor(cfg)
        return session.lock {
            // 1. live page (loads once; later calls reuse the session)
            session.ensureLoaded()

            // 2. wait until the chat input exists (SPAs need seconds to boot);
            //    if we end up on a login page the session was lost
            var inputReady = false
            var loginPage = false
            withTimeoutOrNull(20_000L) {
                while (true) {
                    val p = decodeJs(session.eval(pollJs(cfg.webResponseSel)))?.split('|')
                    when (p?.getOrNull(3)) {
                        null -> {}
                        "-2" -> {
                            loginPage = true; return@withTimeoutOrNull
                        }
                        "-1" -> {}
                        else -> {
                            inputReady = true; return@withTimeoutOrNull
                        }
                    }
                    delay(900L)
                }
            }
            if (loginPage) {
                throw InvalidPayloadException(
                    "The browser session for ${cfg.baseUrl} is logged out (login page shown). " +
                        "Open Settings → Providers → ${cfg.name} → login browser, log in, then test again."
                )
            }
            if (!inputReady) {
                throw InvalidPayloadException(
                    "The chat input never appeared on ${cfg.baseUrl} within 20 s — " +
                        "the page may still be loading or uses an unusual layout. Retry, or set a custom input selector."
                )
            }

            // 3. natural pause — behave like a person, not a script
            delay(900L + (0..700L).random())

            // 4. baseline snapshot BEFORE typing
            val base = decodeJs(session.eval(pollJs(cfg.webResponseSel)))?.split('|')
            val baseSelCount = base?.getOrNull(0)?.toIntOrNull() ?: 0
            val baseBodyLen = base?.getOrNull(1)?.toIntOrNull() ?: 0
            session.eval(armJs()) // count typing mutations separately

            // 5. type the prompt + verify it actually landed in the input
            val typed = decodeJs(session.eval(typeJs(cfg.webInputSel, prompt))) ?: "NO_INPUT"
            if (typed.contains("NO_INPUT")) {
                throw InvalidPayloadException(
                    "Could not find the chat input on ${cfg.baseUrl} — " +
                        "set a custom input selector in the provider settings."
                )
            }
            delay(350L)
            var readbackOk = false
            decodeJs(session.eval(pollJs(cfg.webResponseSel)))?.split('|')?.getOrNull(3)
                ?.toIntOrNull()?.let { readbackOk = it >= (prompt.length - 2).coerceAtLeast(0) }
            if (!readbackOk) {
                throw InvalidPayloadException(
                    "Typing into ${cfg.baseUrl} failed — the input did not hold the prompt " +
                        "(site uses an exotic editor). Set a custom input selector in the provider settings."
                )
            }

            // 6. send: re-arm the mutation counter, click, Enter fallback
            session.eval(armJs())
            val sent = decodeJs(session.eval(sendJs(cfg.webSendSel))) ?: "NO_SEND"
            if (sent.contains("NO_SEND")) {
                decodeJs(session.eval(enterJs(cfg.webInputSel)))
            }

            // 7. wait for a new answer — three-layer detection + rescue re-send
            val promptLen = prompt.length
            var appeared = false
            var lastState = base ?: listOf()
            var lastRescue = 0L
            val t0 = System.currentTimeMillis()
            val deadline = t0 + 60_000L
            while (System.currentTimeMillis() < deadline) {
                delay(1_000L)
                val p = decodeJs(session.eval(pollJs(cfg.webResponseSel)))?.split('|')
                    ?: continue
                lastState = p
                val selCount = p.getOrNull(0)?.toIntOrNull() ?: 0
                val bodyLen = p.getOrNull(1)?.toIntOrNull() ?: baseBodyLen
                val changes = p.getOrNull(2)?.toIntOrNull() ?: 0
                val inputNow = p.getOrNull(3)?.toIntOrNull() ?: -1
                val grew = bodyLen - baseBodyLen
                appeared = selCount > baseSelCount ||
                    grew > promptLen + 60 ||
                    (inputNow in 0..2 && changes >= 5)
                if (appeared) break

                // rescue: text still sits in the input → the send never fired
                val elapsed = System.currentTimeMillis() - t0
                if (elapsed > 5_000L && elapsed - lastRescue > 6_000L) {
                    if (inputNow >= promptLen - 2) {
                        decodeJs(session.eval(sendJs(cfg.webSendSel)))
                        delay(250L)
                        decodeJs(session.eval(enterJs(cfg.webInputSel)))
                        lastRescue = elapsed
                    } else if (elapsed > 14_000L) {
                        // input mysteriously empty but nothing rendered → retype+resend once
                        decodeJs(session.eval(typeJs(cfg.webInputSel, prompt)))
                        delay(250L)
                        decodeJs(session.eval(sendJs(cfg.webSendSel)))
                        delay(200L)
                        decodeJs(session.eval(enterJs(cfg.webInputSel)))
                        lastRescue = elapsed
                    }
                }
            }
            if (!appeared) {
                val d = buildString {
                    append("No new answer appeared on ${cfg.baseUrl} within 60 s ")
                    append("[typed=$typed · send=$sent")
                    append(" · new text bytes: ${lastState.getOrNull(1)?.toIntOrNull()?.minus(baseBodyLen) ?: "?"}")
                    append(" · DOM events: ${lastState.getOrNull(2) ?: "?"}")
                    append(" · input: ${lastState.getOrNull(3) ?: "?"} chars")
                    append(" · page: …${(lastState.getOrNull(5) ?: "").takeLast(40)}]")
                    append(". If the page shows an error or captcha, open it via the provider's login browser and complete it, then retry; otherwise set custom selectors in the provider settings.")
                }
                throw EmptyResponseException(d)
            }

            // 8. stream until the answer stops growing (stable ~2.6 s)
            var lastLen = -1
            var stableSince = 0L
            var text = ""
            val streamDeadline = System.currentTimeMillis() + 240_000L
            while (System.currentTimeMillis() < streamDeadline) {
                delay(900L)
                text = decodeJs(session.eval(extractJs(cfg.webResponseSel, prompt))) ?: ""
                if (text.length != lastLen) {
                    lastLen = text.length
                    stableSince = System.currentTimeMillis()
                    if (text.isNotBlank()) onDelta?.invoke("${cfg.name}#web", text)
                } else if (lastLen > 0 && System.currentTimeMillis() - stableSince > 2_600L) {
                    break
                }
            }
            if (text.isBlank()) throw EmptyResponseException(
                "The web chat returned an empty answer (the reply may still be rendering — retry)."
            )
            LlmResult(
                text = text.trim(),
                providerName = cfg.name,
                modelName = "web:" + cfg.baseUrl.removePrefix("https://").removePrefix("http://").substringBefore('/')
            )
        }
    }
}

/**
 * One persistent WebView per web-chat provider: cookies + login survive
 * across runs, so the site sees a returning normal user.
 */
class WebSession(private val cfg: ProviderConfig) {
    private var webView: WebView? = null
    private val mutex = Mutex()

    suspend fun <T> lock(block: suspend () -> T): T = mutex.withLock { block() }

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun ensureLoaded(): WebView = withContext(Dispatchers.Main) {
        webView?.let { return@withContext it }
        val ctx = WebChatHost.appContext
            ?: throw IllegalStateException("App context not ready — open the app once and retry.")
        val wv = WebView(ctx)
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, true)
        }
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // keep the REAL device user agent — a mismatched UA is the #1 bot signal.
            // only the "wv" (webview) token is stripped so Google logins done in the
            // login dialog (same UA) survive into this automation session.
            userAgentString = wv.settings.userAgentString.replace("; wv", "")
        }
        wv.loadUrl(cfg.baseUrl)
        webView = wv
        // give the page a first beat; the wait-for-input loop handles slow SPAs
        kotlinx.coroutines.delay(1_200L)
        wv
    }

    /** Evaluates JS on the main thread; returns the raw result string or null. */
    suspend fun eval(js: String): String? = withContext(Dispatchers.Main) {
        val wv = webView ?: return@withContext null
        suspendCancellableCoroutine { cont ->
            wv.evaluateJavascript(js) { value -> cont.resume(value) }
        }
    }
}
