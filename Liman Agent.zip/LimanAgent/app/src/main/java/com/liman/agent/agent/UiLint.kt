package com.liman.agent.agent

/**
 * v2.30.0 — DETERMINISTIC UI LINTING (APP FACTORY blueprint §9).
 *
 * "Most real defects are machine-detectable for free." This is the STATIC
 * half (over the HTML/CSS source text); the DYNAMIC half (tap targets,
 * computed contrast, overflow) runs as an audit script inside render_html's
 * WebView. Errors are prompts — every finding carries a fix.
 *
 * Pure Kotlin — unit-tested.
 */
object UiLint {

    data class Finding(val rule: String, val severity: String, val detail: String, val fix: String)

    private val HEX = Regex("""#[0-9a-fA-F]{3,8}\b""")
    private val PX_IN_SPACING = Regex("""(padding|margin|gap|top|bottom|left|right)[^:;{}]*:\s*[^;]*?(\d+(?:\.\d+)?)px""")
    private val FONT_FAMILY = Regex("""font-family\s*:\s*([^;}]+)""")
    private val CDN_LINK = Regex("""(src|href)\s*=\s*["']https?://[^"']+\.(css|js)["']""")
    private val LOREM = Regex("""(?i)lorem\s+ipsum""")
    private val ALERT = Regex("""\b(alert|confirm)\s*\(""")
    private val IMPORTANT = Regex("""!important""")
    private val IMG_NO_ALT = Regex("""<img(?![^>]*\balt=)[^>]*>""")
    private val VIEWPORT = Regex("""<meta[^>]+name\s*=\s*["']viewport["']""")
    private val EMOJI_ICON =
        Regex("<button[^>]*>[\\s]*[🌀-🙏🚀-🛸✨-➿☀-⛿]{1,4}[\\s]*</button>")

    /** Allowed spacing values (the token scale) — anything else is a violation. */
    private val SPACE_OK = DesignTokens.SPACE_SCALE.map { it.toString() }.toSet()

    /** Token DEFINITIONS (--x: #hex) are legitimate; only raw hex USAGE is a violation. */
    private fun stripTokenDefinitions(source: String): String =
        source.replace(Regex("""--[a-zA-Z0-9-]+\s*:\s*#[0-9a-fA-F]{3,8}"""), "--token")

    /**
     * @param html the full HTML document text (inline styles included)
     * @param css extra CSS text (linked files the caller has read), optional
     * @param singleFileBytes size budget check for single-file deliverables (0 = skip)
     */
    fun lint(html: String, css: String = "", singleFileBytes: Long = 0): List<Finding> {
        val out = ArrayList<Finding>()
        val source = html + "\n" + css

        // token violations: raw hex in USAGE (definitions --x:#hex are stripped first)
        val hexHits = HEX.findAll(stripTokenDefinitions(source)).map { it.value }.toList()
        if (hexHits.isNotEmpty()) {
            out.add(Finding("raw-hex", "high",
                "${hexHits.size} raw hex color(s) found (${hexHits.distinct().take(4).joinToString(", ")})",
                "Use design token variables (var(--brand-500), var(--on-surface)…) — generate them with the design_tokens tool. Raw hex breaks dark mode and re-theming."))
        }

        // off-scale spacing
        val badPx = PX_IN_SPACING.findAll(source).mapNotNull { m ->
            val v = m.groupValues[2].removeSuffix(".0")
            v.toDoubleOrNull()?.let { if (it > 0 && v !in SPACE_OK) m.groupValues[0] else null }
        }.distinct().take(6).toList()
        if (badPx.isNotEmpty()) {
            out.add(Finding("off-scale-spacing", "high",
                "Spacing values outside the token scale: ${badPx.joinToString(" · ").take(160)}",
                "Only 0,4,8,12,16,24,32,48,64,96 px (--space-1..9) — consistent spacing reads as quality."))
        }

        // font family budget
        val fonts = FONT_FAMILY.findAll(source).map { it.groupValues[1].trim().substringBefore(',').trim().lowercase() }
            .filter { it.isNotBlank() }.distinct().toList()
        if (fonts.size > 2) {
            out.add(Finding("font-budget", "med", "${fonts.size} distinct font families (${fonts.take(4).joinToString(", ")})",
                "Max 2 families: 1 sans + 1 mono for data. Use the system font stack (--font-sans)."))
        }

        // viewport meta
        if (html.contains("<html", ignoreCase = true) && !VIEWPORT.containsMatchIn(html)) {
            out.add(Finding("viewport-meta", "high", "No <meta name=viewport> — mobile will render at 980px and scale down.",
                "Add: <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"))
        }

        // offline rule: CDN css/js
        val cdn = CDN_LINK.findAll(html).map { it.value }.toList()
        if (cdn.isNotEmpty()) {
            out.add(Finding("cdn-dependency", "high", "${cdn.size} CDN link(s) — the preview must work offline from file://",
                "Inline the CSS/JS or vendor the file locally. CDN links break offline preview and add a network dependency."))
        }

        // dark mode parity signal
        if (html.contains("<html", ignoreCase = true) && !source.contains("prefers-color-scheme")) {
            out.add(Finding("dark-mode", "med", "No prefers-color-scheme handling found.",
                "Dark mode is not a separate design — add the @media dark block (the generated tokens.css already includes it)."))
        }

        // a11y: images without alt
        val noAlt = IMG_NO_ALT.findAll(html).count()
        if (noAlt > 0) out.add(Finding("img-alt", "med", "$noAlt <img> without alt attribute",
            "Add alt=\"\" for decorative images or a real description — screen readers and lint both flag this."))

        // anti-patterns
        if (LOREM.containsMatchIn(html)) out.add(Finding("lorem-ipsum", "high", "Lorem ipsum in a deliverable.",
            "Write real content (or clearly-marked placeholder data the user asked for)."))
        if (ALERT.containsMatchIn(html)) out.add(Finding("alert-confirm", "med", "alert()/confirm() usage detected.",
            "Use in-UI sheets/toasts (kit .alert) — native dialogs block and look amateur."))
        val impCount = IMPORTANT.findAll(source).count()
        if (impCount > 2) out.add(Finding("important", "low", "$impCount !important uses.",
            "Rework specificity instead of !important — it makes iteration brittle."))
        EMOJI_ICON.findAll(html).count().let {
            if (it > 0) out.add(Finding("emoji-icon", "med", "$it emoji-as-icon button(s).",
                "Emoji icons scream AI-made UI. Use inline SVG icons (svg_icon tool) from one family, one weight."))
        }

        // size budget
        if (singleFileBytes > 300_000) {
            out.add(Finding("size-budget", "med", "Single-file deliverable is ${singleFileBytes / 1024} KB (budget 300 KB).",
                "Vector-only assets, system fonts, no bundled raster — check for base64 images."))
        }
        return out
    }

    /** Compact block for tool output. */
    fun report(findings: List<Finding>): String = when {
        findings.isEmpty() -> "UI LINT: ✅ clean — no token/a11y/anti-pattern violations."
        else -> buildString {
            appendLine("UI LINT: ⚠ ${findings.size} finding(s) — fix these before calling it done:")
            findings.take(8).forEach { f ->
                appendLine("- [${f.severity}] ${f.rule}: ${f.detail}")
                appendLine("  fix: ${f.fix}")
            }
        }.trim()
    }
}
