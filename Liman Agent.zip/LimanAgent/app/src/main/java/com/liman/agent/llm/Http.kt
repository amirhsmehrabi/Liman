package com.liman.agent.llm

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.job
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.Closeable
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object Http {

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(300, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .callTimeout(900, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /** A client with tighter timeouts, for tools (web search, downloads, …). */
    fun toolClient(readSeconds: Long = 90): OkHttpClient =
        client.newBuilder()
            .readTimeout(readSeconds, TimeUnit.SECONDS)
            .callTimeout(readSeconds + 30, TimeUnit.SECONDS)
            .build()

    fun jsonPost(url: String, json: String, headers: Map<String, String> = emptyMap()): Request =
        Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .apply { headers.forEach { (k, v) -> header(k, v) } }
            .post(json.toRequestBody("application/json".toMediaType()))
            .build()

    /** Executes a call with coroutine cancellation support. */
    suspend fun await(call: Call): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { call.cancel() }
        call.enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response)
                else response.close()
            }

            override fun onFailure(call: Call, e: IOException) {
                if (call.isCanceled()) cont.cancel(e)
                else if (cont.isActive) cont.resumeWithException(e)
            }
        })
    }

    /**
     * Runs [block] while making sure [closeable] gets closed if the coroutine
     * is cancelled (unblocks a stuck socket read, e.g. mid-stream).
     */
    suspend fun <T> withCancelClose(closeable: Closeable?, block: suspend () -> T): T {
        val job = currentCoroutineContext().job
        val handle = job.invokeOnCompletion { runCatching { closeable?.close() } }
        return try {
            block()
        } finally {
            handle.dispose()
        }
    }

    /** Reads an HTTP (SSE) body line by line on IO, cancelling cleanly. */
    suspend fun readLines(response: Response, onLine: (suspend (String) -> Unit)) {
        withContext(Dispatchers.IO) {
            val source = response.body?.source() ?: return@withContext
            while (true) {
                val line = try {
                    source.readUtf8Line() ?: break
                } catch (e: IOException) {
                    if (!currentCoroutineContext().isActive) throw kotlinx.coroutines.CancellationException("stream cancelled")
                    throw e
                }
                onLine(line)
            }
        }
    }
}

/** Live per-provider health/statistics surfaced in the UI. */
data class ProviderStat(
    val displayName: String = "",
    var calls: Int = 0,
    var failures: Int = 0,
    var lastError: String = "",
    var lastLatencyMs: Long = 0,
    var lastSuccessMs: Long = 0
)

object ProviderStats {
    private val _stats = MutableStateFlow<Map<String, ProviderStat>>(emptyMap())
    val stats: StateFlow<Map<String, ProviderStat>> = _stats

    fun reset() {
        _stats.value = emptyMap()
    }

    fun record(id: String, displayName: String, ok: Boolean, ms: Long, error: String = "") {
        val map = _stats.value.toMutableMap()
        val s = map.getOrDefault(id, ProviderStat(displayName)).copy(displayName = displayName)
        s.calls++
        if (ok) {
            s.lastLatencyMs = ms
            s.lastSuccessMs = System.currentTimeMillis()
        } else {
            s.failures++
            s.lastError = error
        }
        map[id] = s
        _stats.value = map
    }
}
