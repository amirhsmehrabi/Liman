package com.liman.agent.agent

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.liman.agent.LimanApplication
import com.liman.agent.data.Conversation
import com.liman.agent.data.Entry
import com.liman.agent.data.ScheduledTask
import com.liman.agent.llm.ToolCallData
import com.liman.agent.util.now
import com.liman.agent.util.ellipsize
import java.util.concurrent.TimeUnit

/**
 * v2.16.0 — THE CRON ENGINE (ORION P1).
 *
 * "Anything you can do on command, you can do on schedule." Scheduled
 * missions turn Liman from a reactive assistant into an always-on operator:
 *   ⏰ daily briefing        ("at 08:00: fetch weather + RSS + my missions…")
 *   👁 watchtower            ("every 2h: fetch X, diff vs workspace/watch/…,
 *                              notify only on change")
 *   🩺 self-doctor           ("weekly: test every provider, disk usage…")
 *   🕐 any recurring job     — it's just a prompt that runs on a schedule.
 *
 * A WorkManager periodic worker (every 15 min) checks the schedule store,
 * runs DUE tasks as full headless agent cycles (their own conversation,
 * same tools, approvals auto-handled), saves the transcript and posts a
 * notification with the result.
 */
object Scheduler {

    const val CHANNEL_ID = "liman_scheduled"

    /**
     * v2.21 — AUTOMATIONS sync: every enabled non-manual pipeline gets a
     * ScheduledTask (id "pipe-<id>"); deleted/disabled/manual pipelines lose
     * theirs. Existing lastRunAt is preserved so re-syncs never double-fire.
     */
    fun syncPipelines(context: Context) {
        runCatching {
            val stores = (context.applicationContext as com.liman.agent.LimanApplication).container.stores
            val pipes = stores.pipelines.state.value
            val tasks = stores.schedule.state.value
            tasks.filter { it.id.startsWith("pipe-") }.forEach { t ->
                val p = pipes.firstOrNull { "pipe-" + it.id == t.id }
                if (p == null || !p.enabled || p.triggerKind == "manual") stores.schedule.delete(t.id)
            }
            pipes.filter { it.enabled && it.triggerKind != "manual" }.forEach { p ->
                val prev = stores.schedule.state.value.firstOrNull { it.id == "pipe-" + p.id }
                stores.schedule.upsert(
                    com.liman.agent.data.ScheduledTask(
                        id = "pipe-" + p.id,
                        title = "⚙ " + p.name.take(40),
                        prompt = com.liman.agent.data.PipelineDef.runPrompt(p),
                        dailyAt = if (p.triggerKind == "daily") p.dailyAt else "08:00",
                        everyHours = if (p.everyMinutes > 0) 0 else p.everyHours,
                        everyMinutes = p.everyMinutes,
                        enabled = true,
                        lastRunAt = prev?.lastRunAt ?: 0L,
                        activeHours = p.activeHours
                    )
                )
            }
        }
    }
    private const val WORK_NAME = "liman_scheduled_missions"

    /**
     * Call at app start (and after schedule changes): keeps the worker alive.
     * v2.31 — UPDATE (not KEEP): app updates refresh the worker code while
     * keeping the cadence; KEEP alone kept stale worker classes alive across
     * upgrades — the #1 "cron stopped after update" cause.
     */
    fun ensureScheduled(context: Context) {
        val req = PeriodicWorkRequestBuilder<SchedulerWorker>(15, TimeUnit.MINUTES)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req
        )
    }

    fun notify(context: Context, title: String, text: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Scheduled missions", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) return // conversation is still saved; just no banner
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt() and 0xFFFF, n)
    }

    /** Which tasks are due right now (pure — unit tested). */
    fun dueTasks(tasks: List<ScheduledTask>, now: Long = System.currentTimeMillis()): List<ScheduledTask> =
        tasks.filter {
            it.enabled &&
                (if (it.everyMinutes > 0) ScheduleLogic.isDueMinutes(it.everyMinutes, it.lastRunAt, now)
                else ScheduleLogic.isDue(it.dailyAt, it.everyHours, it.lastRunAt, now)) &&
                ScheduleLogic.activeHoursOk(it.activeHours, now)
        }

    /** Run one scheduled task as a full headless agent cycle. Returns the summary. */
    fun runTask(context: Context, task: ScheduledTask): String {
        val app = context.applicationContext as LimanApplication
        val stores = app.container.stores
        val conv = stores.conversations.newConversation().apply {
            title = "⏰ ${task.title.take(40)}"
            // v2.31 — scheduled missions SHARE the root workspace: each run is a
            // NEW conversation, so campaign state (workspace/campaigns/…) must
            // survive across fires — per-chat folders would reset it every time.
            ownWorkspace = false
        }
        val host = HeadlessHost(conv)
        val agent = Agent(context, stores, host)
        // v2.27.0 knotwork logic: prompt variables render FRESH on every fire
        val expandedPrompt = PromptVars.expand(task.prompt, nowMs = System.currentTimeMillis())
        DiagLog.log("cron", "scheduled run fired: " + task.title.take(60))
        val outcome = runCatching {
            kotlinx.coroutines.runBlocking {
                agent.run(conv, expandedPrompt, emptyList())
            }
        }.getOrElse { "Scheduled run failed: ${it.message ?: it.toString()}" }
        kotlinx.coroutines.runBlocking { stores.conversations.save(conv) }
        return if (outcome is Agent.RunOutcome) outcome.summary.ifBlank { "(run ended: ${outcome.reason})" }
        else outcome.toString()
    }
}

/**
 * An AgentHost with no UI: entries land in the conversation (visible in the
 * chats list afterwards), approvals follow the task's auto-approve policy,
 * questions get an honest "no user available" answer so the run continues.
 */
class HeadlessHost(private val conv: Conversation) : Agent.AgentHost {

    override fun postEntry(e: Entry) {
        synchronized(conv) {
            conv.entries = conv.entries + e
            conv.updatedAt = now()
        }
    }

    override fun onStreamTick(tick: Agent.StreamTick?) {}

    override fun onStatus(phase: String, waiting: Boolean) {}

    override suspend fun requestApproval(call: ToolCallData): Boolean {
        // scheduled runs can't wait for a tap: SAFE tools run, risky ones are
        // denied with a clear reason so the agent routes around them
        postEntry(
            Entry.NoteEntry(
                "⏰ Scheduled run — '${call.name}' needs approval and none can be given now; " +
                    "it was denied. Route around it or note it in the final summary.",
                "warn"
            )
        )
        return false
    }

    override suspend fun askUser(question: String, options: List<String>): String {
        postEntry(Entry.NoteEntry("⏰ Question (no user available in scheduled run): ${question.ellipsize(200)} — making a sensible assumption.", "warn"))
        return "(scheduled run — no user available; make a sensible assumption, state it, and continue)"
    }

    override fun speak(text: String) {}
}

/** The periodic worker: finds due tasks, runs them, notifies, records. */
class SchedulerWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as LimanApplication
        val stores = app.container.stores
        return runCatching {
            val due = Scheduler.dueTasks(stores.schedule.state.value)
            due.forEach { task ->
                val summary = runCatching { Scheduler.runTask(applicationContext, task) }
                    .getOrElse { "failed: ${it.message}" }
                stores.schedule.markRan(task.id)
                Scheduler.notify(
                    applicationContext,
                    "⏰ ${task.title}",
                    summary.ellipsize(400)
                )
            }
            Result.success()
        }.getOrElse { Result.retry() }
    }
}
