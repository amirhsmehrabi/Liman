package com.liman.agent.data

import com.liman.agent.util.JSON
import com.liman.agent.util.genId
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import java.io.File

/**
 * v2.23.0 — SUPER AGENT stores: watchers, context triggers, notification
 * digest config and small secret tokens (kept OUT of the user profile so
 * they never leak into prompts).
 *
 * Same doctrine as every Liman store: one JSON file, crash-safe reads,
 * StateFlow for the UI, no database service.
 */

@Serializable
data class Watcher(
    val id: String,
    var name: String,
    var url: String,
    /** "text" (first meaningful chars) | "regex" (first match / capture group 1) */
    var extract: String = "text",
    /** regex pattern when extract == "regex" */
    var pattern: String = "",
    var everyMinutes: Int = 30,
    /** last extraction (ellipsized) — the diff baseline */
    var lastValue: String = "",
    var lastCheckedAt: Long = 0L,
    var lastChangedAt: Long = 0L,
    var enabled: Boolean = true
)

class WatcherStore(private val file: File) {
    private val _state = MutableStateFlow<List<Watcher>>(emptyList())
    val state: StateFlow<List<Watcher>> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(ListSerializer(Watcher.serializer()), file.readText())
        }.getOrDefault(emptyList())
    }

    fun upsert(w: Watcher) {
        _state.value = _state.value.filter { it.id != w.id } + w
        persist()
    }

    fun delete(id: String) {
        _state.value = _state.value.filter { it.id != id }
        persist()
    }

    fun get(id: String): Watcher? = _state.value.firstOrNull { it.id == id }

    /** Record a check; returns true when the extraction CHANGED. */
    fun touch(id: String, value: String, changed: Boolean, at: Long): Boolean {
        val cur = get(id) ?: return false
        cur.lastValue = value
        cur.lastCheckedAt = at
        if (changed) cur.lastChangedAt = at
        persist()
        return true
    }

    private fun persist() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(ListSerializer(Watcher.serializer()), _state.value))
        }
    }
}

// ============================================================
// Context triggers (v2.23 — the phone's real-world events become agent work)
// ============================================================

@Serializable
data class Trigger(
    val id: String,
    var title: String,
    /** charging_on | charging_off | battery_low | battery_ok | screen_on | screen_off | wifi_on | wifi_off | boot */
    var kind: String,
    /** the agent prompt that runs as a full headless cycle when it fires */
    var prompt: String,
    /** minimum minutes between firings (spam guard) */
    var cooldownMinutes: Int = 15,
    var lastFiredAt: Long = 0L,
    var enabled: Boolean = true
)

class TriggerStore(private val file: File) {
    private val _state = MutableStateFlow<List<Trigger>>(emptyList())
    val state: StateFlow<List<Trigger>> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(ListSerializer(Trigger.serializer()), file.readText())
        }.getOrDefault(emptyList())
    }

    fun upsert(t: Trigger) {
        _state.value = _state.value.filter { it.id != t.id } + t
        persist()
    }

    fun delete(id: String) {
        _state.value = _state.value.filter { it.id != id }
        persist()
    }

    /** Triggers of this kind that are enabled and past their cooldown. */
    fun due(kind: String, now: Long): List<Trigger> =
        _state.value.filter { t ->
            t.enabled && t.kind == kind &&
                (now - t.lastFiredAt) >= t.cooldownMinutes * 60_000L
        }

    fun markFired(id: String, at: Long) {
        _state.value.firstOrNull { it.id == id }?.lastFiredAt = at
        persist()
    }

    private fun persist() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(ListSerializer(Trigger.serializer()), _state.value))
        }
    }
}

// ============================================================
// Notification digest (v2.23 — 60 buzzes → 3 calm, ranked digests)
// ============================================================

@Serializable
data class DigestConfig(
    var enabled: Boolean = false,
    /** "HH:MM" windows when a digest may be built */
    var windows: List<String> = listOf("09:00", "14:00", "20:00"),
    /** regex patterns; a matching notification is flagged urgent (relay immediately) */
    var urgentPatterns: List<String> = emptyList(),
    var lastDigestAt: Long = 0L
)

class DigestStore(private val file: File) {
    private val _state = MutableStateFlow(DigestConfig())
    val state: StateFlow<DigestConfig> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(DigestConfig.serializer(), file.readText())
        }.getOrDefault(DigestConfig())
    }

    fun update(block: (DigestConfig) -> Unit) {
        val copy = _state.value.copy()
        block(copy)
        _state.value = copy
        persist()
    }

    private fun persist() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(DigestConfig.serializer(), _state.value))
        }
    }
}

// ============================================================
// Secret tokens (v2.23 — e.g. the GitHub PAT; never in prompts/UI)
// ============================================================

class TokenStore(private val file: File) {
    private val _state = MutableStateFlow<Map<String, String>>(emptyMap())
    val state: StateFlow<Map<String, String>> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(MapSerializer(String.serializer(), String.serializer()), file.readText())
        }.getOrDefault(emptyMap())
    }

    fun get(name: String): String? = _state.value[name]

    fun set(name: String, token: String) {
        _state.value = _state.value + (name to token)
        persist()
    }

    fun has(name: String): Boolean = !_state.value[name].isNullOrBlank()

    private fun persist() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(
                JSON.encodeToString(
                    MapSerializer(String.serializer(), String.serializer()), _state.value
                )
            )
        }
    }
}
