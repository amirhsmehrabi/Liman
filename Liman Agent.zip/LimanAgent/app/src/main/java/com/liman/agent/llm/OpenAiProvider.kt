package com.liman.agent.llm

import com.liman.agent.data.ProviderConfig
import com.liman.agent.util.JSON
import com.liman.agent.util.arr
import com.liman.agent.util.int
import com.liman.agent.util.obj
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * Works with any OpenAI-compatible endpoint:
 * OpenAI, OpenRouter, Groq, DeepSeek, Ollama, LM Studio, vLLM, …
 */
class OpenAiProvider(private val config: ProviderConfig) : ProviderRunner {

    val displayName: String get() = config.name

    private fun chatUrl(): String {
        var b = config.baseUrl.trim().trimEnd('/')
        if (b.isEmpty()) b = "https://api.openai.com/v1"
        if (b.contains("openai.com") && !b.endsWith("/v1") && !b.contains("/v1/")) b += "/v1"
        if (b.endsWith("/chat/completions")) return b
        return "$b/chat/completions"
    }

    override suspend fun complete(
        req: LlmRequest,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?
    ): LlmResult = withContext(Dispatchers.IO) {
        val url = chatUrl()
        val body = buildRequest(req)
        val builder = Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .header("Authorization", "Bearer ${config.apiKey.ifBlank { "none" }}")
        if (url.contains("openrouter", ignoreCase = true)) {
            builder.header("HTTP-Referer", "https://liman.agent")
            builder.header("X-Title", "Liman Agent")
        }
        val call: Call = Http.client.newCall(
            builder.post(body.toString().toRequestBody("application/json".toMediaType())).build()
        )

        val response = Http.await(call)
        Http.withCancelClose(response) {
            if (!response.isSuccessful) {
                throw HttpProvException(response.code, response.body?.string()?.take(1500) ?: "")
            }
            parseResponse(response, req.gen.stream, onDelta, config.name, config.model)
        }
    }

    // ---------------- request building ----------------

    private fun buildRequest(req: LlmRequest): JsonObject {
        // OpenAI's reasoning model families (o*, gpt-5*, gpt-6*) reject
        // max_tokens/temperature and require max_completion_tokens.
        val openAiHost = config.baseUrl.isBlank() || config.baseUrl.contains("openai.com", ignoreCase = true)
        val reasoningFamily = openAiHost &&
            Regex("^(o[0-9]|gpt-5|gpt-6)").containsMatchIn(config.model.trim())
        return buildJsonObject {
            put("model", config.model)
            put("stream", req.gen.stream)
            put("messages", JsonArray(toOpenAiMessages(req.messages)))
            if (req.tools.isNotEmpty()) {
                put("tools", JsonArray(req.tools.map { t ->
                    buildJsonObject {
                        put("type", "function")
                        put("function", buildJsonObject {
                            put("name", t.name)
                            put("description", t.description)
                            put("parameters", safeSchema(t.parametersJson))
                        })
                    }
                }))
                put("tool_choice", "auto")
            }
            if (reasoningFamily) {
                put("max_completion_tokens", req.gen.maxTokens)
            } else {
                put("max_tokens", req.gen.maxTokens)
            }
            // NOTE: temperature is intentionally NOT sent — reasoning model
            // families (o*, gpt-5*, gpt-6*) reject it and each API's own
            // default is compatible with every model.
        }
    }

    private fun toOpenAiMessages(messages: List<LlmMessage>): List<JsonObject> {
        val out = ArrayList<JsonObject>()
        for (m in messages) {
            when (m.role) {
                Role.SYSTEM -> out.add(buildJsonObject {
                    put("role", "system")
                    put("content", m.textOnly())
                })

                Role.USER -> {
                    val texts = m.parts.filterIsInstance<LPart.Text>().joinToString("") { it.text }
                    val media = m.parts.filterIsInstance<LPart.Media>()
                    if (media.isEmpty()) {
                        out.add(buildJsonObject {
                            put("role", "user")
                            put("content", texts)
                        })
                    } else {
                        val content = ArrayList<JsonObject>()
                        if (texts.isNotBlank()) content.add(buildJsonObject {
                            put("type", "text")
                            put("text", texts)
                        })
                        media.forEach { p ->
                            if (p.mime.startsWith("image/")) {
                                content.add(buildJsonObject {
                                    put("type", "image_url")
                                    put("image_url", buildJsonObject {
                                        put("url", "data:${p.mime};base64,${p.b64}")
                                    })
                                })
                            }
                        }
                        out.add(buildJsonObject {
                            put("role", "user")
                            put("content", JsonArray(content))
                        })
                    }
                }

                Role.ASSISTANT -> {
                    val text = m.textOnly()
                    val calls = m.parts.filterIsInstance<LPart.ToolCallPart>()
                    if (text.isBlank() && calls.isEmpty()) continue
                    out.add(buildJsonObject {
                        put("role", "assistant")
                        if (text.isNotBlank()) put("content", text)
                        if (calls.isNotEmpty()) put("tool_calls", JsonArray(calls.map { c ->
                            buildJsonObject {
                                put("id", c.id)
                                put("type", "function")
                                put("function", buildJsonObject {
                                    put("name", c.name)
                                    put("arguments", c.argsJson)
                                })
                            }
                        }))
                    })
                }

                Role.TOOL -> {
                    m.parts.filterIsInstance<LPart.ToolResultPart>().forEach { r ->
                        out.add(buildJsonObject {
                            put("role", "tool")
                            put("tool_call_id", r.toolCallId)
                            put("content", r.text)
                        })
                    }
                }
            }
        }
        return out
    }

    // ---------------- response parsing ----------------

    private class TcBuilder {
        var id: String = ""
        var name: String = ""
        val args = StringBuilder()
    }

    private suspend fun parseResponse(
        response: okhttp3.Response,
        stream: Boolean,
        onDelta: (suspend (attemptKey: String, text: String) -> Unit)?,
        providerName: String,
        model: String
    ): LlmResult {
        val text = StringBuilder()
        val toolCalls = LinkedHashMap<Int, TcBuilder>()
        var finish: String? = null
        var usage: Usage? = null

        fun consumeChunk(obj: JsonObject): Boolean {
            obj.obj("usage")?.let { u ->
                usage = Usage(u.int("prompt_tokens") ?: 0, u.int("completion_tokens") ?: 0)
            }
            val choice = obj.arr("choices")?.firstOrNull() as? JsonObject ?: return true
            choice.str("finish_reason")?.let { finish = it }
            val delta = choice.obj("delta") ?: return true
            delta.str("content")?.let { text.append(it) }
            delta.arr("tool_calls")?.forEach { el ->
                val tc = el as? JsonObject ?: return@forEach
                val idx = tc.int("index") ?: 0
                val b = toolCalls.getOrPut(idx) { TcBuilder() }
                tc.str("id")?.let { b.id = it }
                tc.obj("function")?.let { f ->
                    f.str("name")?.let { b.name += it }
                    f.str("arguments")?.let { b.args.append(it) }
                }
            }
            return true
        }

        if (stream) {
            Http.readLines(response) { line ->
                if (!line.startsWith("data:")) return@readLines
                val data = line.removePrefix("data:").trim()
                if (data.isEmpty() || data == "[DONE]") return@readLines
                val obj = data.toJsonObject() ?: return@readLines
                consumeChunk(obj)
                onDelta?.invoke("openai", text.toString())
            }
        } else {
            val obj = response.body?.string()?.toJsonObject()
                ?: throw EmptyResponseException()
            val choice = obj.arr("choices")?.firstOrNull() as? JsonObject
                ?: throw HttpProvException(502, obj.toString().take(300))
            choice.str("finish_reason")?.let { finish = it }
            obj.obj("usage")?.let { u ->
                usage = Usage(u.int("prompt_tokens") ?: 0, u.int("completion_tokens") ?: 0)
            }
            val msg = choice.obj("message")
            msg?.str("content")?.let { text.append(it) }
            msg?.arr("tool_calls")?.forEach { el ->
                val tc = el as? JsonObject ?: return@forEach
                val f = tc.obj("function")
                toolCalls[toolCalls.size] = TcBuilder().apply {
                    id = tc.str("id") ?: ""
                    name = f?.str("name") ?: ""
                    f?.str("arguments")?.let { args.append(it) }
                }
            }
        }

        val calls = toolCalls.values.map { b ->
            ToolCallData(
                id = b.id.ifBlank { com.liman.agent.util.genId("oai") },
                name = b.name,
                argsJson = b.args.toString().ifBlank { "{}" }
            )
        }
        return LlmResult(
            text = text.toString(),
            toolCalls = calls,
            finishReason = finish,
            usage = usage,
            providerName = providerName,
            modelName = model
        )
    }
}
