package com.liman.agent.agent

import java.io.File

/**
 * v2.24.0 — STORY MOTION STUDIO (built on Vincentwei1021/video-shotcraft).
 *
 * MOTIONKIT is the deterministic HTML/CSS/JS motion runtime that gets INLINED
 * into every generated motion.html — so each project file is fully
 * self-contained and publishable anywhere (open it in any browser and it
 * plays), while also satisfying the studio's determinism law:
 *
 *   no Date.now(), no Math.random() — every pseudo-random value comes from
 *   seeded mulberry32 (straight from the repo's doctrine), so frame N always
 *   renders identically — the precondition for clean MP4 export.
 *
 * Export contract (MotionRecorder relies on it):
 *   window.__limanReady      → true once the composition is set up
 *   window.__limanDuration   → total duration in seconds
 *   window.__limanSeek(t)    → render the exact frame at time t (seconds)
 */
object MotionKit {

    /** The runtime, inlined into every scaffold. NO `$` (no JS template literals). */
    const val RUNTIME = """
/* MotionKit 1.0 — deterministic motion runtime (Liman Story Motion Studio).
   Doctrine from video-shotcraft: determinism (seeded rand), three-channel
   entrance (y+blur+opacity on ONE ease), holds after landing, one hero. */
var MotionKit = (function () {
  var API = {};
  API.duration = 6;                       // seconds; composition overrides
  var updaters = [];                       // function(t) — t in [0, duration]

  // ---- seeded randomness (mulberry32) — determinism law ----
  API.mulberry32 = function (seed) {
    var a = seed >>> 0;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  };
  API.hashSeed = function (s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  };

  // ---- easings (the studio's tuned vocabulary) ----
  var E = API.ease = {
    linear: function (p) { return p; },
    outCubic: function (p) { var q = 1 - p; return 1 - q * q * q; },
    inOutCubic: function (p) { return p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2; },
    outExpo: function (p) { return p >= 1 ? 1 : 1 - Math.pow(2, -10 * p); },
    outBack: function (p) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); },
    inCubic: function (p) { return p * p * p; },
    // dampedSettle — spring that lands and STAYS (no wobble past 3%)
    dampedSettle: function (p) {
      if (p >= 1) return 1;
      return 1 - Math.pow(2, -7 * p) * Math.cos(9 * p);
    }
  };

  // ---- timeline helpers (t = absolute seconds) ----
  API.prog = function (t, start, dur) {         // clamped 0..1
    var p = (t - start) / dur;
    return p < 0 ? 0 : (p > 1 ? 1 : p);
  };
  API.seg = function (t, start, end) { return t >= start && t < end; };
  API.lerp = function (a, b, p) { return a + (b - a) * p; };
  API.stagger = function (i, base, step) { return base + i * step; };
  API.f = function (t) { return Math.round(t * 30); };   // seconds → frame @30fps

  // ---- style application (transform + filter, hardware-friendly) ----
  API.set = function (el, o) {
    if (!el) return;
    var tr = 'translate(' + (o.x || 0) + 'px,' + (o.y || 0) + 'px)' +
      (o.scale !== undefined ? ' scale(' + o.scale + ')' : '') +
      (o.rot !== undefined ? ' rotate(' + o.rot + 'deg)' : '');
    el.style.transform = tr;
    var f = '';
    if (o.blur) f += 'blur(' + o.blur + 'px) ';
    if (o.sat !== undefined) f += 'saturate(' + o.sat + ') ';
    el.style.filter = f || 'none';
    if (o.opacity !== undefined) el.style.opacity = o.opacity;
  };
  API.hide = function (el) { if (el) { el.style.opacity = 0; } };
  API.show = function (el) { if (el) { el.style.opacity = 1; } };

  // ---- THE entrance three-piece: y + blur + opacity on ONE ease (blur-slide) ----
  API.blurSlide = function (el, t, start, dur, ease, y, blur) {
    if (!el) return;
    var p = E[ease || 'outCubic'](API.prog(t, start, dur));
    API.set(el, { y: API.lerp(y || 40, 0, p), blur: API.lerp(blur || 10, 0, 1 - (1 - p)), opacity: p });
    if (p <= 0) el.style.opacity = 0;
  };

  // word-by-word stagger (title cards): words[] of spans
  API.wordStagger = function (words, t, start, step, dur, ease) {
    for (var i = 0; i < words.length; i++) {
      API.blurSlide(words[i], t, start + i * step, dur, ease, 40, 10);
    }
  };

  // typewriter (3f/char for real UI text, ~0.7f/char only for tiny kickers)
  API.typewriter = function (el, fullText, t, start, charsPerSec) {
    if (!el) return;
    var n = Math.floor((t - start) * (charsPerSec || 10));
    el.textContent = fullText.substring(0, Math.max(0, n));
  };

  // camera (2.5D page cam): zoom + pan of a whole stage element — CSS zoom
  // semantics are honored by setting scale via transform here; keep text sharp
  // by sizing the stage at 1920x1080 and scaling the VIEWPORT, not the text.
  API.camera = function (stageEl, t, start, dur, from, to, ease) {
    var p = E[ease || 'outCubic'](API.prog(t, start, dur));
    var z = API.lerp(from.z, to.z, p), x = API.lerp(from.x, to.x, p), y = API.lerp(from.y, to.y, p);
    if (stageEl) stageEl.style.transform =
      'translate(' + (-960 * (z - 1) + x * z) + 'px,' + (-540 * (z - 1) + y * z) + 'px) scale(' + z + ')';
  };

  // ---- scene registration & the deterministic seek ----
  API.scene = function (fn) { updaters.push(fn); };
  API.render = function (t) {
    for (var i = 0; i < updaters.length; i++) updaters[i](Math.max(0, Math.min(t, API.duration)));
  };

  // preview clock (wall clock ONLY here — never affects rendering math)
  var raf = null;
  API.play = function (loop) {
    var t0 = null;
    cancelAnimationFrame(raf);
    function step(ts) {
      if (t0 === null) t0 = ts;
      var t = (ts - t0) / 1000;
      if (t > API.duration) { if (loop) { t0 = ts; t = 0; } else { API.render(API.duration); return; } }
      API.render(t);
      raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
  };
  API.pause = function () { cancelAnimationFrame(raf); raf = null; };

  // ---- export contract ----
  window.__limanDuration = function () { return API.duration; };
  window.__limanSeek = function (t) { API.render(t); return t.toFixed(4); };
  window.__limanReady = true;
  return API;
})();
"""

    /**
     * A complete, publishable motion.html scaffold. The agent's job is to
     * replace COMPOSE_HERE with real shots following STUDIO.md recipes.
     */
    fun scaffoldHtml(
        title: String,
        brief: String,
        durationSeconds: Int,
        width: Int = 1920,
        height: Int = 1080
    ): String {
        // precompute — interpolating method calls with escapes inside raw strings trips the lexer
        val safeTitle = title.replace("<", "").replace(">", "").replace("&", "and")
        val safeBrief = brief.replace("\n", " ").replace("<", " ").replace(">", " ").take(200)
        return buildString {
        appendLine("<!DOCTYPE html>")
        appendLine("<html lang=\"en\">")
        appendLine("<head>")
        appendLine("<meta charset=\"utf-8\">")
        appendLine("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
        appendLine("<title>$safeTitle</title>")
        appendLine("<style>")
        appendLine("html,body{margin:0;height:100%;background:#0b0d12;overflow:hidden;}")
        appendLine("/* the viewport centers + fits the fixed 1920x1080 stage */")
        appendLine("#viewport{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;}")
        appendLine("#fit{transform-origin:center center;}")
        appendLine("#stage{position:relative;width:${width}px;height:${height}px;background:#0b0d12;")
        appendLine("  overflow:hidden;font-family:'Inter',system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;")
        appendLine("  color:#f2f5fa;}")
        appendLine(".layer{position:absolute;will-change:transform,filter,opacity;}")
        appendLine("</style>")
        appendLine("</head>")
        appendLine("<body>")
        appendLine("<div id=\"viewport\"><div id=\"fit\"><div id=\"stage\">")
        appendLine("<!-- LAYERS: create one .layer per element, id them, style in CSS above -->")
        appendLine("</div></div></div>")
        appendLine("<script>")
        appendLine(RUNTIME)
        appendLine("""
/* ================= COMPOSITION =================
   Brief: $safeBrief

   STUDIO.md rules to honor (from video-shotcraft):
   - energy arc: low-open -> single hero -> feature climb (alternate) -> peak finale
   - every landed key visual HOLDS >= 1s before cutting (R1)
   - entrance three-piece: y + blur + opacity on ONE ease (never skip the blur)
   - one effect per shot is the protagonist; no group glints (Q4)
   - seeded randomness only: MotionKit.mulberry32(MotionKit.hashSeed('shot-1'))
   - hold/rest frames are budgeted FIRST, animation fills what remains
*/
(function () {
  var mk = MotionKit;
  mk.duration = $durationSeconds;   // seconds @30fps

  // ---- setup layers here (document.getElementById / createElement) ----

  mk.scene(function (t) {
    // ---- SHOT 1 (0.0-$durationSeconds s): COMPOSE_HERE ----
    // example pattern:
    // var p = mk.ease.outCubic(mk.prog(t, 0.4, 0.9));
    // mk.set(el, { y: mk.lerp(40, 0, p), blur: 10 * (1 - p), opacity: p });
    // hold after landing (R1): after t > 1.6, nothing moves for >= 1s
  });

  mk.render(0);
  mk.play(true);   // autoplay preview; __limanSeek (used by MP4 export) is deterministic
})();

/* fit-to-window for browser viewing */
function __limanFit() {
  var f = document.getElementById('fit');
  var s = Math.min(window.innerWidth / $width, window.innerHeight / $height);
  f.style.transform = 'scale(' + s + ')';
}
window.addEventListener('resize', __limanFit); __limanFit();
""".trimIndent())
        appendLine("</script>")
        appendLine("</body>")
        appendLine("</html>")
        }
    }
}
