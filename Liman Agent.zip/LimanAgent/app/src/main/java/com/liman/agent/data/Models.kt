package com.liman.agent.data

import com.liman.agent.llm.LlmMessage
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import com.liman.agent.util.now

// ============================================================
// Providers
// ============================================================

enum class ProviderKind { OPENAI_COMPATIBLE, GEMINI, ANTHROPIC, WEB_CHAT, OPENCODE_FREE }

enum class ComboMode { FAILOVER, ROUND_ROBIN, RACE }

@Serializable
data class ProviderConfig(
    val id: String,
    var name: String = "New provider",
    var kind: ProviderKind = ProviderKind.OPENAI_COMPATIBLE,
    var baseUrl: String = "",
    var apiKey: String = "",
    var model: String = "",
    var enabled: Boolean = true,
    var presetId: String = "custom",
    /** free models discovered by the model fetch (e.g. OpenRouter ":free") */
    var freeModels: List<String> = emptyList(),
    /** WEB_CHAT overrides: CSS selectors for input / send button / response nodes */
    var webInputSel: String = "",
    var webSendSel: String = "",
    var webResponseSel: String = "",
    /** when true the combo expands into ALL freeModels automatically */
    var useFreePool: Boolean = false
)

@Serializable
data class ComboConfig(
    var providerIds: List<String> = emptyList(),
    var mode: ComboMode = ComboMode.FAILOVER,
    var retriesPerProvider: Int = 1,
    var cooldownMs: Long = 60_000L
)

// ============================================================
// Agent settings
// ============================================================

enum class ReviewMode { OFF, REPORT, ITERATE }

@Serializable
data class AgentSettings(
    var maxOutputTokens: Int = 8192,
    var maxCycles: Int = 24,
    var contextBudgetTokens: Int = 60_000,
    /** v2.27.0 knotwork-style run ceiling: whole-run-tree token budget; 0 = off */
    var runTokenCeiling: Int = 400_000,
    var systemPromptExtra: String = "",
    var streaming: Boolean = true,
    var planFirst: Boolean = true,
    var reviewMode: ReviewMode = ReviewMode.REPORT,
    var maxReviewIterations: Int = 1,
    var smartCompaction: Boolean = true,
    var autoApproveTools: Boolean = false,
    var alwaysAllowTools: List<String> = DEFAULT_SAFE_TOOLS,
    var ttsEnabled: Boolean = false,
    var imageModelGemini: String = "gemini-2.5-flash-image",
    var imageModelOpenAi: String = "gpt-image-1",
    /** STANDARD | BALANCED | CREATIVE | GENIUS */
    var creativity: String = "BALANCED",
    var skillsAutoLoad: Boolean = true,
    var subagentsEnabled: Boolean = true,
    var radarEnabled: Boolean = true,
    /** "system" | "en" | "fa" */
    var language: String = "system",
    /** tool name -> "ask" | "allow" | "deny" (overrides defaults) */
    var toolPolicies: Map<String, String> = emptyMap(),
    /** long-lived user profile the agent maintains about its owner */
    var profile: Map<String, String> = emptyMap(),
    /** SAF document-tree URIs the user granted for android file access */
    var storageRoots: List<String> = emptyList(),
    /** local 9Router-compatible gateway */
    var routerEnabled: Boolean = true,
    /** 20129 since v2.10.1 — 20128 belongs to the REAL 9Router (npm) on Termux */
    var routerPort: Int = 20129,
    var routerLan: Boolean = false,
    /** one-shot: v2.10 force-enables the router once (user asked for it) */
    var routerBootLatch: Boolean = false,
    /** one-shot: v2.10.1 moves the mini-router off 20128 for real 9Router */
    var routerPortMoved: Boolean = false,
    /** v2.11: last self-update of the free no-key model catalog (epoch ms) */
    var freeCatalogSyncAt: Long = 0,
    /** v2.11 one-shot: seed the OpenCode Free provider on first boot */
    var freeProviderSeeded: Boolean = false
) {
    companion object {
        val DEFAULT_SAFE_TOOLS = listOf(
            "list_files", "read_file", "web_search", "memory_recall", "memory_save",
            "calculator", "datetime", "run_js", "finish", "ask_user"
        )
    }
}

// ============================================================
// Long-term memory
// ============================================================

@Serializable
data class MemoryItem(
    var value: String,
    var updatedAt: Long = now()
)

// ============================================================
// Conversation entries (UI history)
// ============================================================

@Serializable
sealed interface Entry {
    @Serializable
    @SerialName("user")
    data class UserEntry(
        val text: String,
        val attachments: List<String> = emptyList(),
        val ts: Long = now()
    ) : Entry

    @Serializable
    @SerialName("assistant")
    data class AssistantEntry(
        val text: String,
        val provider: String = "",
        val model: String = "",
        val cycle: Int = 0,
        val ts: Long = now(),
        val tokensIn: Int = 0,
        val tokensOut: Int = 0
    ) : Entry

    @Serializable
    @SerialName("tool")
    data class ToolEntry(
        val cycle: Int,
        val tool: String,
        val argsJson: String,
        val result: String,
        val ok: Boolean,
        val ms: Long,
        val ts: Long = now()
    ) : Entry

    /** info | warn | error | switch | plan | review | stats */
    @Serializable
    @SerialName("note")
    data class NoteEntry(
        val text: String,
        val kind: String = "info",
        val ts: Long = now()
    ) : Entry

    @Serializable
    @SerialName("review")
    data class ReviewEntry(
        val score: Int,
        val verdict: String,
        val critique: String,
        val issues: List<String>,
        val ts: Long = now()
    ) : Entry

    @Serializable
    @SerialName("prompt")
    data class PromptEntry(
        val question: String,
        val answer: String,
        val ts: Long = now()
    ) : Entry

    /** status: running | done | failed */
    @Serializable
    @SerialName("subagent")
    data class SubagentEntry(
        val id: String,
        val objective: String,
        val status: String,
        val summary: String = "",
        val ts: Long = now()
    ) : Entry

    /**
     * v2.36 — DELIVERABLES: files the run produced (zip/docx/svg/pdf/apk/…),
     * embedded in the chat right under the final answer as downloadable
     * chips — the user taps and saves, no workspace digging.
     */
    @Serializable
    @SerialName("files")
    data class FileEntry(
        val files: List<Deliverable> = emptyList(),
        val ts: Long = now()
    ) : Entry
}

/** One downloadable output file attached to a finished answer. */
@Serializable
data class Deliverable(
    /** path relative to the app workspace root (filesDir/workspace) */
    val path: String,
    val name: String,
    val sizeBytes: Long
)

@Serializable
data class Conversation(
    val id: String,
    var title: String = "New task",
    val createdAt: Long = now(),
    var updatedAt: Long = now(),
    var entries: List<Entry> = emptyList(),
    var llmMessages: List<LlmMessage> = emptyList(),
    /** v2.31 — PLAN MODE — REMOVED in v2.36 (the mode never worked well);
     * kept only so old saved conversations still deserialize. Always false. */
    var planMode: Boolean = false,
    /** v2.31 — this chat keeps its own workspace folder (new chats: true). */
    var ownWorkspace: Boolean = false,
    /** v2.31 — the live roadmap card (proposed → accepted → executed). */
    var roadmap: Roadmap? = null
)

/**
 * v2.31 — THE ROADMAP: the plan-mode deliverable the user can accept or edit;
 * once accepted it becomes the mission checklist the agent executes and
 * checks off, rendered live in the chat.
 */
@Serializable
data class Roadmap(
    var title: String = "Plan",
    /** proposed | accepted */
    var status: String = "proposed",
    var tasks: List<RoadmapTask> = emptyList(),
    val createdAt: Long = now()
) {
    fun doneCount(): Int = tasks.count { it.status == "done" }
}

@Serializable
data class RoadmapTask(
    val id: String,
    var text: String,
    var status: String = "pending"   // pending | in_progress | done | failed | blocked
)

/** Pure roadmap helpers (unit-tested). */
object RoadmapEngine {

    /** One task per line; "- ", "* ", "1. ", "[x] " prefixes stripped. */
    fun parseMarkdown(text: String): List<RoadmapTask> =
        text.lines().mapNotNull { raw ->
            val line = raw.trim()
            if (line.isEmpty()) return@mapNotNull null
            val cleaned = line.removePrefix("-").removePrefix("*")
                .trimStart().replace(Regex("""^\d+[.)]\s*"""), "")
                .replace(Regex("""^\[[ xX]\]\s*"""), "").trim()
            if (cleaned.isEmpty()) null
            else RoadmapTask("t${genIdShort()}", cleaned.take(200))
        }

    fun toMarkdown(r: Roadmap): String =
        r.tasks.joinToString("\n") { "- ${it.text}" }

    fun fromMission(title: String, tasks: List<com.liman.agent.agent.MissionTask>): Roadmap =
        Roadmap(
            title = title.ifBlank { "Plan" },
            tasks = tasks.map { RoadmapTask(it.id, it.goal, it.status) }
        )

    private var counter = 0
    private fun genIdShort(): String = "t${System.nanoTime() % 100000}_${counter++}"

    /** Kickoff message the agent receives when the user accepts the roadmap. */
    fun kickoffMessage(r: Roadmap): String = buildString {
        appendLine("[Roadmap accepted by the user — you are now in BUILD mode. Execute the plan:]")
        appendLine(toMarkdown(r))
        appendLine("Track progress with the mission tool (mission {action:'done', taskId:'…'}) after each task — the user sees the checklist update live. Begin with the first task now.")
    }
}

data class ConversationMeta(
    val id: String,
    val title: String,
    val updatedAt: Long,
    val preview: String,
    val entryCount: Int
)
