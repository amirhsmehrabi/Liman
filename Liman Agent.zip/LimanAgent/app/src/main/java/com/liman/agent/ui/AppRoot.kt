package com.liman.agent.ui

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun AppRoot() {
    val navController = rememberNavController()
    val context = LocalContext.current

    NavHost(navController = navController, startDestination = "conversations") {
        composable("conversations") {
            ConversationsScreen(
                onOpen = { id -> navController.navigate("chat/$id") },
                onSettings = { navController.navigate("settings") },
                onSkills = { navController.navigate("skills") },
                onCredits = { navController.navigate("credits") },
                onAutomations = { navController.navigate("automations") }
            )
        }
        composable("chat/{id}") { entry ->
            val id = entry.arguments?.getString("id") ?: return@composable
            val app = context.applicationContext as Application
            val vm: ChatViewModel = viewModel(key = id) { ChatViewModel(app, id) }
            ChatScreen(
                vm = vm,
                onBack = { navController.popBackStack() },
                onOpenSettings = { navController.navigate("settings") }
            )
        }
        composable("settings") {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
        composable("skills") {
            SkillsScreen(onBack = { navController.popBackStack() })
        }
        composable("credits") {
            CreditsScreen(onBack = { navController.popBackStack() })
        }
        composable("automations") {
            AutomationsScreen(
                onBack = { navController.popBackStack() },
                onOpenChat = { id -> navController.navigate("chat/$id") }
            )
        }
    }
}
