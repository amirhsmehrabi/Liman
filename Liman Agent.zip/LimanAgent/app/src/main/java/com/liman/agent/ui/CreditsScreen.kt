package com.liman.agent.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.liman.agent.LimanApplication
import com.liman.agent.data.UsageAgg
import com.liman.agent.data.UsageState
import com.liman.agent.data.fmtUsd
import com.liman.agent.data.PriceBook
import java.time.LocalDate

/**
 * 💳 Credits & Usage — v2.15.0 CREDIT METER.
 *
 * A LIVE graphic dashboard of everything Liman spends: total estimated cost,
 * a 14-day cost chart, and breakdowns per provider / per model / per combo /
 * per chat. Updates in real time while the agent runs (usage is a StateFlow),
 * so the user can watch their credit burn and stop it in time. Free-tier &
 * unknown models are shown as tokens-only — never a made-up dollar number.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreditsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = remember { LimanApplication.get(context) }
    val stores = app.container.stores
    val usage by stores.usage.state.collectAsState()
    val combo by stores.combo.state.collectAsState()
    val providers by stores.providers.state.collectAsState()

    var confirmReset by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("💳 Credits & Usage") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Back") }
                },
                actions = {
                    IconButton(onClick = { confirmReset = true }) {
                        Icon(Icons.Filled.Delete, "Reset usage history")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(pad)
                .padding(horizontal = 14.dp)
        ) {
            if (usage.total.requests == 0L) {
                Spacer(Modifier.height(48.dp))
                Text(
                    "No usage recorded yet.\n\nEvery model call Liman makes will appear here " +
                        "live — cost per chat, per provider, per model — so you always know " +
                        "exactly how much credit you are burning.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
            } else {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TotalCard(usage)
                    SectionTitle("LAST 14 DAYS — COST PER DAY")
                    DayChart(usage)

                    SectionTitle("PER PROVIDER")
                    BreakdownRows(usage.byProvider)

                    SectionTitle("PER MODEL")
                    ModelTable(usage)

                    if (combo.providerIds.isNotEmpty()) {
                        SectionTitle("CURRENT COMBO (${combo.providerIds.size} providers)")
                        ComboCard(usage, combo.providerIds, providers.map { it.name })
                    }

                    SectionTitle("PER CHAT — TOP SPENDERS")
                    BreakdownRows(
                        usage.byChat.entries
                            .sortedByDescending { it.value.costMicroUsd }
                            .take(12)
                            .associate { (k, v) -> (usage.chatTitles[k] ?: k) to v }
                    )
                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset usage history?") },
            text = { Text("All recorded usage and estimated costs will be cleared. This does not affect your chats or providers.") },
            confirmButton = {
                TextButton(onClick = {
                    stores.usage.reset()
                    confirmReset = false
                }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
        )
    }
}

// ------------------------------------------------------------
// sections
// ------------------------------------------------------------

@Composable
private fun TotalCard(usage: UsageState) {
    Card(colors = cardColors()) {
        Column(Modifier.padding(16.dp)) {
            Text("TOTAL ESTIMATED SPEND", style = sectionLabel())
            Text(
                fmtUsd(usage.total.costMicroUsd),
                fontSize = 34.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "${usage.total.requests} model calls · " +
                    fmtTok(usage.total.inTok) + " in / " + fmtTok(usage.total.outTok) + " out tokens",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            HorizontalDivider()
            Spacer(Modifier.height(8.dp))
            val t = usage.byDay[LocalDate.now().toString()]
            Text(
                "Today: ${fmtUsd(t?.costMicroUsd ?: 0)} · ${t?.requests ?: 0} calls",
                fontSize = 13.sp
            )
            Text(
                "Estimates use public list prices; free-tier & unknown models count $0 (tokens only).",
                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun DayChart(usage: UsageState) {
    val days = (13 downTo 0).map { LocalDate.now().minusDays(it.toLong()).toString() }
    val vals = days.map { usage.byDay[it]?.costMicroUsd ?: 0L }
    val max = (vals.maxOrNull() ?: 1L).coerceAtLeast(1L)
    val barColor = MaterialTheme.colorScheme.primary
    val hiColor = MaterialTheme.colorScheme.tertiary

    Card(colors = cardColors()) {
        Column(Modifier.padding(14.dp)) {
            Canvas(Modifier.fillMaxWidth().height(96.dp)) {
                val gap = 4.dp.toPx()
                val w = (size.width - gap * (days.size - 1)) / days.size
                vals.forEachIndexed { i, v ->
                    val h = if (v == 0L) 2.dp.toPx() else (v.toFloat() / max) * size.height
                    drawRect(
                        color = if (i == days.lastIndex) hiColor else barColor,
                        topLeft = Offset(i * (w + gap), size.height - h),
                        size = Size(w, h)
                    )
                }
            }
            Row(Modifier.fillMaxWidth()) {
                Text(days.first().take(5), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                Text("peak ${fmtUsd(max)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                Text("today", fontSize = 10.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ModelTable(usage: UsageState) {
    Card(colors = cardColors()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            usage.byModel.entries
                .sortedByDescending { it.value.costMicroUsd * 1000 + it.value.requests }
                .forEach { (key, a) ->
                    val model = key.substringAfterLast('|')
                    val provider = key.substringBefore('|')
                    val price = PriceBook.priceFor(model)
                    val priceNote = when {
                        price == null -> "unknown price · tokens only"
                        price.inPer1M == 0.0 && price.outPer1M == 0.0 -> "free"
                        else -> "$${price.inPer1M}/$${price.outPer1M} per 1M tok"
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(model, fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Text(
                                "$provider · $priceNote",
                                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(fmtUsd(a.costMicroUsd), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "${a.requests}× · ${fmtTok(a.inTok)}/${fmtTok(a.outTok)} tok",
                                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                }
        }
    }
}

@Composable
private fun ComboCard(usage: UsageState, comboProviderIds: List<String>, providerNames: List<String>) {
    Card(colors = cardColors()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            comboProviderIds.forEach { pid ->
                val name = providerNames.firstOrNull { it.contains(pid, ignoreCase = true) } ?: pid
                val a = usage.byProvider[name]
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(name, Modifier.weight(1f), fontSize = 13.sp)
                    if (a != null) {
                        Text(
                            "${fmtUsd(a.costMicroUsd)} · ${a.requests} calls · ${fmtTok(a.inTok + a.outTok)} tok",
                            fontSize = 12.sp, fontFamily = FontFamily.Monospace
                        )
                    } else {
                        Text("no usage yet", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }
        }
    }
}

@Composable
private fun BreakdownRows(map: Map<String, UsageAgg>) {
    val entries = map.entries.sortedByDescending { it.value.costMicroUsd * 1000 + it.value.requests }
    val max = (entries.maxOfOrNull { it.value.costMicroUsd } ?: 1L).coerceAtLeast(1L)
    val barColor = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant

    Card(colors = cardColors()) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            entries.forEach { (name, a) ->
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(name, Modifier.weight(1f), fontSize = 13.sp, maxLines = 1)
                        Text(
                            "${fmtUsd(a.costMicroUsd)} · ${a.requests}× · ${fmtTok(a.inTok + a.outTok)} tok",
                            fontSize = 12.sp, fontFamily = FontFamily.Monospace
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    // proportional cost bar
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(track)
                    ) {
                        val frac = if (a.costMicroUsd <= 0) 0f
                        else (a.costMicroUsd.toFloat() / max).coerceIn(0.02f, 1f)
                        if (frac > 0f) {
                            Box(
                                Modifier
                                    .fillMaxWidth(frac)
                                    .fillMaxHeight()
                                    .background(barColor)
                            )
                        }
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }
        }
    }
}

// ------------------------------------------------------------
// helpers
// ------------------------------------------------------------

private fun fmtTok(t: Long): String = when {
    t >= 1_000_000 -> String.format("%.1fM", t / 1_000_000.0)
    t >= 1_000 -> String.format("%.1fk", t / 1_000.0)
    else -> t.toString()
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
}

@Composable
private fun cardColors() = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)

private fun sectionLabel() = TextStyle(
    fontSize = 11.sp,
    letterSpacing = 1.sp
)
