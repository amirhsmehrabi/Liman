package com.liman.agent.data

import com.liman.agent.util.JSON
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.serialization.Serializable
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/**
 * v2.15.0 — CREDIT METER.
 *
 * The user needs to KNOW what each chat / provider / combo / model costs so
 * they can control their credit spend themselves. Every model call Liman
 * makes is recorded here: tokens in/out, request count and an ESTIMATED
 * USD cost from [PriceBook] (unknown models are tracked in tokens only —
 * never guessed). Aggregates are kept per provider, per model, per chat and
 * per day, and are exposed as a StateFlow so the Credits dashboard updates
 * LIVE while the agent runs.
 */
@Serializable
data class UsageAgg(
    var requests: Long = 0,
    var inTok: Long = 0,
    var outTok: Long = 0,
    var costMicroUsd: Long = 0
) {
    fun plus(o: UsageAgg): UsageAgg = UsageAgg(
        requests = requests + o.requests,
        inTok = inTok + o.inTok,
        outTok = outTok + o.outTok,
        costMicroUsd = costMicroUsd + o.costMicroUsd
    )
}

@Serializable
data class UsageState(
    var total: UsageAgg = UsageAgg(),
    /** provider display name → aggregate */
    var byProvider: Map<String, UsageAgg> = emptyMap(),
    /** "provider|model" → aggregate */
    var byModel: Map<String, UsageAgg> = emptyMap(),
    /** chat id → aggregate */
    var byChat: Map<String, UsageAgg> = emptyMap(),
    /** "yyyy-MM-dd" → aggregate */
    var byDay: Map<String, UsageAgg> = emptyMap(),
    /** chat id → last known title (for the dashboard) */
    var chatTitles: Map<String, String> = emptyMap()
)

class UsageStore(private val file: File) {
    private val _state = MutableStateFlow(UsageState())
    val state: StateFlow<UsageState> = _state

    init {
        _state.value = runCatching {
            JSON.decodeFromString(UsageState.serializer(), file.readText())
        }.getOrDefault(UsageState())
    }

    /**
     * Record one model call. Cost is estimated via PriceBook; models with no
     * known price (free tiers, unknown endpoints) are counted in tokens and
     * requests with $0 — shown as "free/unknown" in the dashboard instead of
     * a made-up number.
     */
    fun record(
        chatId: String,
        chatTitle: String,
        provider: String,
        model: String,
        inTok: Long,
        outTok: Long
    ) {
        if (inTok <= 0 && outTok <= 0) return
        val cost = PriceBook.costMicroUsd(model, inTok, outTok) ?: 0L
        val day = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE)
        val inc = UsageAgg(requests = 1, inTok = inTok, outTok = outTok, costMicroUsd = cost)
        val modelKey = "$provider|$model"

        _state.value = _state.value.copy(
            total = _state.value.total.plus(inc),
            byProvider = _state.value.byProvider.mut(provider, inc),
            byModel = _state.value.byModel.mut(modelKey, inc),
            byChat = _state.value.byChat.mut(chatId, inc),
            byDay = _state.value.byDay.mut(day, inc),
            chatTitles = if (chatTitle.isBlank()) _state.value.chatTitles
                         else _state.value.chatTitles + (chatId to chatTitle.take(80))
        )
        persist()
    }

    /** User control: wipe all usage history. */
    fun reset() {
        _state.value = UsageState()
        persist()
    }

    private fun Map<String, UsageAgg>.mut(key: String, inc: UsageAgg): Map<String, UsageAgg> =
        this + (key to (this[key] ?: UsageAgg()).plus(inc))

    private fun persist() {
        runCatching {
            file.parentFile?.mkdirs()
            file.writeText(JSON.encodeToString(UsageState.serializer(), _state.value))
        }
    }
}

/**
 * Approximate public list prices (USD per 1M tokens, input/output) for the
 * models people actually configure. First matching entry wins; ":free"
 * variants and unknown models cost $0 — the dashboard shows them as
 * free/unknown instead of guessing.
 */
object PriceBook {
    data class Price(val inPer1M: Double, val outPer1M: Double)

    private val table: List<Pair<String, Price>> = listOf(
        ":free" to Price(0.0, 0.0),                       // OpenRouter free variants
        "gemini-2.5-pro" to Price(1.25, 10.0),
        "gemini-2.5-flash" to Price(0.30, 2.50),
        "gemini-2.0-flash" to Price(0.10, 0.40),
        "flash-lite" to Price(0.075, 0.30),
        "gemini-1.5-pro" to Price(1.25, 5.0),
        "gemini-1.5-flash" to Price(0.075, 0.30),
        "gpt-4o-mini" to Price(0.15, 0.60),
        "gpt-4.1-mini" to Price(0.40, 1.60),
        "gpt-4.1-nano" to Price(0.10, 0.40),
        "gpt-4.1" to Price(2.0, 8.0),
        "gpt-4o" to Price(2.50, 10.0),
        "o4-mini" to Price(1.10, 4.40),
        "o3-mini" to Price(1.10, 4.40),
        "o3" to Price(2.0, 8.0),
        "claude-opus-4" to Price(15.0, 75.0),
        "claude-sonnet-4" to Price(3.0, 15.0),
        "claude-3-7-sonnet" to Price(3.0, 15.0),
        "claude-3-5-haiku" to Price(0.80, 4.0),
        "claude-3-5-sonnet" to Price(3.0, 15.0),
        "claude-3-haiku" to Price(0.25, 1.25),
        "deepseek-reasoner" to Price(0.55, 2.19),
        "deepseek-chat" to Price(0.27, 1.10),
        "llama" to Price(0.0, 0.0),                       // common free/open models
        "mistral" to Price(0.0, 0.0),
        "qwen" to Price(0.0, 0.0),
        "gemma" to Price(0.0, 0.0)
    )

    /** Price for a model id, or null when unknown (never guessed). */
    fun priceFor(model: String): Price? {
        val m = model.lowercase().removePrefix("models/").trim()
        if (m.isEmpty()) return null
        for ((k, p) in table) if (m.contains(k)) return p
        return null
    }

    /**
     * Estimated cost in micro-USD (1e-6 $). Because prices are per 1M tokens,
     * micro-USD = tokens × price. Returns null for unknown models.
     */
    fun costMicroUsd(model: String, inTok: Long, outTok: Long): Long? {
        val p = priceFor(model) ?: return null
        return Math.round(inTok * p.inPer1M + outTok * p.outPer1M)
    }
}

/** Adaptive USD formatting for tiny amounts: $1.23 / $0.004521 / $0.000019 / $0 */
fun fmtUsd(microUsd: Long): String {
    if (microUsd == 0L) return "$0"
    val usd = microUsd / 1_000_000.0
    val digits = when {
        usd >= 1.0 -> 4
        usd >= 0.01 -> 5
        else -> 6
    }
    return "$" + String.format("%.${digits}f", usd).trimEnd('0').trimEnd('.').ifEmpty { "0" }
}
