package com.liman.agent.agent

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.liman.agent.data.ProviderConfig
import com.liman.agent.data.ProviderKind
import com.liman.agent.data.Stores
import com.liman.agent.llm.Http
import com.liman.agent.util.arr
import com.liman.agent.util.genId
import com.liman.agent.util.str
import com.liman.agent.util.toJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import okhttp3.Request

/**
 * v2.25.1 — 9ROUTER, CLOUD EDITION.
 *
 * The Termux install path is retired (user decision: "doesn't work, forget
 * it — I made it on another server"). The user's 9Router now runs at
 * https://9router-production-5f97a.up.railway.app/ and Liman connects to it
 * like any OpenAI-compatible provider — with one 9Router specialty: COMBOS.
 *
 * Verified against the user's live server (2026-09-14):
 *  • GET  {origin}/api/health        → {"ok":true}
 *  • GET  {origin}/v1/models         → needs "Authorization: Bearer <key>"
 *  • GET  {origin}/api/combos        → dashboard-session only (NOT the API
 *    key) — so combos are fetched from /v1/models instead, where the server
 *    lists them FIRST with owned_by:"combo" (src/app/api/v1/models/route.js:
 *     for (const combo of combos) models.push({ id: combo.name,
 *       object:"model", owned_by:"combo" })).
 *  • a combo is used by passing its NAME as the model id.
 *
 * Distilled from the repo (decolua/9router, MIT): dashboard at
 * {origin}/dashboard (307 → /login when not signed in — that's the browser's
 * business), OpenAI-compatible chat at {origin}/v1/chat/completions.
 */
object NineRouter {

    const val PRESET_ID = "9router"

    /** The user's own deployment — the default everywhere. */
    const val DEFAULT_BASE = "https://9router-production-5f97a.up.railway.app/v1"

    // ---------------- URL helpers ----------------

    /** scheme://host[:port] of whatever base URL the user pasted. */
    fun originOf(baseUrl: String): String {
        val b = baseUrl.trim()
        val schemeEnd = b.indexOf("://")
        if (schemeEnd <= 0) return b.trimEnd('/')
        val rest = b.substring(schemeEnd + 3)
        val host = rest.substringBefore('/').substringBefore('?')
        return b.substring(0, schemeEnd + 3) + host
    }

    fun dashboardUrl(baseUrl: String): String = originOf(baseUrl) + "/dashboard"

    /**
     * Canonical API base: trims, drops trailing slash / /chat/completions /
     * /models tails, and appends /v1 when the user pasted just the origin
     * (9Router serves the OpenAI API under /v1 — its /models would 404).
     */
    fun normalizeBase(baseUrl: String): String {
        var b = baseUrl.trim().trimEnd('/')
        if (b.isEmpty()) return DEFAULT_BASE
        if (b.endsWith("/chat/completions")) b = b.removeSuffix("/chat/completions")
        if (b.endsWith("/models")) b = b.removeSuffix("/models")
        if (!b.endsWith("/v1") && !b.contains("/v1/")) b += "/v1"
        return b
    }

    // ---------------- catalog (combos!) ----------------

    /**
     * The /v1/models answer split into 9Router's two species:
     * combos (owned_by "combo", listed first by the server) and plain models.
     */
    data class Catalog(val combos: List<String>, val models: List<String>) {
        val total: Int get() = combos.size + models.size
        fun all(): List<String> = combos + models
    }

    fun parseCatalog(json: String): Catalog = runCatching {
        val data = json.toJsonObject()?.arr("data") ?: return Catalog(emptyList(), emptyList())
        val combos = ArrayList<String>()
        val models = ArrayList<String>()
        for (el in data) {
            val o = el as? JsonObject ?: continue
            val id = o.str("id")?.trim().orEmpty()
            if (id.isEmpty()) continue
            if (o.str("owned_by") == "combo") combos.add(id) else models.add(id)
        }
        Catalog(combos, models)
    }.getOrDefault(Catalog(emptyList(), emptyList()))

    /** Fetch combos + models from the server (needs the dashboard-created API key). */
    suspend fun fetchCatalog(baseUrl: String, apiKey: String): Catalog =
        withContext(Dispatchers.IO) {
            val url = normalizeBase(baseUrl) + "/models"
            val req = Request.Builder().url(url)
                .apply { if (apiKey.isNotBlank()) header("Authorization", "Bearer $apiKey") }
                .get().build()
            Http.toolClient(25).newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException(
                        "HTTP ${resp.code}: ${resp.body?.string()?.take(250).orEmpty().ifBlank { resp.message }}"
                    )
                }
                parseCatalog(resp.body?.string() ?: "")
            }
        }

    /** Quick reachability probe — GET {origin}/api/health (verified: {"ok":true}). */
    suspend fun isUp(baseUrl: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            Http.toolClient(6).newCall(
                Request.Builder().url(originOf(baseUrl) + "/api/health").get().build()
            ).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    // ---------------- provider wiring ----------------

    /**
     * Create-or-update the Liman provider entry for 9Router. Once saved +
     * enabled it appears in the combo picker — the user's "open combos" step.
     */
    fun ensureProvider(stores: Stores, baseUrl: String, apiKey: String, model: String): ProviderConfig {
        val existing = stores.providers.state.value.firstOrNull { it.presetId == PRESET_ID }
        val cfg = existing?.copy() ?: ProviderConfig(
            id = genId("prov"), name = "9Router (my server)", presetId = PRESET_ID
        )
        cfg.kind = ProviderKind.OPENAI_COMPATIBLE
        cfg.baseUrl = if (baseUrl.isBlank()) DEFAULT_BASE else normalizeBase(baseUrl)
        cfg.apiKey = apiKey.trim()
        cfg.model = model.trim()
        cfg.enabled = true
        stores.providers.upsert(cfg)
        return cfg
    }

    fun savedProvider(stores: Stores): ProviderConfig? =
        stores.providers.state.value.firstOrNull { it.presetId == PRESET_ID }

    // ---------------- dashboard (the button → Chrome) ----------------

    fun openDashboard(context: Context, baseUrl: String): Boolean = runCatching {
        context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(dashboardUrl(baseUrl)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    }.getOrDefault(false)
}
