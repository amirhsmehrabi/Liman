package com.liman.agent.agent

import com.liman.agent.data.Pipeline
import com.liman.agent.data.Trigger
import com.liman.agent.data.Watcher
import com.liman.agent.util.JSON
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * v2.23.0 — PLUGIN PACKS: a Liman ecosystem.
 *
 * A pack is one .zip: manifest + skills (markdown) + pipelines + triggers +
 * watchers. Export your setup, import a friend's, share a "visa-docs
 * tracker" pack in one file. Pure file/zip logic — fully testable.
 */
object Packs {

    const val MANIFEST = "liman-pack.json"

    @Serializable
    data class Manifest(
        val name: String,
        val format: Int = 1,
        val exportedAt: Long,
        val skills: List<String> = emptyList(),
        val pipelines: Int = 0,
        val triggers: Int = 0,
        val watchers: Int = 0,
        val notes: String = ""
    )

    // ---------------- export ----------------

    fun exportPack(
        name: String,
        outDir: File,
        skillsDir: File?,
        skillIds: List<String>,
        pipelines: List<Pipeline>,
        triggers: List<Trigger>,
        watchers: List<Watcher>,
        notes: String = ""
    ): File {
        outDir.mkdirs()
        val safe = name.lowercase().replace(Regex("[^a-z0-9._-]+"), "-").trim('-').ifBlank { "pack" }
        val out = File(outDir, "$safe.limanpack.zip")
        ZipOutputStream(out.outputStream().buffered()).use { zip ->
            val manifest = Manifest(
                name = name, exportedAt = System.currentTimeMillis(),
                skills = skillIds, pipelines = pipelines.size,
                triggers = triggers.size, watchers = watchers.size, notes = notes
            )
            zip.putNextEntry(ZipEntry(MANIFEST))
            zip.write(Json.encodeToString(Manifest.serializer(), manifest).toByteArray())
            zip.closeEntry()
            skillsDir?.let { sd ->
                skillIds.forEach { id ->
                    val folder = File(sd, id)
                    listOf("SKILL.md", "meta.json").forEach { fn ->
                        val f = File(folder, fn)
                        if (f.isFile) {
                            zip.putNextEntry(ZipEntry("skills/$id/$fn"))
                            zip.write(f.readBytes())
                            zip.closeEntry()
                        }
                    }
                }
            }
            if (pipelines.isNotEmpty()) writeJson(zip, "pipelines.json", ListSerializer(Pipeline.serializer()), pipelines)
            if (triggers.isNotEmpty()) writeJson(zip, "triggers.json", ListSerializer(Trigger.serializer()), triggers)
            if (watchers.isNotEmpty()) writeJson(zip, "watchers.json", ListSerializer(Watcher.serializer()), watchers)
        }
        return out
    }

    private fun writeJson(zip: ZipOutputStream, entry: String, serializer: kotlinx.serialization.KSerializer<*>, value: Any) {
        @Suppress("UNCHECKED_CAST")
        val text = JSON.encodeToString(serializer as kotlinx.serialization.KSerializer<Any>, value)
        zip.putNextEntry(ZipEntry(entry))
        zip.write(text.toByteArray())
        zip.closeEntry()
    }

    // ---------------- inspect ----------------

    fun readManifest(zipFile: File): Manifest? = runCatching {
        ZipInputStream(zipFile.inputStream().buffered()).use { zin ->
            var e: ZipEntry? = zin.nextEntry
            while (e != null) {
                if (e.name == MANIFEST) {
                    return@use Json.decodeFromString(
                        Manifest.serializer(),
                        zin.readBytes().decodeToString()
                    )
                }
                e = zin.nextEntry
            }
            null
        }
    }.getOrNull()

    // ---------------- import ----------------

    data class ImportResult(
        val skills: Int, val skillsSkipped: Int,
        val pipelines: Int, val triggers: Int, val watchers: Int
    )

    fun importPack(
        zipFile: File,
        skillsDir: File,
        existingSkillIds: List<String>,
        pipelineSink: (List<Pipeline>) -> Unit,
        triggerSink: (List<Trigger>) -> Unit,
        watcherSink: (List<Watcher>) -> Unit
    ): ImportResult {
        var skills = 0
        var skipped = 0
        var pip = 0
        var trig = 0
        var wat = 0
        skillsDir.mkdirs()
        ZipInputStream(zipFile.inputStream().buffered()).use { zin ->
            var e: ZipEntry? = zin.nextEntry
            while (e != null) {
                val bytes = zin.readBytes()
                when {
                    e.name.startsWith("skills/") && e.name.count { it == '/' } == 2 -> {
                        // skills/<id>/<file>
                        val rest = e.name.removePrefix("skills/")
                        val id = rest.substringBefore('/')
                        val fn = rest.substringAfter('/')
                        if (id in existingSkillIds) {
                            if (fn == "SKILL.md") skipped++
                        } else {
                            File(File(skillsDir, id), fn).apply { parentFile?.mkdirs() }.writeBytes(bytes)
                            if (fn == "SKILL.md") skills++
                        }
                    }
                    e.name == "pipelines.json" -> runCatching {
                        Json.decodeFromString(ListSerializer(Pipeline.serializer()), bytes.decodeToString())
                    }.getOrNull()?.let { pipelineSink(it); pip = it.size }
                    e.name == "triggers.json" -> runCatching {
                        Json.decodeFromString(ListSerializer(Trigger.serializer()), bytes.decodeToString())
                    }.getOrNull()?.let { triggerSink(it); trig = it.size }
                    e.name == "watchers.json" -> runCatching {
                        Json.decodeFromString(ListSerializer(Watcher.serializer()), bytes.decodeToString())
                    }.getOrNull()?.let { watcherSink(it); wat = it.size }
                }
                e = zin.nextEntry
            }
        }
        return ImportResult(skills, skipped, pip, trig, wat)
    }
}
