package com.liman.agent.llm

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Gemini's function-declaration schemas accept only a strict subset of JSON
 * Schema. Anything else — "additionalProperties", "$schema", "default",
 * OpenAI-style type arrays, properties without a "type", "$ref", "pattern",
 * "exclusiveMinimum"… — makes the whole request die with:
 *
 *     400 Invalid JSON payload received. Unknown name "additionalProperties"
 *
 * This sanitizer recursively rewrites any tool schema into the shape Gemini
 * accepts, never throwing (a bad spec must never break the provider request).
 */
object GeminiSchema {

    private val ALLOWED = setOf(
        "type", "description", "nullable", "enum", "format",
        "items", "properties", "required",
        "minimum", "maximum", "minItems", "maxItems", "anyOf"
    )

    fun sanitize(schema: JsonObject): JsonObject {
        val type = normalizeType(schema)
        val out = buildJsonObject {
            put("type", type)
            schema["description"]?.let { put("description", it) }
            schema["nullable"]?.let { put("nullable", it) }
            schema["enum"]?.let { if (it is JsonArray) put("enum", it) }
            if (type == "object") {
                val props = schema["properties"] as? JsonObject
                if (props != null && props.isNotEmpty()) {
                    put("properties", buildJsonObject {
                        props.forEach { (k, v) ->
                            val child = when (v) {
                                is JsonObject -> sanitize(v)
                                else -> buildJsonObject { put("type", "string") }
                            }
                            put(k, child)
                        }
                    })
                }
                (schema["required"] as? JsonArray)?.let { put("required", it) }
            }
            if (type == "array") {
                val items = schema["items"] as? JsonObject
                put("items", if (items != null) sanitize(items) else buildJsonObject { put("type", "string") })
            }
            if (type == "number" || type == "integer") {
                schema["minimum"]?.let { put("minimum", it) }
                schema["maximum"]?.let { put("maximum", it) }
            }
        }
        return out
    }

    /** Resolves the effective type: handles OpenAI-style ["string","null"] arrays. */
    private fun normalizeType(schema: JsonObject): String {
        // real JSON array of types: ["integer", "null"]
        (schema["type"] as? JsonArray)?.let { arr ->
            val first = arr.filterIsInstance<JsonPrimitive>()
                .map { it.content }
                .firstOrNull { it.isNotBlank() && it != "null" }
            return canon(first)
        }
        val raw = (schema["type"] as? JsonPrimitive)?.content
        if (raw != null) {
            if (raw.startsWith("[")) {
                // JSON stringified array — rare but seen in the wild
                val inner = raw.removePrefix("[").removeSuffix("]").split(",")
                    .map { it.trim().removeSurrounding("\"").trim() }
                    .firstOrNull { it.isNotBlank() && it != "null" }
                return canon(inner)
            }
            return canon(raw)
        }
        val anyOf = schema["anyOf"] as? JsonArray
        if (anyOf != null) {
            val first = anyOf.firstOrNull { it is JsonObject } as? JsonObject
            return canon(first?.get("type")?.let { (it as? JsonPrimitive)?.content })
        }
        // infer from structure
        return when {
            schema.containsKey("properties") -> "object"
            schema.containsKey("items") -> "array"
            schema.containsKey("enum") -> "string"
            else -> "string"
        }
    }

    private fun canon(t: String?): String = when (t?.lowercase()) {
        "str", "text" -> "string"
        "int" -> "integer"
        "float", "double" -> "number"
        "bool" -> "boolean"
        "object", "array", "string", "integer", "number", "boolean" -> t.lowercase()
        else -> "string"
    }
}
