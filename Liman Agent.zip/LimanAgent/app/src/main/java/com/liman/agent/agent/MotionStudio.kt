package com.liman.agent.agent

import java.io.File

/**
 * v2.24.0 — STORY MOTION STUDIO.
 *
 * Distilled from Vincentwei1021/video-shotcraft (Apache-2.0, 8.3k★) —
 * 157 shot recipe cards, the promo energy arc, 27 case-law aesthetic rules,
 * an 8-stage pipeline — adapted from its Remotion/PC home to Liman's
 * on-device doctrine: deterministic MotionKit HTML (publishable anywhere)
 * + in-app 1080p MP4 export via the WebView frame recorder.
 *
 * Credit where due: every rule below traces back to that repo's
 * aesthetic-rules.md / promo-energy-arc.md / shot cards.
 */
object MotionStudio {

    // ---------------- planning (the prompt-engineering core) ----------------

    /** Compact planning doctrine returned by `motion plan` — the agent's brief. */
    fun planningBrief(): String = """
PLANNING A MOTION PIECE (video-shotcraft doctrine, adapted):

1. MODE — pick one, don't merge:
   - FAST: short piece (<=15s), one clear message, 2-4 shots. Go straight to storyboard.
   - CREATIVE (autonomous): you own visual direction; decide and execute continuously,
     never pause mid-way. Record your key judgments in the storyboard file.
   - CO-CREATE: propose brief/direction/shot-map/storyboard, confirm with ask_user
     (max 2-3 questions per round, batched) before implementing.

2. BRIEF (30 seconds of thought): who is it for, ONE message, tone. If it's for a real
   product/page: the visual language (fonts, colors, spacing, radius) must GROW FROM the
   product itself — extract real tokens, never invent an unrelated "promo skin".

3. ENERGY ARC (the whole-film skeleton — fill slots BEFORE animating):
   | Segment        | Share of runtime | Energy        | Job                                   |
   | Brand open     | 8-12%            | LOW           | wordmark lands + HOLDS >= 1s (R1)     |
   | Single hero    | 12-15%           | MEDIUM (slow) | ONE hero, complete action arc >= 3s   |
   | Feature climb  | 55-65%           | alternate     | one feature per shot, one technique   |
   |                |                  | hi/lo         | as protagonist only once (P4)         |
   | Launch finale  | 13-16%           | PEAK          | elements fly in around the wordmark,  |
   |                |                  |               | sign-off holds >= 1s                  |
   Breathing title cards (paper-title-card): one per 1-2 feature shots, ~1.8s each, 2-4 total.
   Budget hold/rest frames FIRST (landings >= 30f, batch endings 15f), animation fills the rest.

4. SHOT MAP: scan the catalog in STUDIO.md (10 categories, detailed recipes).
   Pick cards per slot; write the storyboard table:
   shot | card | start-end (s) | key motion | hold budget | copy

5. COMPOSE in motion.html with MotionKit (deterministic: seeded rand only).
6. VERIFY: render_html the file at t=0 and key timestamps (seek by calling
   window.__limanSeek before the screenshot if needed) — inspect like a human: legible?
   holds honored? any uniform linear motion? (that reads as cheap PPT — R2)
7. EXPORT: motion {action:'export'} → 1080p MP4 + deliver the HTML too (it's publishable).
""".trim()

    /** The full on-device handbook, written to workspace/motion/STUDIO.md once. */
    fun handbook(): String = """
# LIMAN STORY MOTION STUDIO — the handbook

Distilled from **[video-shotcraft](https://github.com/Vincentwei1021/video-shotcraft)**
(Apache-2.0) by Vincent Wei — 157 shot recipe cards, case-law aesthetic rules, and a
production pipeline, adapted here for on-device HTML composition + MP4 export.
The original is a Remotion skill; shot vocabulary and rules transfer 1:1.

## The 8-stage pipeline
0. Product understanding — what IS this, who watches, ONE message.
1. Visual direction & styleframe — extract REAL design tokens from the product
   (fonts/weights, type scale, grid, radius, background/surface/text/accent colors).
   The film's language grows from the product; never slap on an unrelated promo skin.
2. Feature → shot mapping — one feature per shot, one motion technique as
   protagonist only once in the whole film (P4). Repeats get deleted.
3. Storyboard & go — the table from `motion plan`; breathing cards placed.
4. Asset capture — REAL screenshots for anything reproducing a real page
   (ui tool screenshot / render_html of the real app); hand-built UI only for
   non-reproduction scenes (abstract opens, brand segments) and only at
   publish-grade quality (Q1). Fake/sanitize any sensitive data first.
5. Per-shot implementation — MotionKit scenes; each shot = one scene function.
6. Sound design (when audio is added later) — vocabulary: whoosh (camera),
   impact (landing), riser (build-up), sparkle (light), transition; cinematic
   tones, never game-UI bleeps; declarative frame-pinned SFX table (S1/S2).
7. Acceptance — render key frames, run the rule checklist below, output
   "R1 ✓ / R1 ✗(shot-3, f72)" per rule. Never ship a first look to the user (P1).

## Aesthetic rules — the case law (R/Q/S/C/P)
- R1 LAND AND BREATHE: key info (wordmark, numbers, full grid) holds STILL >= 1s
  after landing. The pause belongs to brand moments, not ordinary cards.
- R2 SPEED = ACCELERATION: entrances are eased and non-uniform, staggered;
  batch entrances accelerate ("dealing" metaphor beats abstract flood);
  after a full board, 0.5s of stillness before the next beat. NO uniform
  linear motion anywhere (it reads as cheap slides).
- R3 SLOWER OVER FASTER: first version is always too fast. Opening hero action
  arc >= 3s; simulated interactions move at real human speed; budget hold frames.
- R4 BEAT HITS ARE TIMING, NOT AMPLITUDE: full-frame/camera slams <= 3 per film,
  on the strongest hits only; other beat actions touch the element layer only.
- Q1 REAL SCREENSHOTS for real pages; hand-built UI only where nothing is being
  reproduced — quality and instant legibility are hard gates.
- Q3 STABLE CAMERA: no handheld shake in bright UI films.
- Q4 GLINTS: never group-fired. At most ONE per shot, on the hero, clipped to
  the element's border-radius. Light effects that survive must look GOOD, not just exist.
- Q5 OPEN WITH ONE HERO: one subject, one complete arc
  (spotlight → push in → hover → outline light → settle). Not a group dance.
- Q6 CAMERA SERVES LEGIBILITY: dense info = frontal; text close-ups = level side
  angles; tilt only shot-by-shot with a reason.
- Q7 OBJECT CLOSE-UP FOUR-PIECE: tilted side angle + perceivable stack height +
  orbit around the subject + contrasted dark material background, then pull back.
- Q8 FINALE = LAUNCH GROUP PHOTO: representative elements of every shown feature
  fly in from all directions around the wordmark; the film's energy PEAK;
  first version is always too conservative — push one notch.
- Q9 FLY-INS LAND IN REAL SLOTS: elements embed into the page layout at real
  positions; nothing hovers above it forever.
- Q10 DOCUMENT SHOTS ARE PUBLISH-GRADE: native typography, text fills the frame,
  full layout visible (sidebars, comment panes). "Poster + tagline" mocks get redone.
- C2 TAGLINES: "team + product + concrete benefit" — no abstract metaphor words.
- P1 You render and inspect frames yourself before the user ever sees them.
- P4 Feature list → shot list, 1:1; duplicates deleted.

## Energy arc (fill BEFORE animating)
Brand open (8-12%, LOW, wordmark holds 1s) → single hero (12-15%, slowest+richest,
arc >= 3s) → feature climb (55-65%, hi/lo alternation + breathing cards) →
launch finale (13-16%, PEAK, group photo + sign-off hold 1s).
Breathing cards ~1.8s, 2-4 per film, before important features; never repeat the outro tagline.

## Shot catalog (10 categories — signature recipes)
OPENING: brand-ink-open (crosshair draws → wordmark letterpress char-by-char,
scale 1.6→1 + blur 6→0, typewriter kicker 0.7f/char, HOLD 1s, exit rises 40px/7f);
orbit-ring-title-open (8 cards orbit an ellipse, title blur-slides per word);
crane-rise-reveal; dataviz-landscape-open; letterspace-materialize.
TYPOGRAPHY: blur-slide (words enter y40→0 + blur10→0 + opacity on ONE outCubic,
~3.5f stagger — THE entrance three-piece); lead-word-zoom-assemble (first word 2.3x,
zoom+slide read as one motion, transform-origin pinned to baseline); fracture;
magician-card-flourish.
UI-ENTRANCE: spotlight-hero-card (the single-hero open: spotlight→push→hover→settle);
deck-deal-flyin (cards dealt with hard acceleration, land in REAL grid slots (Q9),
board rests 0.5s); row-embed (rows fly in and embed the layout); avatar-bracket-carousel;
assemble-then-type-flyin (silent skeletons fly in first, THEN text char-by-char from 3D).
DATA: digit-roll counters; avatar-grid-radial-build-colorize; before-after-slider-scrub
(rod whips fast then scrubs slow — fast=hit, slow=read); dataviz growth.
INTERACTION: type-and-filter (REAL typing speed 3f/char, unhurried filtering);
ai-stream-response (readable summary lands FIRST, evidence rows stream in,
settles to done-state >= 15f); autolayout-gap-dial.
CAMERA: basic-3d-scene (cards scattered in 3D, camera flies pose-to-pose);
page-cam 2.5D zoom/pan (keep text sharp: rasterize at display size, zoom the
viewport not the text); side-tilt orbit close-ups (Q7).
TRANSITION: match-cut on shape; whip-pan; luminance wipe; shot-transitions six-form picker.
RHYTHM: beat-cut-moves (hard cuts AS the instrument, halving intervals);
beat-step-list-theme-cycle (three channels locked to one beat: row/color/background).
EFFECTS: aurora-bloom-bg-flip (soft blobs rise, then the whole base flips dark in ~0.36s);
assemble-then-type; single-hero glint (Q4 law).
OUTRO: outro-group-photo-launch (Q8: every feature's element flies in from its
direction, crane + stage light + confetti at PEAK energy, sign-off holds 1s).

Full card list (157) with durations/energy: github {action:'research', query:'video-shotcraft'}
or the gallery: https://vincentwei1021.github.io/video-shotcraft/library.html

## MotionKit API (compose with this)
- mk.duration = N (seconds, 30fps); mk.scene(fn) — fn(t) renders absolute time t.
- mk.prog(t, start, dur) → clamped 0..1; mk.ease.outCubic/inOutCubic/outExpo/outBack/dampedSettle.
- mk.set(el, {x, y, scale, rot, blur, sat, opacity}); mk.blurSlide(el, t, start, dur, ease, y, blur)
  — the three-piece entrance; mk.wordStagger(words, t, start, step, dur);
  mk.typewriter(el, text, t, start, cps); mk.camera(stage, t, start, dur, from, to, ease).
- RANDOMNESS: ONLY mk.mulberry32(mk.hashSeed('shot-1')) — Math.random()/Date.now() are
  FORBIDDEN (determinism law; the MP4 export replays frames through __limanSeek).
- Export contract: keep window.__limanSeek + __limanReady intact; stage fixed 1920x1080.

## Export
motion {action:'export', name:'<project>'} → frame-perfect 1080p30 H.264 MP4
(rendered from the deterministic timeline — what you verified is what you get).
Deliver BOTH: the motion.html (self-contained, publishable, plays in any browser)
and the MP4. build_apk can wrap the HTML into an installable app on request.
""".trim()

    // ---------------- project management ----------------

    fun slugify(name: String): String =
        name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(32).ifBlank { "motion" }

    fun motionRoot(workspace: File): File = File(workspace, "motion")

    /** Create (or reuse) a project; ensures the shared handbook exists. */
    fun create(workspace: File, name: String, brief: String, durationSeconds: Int): File {
        val root = motionRoot(workspace).apply { mkdirs() }
        val handbookFile = File(root, "STUDIO.md")
        if (!handbookFile.exists()) handbookFile.writeText(handbook())
        val dir = File(root, slugify(name)).apply { mkdirs() }
        val html = File(dir, "motion.html")
        if (!html.exists()) {
            html.writeText(MotionKit.scaffoldHtml(name, brief, durationSeconds.coerceIn(3, 120)))
        }
        val board = File(dir, "storyboard.md")
        if (!board.exists()) {
            board.writeText(
                "# Storyboard — $name\n\nBrief: $brief\nDuration: ${durationSeconds}s @30fps\n\n" +
                    "| # | shot | card | start-end | key motion | hold budget | copy |\n" +
                    "|---|------|------|-----------|------------|-------------|------|\n" +
                    "| 1 | … | … | 0.0-${durationSeconds}.0 | … | … | … |\n\n" +
                    "Fill from the energy arc (STUDIO.md) BEFORE composing motion.html.\n"
            )
        }
        return dir
    }

    fun projects(workspace: File): List<File> =
        motionRoot(workspace).takeIf { it.isDirectory }?.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }
            ?: emptyList()

    fun findProject(workspace: File, name: String?): File? {
        val all = projects(workspace)
        if (all.isEmpty()) return null
        if (name.isNullOrBlank()) return all.last()
        return all.firstOrNull { it.name.equals(slugify(name), true) || it.name.equals(name, true) }
    }

    /** Cheap static validation the recorder depends on. */
    fun exportReadiness(html: String): String? = when {
        !html.contains("__limanSeek") -> "motion.html is missing the MotionKit export contract (window.__limanSeek) — scaffold broken?"
        !html.contains("__limanReady") -> "motion.html is missing window.__limanReady."
        !html.contains("mk.duration") && !html.contains("MotionKit.duration") -> "no mk.duration set — the recorder needs a timeline length."
        html.contains("Math.random") -> "DETERMINISM LAW VIOLATED: Math.random() found — use MotionKit.mulberry32(seed) instead."
        html.contains("Date.now") -> "DETERMINISM LAW VIOLATED: Date.now() found — the timeline must be a pure function of t."
        else -> null
    }
}
