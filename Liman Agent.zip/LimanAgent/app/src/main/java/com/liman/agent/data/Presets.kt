package com.liman.agent.data

/** One-tap provider templates. Everything stays fully editable after applying. */
data class ProviderPreset(
    val id: String,
    val title: String,
    val kind: ProviderKind,
    val baseUrl: String,
    val models: List<String>,
    val defaultModel: String,
    val keyHint: String,
    val needsKey: Boolean = true
)

val PROVIDER_PRESETS: List<ProviderPreset> = listOf(
    ProviderPreset(
        id = "opencode-free", title = "OpenCode Free (no key · Muse free models)",
        kind = ProviderKind.OPENCODE_FREE,
        baseUrl = "https://opencode.ai",
        models = listOf(
            "muse-spark-1.3-contributor-free", "muse-spark-1.2-contributor-free"
        ),
        defaultModel = "muse-spark-1.3-contributor-free",
        keyHint = "Zero setup: anonymous free tier, no API key, no account. Muse free models; " +
            "the list self-updates (Free Catalog). Shared pool — busy moments are retried automatically.",
        needsKey = false
    ),
    ProviderPreset(
        id = "gemini", title = "Google Gemini (API key only)",
        kind = ProviderKind.GEMINI,
        baseUrl = "https://generativelanguage.googleapis.com",
        models = listOf(
            "gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.5-flash-lite", "gemini-2.0-flash"
        ),
        defaultModel = "gemini-2.5-flash",
        keyHint = "Free key: aistudio.google.com/apikey"
    ),
    ProviderPreset(
        id = "9router", title = "9Router (my server · combos)",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "https://9router-production-5f97a.up.railway.app/v1",
        models = emptyList(),
        defaultModel = "",
        keyHint = "Your 9Router deployment. API key: open the dashboard → API Keys → create, paste below. 'Check key' fetches your COMBOS (fusion / fallback / round-robin) — pick one as the model."
    ),
    ProviderPreset(
        id = "limanrouter", title = "Liman mini-router (local · free)",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "http://127.0.0.1:20129/v1",
        models = listOf("auto", "free"),
        defaultModel = "auto",
        keyHint = "Runs inside Liman on port 20129 — no key needed. Enable it in Settings → Local router.",
        needsKey = false
    ),
    ProviderPreset(
        id = "webchat", title = "Web chat (ChatGPT / Gemini / any site)",
        kind = ProviderKind.WEB_CHAT,
        baseUrl = "https://chatgpt.com",
        models = emptyList(),
        defaultModel = "web",
        keyHint = "No API key — Liman drives the site's own chat in a real browser session. Log in once from Settings.",
        needsKey = false
    ),
    ProviderPreset(
        id = "openai", title = "OpenAI",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "https://api.openai.com/v1",
        models = listOf("gpt-5.2", "gpt-5.1", "gpt-5-mini", "gpt-4.1", "gpt-4o-mini"),
        defaultModel = "gpt-5-mini",
        keyHint = "Key: platform.openai.com/api-keys"
    ),
    ProviderPreset(
        id = "anthropic", title = "Anthropic Claude (API key only)",
        kind = ProviderKind.ANTHROPIC,
        baseUrl = "https://api.anthropic.com",
        models = listOf(
            "claude-sonnet-5", "claude-opus-5", "claude-fable-5-1", "claude-haiku-4-5-20251001"
        ),
        defaultModel = "claude-sonnet-5",
        keyHint = "Key: console.anthropic.com/settings/keys"
    ),
    ProviderPreset(
        id = "openrouter", title = "OpenRouter (many models)",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "https://openrouter.ai/api/v1",
        models = listOf(
            "google/gemini-2.5-flash", "openai/gpt-6-astra",
            "anthropic/claude-sonnet-5", "deepseek/deepseek-chat"
        ),
        defaultModel = "google/gemini-2.5-flash",
        keyHint = "Key: openrouter.ai/keys"
    ),
    ProviderPreset(
        id = "groq", title = "Groq (fast)",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "https://api.groq.com/openai/v1",
        models = listOf(
            "llama-3.3-70b-versatile", "openai/gpt-oss-120b", "llama-3.1-8b-instant"
        ),
        defaultModel = "llama-3.3-70b-versatile",
        keyHint = "Key: console.groq.com/keys"
    ),
    ProviderPreset(
        id = "deepseek", title = "DeepSeek",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "https://api.deepseek.com/v1",
        models = listOf("deepseek-chat", "deepseek-reasoner"),
        defaultModel = "deepseek-chat",
        keyHint = "Key: platform.deepseek.com"
    ),
    ProviderPreset(
        id = "ollama", title = "Ollama (local, in Termux)",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "http://127.0.0.1:11434/v1",
        models = listOf("llama3.2", "qwen3:8b", "mistral"),
        defaultModel = "llama3.2",
        keyHint = "No key needed — run Ollama in Termux on the phone",
        needsKey = false
    ),
    ProviderPreset(
        id = "lmstudio", title = "LM Studio (local)",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "http://127.0.0.1:1234/v1",
        models = listOf("local-model"),
        defaultModel = "local-model",
        keyHint = "No key needed — start LM Studio's local server",
        needsKey = false
    ),
    ProviderPreset(
        id = "custom", title = "Custom (OpenAI-compatible)",
        kind = ProviderKind.OPENAI_COMPATIBLE,
        baseUrl = "",
        models = emptyList(),
        defaultModel = "",
        keyHint = "Any OpenAI-compatible endpoint: base URL + key + model name"
    )
)

fun presetById(id: String): ProviderPreset = PROVIDER_PRESETS.firstOrNull { it.id == id } ?: PROVIDER_PRESETS.last()
