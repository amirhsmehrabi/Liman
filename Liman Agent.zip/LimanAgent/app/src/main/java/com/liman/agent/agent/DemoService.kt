package com.liman.agent.agent

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * v2.21.0 — THE UI BRIDGE (Demonstration → Automation + cross-app control).
 *
 * Two capabilities in one Android AccessibilityService:
 *
 *  1. DEMONSTRATION RECORDING ("watch me once, automate it forever"):
 *     while recording, every screen change, tap, typed text, scroll and
 *     notification is appended as a human-readable line to a session log in
 *     workspace/demo/. The agent reads the log, distills the PROCEDURE
 *     (what happened, why, which parts are variables), and replays or
 *     automates it. Better than a macro recorder: the recording becomes an
 *     explanation the agent can generalize from, not blind coordinates.
 *
 *  2. UI ACTIONS (the act half of the bridge): tap by text/id, type into
 *     the focused field, scroll, back/home/recents/notifications, and
 *     open_app. This is how Liman drives apps that have no API (Instagram,
 *     Bale, Eitaa, …) — the missing piece of cross-platform pipelines.
 *
 * The user enables it once in system Settings → Accessibility → Liman.
 * Pure helpers ([DemoLog]) are unit-tested; the service itself is a thin shell.
 */
class DemoService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        if (!recording || event == null) return
        runCatching {
            val src = event.source
            val line = DemoLog.describe(
                type = event.eventType,
                pkg = event.packageName?.toString().orEmpty(),
                cls = event.className?.toString().orEmpty(),
                eventText = joinText(event.text),
                srcText = joinText(src?.text),
                srcDesc = src?.contentDescription?.toString()?.trim().orEmpty(),
                viewId = src?.viewIdResourceName.orEmpty()
            ) ?: return
            val f = logFile ?: return
            synchronized(f) { f.appendText(line + "\n") }
        }
    }

    override fun onInterrupt() {}

    /** AccessibilityEvent.text is a List<CharSequence>, node text is a
     *  CharSequence — handle both shapes defensively. */
    private fun joinText(v: Any?): String = when (v) {
        null -> ""
        is List<*> -> v.joinToString(" ") { it?.toString() ?: "" }.trim()
        else -> v.toString().trim()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile
        var recording: Boolean = false
            private set

        @Volatile
        var logFile: File? = null
            private set

        @Volatile
        var instance: DemoService? = null
            private set

        fun serviceReady(): Boolean = instance != null

        /** Start a recording session; returns the log file (header pre-written). */
        fun start(workspace: File): File {
            val dir = File(workspace, "demo").apply { mkdirs() }
            val ts = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val f = File(dir, "session-$ts.log")
            f.writeText(
                "DEMO SESSION $ts — the user demonstrates a manual procedure.\n" +
                    "Lines: SCREEN <app> · TAP <control> · TYPE \"<text>\" → <field> · SCROLL · NOTIF <app>.\n" +
                    "Distill this into a procedure (steps + why + variables), not blind coordinates.\n" +
                    "----\n"
            )
            logFile = f
            recording = true
            return f
        }

        fun stop(): File? {
            recording = false
            return logFile
        }

        // ---------------- UI actions (used by the `ui` tool) ----------------

        fun tap(text: String?, viewId: String?, desc: String?): String {
            val svc = instance ?: return notEnabled()
            val root = svc.rootInActiveWindow ?: return "No active window to tap in."
            var node: AccessibilityNodeInfo? = when {
                !text.isNullOrBlank() ->
                    root.findAccessibilityNodeInfosByText(text)
                        .firstOrNull { it.text?.toString()?.contains(text, true) == true || it.viewIdResourceName?.contains(text, true) == true }
                        ?: root.findAccessibilityNodeInfosByText(text).firstOrNull()
                !viewId.isNullOrBlank() -> root.findAccessibilityNodeInfosByViewId(viewId).firstOrNull()
                !desc.isNullOrBlank() -> root.findAccessibilityNodeInfosByText(desc).firstOrNull()
                else -> null
            } ?: return "Control not found (text='$text' id='$viewId' desc='$desc'). Try ui record to see the screen, or tap by another label."
            // walk up to the nearest clickable ancestor (labels aren't clickable)
            var cur = node
            var hops = 0
            while (cur != null && !cur.isClickable && hops < 8) {
                cur = cur.parent; hops++
            }
            val target = (cur ?: node) ?: return "Control vanished before the tap."
            return if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                "TAPPED: '${target.text ?: target.contentDescription ?: target.viewIdResourceName ?: "?"}'"
            } else "Found the control but it refused the click (not clickable). Try scrolling it into view or tapping its parent by text."
        }

        fun typeText(value: String): String {
            val svc = instance ?: return notEnabled()
            val root = svc.rootInActiveWindow ?: return "No active window."
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: return "No focused input field — tap a field first (ui tap), then type."
            val args = Bundle().apply { putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value
            ) }
            return if (focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                "TYPED ${value.length} chars into the focused field."
            } else "The focused field does not accept programmatic text (some keyboards/webviews). Try clipboard + paste manually."
        }

        fun scroll(direction: String): String {
            val svc = instance ?: return notEnabled()
            val root = svc.rootInActiveWindow ?: return "No active window."
            val scrollable = findScrollable(root, 0)
                ?: return "No scrollable container found on this screen."
            val action = if (direction.equals("backward", true))
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            return if (scrollable.performAction(action)) "Scrolled $direction."
            else "Scroll container refused the action."
        }

        fun global(action: String): String {
            val svc = instance ?: return notEnabled()
            val ga = when (action) {
                "back" -> GLOBAL_ACTION_BACK
                "home" -> GLOBAL_ACTION_HOME
                "recents" -> GLOBAL_ACTION_RECENTS
                "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
                else -> return "Unknown global action '$action'."
            }
            return if (svc.performGlobalAction(ga)) "Performed $action." else "Global action '$action' failed."
        }

        // ---------------- v2.27.0 PERCEPTION (droidclaw perceive + agent-device refs) ----------------

        /** nodes of the LAST snapshot, parallel to UiGuard refs — refs are valid from the latest snapshot only */
        private var snapshotNodes: List<AccessibilityNodeInfo> = emptyList()
        private var snapshotElements: List<UiGuard.Element> = emptyList()

        private fun collectInteractive(n: AccessibilityNodeInfo?, out: ArrayList<UiGuard.RawNode>, nodes: ArrayList<AccessibilityNodeInfo>, depth: Int) {
            if (n == null || out.size >= 60 || depth > 30) return
            if (n.isClickable || n.isEditable || n.isCheckable) {
                out.add(UiGuard.RawNode(n.isClickable, n.isEditable, n.isCheckable, n.text?.toString() ?: "", n.contentDescription?.toString() ?: "", n.viewIdResourceName ?: ""))
                nodes.add(n)
            }
            for (i in 0 until n.childCount.coerceAtMost(40)) {
                collectInteractive(n.getChild(i), out, nodes, depth + 1)
            }
        }

        /**
         * THE EYES of the ui tool: a compact, ref-addressable view of the
         * current screen (interactive elements only — token-efficient).
         */
        fun snapshot(): String {
            val svc = instance ?: return notEnabled()
            val root = svc.rootInActiveWindow ?: return "No active window. Launch the app first (ui open_app), then snapshot."
            val raw = ArrayList<UiGuard.RawNode>()
            val nodes = ArrayList<AccessibilityNodeInfo>()
            collectInteractive(root, raw, nodes, 0)
            val elements = UiGuard.assignRefs(raw)
            snapshotNodes = nodes
            snapshotElements = elements
            val pkg = root.packageName?.toString() ?: "?"
            val sig = UiGuard.signature(elements)
            val stuck = UiGuard.observeScreen(sig)
            return buildString {
                appendLine("SCREEN SNAPSHOT — app: $pkg · ${elements.size} interactive elements (refs are valid until the next action; re-snapshot after acting):")
                if (elements.isEmpty()) {
                    appendLine("(no interactive elements — webview/game/canvas? try scrolling, or drive it blind with tap by text)")
                } else {
                    elements.forEach { appendLine(it.line()) }
                }
                stuck?.let { appendLine(it) }
            }
        }

        /** The elements of the last snapshot (for ref lookups elsewhere). */
        fun lastElements(): List<UiGuard.Element> = snapshotElements

        /** Tap by ref from the LATEST snapshot (agent-device contract). */
        fun tapRef(ref: String): String {
            val idx = ref.trim().removePrefix("@e").toIntOrNull()
            if (idx == null || idx < 1 || idx > snapshotNodes.size)
                return "Unknown ref '$ref' — refs are valid only from the LATEST ui snapshot. Take one and use its @eN ids."
            val node = snapshotNodes[idx - 1]
            runCatching { node.refresh() }
            var cur: AccessibilityNodeInfo? = node
            var hops = 0
            while (cur != null && !cur.isClickable && hops < 8) { cur = cur.parent; hops++ }
            val target = cur ?: node
            val label = target.text?.toString() ?: target.contentDescription?.toString() ?: ref
            return if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                "TAPPED $ref: '$label'"
            } else "Ref $ref ('${label.take(30)}') found but refused the click — take a fresh snapshot and try another control."
        }

        private fun findScrollable(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
            if (n == null || depth > 14) return null
            if (n.isScrollable) return n
            for (i in 0 until (n.childCount.coerceAtMost(30))) {
                findScrollable(n.getChild(i), depth + 1)?.let { return it }
            }
            return null
        }

        private fun notEnabled(): String =
            "The Liman accessibility service is not enabled. Ask the user to open " +
                "Android Settings → Accessibility → Liman (demo recorder & UI bridge) and turn it ON, then retry."
    }
}

/**
 * Pure helpers for the demo log — unit-tested (no Android dependencies).
 */
object DemoLog {

    // Android accessibility event types (stable public constants)
    const val TYPE_VIEW_CLICKED = 0x1
    const val TYPE_VIEW_LONG_CLICKED = 0x2
    const val TYPE_VIEW_TEXT_CHANGED = 0x10
    const val TYPE_WINDOW_STATE_CHANGED = 0x20
    const val TYPE_NOTIFICATION_STATE_CHANGED = 0x40
    const val TYPE_VIEW_SCROLLED = 0x1000

    /** Map an accessibility event to one human-readable log line (null = ignore). */
    fun describe(
        type: Int,
        pkg: String,
        cls: String,
        eventText: String,
        srcText: String,
        srcDesc: String,
        viewId: String
    ): String? {
        val app = appShort(pkg)
        val label = (srcText.ifBlank { srcDesc }).take(80)
        val idNote = viewId.substringAfterLast('/').take(40).ifBlank { "" }
        return when (type) {
            TYPE_WINDOW_STATE_CHANGED -> {
                val screen = cls.substringAfterLast('.').ifBlank { app }
                "SCREEN $app · $screen"
            }
            TYPE_VIEW_CLICKED, TYPE_VIEW_LONG_CLICKED -> {
                val kind = if (type == TYPE_VIEW_LONG_CLICKED) "LONG-TAP" else "TAP"
                "$kind ${label.ifBlank { eventText.take(60).ifBlank { idNote.ifBlank { "?" } } }}" +
                    (if (idNote.isNotBlank()) " (id:$idNote)" else "") + " @ $app"
            }
            TYPE_VIEW_TEXT_CHANGED -> {
                if (eventText.isBlank()) null
                else "TYPE \"${eventText.take(80)}\" → ${idNote.ifBlank { label.ifBlank { "field" } }} @ $app"
            }
            TYPE_VIEW_SCROLLED -> "SCROLL @ $app"
            TYPE_NOTIFICATION_STATE_CHANGED -> "NOTIF $app${if (eventText.isNotBlank()) " · ${eventText.take(60)}" else ""}"
            else -> null
        }
    }

    /**
     * org.telegram.messenger → telegram · com.instagram.android → instagram
     * com.android.chrome → chrome · com.google.android.youtube → youtube
     * (skips generic segments like android/google/app when something more
     * distinctive follows them)
     */
    private val GENERIC_SEGMENTS = setOf(
        "android", "google", "app", "apps", "mobile", "client", "core",
        "com", "org", "net", "io", "co", "inc", "official", "free", "pro", "www"
    )

    fun appShort(pkg: String): String {
        val parts = pkg.split('.').filter { it.isNotBlank() }
        if (parts.isEmpty()) return "?"
        val candidates = if (parts.size == 1) parts else parts.drop(1)
        return candidates.firstOrNull { it !in GENERIC_SEGMENTS }
            ?: candidates.lastOrNull { it !in GENERIC_SEGMENTS }
            ?: parts.last()
    }

    /**
     * Distill a raw session log into a numbered procedure the agent (and the
     * user) can review: drops the header, collapse repeated identical lines
     * into "(×N)", keeps order. This is the "what happened" half of
     * Demonstration → Automation; the agent adds the "why + variables".
     */
    fun summarize(log: String, maxSteps: Int = 40): String {
        val lines = log.lines()
            .dropWhile { it.startsWith("DEMO SESSION") || it.startsWith("Lines:") || it.startsWith("Distill") }
            .filter { it.isNotBlank() && it != "----" }
        if (lines.isEmpty()) return "(empty recording)"
        val condensed = mutableListOf<String>()
        var last: String? = null
        var repeat = 0
        for (l in lines) {
            if (l == last) { repeat++; continue }
            if (last != null) condensed += last + if (repeat > 0) "  (×${repeat + 1})" else ""
            last = l; repeat = 0
        }
        last?.let { condensed += it + if (repeat > 0) "  (×${repeat + 1})" else "" }
        return condensed.take(maxSteps).mapIndexed { i, s -> "${i + 1}. $s" }
            .joinToString("\n") + if (condensed.size > maxSteps) "\n…(+${condensed.size - maxSteps} more)" else ""
    }

    /** Status line for the `ui` tool (pure — state passed in). */
    fun status(serviceOn: Boolean, recordingOn: Boolean, logName: String?): String = buildString {
        append("accessibility service: ").append(if (serviceOn) "ON" else "OFF")
        append(" · recording: ").append(if (recordingOn) "ON → ${logName ?: "?"}" else "off")
    }

    /** Fire a toast hint (device only). */
    fun hint(context: android.content.Context, msg: String) {
        runCatching { Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
    }
}
