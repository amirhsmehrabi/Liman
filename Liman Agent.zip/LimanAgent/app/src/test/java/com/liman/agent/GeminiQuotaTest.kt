package com.liman.agent

import com.liman.agent.llm.GeminiProvider
import com.liman.agent.llm.HttpProvException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.13.3 — Gemini free-tier quota handling.
 *
 * The user hit "429 You exceeded your current quota" after ONE message and
 * Liman retried blindly every ~8 s, which can never clear a per-minute quota
 * window (and is hopeless for the daily cap). These tests pin the parser:
 * clean message (no raw JSON in the chat), server retryDelay extraction, and
 * per-minute vs DAILY quota detection.
 */
class GeminiQuotaTest {

    private val perMinuteBody = """
    {
      "error": {
        "code": 429,
        "message": "You exceeded your current quota, please check your plan and billing details. For more information on this error, head to: https://ai.google.dev/gemini-api/docs/rate-limits.",
        "status": "RESOURCE_EXHAUSTED",
        "details": [
          {
            "@type": "type.googleapis.com/google.rpc.RetryInfo",
            "retryDelay": "26s"
          },
          {
            "@type": "type.googleapis.com/google.rpc.QuotaFailure",
            "violations": [
              {
                "quotaMetric": "generativelanguage.googleapis.com/generate_content_free_tier_requests",
                "quotaId": "GenerateRequestsPerMinutePerProjectPerModel"
              }
            ]
          }
        ]
      }
    }
    """.trimIndent()

    private val dailyBody = """
    {
      "error": {
        "code": 429,
        "message": "You exceeded your current quota, please check your plan and billing details.",
        "status": "RESOURCE_EXHAUSTED",
        "details": [
          {
            "@type": "type.googleapis.com/google.rpc.QuotaFailure",
            "violations": [
              {
                "quotaMetric": "generativelanguage.googleapis.com/generate_content_free_tier_requests",
                "quotaId": "GenerateRequestsPerDayPerProjectPerModel"
              }
            ]
          }
        ]
      }
    }
    """.trimIndent()

    @Test
    fun parsesPerMinuteQuotaWithRetryDelay() {
        val e = GeminiProvider.parseError(429, perMinuteBody)
        assertEquals(429, e.code)
        assertTrue("retryDelay 26s must be honored", e.retryAfterMs == 26_000L)
        assertTrue("must be flagged as a quota limit", e.quotaPerMinute)
        assertFalse("not the daily cap", e.quotaDaily)
        // clean message: no raw JSON braces in what the user sees
        assertTrue("message must be the clean text", e.message!!.contains("You exceeded your current quota"))
        assertFalse("no raw JSON dump in the message", e.message!!.contains("\"error\""))
        assertFalse("no raw JSON dump in the message", e.message!!.contains("{"))
    }

    @Test
    fun parsesDailyCap() {
        val e = GeminiProvider.parseError(429, dailyBody)
        assertTrue("PerDay quota must be detected", e.quotaDaily)
        assertTrue("daily cap still gets a sane default wait", (e.retryAfterMs ?: 0) >= 20_000L)
    }

    @Test
    fun nonQuotaErrorsKeepTheirMessage() {
        val e = GeminiProvider.parseError(400, """{"error":{"code":400,"message":"API key not valid."}}""")
        assertEquals(400, e.code)
        assertTrue(e.message!!.contains("API key not valid."))
        assertNull(e.retryAfterMs)
        assertFalse(e.quotaDaily)
    }

    @Test
    fun garbageBodyFallsBackToRawTextAndDefault429Wait() {
        val e = GeminiProvider.parseError(429, "<html>gateway error</html>")
        assertEquals(429, e.code)
        assertTrue(e.message!!.contains("gateway error"))
        assertEquals("429 with unknown body gets the default free-tier wait", 20_000L, e.retryAfterMs)
    }

    @Test
    fun fractionalRetryDelayIsParsed() {
        val body = """{"error":{"code":429,"message":"slow down","details":[
            {"@type":"type.googleapis.com/google.rpc.RetryInfo","retryDelay":"1.5s"}]}}"""
        val e = GeminiProvider.parseError(429, body)
        assertEquals(1_500L, e.retryAfterMs)
    }
}
