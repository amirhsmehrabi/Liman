package com.liman.agent

import com.liman.agent.data.Conversation
import com.liman.agent.data.ConversationStore
import com.liman.agent.util.now
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/** v2.31 — per-chat workspaces + conversation plan-mode/roadmap persistence. */
class WorkspaceTest {

    @get:Rule
    val tmp = TemporaryFolder()

    @Test fun `new conversations own their workspace, legacy ones do not`() {
        val store = ConversationStore(File(tmp.newFolder(), "convs"))
        val fresh = store.newConversation()
        assertTrue("new chats get their own folder", fresh.ownWorkspace)
        val legacy = Conversation(id = "old-1", ownWorkspace = false)
        assertFalse(legacy.ownWorkspace)
    }

    @Test fun `chat workspace lives under workspace-chats`() {
        val root = File(tmp.newFolder(), "workspace")
        val chatDir = File(root, "chats/task-42").apply { mkdirs() }
        File(chatDir, "report.md").writeText("hi")
        assertEquals("hi", File(chatDir, "report.md").readText())
        assertTrue(chatDir.toPath().startsWith(root.resolve("chats").toPath()))
    }

    @Test fun `conversation roundtrips plan mode and roadmap`() {
        val store = ConversationStore(File(tmp.newFolder(), "convs"))
        val c = store.newConversation()
        c.planMode = true
        c.roadmap = com.liman.agent.data.Roadmap(
            "Build a Bale bot", "proposed",
            listOf(
                com.liman.agent.data.RoadmapTask("t1", "read the bot API docs"),
                com.liman.agent.data.RoadmapTask("t2", "write + deploy the bot", "in_progress")
            )
        )
        c.updatedAt = now()
        kotlinx.coroutines.runBlocking { store.save(c) }
        val loaded = store.load(c.id)!!
        assertTrue(loaded.planMode)
        assertEquals("Build a Bale bot", loaded.roadmap!!.title)
        assertEquals(2, loaded.roadmap!!.tasks.size)
        assertEquals("in_progress", loaded.roadmap!!.tasks[1].status)
        assertEquals("proposed", loaded.roadmap!!.status)
    }

    @Test fun `legacy conversation json without new fields still loads`() {
        val dir = File(tmp.newFolder(), "convs").apply { mkdirs() }
        // serialized by v2.30 (no planMode/ownWorkspace/roadmap keys)
        File(dir, "legacy.json").writeText(
            """{"id":"legacy","title":"Old","createdAt":1,"updatedAt":2,"entries":[],"llmMessages":[]}"""
        )
        val store = ConversationStore(dir)
        val c = store.load("legacy")
        assertTrue(c != null)
        assertEquals("Old", c!!.title)
        assertFalse(c.planMode)
        assertEquals(null, c.roadmap)
    }
}
