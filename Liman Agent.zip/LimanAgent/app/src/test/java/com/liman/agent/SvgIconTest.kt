package com.liman.agent

import com.liman.agent.agent.HtmlRenderer
import com.liman.agent.agent.SvgIcon
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v2.30.0 — vector icon pipeline + SVG→VectorDrawable (APP FACTORY §5). */
class SvgIconTest {

    @Test fun `base icon set is substantial and svg-compliant`() {
        assertTrue("embedded set too small: ${SvgIcon.ICONS.size}", SvgIcon.ICONS.size >= 30)
        SvgIcon.ICONS.forEach { (name, body) ->
            assertTrue("$name not kebab-case", Regex("^[a-z0-9-]+$").matches(name))
            assertTrue("$name has raw color", !body.contains("#"))
        }
        val svg = SvgIcon.svg("search")!!
        assertTrue(svg.contains("""viewBox="0 0 24 24""""))
        assertTrue(svg.contains("stroke-width=\"1.75\""))
        assertNull(SvgIcon.svg("nonexistent"))
    }

    @Test fun `convert embedded icon to vector drawable`() {
        val r = SvgIcon.toVectorDrawable(SvgIcon.svg("trash")!!, "ic_trash")
        assertTrue(r.ok)
        val xml = r.xml!!
        assertTrue(xml.contains("<vector"))
        assertTrue(xml.contains("android:viewportWidth=\"24\""))
        assertTrue(xml.contains("android:pathData="))
        assertTrue(xml.contains("android:strokeColor=\"#FF000000\""))
        assertTrue(xml.contains("android:strokeWidth=\"1.75\""))
        assertTrue(xml.contains("android:fillColor=\"#00000000\""))
    }

    @Test fun `convert circle rect line shapes`() {
        val svg = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/><rect x="2" y="2" width="20" height="20"/><line x1="4" y1="4" x2="20" y2="20"/>
        </svg>"""
        val r = SvgIcon.toVectorDrawable(svg, "ic_shapes")
        assertTrue(r.ok)
        assertTrue(r.xml!!.contains("A 10.0 10.0 0 1 0"))     // circle → arcs
        assertTrue(r.xml!!.contains("H22.0 V22.0"))           // rect → H/V
        assertTrue(r.xml!!.contains("M4 4 L20 20"))           // line → M/L
    }

    @Test fun `unsupported features are rejected not broken`() {
        val bad = """<svg viewBox="0 0 24 24"><defs><filter id="f"><feGaussianBlur/></filter></defs><path d="M0 0" filter="url(#f)"/></svg>"""
        val r = SvgIcon.toVectorDrawable(bad, "ic_bad")
        assertTrue(!r.ok)
        assertTrue(r.error!!.contains("unsupported"))
    }

    @Test fun `spec is the doctrine`() {
        val s = SvgIcon.spec()
        assertTrue(s.contains("viewBox=\"0 0 24 24\""))
        assertTrue(s.contains("66dp safe zone"))
        assertTrue(s.contains("kebab-case"))
    }

    @Test fun `audit formatter parses webview result`() {
        val js = "\"LIMAN_AUDIT|clickable=3|tapTargetFail=1|tap: BUTTON \\\"Save\\\" 40x32|hOverflow=true|h1Count=1|imgNoAlt=0\""
        val out = HtmlRenderer.formatAudit(js)
        assertTrue(out.contains("tap target(s) under 44px"))
        assertTrue(out.contains("Save"))
        assertTrue(out.contains("horizontal overflow"))
        val clean = HtmlRenderer.formatAudit("\"LIMAN_AUDIT|clickable=5|tapTargetFail=0|hOverflow=false|h1Count=1|imgNoAlt=0\"")
        assertTrue(clean.contains("clean"))
        assertEquals("", HtmlRenderer.formatAudit(null))
    }

    @Test fun `audit formatter reads low contrast note`() {
        val js = "\"LIMAN_AUDIT|clickable=2|tapTargetFail=0|hOverflow=false|h1Count=1|imgNoAlt=0|lowContrast: \\\"Read more\\\" 2.90:1\""
        val out = HtmlRenderer.formatAudit(js)
        assertTrue(out.contains("low contrast"))
        assertTrue(out.contains("2.90:1"))
    }
}
