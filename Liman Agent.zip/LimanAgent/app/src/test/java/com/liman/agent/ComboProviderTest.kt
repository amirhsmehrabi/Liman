package com.liman.agent

import com.liman.agent.data.ComboConfig
import com.liman.agent.data.ComboMode
import com.liman.agent.llm.ComboFailureException
import com.liman.agent.llm.ComboProvider
import com.liman.agent.llm.EmptyResponseException
import com.liman.agent.llm.GenSettings
import com.liman.agent.llm.HttpProvException
import com.liman.agent.llm.LlmMessage
import com.liman.agent.llm.LlmResult
import com.liman.agent.llm.LlmRequest
import com.liman.agent.llm.LPart
import com.liman.agent.llm.ProviderRunner
import com.liman.agent.llm.Role
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class ComboProviderTest {

    private val req = LlmRequest(
        listOf(LlmMessage(Role.USER, listOf(LPart.Text("hi")))),
        emptyList(),
        GenSettings(0.5, 100, false)
    )

    private fun handle(id: String, behavior: suspend () -> LlmResult): ComboProvider.Handle =
        ComboProvider.Handle(id, id, "test-model", ProviderRunner { _, _ -> behavior() })

    private fun ok(text: String = "done") = LlmResult(text = text, providerName = "x", modelName = "m")

    @Test
    fun failoverSwitchesToSecondProvider() = runBlocking {
        val events = ArrayList<String>()
        val combo = ComboProvider(
            listOf(
                handle("a") { throw IOException("network down") },
                handle("b") { ok("from B") }
            ),
            ComboConfig(mode = ComboMode.FAILOVER, retriesPerProvider = 1),
            onEvent = { events.add(it) }
        )
        val result = combo.complete(req)
        assertEquals("from B", result.text)
        assertTrue(events.any { it.contains("a failed") })
        assertTrue(events.any { it.contains("Switching provider") })
    }

    @Test
    fun retriesOnRetryableError() = runBlocking {
        var calls = 0
        val combo = ComboProvider(
            listOf(handle("a") {
                calls++
                if (calls < 3) throw HttpProvException(429, "rate limited") else ok("third time lucky")
            }),
            ComboConfig(mode = ComboMode.FAILOVER, retriesPerProvider = 3),
            delayer = { } // no waiting in tests
        )
        val result = combo.complete(req)
        assertEquals("third time lucky", result.text)
        assertEquals(3, calls)
    }

    @Test
    fun nonRetryableSkipsStraightToNextProvider() = runBlocking {
        var callsA = 0
        val combo = ComboProvider(
            listOf(
                handle("a") { callsA++; throw HttpProvException(401, "bad key") },
                handle("b") { ok("B wins") }
            ),
            ComboConfig(mode = ComboMode.FAILOVER, retriesPerProvider = 3),
            delayer = { }
        )
        assertEquals("B wins", combo.complete(req).text)
        assertEquals(1, callsA) // 401 is fatal → no retry on A
    }

    @Test
    fun raceReturnsFirstSuccess() = runBlocking {
        val combo = ComboProvider(
            listOf(
                handle("slow") { kotlinx.coroutines.delay(250); ok("slow") },
                handle("fast") { ok("fast wins") }
            ),
            ComboConfig(mode = ComboMode.RACE)
        )
        assertEquals("fast wins", combo.complete(req).text)
    }

    @Test
    fun allFailuresThrow() {
        var threw = false
        try {
            runBlocking {
                val combo = ComboProvider(
                    listOf(handle("a") { throw EmptyResponseException() }),
                    ComboConfig(mode = ComboMode.FAILOVER, retriesPerProvider = 2),
                    delayer = { }
                )
                combo.complete(req)
            }
        } catch (e: ComboFailureException) {
            threw = true
        }
        assertTrue(threw)
    }

    @Test
    fun roundRobinRotates() = runBlocking {
        var aCalls = 0
        var bCalls = 0
        val combo = ComboProvider(
            listOf(
                handle("a") { aCalls++; ok("A") },
                handle("b") { bCalls++; ok("B") }
            ),
            ComboConfig(mode = ComboMode.ROUND_ROBIN)
        )
        combo.complete(req)
        combo.complete(req)
        // after two rotations both providers should have served once
        assertEquals(1, aCalls)
        assertEquals(1, bCalls)
    }
}
