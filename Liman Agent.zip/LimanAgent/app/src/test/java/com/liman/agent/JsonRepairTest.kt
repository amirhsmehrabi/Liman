package com.liman.agent

import com.liman.agent.util.JsonRepair
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * JsonRepair — the fix for runs stalling after long high-volume
 * tool-call work: malformed / truncated JSON arguments get repaired
 * instead of failing the parse.
 */
class JsonRepairTest {

    private fun roundtrip(raw: String): Pair<String, Boolean> = JsonRepair.repair(raw)

    @Test
    fun `valid json passes through untouched`() {
        val (s, fixed) = roundtrip("""{"name":"a.txt","content":"hi"}""")
        assertFalse(fixed)
        assertTrue(s.contains("a.txt"))
    }

    @Test
    fun `truncated object is closed`() {
        val raw = """{"name":"report.md","content":"# Title
some long text that got cut off mid-va"""
        val (s, fixed) = roundtrip(raw)
        assertTrue(fixed)
        assertNotNull(s)
        assertTrue(s.contains("report.md"))
    }

    @Test
    fun `truncated nested structure is balanced`() {
        val raw = """{"files":["one.txt","two.txt","three"""
        val (s, fixed) = roundtrip(raw)
        assertTrue(fixed)
        assertTrue(s.contains("one.txt"))
    }

    @Test
    fun `code fence is stripped`() {
        val raw = "```json\n{\"a\":1}\n```"
        val (s, fixed) = roundtrip(raw)
        assertTrue(fixed) // stripping the fence counts as a repair
        assertEquals("""{"a":1}""", s)
    }

    @Test
    fun `dangling key gets empty string`() {
        val raw = """{"name":"x","content":"""
        val (s, fixed) = roundtrip(raw)
        assertTrue(fixed)
        assertTrue(s.contains("x"))
    }

    @Test
    fun `trailing comma is dropped`() {
        val raw = """{"a":1,"b":2,"""
        val (s, fixed) = roundtrip(raw)
        assertTrue(fixed)
        assertTrue(s.contains("1"))
    }

    @Test
    fun `garbage stays garbage without crash`() {
        val (s, fixed) = roundtrip("")
        assertFalse(fixed)
        val (s2, fixed2) = roundtrip("not json at all")
        assertFalse(fixed2)
        assertEquals("not json at all", s2)
    }

    @Test
    fun `multi-path string with escaped quote inside truncation`() {
        val raw = """{"find":"he said \"hi","replace":"bye","name":"f"""
        val (s, fixed) = roundtrip(raw)
        assertTrue(fixed)
    }
}
