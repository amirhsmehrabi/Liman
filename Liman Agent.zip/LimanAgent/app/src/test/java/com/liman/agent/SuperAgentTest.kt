package com.liman.agent

import com.liman.agent.agent.PromptVars
import com.liman.agent.agent.UiGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.27.0 — THE SUPER AGENT PACK, distilled from five studied repos:
 *  • droidclaw — stuck-loop / repetition / drift detection
 *  • agent-device — token-efficient snapshots with @eN refs
 *  • knotwork — prompt variables, run ceilings, date-chip/bubble style
 *  • openclaude — slash commands (UI-side)
 *  • opencode — auto-compact (already existed in Liman, 3-stage)
 */
class SuperAgentTest {

    private fun v(name: String) = "\$" + name // a literal $NAME for prompts under test

    // ================================================== refs (agent-device)

    @Test fun refsAssignedInOrderAndCapped() {
        val raw = (1..70).map { UiGuard.RawNode(true, false, false, "btn" + it, "", "com.app:id/b" + it) }
        val els = UiGuard.assignRefs(raw)
        assertEquals(60, els.size) // capped for token efficiency
        assertEquals("@e1", els.first().ref)
        assertEquals("@e60", els.last().ref)
        assertTrue(els.first().line().contains("[button] \"btn1\""))
    }

    @Test fun elementKindsFromNodeFacts() {
        val els = UiGuard.assignRefs(
            listOf(
                UiGuard.RawNode(true, false, false, "Save", "", "id/save"),
                UiGuard.RawNode(false, true, false, "", "your name", "id/name"),
                UiGuard.RawNode(true, true, false, "ok", "", "id/ok"),
                UiGuard.RawNode(false, false, true, "Dark mode", "", "id/dark"),
                UiGuard.RawNode(true, false, false, "https://x.com/a", "", "id/link")
            )
        )
        assertEquals("button", els[0].kind)
        assertEquals("field", els[1].kind)
        assertEquals("field", els[2].kind)   // editable wins for input-like nodes
        assertEquals("toggle", els[3].kind)
        assertEquals("link", els[4].kind)
    }

    @Test fun signatureDetectsScreenChange() {
        val a = UiGuard.assignRefs(listOf(UiGuard.RawNode(true, false, false, "Login", "", "id/l")))
        val b = UiGuard.assignRefs(listOf(UiGuard.RawNode(true, false, false, "Logout", "", "id/l")))
        val a2 = UiGuard.assignRefs(listOf(UiGuard.RawNode(true, false, false, "Login", "", "id/l")))
        assertNotEquals(UiGuard.signature(a), UiGuard.signature(b))
        assertEquals(UiGuard.signature(a), UiGuard.signature(a2))
    }

    // ================================================== anti-fragility (droidclaw)

    @Test fun stuckLoopDetectedAfterThreeUnchangedScreens() {
        UiGuard.reset()
        val sig = "deadbeef"
        assertNull(UiGuard.observeScreen(sig))
        assertNull(UiGuard.observeScreen(sig))
        val hint = UiGuard.observeScreen(sig)
        assertNotNull(hint)
        assertTrue(hint!!.contains("STUCK"))
        assertTrue(hint.contains("NOT changed"))
        // a changed screen clears it
        assertNull(UiGuard.observeScreen("other"))
    }

    @Test fun repetitionDetectedOnThirdSameTarget() {
        UiGuard.reset()
        assertNull(UiGuard.recordAction("tap", "@e3"))
        assertNull(UiGuard.recordAction("tap", "@e3"))
        val hint = UiGuard.recordAction("tap", "@e3")
        assertNotNull(hint)
        assertTrue(hint!!.contains("REPETITION"))
        // varied targets do not trigger
        UiGuard.reset()
        assertNull(UiGuard.recordAction("tap", "@e3"))
        assertNull(UiGuard.recordAction("tap", "@e4"))
        assertNull(UiGuard.recordAction("tap", "@e3"))
    }

    @Test fun driftDetectedAfterFiveVariedNavOnlyActions() {
        UiGuard.reset()
        // wandering: varied navigation, no interaction — repetition can't fire, drift must
        assertNull(UiGuard.recordAction("scroll", "screen"))
        assertNull(UiGuard.recordAction("scroll", "screen"))
        assertNull(UiGuard.recordAction("back", "system"))
        assertNull(UiGuard.recordAction("home", "system"))
        val hint = UiGuard.recordAction("recents", "system")
        assertNotNull(hint)
        assertTrue(hint!!.contains("DRIFT"))
        // interacting resets the streak
        assertNull(UiGuard.recordAction("tap", "@e1"))
    }

    @Test fun repeatedIdenticalScrollStillFlaggedAsRepetition() {
        UiGuard.reset()
        assertNull(UiGuard.recordAction("scroll", "screen"))
        assertNull(UiGuard.recordAction("scroll", "screen"))
        val hint = UiGuard.recordAction("scroll", "screen")
        assertNotNull(hint)
        assertTrue(hint!!.contains("REPETITION"))
    }

    // ================================================== prompt variables (knotwork)

    @Test fun promptVarsRenderFresh() {
        val prompt = "Good morning " + v("USER") + " — it's " + v("WEEKDAY") + " " + v("DATE") + " " + v("TIME") +
            " on your " + v("DEVICE") + " (battery " + v("BATTERY") + ", lang " + v("LANG") + ", model " + v("MODEL") + ")."
        val out = PromptVars.expand(
            prompt, model = "gemini-2.5-flash", batteryPct = 77, language = "fa",
            userName = "Ali", nowMs = 1_760_000_000_000L
        )
        assertTrue(out.startsWith("Good morning Ali — it's "))
        assertTrue(out.contains("on your "))            // $DEVICE resolved to a device string
        assertTrue(out.contains("(battery 77%"))
        assertTrue(out.contains("lang fa"))
        assertTrue(out.contains("model gemini-2.5-flash"))
        assertTrue(!out.contains("$"))                  // nothing left unrendered
    }

    @Test fun promptVarsLeavePlainPromptsAlone() {
        assertEquals("just a normal prompt", PromptVars.expand("just a normal prompt", nowMs = 123L))
        assertEquals("(current combo)", PromptVars.expand(v("MODEL"), nowMs = 123L))
    }

    @Test fun promptVarsDatesUseInjectedClock() {
        val a = PromptVars.expand(v("DATE") + " " + v("TIME"), nowMs = 1_760_000_000_000L)
        val b = PromptVars.expand(v("DATE") + " " + v("TIME"), nowMs = 1_760_086_400_000L)
        assertNotEquals(a, b)
        assertTrue(a.matches(Regex("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")))
    }

    // ================================================== run ceiling (knotwork)

    @Test fun ceilingMathMatchesAgentCheck() {
        // the Agent loop aborts when tokensIn+tokensOut > ceiling; 0 disables it
        fun hit(inT: Int, outT: Int, ceiling: Int) = ceiling > 0 && inT + outT > ceiling
        assertTrue(hit(350_000, 80_000, 400_000))
        assertFalse(hit(350_000, 49_999, 400_000))
        assertFalse(hit(9_999_999, 9_999_999, 0)) // off
    }
}
