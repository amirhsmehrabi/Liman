package com.liman.agent

import com.liman.agent.agent.UiLint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v2.30.0 — deterministic static UI lint (APP FACTORY blueprint §9). */
class UiLintTest {

    private fun rules(html: String, css: String = "", bytes: Long = 0) =
        UiLint.lint(html, css, bytes).map { it.rule }

    @Test fun `clean token-based page passes`() {
        val html = """
            <!doctype html><html><head><meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>@media (prefers-color-scheme: dark){:root{--surface:#111}}</style></head>
            <body><h1>Hi</h1><img alt="dog"><button class="btn">Go</button></body></html>
        """.trimIndent()
        assertEquals(emptyList<String>(), rules(html))
    }

    @Test fun `raw hex is flagged`() {
        val f = UiLint.lint("<style>.a{color: #ff5a36}</style>", "")
        assertTrue(f.any { it.rule == "raw-hex" && it.detail.contains("#ff5a36") })
        assertTrue(f.first { it.rule == "raw-hex" }.fix.contains("token"))
    }

    @Test fun `off-scale spacing is flagged, on-scale passes`() {
        val bad = UiLint.lint("<style>.a{padding: 13px}</style>")
        assertTrue(bad.any { it.rule == "off-scale-spacing" })
        val good = UiLint.lint("<style>.a{padding: 12px;margin: 0 16px;gap: 24px}</style>")
        assertTrue(good.none { it.rule == "off-scale-spacing" })
    }

    @Test fun `missing viewport and cdn links`() {
        val f = rules("<html><head><script src=\"https://cdn.example.com/lib.js\"></script></head><body><h1>x</h1></body></html>")
        assertTrue("viewport-meta" in f)
        assertTrue("cdn-dependency" in f)
    }

    @Test fun `anti patterns`() {
        val html = "<html><head><meta name=viewport content=x></head><body>" +
            "<p>lorem ipsum dolor</p><script>alert('x')</script>" +
            "<button>🔥</button></body></html>"
        val f = rules(html)
        assertTrue("lorem-ipsum" in f)
        assertTrue("alert-confirm" in f)
        assertTrue("emoji-icon" in f)
    }

    @Test fun `img without alt and no dark mode`() {
        val f = rules("<html><head><meta name=viewport content=x></head><body><img src=a.png></body></html>")
        assertTrue("img-alt" in f)
        assertTrue("dark-mode" in f)
    }

    @Test fun `font budget and important`() {
        val css = ".a{font-family:Georgia}.b{font-family:Verdana}.c{font-family:Impact;color:red !important; border:none !important; margin:0 !important}"
        val f = UiLint.lint("<style>$css</style>", "")
        assertTrue(f.any { it.rule == "font-budget" })
        assertTrue(f.any { it.rule == "important" })
    }

    @Test fun `size budget`() {
        val f = UiLint.lint("<html></html>", "", singleFileBytes = 400_000)
        assertTrue(f.any { it.rule == "size-budget" })
    }

    @Test fun `report formats findings with fixes`() {
        val r = UiLint.report(UiLint.lint("<style>.a{color:#fff;padding:13px}</style>"))
        assertTrue(r.contains("UI LINT: ⚠"))
        assertTrue(r.contains("fix:"))
        assertTrue(UiLint.report(emptyList()).contains("clean"))
    }
}
