package com.liman.agent

import com.liman.agent.agent.ApkBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Builds a sample APK with the pure-JVM ApkBuilder and writes it to
 * /tmp/liman-apkbuilder-test/sample.apk so it can be verified with the
 * reference Android tooling (aapt2 dump badging, apksigner verify).
 *
 * Also structurally self-verifies the zip, because the original streamed-zip
 * bug (data descriptors / zeroed local headers) made APKs uninstallable on
 * some Android 10 OEM ROMs with "There was a problem parsing the package":
 *  - every local header must carry REAL sizes+CRC and NEVER flag 0x0008
 *  - entry data must be 4-byte aligned (zipalign semantics)
 *  - META-INF v1 signature files must be present (v1+v2 dual signing)
 */
class ApkBuilderTest {

    private fun asset(name: String): ByteArray =
        File("src/main/assets/apkshell/$name").readBytes()

    @Test
    fun buildsVerifiedInstallableApk() {
        val files = mapOf(
            "index.html" to """
                <!DOCTYPE html>
                <html><head><meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>Liman Test App</title></head>
                <body><h1>Hello from Liman</h1><script src="app.js"></script></body></html>
            """.trimIndent().toByteArray(),
            "app.js" to "document.body.innerHTML += '<p>js works</p>'; localStorage.setItem('ok','1');".toByteArray()
        )
        val pkg = ApkBuilder.packageNameFor("Test App")
        val apk = ApkBuilder.build(
            appLabel = "Test App",
            packageName = pkg,
            files = files,
            classesDex = asset("classes.dex"),
            keyPkcs8Der = asset("signing.key"),
            certDer = asset("signing.cert")
        )

        assertTrue("APK too small: ${apk.size}", apk.size > 3_500)
        assertTrue("not a zip", apk[0] == 'P'.code.toByte() && apk[1] == 'K'.code.toByte())

        // v2 signing block magic must appear right before the central directory
        val magic = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)
        assertTrue("APK Sig Block magic not found", apk.indexOf(magic) > 0)

        // ---- structural zip self-check (the Android 10 OEM-ROM bug) ----
        val names = assertNonStreamedZip(apk)
        assertEquals("entry count", 7, names.size) // manifest, dex, 2 app files, 3 META-INF
        assertTrue("missing AndroidManifest.xml", "AndroidManifest.xml" in names)
        assertTrue("missing classes.dex", "classes.dex" in names)
        assertTrue("missing v1 MANIFEST.MF", "META-INF/MANIFEST.MF" in names)
        assertTrue("missing v1 CERT.SF", "META-INF/CERT.SF" in names)
        assertTrue("missing v1 CERT.RSA", "META-INF/CERT.RSA" in names)

        // v1 manifests are JAR-format with folded lines and sha-256 digests
        val mfText = String(entryBytes(apk, "META-INF/MANIFEST.MF"), Charsets.UTF_8)
        assertTrue("MF version line", mfText.startsWith("Manifest-Version: 1.0"))
        assertTrue("MF digests classes.dex", "Name: classes.dex" in mfText && "SHA-256-Digest:" in mfText)

        val out = File("/tmp/liman-apkbuilder-test")
        out.mkdirs()
        File(out, "sample.apk").writeBytes(apk)
        assertTrue(File(out, "sample.apk").length() == apk.size.toLong())
    }

    // ---------- zip structural checks (pure JVM, no android.*) ----------

    /** Walks EOCD → central directory → local headers; returns entry names. */
    private fun assertNonStreamedZip(apk: ByteArray): List<String> {
        // EOCD = last 22 bytes (we write no comment)
        val eocd = apk.size - 22
        assertEquals("EOCD magic", 0x06054b50, apk.readU32(eocd))
        val count = apk.readU16(eocd + 10)
        val cdOffset = apk.readU32(eocd + 16)

        val names = ArrayList<String>(count)
        var p = cdOffset
        for (i in 0 until count) {
            assertEquals("CD magic entry $i", 0x02014b50, apk.readU32(p))
            val nameLen = apk.readU16(p + 28)
            val extraLen = apk.readU16(p + 30)
            val commentLen = apk.readU16(p + 32)
            val lfhOffset = apk.readU32(p + 42)
            val name = String(apk, p + 46, nameLen, Charsets.UTF_8)
            names.add(name)

            // ---- local header must carry REAL values, never data descriptors ----
            assertEquals("LFH magic for $name", 0x04034b50, apk.readU32(lfhOffset))
            val flags = apk.readU16(lfhOffset + 6)
            assertTrue(
                "$name uses data descriptors (flags=${
                    Integer.toHexString(flags)
                }) — Android 10 OEM ROMs reject this",
                flags and 0x0008 == 0
            )
            val csize = apk.readU32(lfhOffset + 18)
            val usize = apk.readU32(lfhOffset + 22)
            val crc = apk.readU32(lfhOffset + 14)
            assertTrue("$name has zero csize in local header", csize != 0)
            assertTrue("$name has zero usize in local header", usize != 0)
            assertTrue("$name has zero crc in local header", crc != 0)
            // local and central records must agree
            assertEquals("$name csize mismatch", csize, apk.readU32(p + 20))
            assertEquals("$name usize mismatch", usize, apk.readU32(p + 24))

            // ---- 4-byte alignment of entry data (zipalign semantics) ----
            val lNameLen = apk.readU16(lfhOffset + 26)
            val lExtraLen = apk.readU16(lfhOffset + 28)
            val dataOffset = lfhOffset + 30 + lNameLen + lExtraLen
            assertTrue("$name data not 4-byte aligned (offset $dataOffset)", dataOffset % 4 == 0)

            p += 46 + nameLen + extraLen + commentLen
        }
        assertEquals("CD ends at EOCD", eocd, p)
        return names
    }

    /** reads a stored-in-CD entry by name and inflates it */
    private fun entryBytes(apk: ByteArray, want: String): ByteArray {
        val eocd = apk.size - 22
        val count = apk.readU16(eocd + 10)
        var p = apk.readU32(eocd + 16)
        for (i in 0 until count) {
            val nameLen = apk.readU16(p + 28)
            val extraLen = apk.readU16(p + 30)
            val commentLen = apk.readU16(p + 32)
            val lfhOffset = apk.readU32(p + 42)
            val name = String(apk, p + 46, nameLen, Charsets.UTF_8)
            if (name == want) {
                val method = apk.readU16(lfhOffset + 8)
                val csize = apk.readU32(lfhOffset + 18)
                val lNameLen = apk.readU16(lfhOffset + 26)
                val lExtraLen = apk.readU16(lfhOffset + 28)
                val dataOffset = lfhOffset + 30 + lNameLen + lExtraLen
                val data = apk.copyOfRange(dataOffset, dataOffset + csize)
                return if (method == 8) java.util.zip.InflaterInputStream(
                    data.inputStream(), java.util.zip.Inflater(true)
                ).readBytes() else data
            }
            p += 46 + nameLen + extraLen + commentLen
        }
        throw IllegalArgumentException("entry not found: $want")
    }
}

private fun ByteArray.indexOf(needle: ByteArray): Int {
    outer@ for (i in 0..size - needle.size) {
        for (j in needle.indices) if (this[i + j] != needle[j]) continue@outer
        return i
    }
    return -1
}

private fun ByteArray.readU16(off: Int): Int =
    (this[off].toInt() and 0xFF) or ((this[off + 1].toInt() and 0xFF) shl 8)

private fun ByteArray.readU32(off: Int): Int =
    readU16(off) or (readU16(off + 2) shl 16)
