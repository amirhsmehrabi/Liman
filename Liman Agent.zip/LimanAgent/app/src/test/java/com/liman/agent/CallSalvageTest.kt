package com.liman.agent

import com.liman.agent.agent.HeroMode
import com.liman.agent.agent.TextToolCalls
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.35.0 — CALL SALVAGE + FAILURE-NARRATIVE REJECTION.
 *
 * The production incident: the model wrote REAL tool calls as Claude-style
 * XML markup (<function_calls>/<invoke>/<parameter>) with a broken wrapper
 * closer (stray </design_tokens>). The JSON-only rescue couldn't parse it, so
 * the raw markup leaked into the chat as garbage and the run ended with
 * nothing executed — followed by an "attempt 1 crashed… nothing was built"
 * essay as the final answer. These tests pin every fix.
 */
class CallSalvageTest {

    private val known = setOf(
        "design_tokens", "run_js", "write_file", "http_request", "finish", "ask_user"
    )

    // The exact shape from the user's report (abridged code payload, same form).
    private val incident = """Short, honest answer: No — nothing was built yet. Every attempt so far died before a single file existed:
- Attempt 1: my first batch of icon/token calls crashed with a system error — zero tools ran.
- Attempt 2: I sent the design contract call but it was malformed — the tool call failed to parse.
- Attempt 3: I typed a narrative "I will build" reply — no tools at all.

So: no HTML, no design, nothing to show yet. That pattern stops now — this turn is actual builds, not claims. Verifying state + locking the design contract right now:

<function_calls>
<invoke name="design_tokens">
<parameter name="action">contract</parameter>
</invoke>
<invoke name="run_js">
<parameter name="code">const fs=require('fs');const p=require('path');function ls(d,pre=''){let out='';return out}console.log('WORKSPACE ROOT:');console.log(ls('.'))</parameter>
</invoke>
</design_tokens>"""

    // ---------- XML rescue ----------

    @Test
    fun xmlCallsWithBrokenWrapperAreRescued() {
        val s = TextToolCalls.parseDetailed(incident, known)
        assertEquals(2, s.calls.size)
        assertEquals("design_tokens", s.calls[0].first)
        assertTrue(s.calls[0].second.contains("contract"))
        assertEquals("run_js", s.calls[1].first)
        assertTrue(s.calls[1].second.contains("require('fs')"))
        assertTrue(s.hadMarkup)
        assertTrue(s.unknownTools.isEmpty())
    }

    @Test
    fun redactStripsMarkupButKeepsNarrative() {
        val s = TextToolCalls.parseDetailed(incident, known)
        val clean = TextToolCalls.redact(incident, s)
        assertFalse(clean.contains("<invoke"))
        assertFalse(clean.contains("</design_tokens>"))
        assertFalse(clean.contains("function_calls"))
        assertTrue(clean.startsWith("Short, honest answer"))
    }

    @Test
    fun unknownXmlToolIsReportedNotExecuted() {
        val t = "<function_calls>\n<invoke name=\"teleport_home\">\n<parameter name=\"x\">1</parameter>\n</invoke>\n</function_calls>"
        val s = TextToolCalls.parseDetailed(t, known)
        assertTrue(s.calls.isEmpty())
        assertEquals(listOf("teleport_home"), s.unknownTools)
        assertTrue(s.hadMarkup)
        val fb = TextToolCalls.formatFeedback(s, known.toList())
        assertTrue(fb.contains("teleport_home"))
        assertTrue(fb.contains("DO NOT EXIST"))
        assertTrue(fb.contains("Valid tools"))
    }

    @Test
    fun markupWrapperWithoutInvokesStillFlags() {
        val s = TextToolCalls.parseDetailed(
            "I will act now:\n<function_calls>\n</function_calls>", known
        )
        assertTrue(s.hadMarkup)
        assertTrue(s.calls.isEmpty())
    }

    @Test
    fun unterminatedInvokeDoesNotCrash() {
        val s = TextToolCalls.parseDetailed(
            "Acting: <invoke name=\"write_file\"><parameter name=\"name\">x.md", known
        )
        // no </param> close → no args; invoke has no close → still flagged as markup
        assertTrue(s.hadMarkup)
    }

    @Test
    fun escapedXmlEntitiesAreUnescaped() {
        val t = "<function_calls><invoke name=\"write_file\"><parameter name=\"content\">a &lt; b &amp;&amp; c &quot;d&quot;</parameter></invoke></function_calls>"
        val s = TextToolCalls.parseDetailed(t, known)
        assertEquals(1, s.calls.size)
        assertTrue(s.calls[0].second.contains("a < b"))
        assertTrue(s.calls[0].second.contains("&& c"))
    }

    // ---------- JSON rescue regression + redaction ----------

    @Test
    fun jsonRescueStillWorksAndRedacts() {
        val t = "Deploying now.\n{\"name\": \"write_file\", \"arguments\": {\"name\": \"a.md\", \"content\": \"hi\"}}"
        val s = TextToolCalls.parseDetailed(t, known)
        assertEquals(1, s.calls.size)
        assertEquals("write_file", s.calls[0].first)
        val clean = TextToolCalls.redact(t, s)
        assertFalse(clean.contains("write_file"))
        assertTrue(clean.contains("Deploying now"))
    }

    @Test
    fun plainTextHasNoMarkupAndNoCalls() {
        val s = TextToolCalls.parseDetailed("The capital of Iran is Tehran.", known)
        assertFalse(s.hadMarkup)
        assertTrue(s.calls.isEmpty())
        assertEquals(TextToolCalls.redact("The capital of Iran is Tehran.", s), "The capital of Iran is Tehran.")
    }

    // ---------- failure narrative is never a final answer ----------

    @Test
    fun failureNarrativeEssayIsRejectedAsFinalAnswer() {
        val essay = "Short, honest answer: No — nothing was built yet. Attempt 1: my first batch of " +
            "calls crashed with a system error — zero tools ran. Attempt 3: I typed a narrative " +
            "reply — no tools at all. So: no HTML, no design, nothing to show yet."
        assertTrue(
            HeroMode.shouldForceAction(essay, "build the design system for my app", toolsCalledSoFar = 0, cycle = 3)
        )
    }

    @Test
    fun rawMarkupLeakIsRejectedAsFinalAnswer() {
        val t = "Sure, doing it:\n<function_calls><invoke name=\"write_file\"><parameter name=\"name\">x</parameter></invoke></function_calls>"
        assertTrue(HeroMode.shouldForceAction(t, "write the file x for me", toolsCalledSoFar = 0, cycle = 2))
    }

    @Test
    fun fullIncidentIsRejectedAsFinalAnswer() {
        assertTrue(
            HeroMode.shouldForceAction(incident, "build the design tokens contract for my app", toolsCalledSoFar = 0, cycle = 3)
        )
    }

    @Test
    fun honestQuestionStillAccepted() {
        assertFalse(
            HeroMode.shouldForceAction(
                "Which design preset should I use — swiss-minimal or glass-aurora?",
                "build the design system for my app", toolsCalledSoFar = 0, cycle = 1
            )
        )
    }

    @Test
    fun plainFactAnswerOnNonCommandChatStillAccepted() {
        // no command verb → conversational guard keeps it a complete answer
        assertFalse(
            HeroMode.shouldForceAction(
                "Nothing was built in that project yet — the repo is empty.",
                "what is the state of my project?", toolsCalledSoFar = 0, cycle = 1
            )
        )
    }
}
