package com.liman.agent

import com.liman.agent.agent.MissionTask
import com.liman.agent.data.Roadmap
import com.liman.agent.data.RoadmapEngine
import com.liman.agent.data.RoadmapTask
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.31 → v2.36 — roadmap/mission engine (pure logic). The plan-mode gate is
 * GONE: plan/build mode was removed in v2.36 — the agent plans by doing.
 */
class PlanAndRoadmapTest {

    @Test fun `roadmap markdown roundtrip`() {
        val tasks = RoadmapEngine.parseMarkdown(
            """
            - Research Telegram bot APIs
            - Write the bot in Termux
            3. Deploy + verify it replies
            * [x] already done thing
            """.trimIndent()
        )
        assertEquals(4, tasks.size)
        assertEquals("Research Telegram bot APIs", tasks[0].text)
        assertEquals("Deploy + verify it replies", tasks[2].text)
        assertEquals("already done thing", tasks[3].text)
        assertTrue(tasks.all { it.id.isNotBlank() })

        val r = Roadmap("Test plan", "proposed", tasks)
        val md = RoadmapEngine.toMarkdown(r)
        assertTrue(md.contains("- Research Telegram bot APIs"))
        val reparsed = RoadmapEngine.parseMarkdown(md)
        assertEquals(tasks.map { it.text }, reparsed.map { it.text })
    }

    @Test fun `empty lines are skipped, blank input is empty`() {
        assertTrue(RoadmapEngine.parseMarkdown("  \n\n   ").isEmpty())
    }

    @Test fun `fromMission maps statuses for the live card`() {
        val r = RoadmapEngine.fromMission(
            "Build the bot",
            listOf(
                MissionTask("t1", "research", ""),
                MissionTask("t2", "write code", "compiles").also { }
            )
        )
        assertEquals("Build the bot", r.title)
        assertEquals(2, r.tasks.size)
        assertEquals(0, r.doneCount())
        val done = r.copy(tasks = r.tasks.map { RoadmapTask(it.id, it.text, "done") })
        assertEquals(2, done.doneCount())
    }

    @Test fun `kickoff message instructs execution`() {
        val r = Roadmap("Plan", "accepted", listOf(RoadmapTask("t1", "do the thing")))
        val k = RoadmapEngine.kickoffMessage(r)
        assertTrue(k.contains("BUILD mode"))
        assertTrue(k.contains("do the thing"))
        assertTrue(k.contains("mission"))
    }
}
