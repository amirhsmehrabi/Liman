package com.liman.agent

import com.liman.agent.agent.DemoLog
import com.liman.agent.agent.Quarantine
import com.liman.agent.agent.StorageDoctor
import com.liman.agent.agent.ToolForge
import com.liman.agent.data.Pipeline
import com.liman.agent.data.PipelineDef
import com.liman.agent.data.PipelineStore
import com.liman.agent.agent.ScheduleLogic
import com.liman.agent.agent.builtInToolSpecs
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * v2.21.0 — THE AUTOMATION LAYER unit tests:
 *  - DemoLog (demonstration → procedure distillation)
 *  - ToolForge (agent-forged tools: registry + JS contract)
 *  - Pipelines (store + definition + trigger text + headless prompt)
 *  - ScheduleLogic.isDueMinutes (sub-hour watchtowers)
 *  - StorageDoctor (triage) + Quarantine (manifest roundtrip)
 *  - the 5 new tools registered with strict-valid schemas
 */
class AutomationLayerTest {

    @get:Rule
    val tmp = TemporaryFolder()

    // ---------------- DemoLog ----------------

    @Test
    fun demoEventsBecomeReadableLines() {
        assertEquals("SCREEN telegram · ChatActivity", DemoLog.describe(
            DemoLog.TYPE_WINDOW_STATE_CHANGED, "org.telegram.messenger", "ChatActivity", "", "", "", ""
        ))
        assertEquals("TAP Send (id:send_btn) @ telegram", DemoLog.describe(
            DemoLog.TYPE_VIEW_CLICKED, "org.telegram.messenger", "Button", "", "Send", "", "org.telegram.messenger:id/send_btn"
        ))
        assertTrue(DemoLog.describe(
            DemoLog.TYPE_VIEW_TEXT_CHANGED, "com.android.chrome", "EditText", "hello world", "", "", "com.android.chrome:id/url"
        )!!.startsWith("TYPE \"hello world\" → url @ chrome"))
        assertEquals("NOTIF gm · New mail", DemoLog.describe(
            DemoLog.TYPE_NOTIFICATION_STATE_CHANGED, "com.google.android.gm", "", "New mail", "", "", ""
        ))
        // noise is ignored (null)
        assertEquals(null, DemoLog.describe(0x8000, "x", "y", "", "", "", ""))
        assertEquals(null, DemoLog.describe(DemoLog.TYPE_VIEW_TEXT_CHANGED, "x", "y", "", "", "", ""))
    }

    @Test
    fun demoSummarizeCollapsesRepeatsAndNumbersSteps() {
        val log = """
            DEMO SESSION 20260913 — the user demonstrates a manual procedure.
            Lines: SCREEN · TAP · TYPE · SCROLL · NOTIF.
            Distill this into a procedure.
            ----
            SCREEN telegram · ChatActivity
            SCROLL @ telegram
            SCROLL @ telegram
            SCROLL @ telegram
            TAP Forward @ telegram
            TYPE "check this out" → message @ telegram
        """.trimIndent()
        val summary = DemoLog.summarize(log)
        assertTrue(summary.contains("1. SCREEN telegram"))
        assertTrue("repeats collapsed with count", summary.contains("(×3)"))
        assertTrue(summary.contains("TAP Forward"))
        assertTrue("numbered", summary.contains("4. TYPE"))
        assertFalse("header dropped", summary.contains("DEMO SESSION"))
    }

    // ---------------- ToolForge ----------------

    @Test
    fun forgedToolLifecycle() {
        val ws = tmp.newFolder()
        val spec = ToolForge.ForgedSpec(
            name = "extract_numbers", description = "Extracts numbers from text",
            engine = "js", params = """{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}""",
            code = "return (input.text.match(/\\d+/g) || []).map(Number);"
        )
        assertTrue(ToolForge.validName("extract_numbers"))
        assertFalse("bad names rejected", ToolForge.validName("2fast"))
        assertFalse(ToolForge.validName("Write-File"))
        assertTrue(ToolForge.save(ws, spec))
        val loaded = ToolForge.loadAll(ws)
        assertEquals(1, loaded.size)
        assertEquals("extract_numbers", loaded[0].name)
        assertTrue(ToolForge.delete(ws, "extract_numbers"))
        assertTrue(ToolForge.loadAll(ws).isEmpty())
    }

    @Test
    fun forgedJsToolHonorsTheInputContract() {
        val ws = tmp.newFolder()
        val spec = ToolForge.ForgedSpec(
            name = "sum_tool", description = "sums", engine = "js",
            params = """{"type":"object","properties":{}}""",
            code = "var t = 0; for (var k in input) t += input[k]; return t;"
        )
        val out = ToolForge.runJs(spec, """{"a":1,"b":2,"c":39}""", ws)
        assertTrue("expected 42 in: $out", out.contains("42"))
        assertFalse(ToolForge.isJsResultError(out))
        // a broken tool is caught, not crashed
        val broken = spec.copy(code = "return undefinedVar + 1;")
        val err = ToolForge.runJs(broken, "{}", ws)
        assertTrue(ToolForge.isJsResultError(err))
    }

    @Test
    fun forgedPythonToolScriptEmbedsCodeAndInputSafely() {
        val spec = ToolForge.ForgedSpec(
            name = "py_tool", description = "python tool", engine = "python",
            params = """{"type":"object","properties":{}}""",
            code = "import json, sys\nx = json.load(sys.stdin)\nprint(json.dumps({'ok': True, 'got': x}))"
        )
        val script = ToolForge.pythonScript(spec, """{"k":"v with 'quotes' and star*chars"}""")
        assertTrue(script.contains("~/.liman-tools/py_tool.py"))
        assertTrue("code is base64-embedded (no quoting hell)", script.contains("base64 -d"))
        assertFalse("raw code never appears in the bash line", script.contains("import json, sys"))
    }

    // ---------------- Pipelines ----------------

    @Test
    fun pipelineStoreRoundtripAndTriggerText() {
        val f = File(tmp.newFolder(), "pipelines.json")
        val store = PipelineStore(f)
        store.upsert(Pipeline(
            id = "pipe1", name = "Engineering News Bot",
            description = "5 telegram channels → summarize → my channel",
            triggerKind = "daily", dailyAt = "08:00", file = "pipelines/pipe1.md"
        ))
        store.upsert(Pipeline(
            id = "pipe2", name = "Watchtower", triggerKind = "interval", everyMinutes = 30, file = "x.md"
        ))
        assertEquals(2, store.state.value.size)
        assertEquals("daily 08:00", PipelineDef.triggerText(store.get("pipe1")!!))
        assertEquals("every 30m", PipelineDef.triggerText(store.get("pipe2")!!))
        // persisted + reloadable
        val re = PipelineStore(f)
        assertEquals(2, re.state.value.size)
        assertEquals("Engineering News Bot", re.get("pipe1")!!.name)
        // pause persists
        store.upsert(store.get("pipe1")!!.copy(enabled = false))
        assertFalse(PipelineStore(f).get("pipe1")!!.enabled)
    }

    @Test
    fun pipelineDefinitionAndRunPromptCarryTheContract() {
        val def = PipelineDef.render(
            "News Bot", "channels → summary → channel",
            listOf("fetch" to "Read the 5 channels listed in state", "transform" to "Summarize in Persian, 5 bullets", "output" to "Post to my channel @x")
        )
        assertTrue(def.contains("# Automation: News Bot"))
        assertTrue(def.contains("1. [fetch] Read the 5 channels"))
        assertTrue(def.contains("2. [transform] Summarize in Persian"))
        assertTrue(def.contains("STATE"))
        assertTrue(def.contains("HEADLESS RULES"))
        assertTrue(def.contains("NO_REPLY"))

        val p = Pipeline(id = "p", name = "News Bot", file = "pipelines/p.md", triggerKind = "daily")
        val prompt = PipelineDef.runPrompt(p)
        assertTrue(prompt.contains("AUTOMATION RUN: News Bot"))
        assertTrue(prompt.contains("workspace/pipelines/p.md"))
        assertTrue(prompt.contains("dedupe"))
    }

    @Test
    fun subHourMissionsAreDue() {
        val now = System.currentTimeMillis()
        assertFalse(ScheduleLogic.isDueMinutes(30, now - 29 * 60_000L, now))
        assertTrue(ScheduleLogic.isDueMinutes(30, now - 30 * 60_000L, now))
        assertFalse(ScheduleLogic.isDueMinutes(0, 0, now))
        // first run (never ran) fires immediately
        assertTrue(ScheduleLogic.isDueMinutes(15, 0L, now))
    }

    // ---------------- StorageDoctor + Quarantine ----------------

    private fun facts(path: String, size: Int, modified: Long = System.currentTimeMillis(), mime: String = "text/plain") =
        StorageDoctor.FileFacts(path, path.substringAfterLast('/'), size.toLong(), modified, mime)

    @Test
    fun triageSeparatesSafeReviewAndKeep() {
        val now = System.currentTimeMillis()
        val old = now - 100L * 24 * 3600 * 1000
        val files = listOf(
            facts("Downloads/setup.tmp", 5_000),                     // temp → SAFE
            facts("Backup/app.log", 3_000),                           // log → SAFE
            facts("Downloads/report.pdf", 900_000),                   // keep
            facts("DCIM/IMG_1.jpg", 2_000_000),                      // keep
            facts("Screenshots/IMG_1.jpg", 2_000_000, old),          // exact dup (same name+size) → SAFE
            facts("Apps/oldgame.apk", 80_000_000),                   // apk → REVIEW
            facts("Downloads/backup.zip", 60_000_000),               // archive → REVIEW
            facts("Movies/oldtrip.mp4", 500_000_000, old),           // old video → REVIEW
            facts("Downloads/hugefile.bin", 900_000_000),            // >50MB → REVIEW
            facts("Docs/notes.md", 400)
        )
        val r = StorageDoctor.triage(files, now)
        val safePaths = r.safe.flatMap { it.files }.map { it.relPath }
        val reviewPaths = r.review.flatMap { it.files }.map { it.relPath }
        val keepPaths = r.keep.files.map { it.relPath }
        assertTrue(safePaths.contains("Downloads/setup.tmp"))
        assertTrue(safePaths.contains("Backup/app.log"))
        assertTrue("exact duplicate flagged", safePaths.contains("Screenshots/IMG_1.jpg") && safePaths.contains("DCIM/IMG_1.jpg"))
        assertTrue(reviewPaths.contains("Apps/oldgame.apk"))
        assertTrue(reviewPaths.contains("Downloads/backup.zip"))
        assertTrue(reviewPaths.contains("Movies/oldtrip.mp4"))
        assertTrue(reviewPaths.contains("Downloads/hugefile.bin"))
        assertTrue(keepPaths.contains("Downloads/report.pdf"))
        assertTrue(keepPaths.contains("Docs/notes.md"))
        assertTrue("safe bytes counted", r.reclaimableSafe > 0)
        assertTrue(r.reclaimableWithReview > r.reclaimableSafe)
        // rendered report mentions the undoability
        val text = StorageDoctor.renderReport(r, "Downloads")
        assertTrue(text.contains("SAFE TO DELETE"))
        assertTrue(text.contains("REVIEW FIRST"))
        assertTrue(text.contains("KEEP"))
        assertTrue(text.contains("quarantine"))
    }

    @Test
    fun likelyDuplicatesGoToReviewNotSafe() {
        val now = System.currentTimeMillis()
        val files = listOf(
            facts("A/video_final_cut.mp4", 123_456_789),
            facts("B/vid_export.mp4", 123_456_789)   // same big size, different name
        )
        val r = StorageDoctor.triage(files, now)
        val safePaths = r.safe.flatMap { it.files }.map { it.relPath }
        val reviewPaths = r.review.flatMap { it.files }.map { it.relPath }
        assertFalse("same-size different-name is NOT auto-safe", safePaths.contains("A/video_final_cut.mp4"))
        assertTrue(reviewPaths.contains("A/video_final_cut.mp4"))
    }

    @Test
    fun quarantineManifestRoundtrip() {
        val ws = tmp.newFolder()
        val batch = Quarantine.newBatchDir(ws)
        val bytes = "hello world".toByteArray()
        val e = Quarantine.Entry("Downloads", "Docs/old.txt", "old.txt", bytes.size.toLong(), Quarantine.sha256(bytes), 1L)
        Quarantine.writeManifest(batch, listOf(e))
        val latest = Quarantine.latest(ws)
        assertNotNull(latest)
        assertEquals(batch.name, latest!!.second.batch)
        assertEquals(1, latest.second.entries.size)
        assertEquals("Downloads", latest.second.entries[0].rootLabel)
        assertEquals(Quarantine.sha256(bytes), latest.second.entries[0].sha256)
        assertEquals("b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9", Quarantine.sha256("hello world".toByteArray()))
    }

    // ---------------- registration ----------------

    @Test
    fun automationToolsAreRegisteredWithValidSchemas() {
        val names = builtInToolSpecs().map { it.name }.toSet()
        listOf("ui", "tool_forge", "automation", "storage_scan", "storage_clean").forEach {
            assertTrue("missing tool $it", names.contains(it))
        }
        val strict = Json { }
        builtInToolSpecs().filter { it.name in setOf("ui", "tool_forge", "automation", "storage_scan", "storage_clean") }
            .forEach { strict.parseToJsonElement(it.parametersJson) }
    }
}
