package com.liman.agent

import com.liman.agent.agent.DesignTokens
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v2.30.0 — design system kernel (APP FACTORY blueprint §4/§10). */
class DesignTokensTest {

    @Test fun `five presets with complete token sets`() {
        assertEquals(5, DesignTokens.PRESETS.size)
        assertEquals(
            listOf("swiss-minimal", "soft-material", "dark-terminal", "neo-brutalist", "glass-aurora"),
            DesignTokens.PRESETS.map { it.id }
        )
        DesignTokens.PRESETS.forEach { p ->
            listOf(p.brand, p.surface, p.onSurface, p.dSurface, p.dOnSurface).forEach {
                assertTrue("${p.id} token $it", Regex("#[0-9A-Fa-f]{6,8}").matches(it))
            }
            assertTrue("${p.id} vibe blank", p.vibe.isNotBlank())
            assertTrue("${p.id} keyMoves blank", p.keyMoves.isNotBlank())
        }
    }

    @Test fun `preset lookup`() {
        assertNotNull(DesignTokens.preset("swiss-minimal"))
        assertNull(DesignTokens.preset("windows-95"))
    }

    @Test fun `tokens css has light and dark blocks`() {
        val css = DesignTokens.tokensCss("dark-terminal")!!
        assertTrue(css.contains(":root {"))
        assertTrue(css.contains("--brand-500"))
        assertTrue(css.contains("--space-4: 16px"))
        assertTrue(css.contains("prefers-color-scheme: dark"))
        assertTrue(css.contains(DesignTokens.preset("dark-terminal")!!.dSurface))
        assertNull(DesignTokens.tokensCss("nope"))
    }

    @Test fun `android colors xml is valid resources xml`() {
        val xml = DesignTokens.androidColorsXml("soft-material")!!
        assertTrue(xml.startsWith("<?xml"))
        assertTrue(xml.contains("<resources>"))
        assertTrue(xml.contains("<color name=\"brand\">"))
        assertTrue(xml.contains(DesignTokens.preset("soft-material")!!.brand))
        assertTrue(xml.endsWith("</resources>"))
    }

    @Test fun `kit css covers the component vocabulary`() {
        val kit = DesignTokens.kitCss()
        listOf(".btn--primary", ".card", ".field", ".input", ".badge", ".topbar", ".empty", ":focus-visible")
            .forEach { assertTrue("kit missing $it", kit.contains(it)) }
        assertTrue("kit must prefer tokens over raw hex", !Regex("""#[0-9a-fA-F]{6}\b""").containsMatchIn(kit.replace("#fff", "").replace("#000", "")))
    }

    @Test fun `contract and archetypes are the doctrine`() {
        val c = DesignTokens.contract()
        assertTrue(c.contains("never invent a hex"))
        assertTrue(c.contains("44px/48dp"))
        assertEquals(9, DesignTokens.ARCHETYPES.size)
        assertTrue(DesignTokens.ARCHETYPES.any { it.first == "list-detail" })
        assertEquals(listOf(0, 4, 8, 12, 16, 24, 32, 48, 64, 96), DesignTokens.SPACE_SCALE)
    }
}
