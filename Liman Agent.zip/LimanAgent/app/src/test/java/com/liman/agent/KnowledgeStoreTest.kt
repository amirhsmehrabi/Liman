package com.liman.agent

import com.liman.agent.data.KnowledgeStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * v2.20.0 — the PRIVATE LIBRARY (Agno knowledge stores + RAGFlow agentic
 * retrieval), ported to run fully on-device with BM25 instead of an
 * embedding API.
 */
class KnowledgeStoreTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun store() = KnowledgeStore(File(tmp.newFolder(), "kb"))

    @Test
    fun chunksRespectParagraphsAndStaySized() {
        val paras = (1..30).joinToString("\n\n") { i ->
            "Paragraph $i: " + ("lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod ".repeat(3))
        }
        val chunks = com.liman.agent.data.Chunker.chunk(paras)
        assertTrue("expected multiple chunks", chunks.size > 3)
        chunks.forEach { c ->
            assertTrue("chunk too big: ${c.length}", c.length <= 900 + 200) // TARGET + overlap headroom
            assertTrue("empty chunk", c.isNotBlank())
        }
        // paragraph boundaries preserved: all 30 "Paragraph N:" markers appear
        // complete (never sliced mid-word by the hard cut or overlap head)
        val joined = chunks.joinToString(" ")
        assertEquals(
            "all paragraph markers survived intact",
            30, Regex("Paragraph \\d+:").findAll(joined).count()
        )
        assertFalse(
            "a marker word was sliced",
            Regex("Paragra(?!ph)").containsMatchIn(joined)
        )
    }

    @Test
    fun smallDocumentIsSingleChunk() {
        val chunks = com.liman.agent.data.Chunker.chunk("Just one short note about tea.")
        assertEquals(1, chunks.size)
    }

    @Test
    fun bm25RanksTheRelevantDocumentFirst() {
        val s = store()
        s.add("solar-guide", "text", buildString {
            repeat(12) { append("Solar panel installation on a roof requires mounting rails and an inverter. ") }
        })
        s.add("job-guide", "text", buildString {
            repeat(12) { append("Job applications need a tailored resume and a short cover letter. ") }
        })
        val hits = s.search(listOf("how to install solar panels", "solar inverter mounting"), k = 4)
        assertTrue("expected hits", hits.isNotEmpty())
        assertEquals("solar-guide must rank first", "solar-guide", hits.first().docName)
        assertTrue("citation format doc#chunk", hits.first().let { it.chunkIndex >= 0 })
    }

    @Test
    fun multiQueryMergesAcrossPhrasings() {
        val s = store()
        s.add("contracts", "text",
            "The apartment lease runs for 24 months with a deposit of two months rent. " +
                "Termination notice is three months before the end of the lease period. ".repeat(6))
        s.add("recipes", "text",
            "Thai green curry paste: pound lemongrass, galangal, green chilies and kaffir lime. ".repeat(6))
        // two very different phrasings; the contract doc must surface either way
        val hits = s.search(listOf("how long is the lease", "termination notice period"), k = 3)
        assertTrue(hits.isNotEmpty())
        assertTrue("contracts doc expected in hits", hits.any { it.docName == "contracts" })
    }

    @Test
    fun listAddForgetAndSameNameReplace() {
        val s = store()
        s.add("doc-a", "text", "alpha beta gamma")
        s.add("doc-b", "text", "delta epsilon zeta")
        assertEquals(2, s.list().size)
        // re-ingesting the same name REPLACES, not duplicates (idempotent)
        s.add("doc-a", "text", "completely different content now")
        assertEquals(2, s.list().size)
        assertTrue(s.list().any { it.name == "doc-a" && it.chunks.first().contains("different") })
        assertTrue(s.forget("DOC-A")) // case-insensitive
        assertEquals(1, s.list().size)
        assertFalse(s.forget("nope"))
    }

    @Test
    fun emptyStoreAndEmptyQueryAreSafe() {
        val s = store()
        assertTrue(s.search(listOf("anything"), 5).isEmpty())
        assertTrue(s.search(listOf("", "  "), 5).isEmpty())
        s.add("empty-ish", "text", "")
        // the chunker never produces empty chunks — an empty doc has zero of them
        assertTrue(s.list().first { it.name == "empty-ish" }.chunks.isEmpty())
    }
}
