package com.liman.agent

import com.liman.agent.agent.NativeBuilder
import com.liman.agent.agent.builtInToolSpecs
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * v2.22.0 — THE NATIVE APK FACTORY.
 *
 * The pipeline itself was verified END-TO-END before shipping (real
 * kotlinc 2.0.21 + d8 + aapt2 + zipalign + apksigner on the same android.jar
 * URL the phone uses → 1.38 MB signed APK from this exact template).
 * These tests pin the pieces that must never regress:
 * scaffold correctness, package validation, the generated Termux scripts
 * (right commands, right escapes, right markers), and the md5-verified
 * chunk transfer.
 */
class NativeBuilderTest {

    @get:Rule
    val tmp = TemporaryFolder()

    // ---------------- naming ----------------

    @Test
    fun packageValidation() {
        assertTrue(NativeBuilder.validPackage("com.liman.hello"))
        assertTrue(NativeBuilder.validPackage("org.example.my_app.deep"))
        assertFalse("uppercase rejected", NativeBuilder.validPackage("Com.Liman"))
        assertFalse("single segment rejected", NativeBuilder.validPackage("app"))
        assertFalse("hyphens rejected", NativeBuilder.validPackage("com.my-app"))
        assertEquals("com.liman.myc00lapp", NativeBuilder.defaultPackage("My C00l App!!"))
        assertEquals("myc00lapp", NativeBuilder.slugify("My C00l App!!"))
    }

    // ---------------- scaffold ----------------

    @Test
    fun scaffoldCreatesACompilableProjectShape() {
        val ws = tmp.newFolder()
        val dir = NativeBuilder.scaffold(
            ws, "Electricity Monitor", null,
            "notifies when a message contains a code",
            listOf("android.permission.POST_NOTIFICATIONS", "android.permission.INTERNET", " ")
        )
        assertTrue(dir.isDirectory)
        val manifest = File(dir, "AndroidManifest.xml").readText()
        assertTrue(manifest.contains("package=\"com.liman.electricitymonitor\""))
        assertTrue(manifest.contains("android:label=\"Electricity Monitor\""))
        assertTrue(manifest.contains("android.permission.POST_NOTIFICATIONS"))
        assertTrue(manifest.contains("android.permission.INTERNET"))
        assertFalse("blank permissions dropped", manifest.contains("  \" />"))
        assertTrue(manifest.contains("android:minSdkVersion=\"24\""))
        assertTrue(manifest.contains("android:targetSdkVersion=\"${NativeBuilder.API_LEVEL}\""))
        assertTrue(manifest.contains("<category android:name=\"android.intent.category.LAUNCHER\" />"))

        val kt = File(dir, "src/com/liman/electricitymonitor/MainActivity.kt").readText()
        assertTrue(kt.startsWith("package com.liman.electricitymonitor"))
        assertTrue("class MainActivity : Activity()", kt.contains("class MainActivity : Activity()"))
        assertTrue(kt.contains("onCreate"))
        assertTrue(kt.contains("Electricity Monitor"))
        assertTrue("no broken quotes from description", kt.contains("notifies when a message contains a code"))

        assertTrue(File(dir, "res/values/themes.xml").readText().contains("android:Theme.Material.NoActionBar"))
        assertTrue(File(dir, "PROJECT.md").exists())
        // custom package honored
        val dir2 = NativeBuilder.scaffold(ws, "X", "org.user.custom", "", emptyList())
        assertTrue(File(dir2, "AndroidManifest.xml").readText().contains("package=\"org.user.custom\""))
        assertTrue(File(dir2, "src/org/user/custom/MainActivity.kt").exists())
        // invalid package falls back to default
        val dir3 = NativeBuilder.scaffold(ws, "Y", "NOT VALID!!", "", emptyList())
        assertTrue(File(dir3, "AndroidManifest.xml").readText().contains("package=\"com.liman.y\""))
    }

    // ---------------- generated scripts ----------------

    @Test
    fun buildScriptCarriesTheVerifiedPipeline() {
        val files = listOf(
            "AndroidManifest.xml" to "<manifest/>".toByteArray(),
            "src/com/liman/x/MainActivity.kt" to "package com.liman.x".toByteArray()
        )
        val script = NativeBuilder.buildScript("xapp", files)
        // transfer section
        assertTrue(script.contains("mkdir -p \"$(dirname 'src/com/liman/x/MainActivity.kt')\""))
        assertTrue(script.contains("| base64 -d > 'AndroidManifest.xml'"))
        // the VERIFIED pipeline, in order
        val order = listOf(
            "aapt2 compile --dir res -o build.res.zip",
            "aapt2 link -o app.unaligned.apk -I ~/liman-native/android.jar --manifest AndroidManifest.xml --java build.gen build.res.zip --auto-add-overlay",
            "kotlinc -classpath ~/liman-native/android.jar -jvm-target 1.8 -include-runtime -d app.jar",
            "d8 --release --lib ~/liman-native/android.jar --min-api 24 --output .",
            "dx --dex --min-sdk-version 24 --output classes.dex",
            "zip -q -j app.unaligned.apk classes.dex",
            "zipalign -f 4 app.unaligned.apk app.aligned.apk",
            "apksigner sign --ks ~/liman-native/debug.keystore --ks-pass pass:${NativeBuilder.STORE_PASS} --ks-key-alias liman --out app.apk",
            "apksigner verify app.apk",
            "LIMAN_BUILD_OK"
        )
        var last = -1
        order.forEach { cmd ->
            val i = script.indexOf(cmd)
            assertTrue("pipeline missing: $cmd", i >= 0)
            assertTrue("pipeline out of order: $cmd", i > last)
            last = i
        }
        // bash $ escaped correctly (literal $KTS in the script, not Kotlin interpolation)
        assertTrue(script.contains("KTS=${'$'}(find src -name '*.kt')"))
        assertTrue(script.contains("if [ -n \"${'$'}KTS\" ]"))
        assertTrue(script.contains("SIZE=${'$'}(stat -c%s app.apk)"))
        assertTrue(script.contains("echo \"LIMAN_BUILD_OK ${'$'}SIZE ${'$'}MD5\""))
        // fallbacks present
        assertTrue(script.contains("command -v d8 >/dev/null"))
        assertTrue(script.contains("command -v zipalign >/dev/null"))
    }

    @Test
    fun setupScriptInstallsTheToolchain() {
        val s = NativeBuilder.setupScript()
        assertTrue(s.contains("pkg install -y openjdk-17 kotlin aapt2 apksigner dx zip unzip curl"))
        assertTrue(s.contains(NativeBuilder.ANDROID_JAR_URL))
        assertTrue(s.contains("keytool -genkeypair"))
        assertTrue(s.contains("-storepass ${NativeBuilder.STORE_PASS}"))
        assertTrue(s.endsWith("echo " + '\"' + "LIMAN_NATIVE_SETUP_OK" + '\"'))
    }

    @Test
    fun envProbeChecksEveryTool() {
        val s = NativeBuilder.envProbeScript()
        // the probe loops over the tool list with `command -v $t`
        val tools = "java kotlinc javac aapt2 d8 dx apksigner zip unzip curl"
        assertTrue("probe tool list", s.contains("for t in $tools"))
        assertTrue(s.contains("command -v ${'$'}t"))
        assertTrue(s.contains("${'$'}t:missing"))
        assertTrue(s.contains("android.jar:ok"))
        assertTrue(s.contains("keystore:ok"))
    }

    // ---------------- chunk transfer ----------------

    @Test
    fun chunkRoundtripWithMd5Verification() {
        val apk = ByteArray(600_000) { (it % 251).toByte() }
        val md5 = NativeBuilder.md5(apk)
        val chunks = (0 until NativeBuilder.chunkCount(apk.size.toLong())).map { i ->
            java.util.Base64.getEncoder().encodeToString(
                apk.copyOfRange(
                    i * 256 * 1024,
                    minOf((i + 1) * 256 * 1024, apk.size)
                )
            )
        }
        assertEquals(3, chunks.size)
        val back = NativeBuilder.assembleChunks(chunks, md5)
        assertNotNull(back)
        assertTrue(apk.contentEquals(back!!))
        // corrupted transfer is caught
        val bad = chunks.toMutableList()
        bad[1] = bad[1].dropLast(40)
        assertNull("md5 mismatch must fail", NativeBuilder.assembleChunks(bad, md5))
        assertNull("invalid base64 must fail", NativeBuilder.assembleChunks(listOf("!!!not-base64!!!"), md5))
    }

    @Test
    fun chunkScriptUsesBoundedDd() {
        val s = NativeBuilder.chunkScript("myapp", 2)
        assertTrue(s.contains("bs=262144"))
        assertTrue(s.contains("skip=2"))
        assertTrue(s.contains("count=1"))
        assertTrue(s.contains("base64 -w0"))
    }

    @Test
    fun buildOkParsing() {
        val out = "=== [6/6] sign ===\nSigned by 'CN=Liman Debug'\nLIMAN_BUILD_OK 1384869 abc123def4567890123456789012abcd\n"
        val ok = NativeBuilder.parseBuildOk(out)
        assertNotNull(ok)
        assertEquals(1384869, ok!!.first)
        assertEquals("abc123def4567890123456789012abcd", ok.second)
        assertNull(NativeBuilder.parseBuildOk("kotlinc: error: unresolved reference"))
    }

    @Test
    fun projectFilesTransferCapsHold() {
        val ws = tmp.newFolder()
        val dir = NativeBuilder.scaffold(ws, "Cap Test", null, "", emptyList())
        File(dir, "build").mkdirs()
        File(dir, "build/stale.apk").writeBytes(ByteArray(100))
        File(dir, ".hidden").writeText("x")
        val files = NativeBuilder.projectFiles(dir)
        assertTrue("manifest included", files.any { it.first == "AndroidManifest.xml" })
        assertTrue("sources included", files.any { it.first.endsWith("MainActivity.kt") })
        assertFalse("build dir excluded", files.any { it.first.startsWith("build/") })
        assertFalse("hidden files excluded", files.any { it.first.startsWith(".") })
        assertTrue(files.all { it.second.size <= 200_000 })
    }

    // ---------------- registration ----------------

    @Test
    fun nativeApkToolRegisteredWithValidSchema() {
        val spec = builtInToolSpecs().firstOrNull { it.name == "native_apk" }
        assertNotNull(spec)
        Json { }.parseToJsonElement(spec!!.parametersJson)
        assertTrue(spec.description.contains("kotlinc"))
        assertTrue(spec.description.contains("REAL"))
    }
}
