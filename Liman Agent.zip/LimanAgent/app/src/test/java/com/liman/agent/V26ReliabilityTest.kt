package com.liman.agent

import com.liman.agent.agent.MissionTask
import com.liman.agent.agent.MissionTracker
import com.liman.agent.agent.NativeBuilder
import com.liman.agent.util.isPersian
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.26.0 — the three real-world bugs from the user's phone, locked down:
 *  1. mission: "unknown task id 'probe'" → fuzzy resolution + teaching error
 *  2. native_apk: Long/Int + ::isInitialized compile failures → buildHints
 *     teach the fix in one retry; job markers no longer pollute the log
 *  3. Persian paragraphs with English words → per-block RTL detection
 */
class V26ReliabilityTest {

    // ================================================================ mission

    private fun tracker(): MissionTracker = MissionTracker().apply {
        plan(
            "deploy app",
            listOf(
                MissionTask("setup", "install the toolchain in Termux"),
                MissionTask("scaffold", "scaffold the Kotlin project"),
                MissionTask("build", "compile and sign the APK")
            )
        )
    }

    @Test fun missionResolvesExactAndCaseInsensitive() {
        val m = tracker()
        assertEquals("build", m.resolveTaskId("build")?.id)
        assertEquals("build", m.resolveTaskId(" BUILD ")?.id)
    }

    @Test fun missionResolvesIndexForms() {
        val m = tracker()
        // the real-world failure: the model sent 'probe' — but indexes must work too
        assertEquals("setup", m.resolveTaskId("1")?.id)
        assertEquals("scaffold", m.resolveTaskId("#2")?.id)
        assertEquals("build", m.resolveTaskId("task 3")?.id)
    }

    @Test fun missionResolvesGoalTextAndIdFragment() {
        val m = tracker()
        assertEquals("scaffold", m.resolveTaskId("scaffold the Kotlin project")?.id)
        assertEquals("build", m.resolveTaskId("compile and sign")?.id)
        assertEquals("scaffold", m.resolveTaskId("scaff")?.id)
    }

    @Test fun missionUnknownIdStillFailsButCanTeach() {
        val m = tracker()
        assertNull(m.resolveTaskId("probe"))
        assertNull(m.resolveTaskId(""))
        // the tool layer turns this into a teaching error listing valid ids
        val valid = m.tasks.joinToString(", ") { it.id }
        assertTrue(valid.contains("setup") && valid.contains("build"))
    }

    @Test fun missionUpdateWorksThroughFuzzyResolution() {
        val m = tracker()
        assertTrue(m.update("2", "done"))            // index
        assertTrue(m.update("build", "in_progress")) // exact
        assertTrue(m.update("install the toolchain in Termux", "done")) // goal text
        assertEquals(2, m.tasks.count { it.status == "done" }) // build is still in_progress
        assertEquals("in_progress", m.tasks.first { it.id == "build" }.status)
        assertFalse(m.update("probe", "done"))
        assertTrue(m.render().contains("2/3"))
    }

    // ================================================================ build hints

    private val longIntLog = """
        auraplayer/Screens.kt:289:37: error: argument type mismatch: actual type is 'Long', but 'Int' was expected.
            vCur = tv(ctx, "0:00", 11f, MUT)
        src/com/liman/auraplayer/Screens.kt:299:44: error: argument type mismatch: actual type is 'Long', but 'Int' was expected.
    """.trimIndent()

    private val isInitLog = """
        src/com/liman/auraplayer/MainActivity.kt:144:31: error: backing field of 'var pViz: VisualizerView' is not accessible at this point.
            if (screens::pViz.isInitialized) screens.pViz.active = (idx == 1)
    """.trimIndent()

    @Test fun hintForTheLongIntColorGotcha() {
        val h = NativeBuilder.buildHints(longIntLog)
        assertTrue(h.contains("0x80000000"))
        assertTrue(h.contains(".toInt()"))
        assertTrue(h.contains("setTextColor"))
    }

    @Test fun hintForTheIsInitializedGotcha() {
        val h = NativeBuilder.buildHints(isInitLog)
        assertTrue(h.contains("::isInitialized"))
        assertTrue(h.contains("nullable"))
    }

    @Test fun hintForJansiNoise() {
        val h = NativeBuilder.buildHints(
            "Failed to load native library:jansi-2.4.0-libjansi.so\ndlopen failed: library \"libc.so.6\" not found"
        )
        assertTrue(h.contains("harmless"))
    }

    @Test fun noHintsForACleanLog() {
        assertEquals("", NativeBuilder.buildHints("all good, no errors here"))
    }

    @Test fun eachHintSaidOnce() {
        val h = NativeBuilder.buildHints(longIntLog + longIntLog)
        assertEquals(1, Regex("0x80000000").findAll(h).count())
    }

    // ================================================================ clean log

    @Test fun jobMarkersAreStripped() {
        val raw = "step 1 ok\nstep 2 failed\nLIMAN_JOB_EXIT_1\n\nLIMAN_JOB_DONE\n"
        val clean = NativeBuilder.cleanJobLog(raw)
        assertFalse(clean.contains("LIMAN_JOB"))
        assertTrue(clean.contains("step 1 ok"))
        assertTrue(clean.contains("exited with an error code"))
    }

    @Test fun cleanLogKeepsSuccessQuiet() {
        val clean = NativeBuilder.cleanJobLog("LIMAN_NATIVE_SETUP_OK\nLIMAN_JOB_EXIT_0\nLIMAN_JOB_DONE")
        assertTrue(clean.contains("LIMAN_NATIVE_SETUP_OK"))
        assertFalse(clean.contains("exited with an error"))
    }

    // ================================================================ per-block Persian

    @Test fun persianParagraphWithEnglishWordsIsPersian() {
        // the user's exact complaint: English words inside a Persian paragraph
        assertTrue(isPersian("این یک پاراگراف فارسی است که چند کلمهٔ English هم داخلش دارد"))
        // a mostly-English paragraph with a stray Persian word is NOT flipped
        assertFalse(isPersian("The build finished with status done and only one کلمه inside"))
    }

    @Test fun mixedMessageHasBothKindsOfBlocks() {
        val md = "این توضیح فارسی است با API key وسط متن.\n\nThe English paragraph explains the next step."
        val blocks = com.liman.agent.ui.MarkdownParser.parse(md)
        val paras = blocks.filterIsInstance<com.liman.agent.ui.MdBlock.Paragraph>()
        assertEquals(2, paras.size)
        // per-block detection sees one of each — the whole-message heuristic would pick one side
        val persian = paras.any { isPersian(it.inline.joinToString(" ") { s -> s.toString() }) }
        assertTrue(persian)
    }
}
