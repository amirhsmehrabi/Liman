package com.liman.agent

import com.liman.agent.agent.DefaultSkills
import com.liman.agent.data.SkillStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * v2.19.0 — SKILL PACKS ported from the two reference projects
 * (GhostGram: Telegram userbot + human-paced behavior; ai-job-search:
 * the gated, drafter-reviewer job-application pipeline).
 *
 * Pins: the three skills install on first boot, carry the ported
 * mechanics (gates, scoring dimensions, pacing formulas, untrusted-posting
 * rule), and — critically — are NEVER overwritten once the user has them
 * (idempotent install that respects user edits).
 */
class DefaultSkillsTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun store() = SkillStore(File(tmp.newFolder(), "skills"))

    @Test
    fun installsAllSkillPacks() {
        val s = store()
        DefaultSkills.ensure(s)
        val ids = s.state.value.map { it.id }
        assertTrue(ids.contains("job-hunt"))
        assertTrue(ids.contains("telegram-outreach"))
        assertTrue(ids.contains("email-outreach"))
        assertTrue(ids.contains("ui-craft")) // v2.30.0
        assertEquals(4, s.state.value.size)
    }

    @Test
    fun jobHuntCarriesTheReferenceMechanics() {
        val s = store()
        DefaultSkills.ensure(s)
        val md = s.instructions("job-hunt") ?: ""
        // the ai-job-search pipeline essentials
        assertTrue("eligibility gate", md.contains("ELIGIBILITY"))
        assertTrue("silence is not permission", md.contains("Silence is NOT permission"))
        assertTrue("language gate", md.contains("LANGUAGE"))
        assertTrue("5 scoring dimensions", md.contains("5 dimensions"))
        assertTrue("deal-breaker veto", md.contains("VETO"))
        assertTrue("drafter-reviewer", md.contains("verifier subagent"))
        assertTrue("tracker as system of record", md.contains("applications.csv"))
        assertTrue("archive exactly what was sent", md.contains("EXACTLY what was sent"))
        assertTrue("follow-up cap", md.contains("at most 2 follow-ups"))
        assertTrue("untrusted postings", md.contains("UNTRUSTED DATA"))
        assertTrue("never invent experience", md.contains("never invent experience"))
        assertTrue("STAR mapping", md.contains("STAR"))
        assertTrue("dashboard", md.contains("report.html"))
    }

    @Test
    fun telegramSkillCarriesTheGhostGramPacingFormulas() {
        val s = store()
        DefaultSkills.ensure(s)
        val md = s.instructions("telegram-outreach") ?: ""
        // GhostGram's exact human-behavior math
        assertTrue("reading formula", md.contains("1.5 + length/25"))
        assertTrue("typing formula", md.contains("1.5 + 0.1*len"))
        assertTrue("35s cap", md.contains("cap 35s"))
        assertTrue("floodwait handling", md.contains("FloodWaitError"))
        assertTrue("fatigue breaks", md.contains("fatigue micro-break"))
        assertTrue("daily bulk limit", md.contains("20 unsolicited"))
        assertTrue("approval for outbound", md.contains("approval"))
        assertTrue("state file", md.contains("campaigns/"))
    }

    @Test
    fun emailSkillHasWorkingSmtpSkeleton() {
        val s = store()
        DefaultSkills.ensure(s)
        val md = s.instructions("email-outreach") ?: ""
        assertTrue(md.contains("smtplib"))
        assertTrue(md.contains("smtp.gmail.com"))
        assertTrue(md.contains("App Password"))
        assertTrue(md.contains("get approval"))
    }

    @Test
    fun neverOverwritesUserModifiedSkills() {
        val s = store()
        DefaultSkills.ensure(s)
        // user customizes the skill
        s.upsert(
            s.state.value.first { it.id == "job-hunt" }.copy(description = "my custom desc"),
            "---\nname: Job hunt\n---\nMY OWN VERSION"
        )
        DefaultSkills.ensure(s) // second boot
        // still the user's markdown (frontmatter + body), NOT the default pack
        val after = s.instructions("job-hunt") ?: ""
        assertTrue(after.contains("MY OWN VERSION"))
        assertTrue(!after.contains("STEP 0"))
        assertNotNull(s.get("job-hunt"))
        // the other two still exist untouched
        assertNotNull(s.get("telegram-outreach"))
        assertNotNull(s.get("email-outreach"))
    }
}
