package com.liman.agent

import com.liman.agent.agent.Calculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculatorTest {

    private fun eval(s: String): String = Calculator.evaluate(s)

    @Test
    fun basicArithmetic() {
        assertEquals("7", eval("1+2*3"))
        assertEquals("21", eval("(1+2)*(3+4)"))
        assertEquals("-2", eval("-5+3"))
        assertEquals("1024", eval("2^10"))
        assertEquals("1", eval("10%3"))
        assertEquals("0.5", eval("1/2"))
    }

    @Test
    fun functions() {
        assertEquals("5", eval("sqrt(16)+1"))
        assertEquals("0", eval("sin(0)"))
        assertEquals("3", eval("log(1000)"))
        assertEquals("7", eval("max(3,7)"))
        assertEquals("3", eval("min(3,7)"))
        assertEquals("8", eval("hypot(8,0)"))
    }

    @Test
    fun precedenceAndUnary() {
        assertEquals("-8", eval("-2^3"))
        assertEquals("4", eval("--4"))
        assertEquals("2", eval("sqrt(3+1)"))
    }

    @Test
    fun formatting() {
        assertEquals("1000000000", eval("1e9"))
        assertEquals("0.1", eval("0.1"))
    }

    @Test
    fun errors() {
        assertTrue(eval("1+").startsWith("Error"))
        assertTrue(eval("foo(1)").startsWith("Error"))
        assertTrue(eval("nosuchname").startsWith("Error"))
        assertTrue(eval("(1+2").startsWith("Error"))
    }
}
