package com.liman.agent

import com.liman.agent.agent.TaskTitles
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v2.36 — AI TASK NAMING: titles are never the raw first prompt. */
class TaskTitlesTest {

    @Test
    fun heuristicSkipsStopwordsAndPicksThreeWords() {
        val t = TaskTitles.heuristic("please can you build me a website for my portfolio with dark theme")
        // stopwords (please/can/you/me/a/for/my/with) skipped, first 3 real words kept
        assertEquals("Build Website Portfolio", t)
    }

    @Test
    fun heuristicStripsPunctuation() {
        val t = TaskTitles.heuristic("fix the **login bug** in app.java!")
        assertEquals("Fix Login Bug", t)
    }

    @Test
    fun heuristicCapsLength() {
        val t = TaskTitles.heuristic("deploy supercalifragilisticexpialidocious infrastructure immediately")
        assertTrue(t.length <= 28)
    }

    @Test
    fun heuristicOnBlankIsBlank() {
        assertEquals("", TaskTitles.heuristic("   the a of  "))
        assertEquals("", TaskTitles.heuristic(""))
    }

    @Test
    fun cleanSanitizesModelReply() {
        assertEquals("Harbor Dashboard", TaskTitles.clean("\"Harbor Dashboard\""))
        assertEquals("Neon Shop", TaskTitles.clean("Neon Shop!"))
        assertEquals("Green Thumb", TaskTitles.clean("Title: Green Thumb"))
        assertEquals("", TaskTitles.clean("\"\"  "))
    }

    @Test
    fun cleanLimitsToThreeWords() {
        assertEquals("One Two Three", TaskTitles.clean("one two three four five"))
    }

    @Test
    fun cleanKeepsPersianWords() {
        val t = TaskTitles.clean("دریا آبی")
        assertTrue(t.isNotBlank())
        assertEquals(2, t.split(" ").size)
    }

    @Test
    fun promptsAreCompact() {
        assertTrue(TaskTitles.SYSTEM.contains("2-3 word"))
        assertTrue(TaskTitles.userPrompt("build a shop").contains("build a shop"))
    }
}
