package com.liman.agent

import com.liman.agent.agent.RunLedger
import com.liman.agent.agent.RunLessons
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * v2.35.0 — CROSS-RUN LEARNING + RUN LEDGER.
 *
 * The Hermes-style learning loop: failed/spinning runs leave a one-line
 * lesson in workspace/.liman-lessons.md (injected into every later prompt),
 * and every 15th run the ledger compiles a performance audit.
 */
class RunLessonsLedgerTest {

    private fun tmpDir(): File =
        File(System.getProperty("java.io.tmpdir"), "liman-test-${System.currentTimeMillis()}-${(0..99999).random()}")
            .apply { mkdirs() }

    // ---------- RunLessons ----------

    @Test
    fun lessonFileCreatedWithHeaderAndPrescription() {
        val ws = tmpDir()
        val f = RunLessons.append(ws, "build me a website", "loop", cycles = 6, toolCalls = 9, mutated = false)
        assertTrue(f.exists())
        assertEquals(".liman-lessons.md", f.name)
        val txt = f.readText()
        assertTrue(txt.contains("never repeat these mistakes"))   // header
        assertTrue(txt.contains("GOAL \"build me a website\""))
        assertTrue(txt.contains("ended=loop"))
        assertTrue(txt.contains("cycles=6"))
        assertTrue(txt.contains("never repeat an identical call")) // loop prescription
    }

    @Test
    fun readWriteRunGetsDeliveryPrescription() {
        val ws = tmpDir()
        RunLessons.append(ws, "research the best host", "completed", cycles = 5, toolCalls = 7, mutated = false)
        val txt = RunLessons.file(ws).readText()
        assertTrue(txt.contains("research without delivery is not progress"))
    }

    @Test
    fun lessonsAreCappedAtForty() {
        val ws = tmpDir()
        repeat(45) { RunLessons.append(ws, "goal number $it", "max_cycles", 5, 5, false) }
        val lines = RunLessons.file(ws).readLines().filter { it.startsWith("- ") }
        assertEquals(40, lines.size)
        assertTrue(lines.last().contains("goal number 44"))
        assertTrue(lines.first().contains("goal number 5"))  // oldest aged out
    }

    @Test
    fun goalNewlinesAndLengthAreSanitized() {
        val ws = tmpDir()
        RunLessons.append(ws, "line1\nline2\n" + "x".repeat(300), "error", 2, 1, false)
        val lines = RunLessons.file(ws).readLines().filter { it.startsWith("- ") }
        assertEquals(1, lines.size)
        assertTrue(lines[0].contains("line1 line2"))
        assertTrue(lines[0].length < 400)
    }

    // ---------- RunLedger ----------

    @Test
    fun noAuditBeforeTheFifteenthRun() {
        val dir = tmpDir()
        repeat(14) { assertNull(RunLedger.record(dir, "completed", 3, 5)) }
    }

    @Test
    fun fifteenthRunCompilesAudit() {
        val dir = tmpDir()
        repeat(14) { RunLedger.record(dir, "completed", 3, 5) }
        val audit = RunLedger.record(dir, "completed", 3, 5)   // #15
        assertNotNull(audit)
        audit!!
        assertEquals(15, audit.runs)
        assertEquals(15, audit.completed)
        assertTrue(audit.body.contains("15/15"))
        assertTrue(audit.body.contains("healthy"))
    }

    @Test
    fun spinHeavyHistoryIsFlagged() {
        val dir = tmpDir()
        repeat(14) { RunLedger.record(dir, if (it % 2 == 0) "loop" else "max_cycles", 8, 2) }
        val audit = RunLedger.record(dir, "loop", 8, 2)
        assertNotNull(audit)
        assertTrue(audit!!.body.contains("spinning"))
        assertTrue(audit.body.contains("lessons in .liman-lessons.md"))
    }

    @Test
    fun auditFiresEveryFifteenRuns() {
        val dir = tmpDir()
        repeat(15) { RunLedger.record(dir, "completed", 2, 4) }
        assertNull(RunLedger.record(dir, "completed", 2, 4))    // #16
        repeat(13) { RunLedger.record(dir, "completed", 2, 4) } // #17–#29
        assertNotNull(RunLedger.record(dir, "completed", 2, 4)) // #30
    }
}
