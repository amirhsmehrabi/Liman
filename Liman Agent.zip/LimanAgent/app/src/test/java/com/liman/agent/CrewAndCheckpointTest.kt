package com.liman.agent

import com.liman.agent.agent.CheckpointData
import com.liman.agent.agent.CrewPlanner
import com.liman.agent.agent.CrewTask
import com.liman.agent.agent.RunCheckpointer
import com.liman.agent.agent.ScheduleLogic
import com.liman.agent.agent.builtInToolSpecs
import com.liman.agent.llm.LPart
import com.liman.agent.llm.LlmMessage
import com.liman.agent.llm.Role
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.Calendar

/**
 * v2.20.0 — SYNTHESIS unit tests:
 *  - CrewPlanner (CrewAI role/task/process + AutoGen termination + manager plans)
 *  - RunCheckpointer (LangGraph crash-resume roundtrip)
 *  - ScheduleLogic.activeHoursOk (OpenClaw heartbeat windows)
 *  - the 5 new tools are registered with strict-valid schemas
 */
class CrewAndCheckpointTest {

    @get:Rule
    val tmp = TemporaryFolder()

    // ---------------- CrewPlanner ----------------

    private fun crewArgs(
        process: String? = null,
        tasks: Int = 2,
        roles: Boolean = true
    ) = buildJsonObject {
        put("goal", "Produce a competitive analysis report")
        process?.let { put("process", it) }
        if (roles) put("roles", buildJsonArray {
            add(buildJsonObject {
                put("role", "Researcher"); put("goal", "gather facts"); put("backstory", "10y analyst")
            })
            add(buildJsonObject {
                put("role", "Writer"); put("goal", "clear prose"); put("backstory", "ex journalist")
            })
        })
        put("tasks", buildJsonArray {
            (1..tasks).forEach { i ->
                add(buildJsonObject {
                    put("description", "Task $i: analyze competitor $i")
                    put("agent", if (i == 1) "Researcher" else "Writer")
                    put("expected_output", "findings for competitor $i")
                })
            }
        })
    }

    @Test
    fun parsesCrewAndMatchesRoles() {
        val plan = CrewPlanner.parse(crewArgs())!!
        assertEquals("sequential", plan.process) // default
        assertEquals(2, plan.tasks.size)
        assertEquals("Researcher", plan.roleFor(plan.tasks[0])!!.role)
        assertEquals("Writer", plan.roleFor(plan.tasks[1])!!.role)
        assertTrue(plan.roles[0].backstory.contains("analyst"))
    }

    @Test
    fun validatesMissingPieces() {
        // no goal
        assertNull(CrewPlanner.parse(buildJsonObject {
            put("tasks", buildJsonArray { add(buildJsonObject { put("description", "x") }) })
        }))
        // no tasks
        assertNull(CrewPlanner.parse(buildJsonObject { put("goal", "g") }))
        // malformed process falls back to sequential, not null
        val plan = CrewPlanner.parse(crewArgs(process = "chaos"))!!
        assertEquals("sequential", plan.process)
    }

    @Test
    fun broadcastAndHierarchicalProcessesAccepted() {
        assertEquals("broadcast", CrewPlanner.parse(crewArgs(process = "broadcast"))!!.process)
        assertEquals("hierarchical", CrewPlanner.parse(crewArgs(process = "hierarchical"))!!.process)
    }

    @Test
    fun briefCarriesCrewContract() {
        val plan = CrewPlanner.parse(crewArgs())!!
        val brief = CrewPlanner.brief(plan, plan.tasks[0], "### Output of task 1: earlier findings")
        assertTrue(brief.contains("CREW GOAL"))
        assertTrue(brief.contains("YOUR ROLE: Researcher"))
        assertTrue(brief.contains("BACKSTORY"))
        assertTrue(brief.contains("EXPECTED OUTPUT"))
        assertTrue(brief.contains("CONTEXT"))
        assertTrue(brief.contains("do NOT redo"))
        assertTrue(brief.contains("TERMINATE"))
    }

    @Test
    fun autoGenTerminationConditions() {
        // TextMentionTermination
        assertTrue(CrewPlanner.isTerminate("TERMINATE: cannot access the data"))
        assertTrue(CrewPlanner.isTerminate("I must TERMINATE now"))
        // plain text / lowercase / embedded words must NOT fire
        assertFalse(CrewPlanner.isTerminate("The task is complete, all good."))
        assertFalse(CrewPlanner.isTerminate("we terminated the worker process earlier"))
        assertFalse(CrewPlanner.isTerminate("termination notice period"))
        assertEquals("cannot access the data", CrewPlanner.terminateReason("TERMINATE: cannot access the data"))
    }

    @Test
    fun managerPlanParsesIntoOrderedTasks() {
        val plan = CrewPlanner.parse(crewArgs())!!
        val managerText = """
            Here is the plan:
            1. Researcher :: Task 1: analyze competitor 1
            2. Writer :: Task 2: analyze competitor 2
            3. Writer :: also write an executive summary
        """.trimIndent()
        val ordered = CrewPlanner.parseManagerPlan(managerText, plan)
        assertEquals(3, ordered.size)
        assertEquals("Researcher", ordered[0].agent)
        assertTrue(ordered[2].description.contains("executive summary")) // ad-hoc task accepted
        // garbage input falls back to the proposed order
        val fallback = CrewPlanner.parseManagerPlan("I could not produce a plan, sorry.", plan)
        assertEquals(plan.tasks, fallback)
    }

    // ---------------- RunCheckpointer (LangGraph port) ----------------

    @Test
    fun checkpointRoundtripSurvivesToolMessages() {
        val dir = File(tmp.newFolder(), "runstate")
        val msgs = listOf(
            LlmMessage(Role.SYSTEM, listOf(LPart.Text("sys"))),
            LlmMessage(Role.USER, listOf(LPart.Text("do the thing"))),
            LlmMessage(Role.ASSISTANT, listOf(
                LPart.Text("calling"),
                LPart.ToolCallPart("call-1", "write_file", """{"name":"a.txt"}""")
            )),
            LlmMessage(Role.TOOL, listOf(
                LPart.ToolResultPart("call-1", "write_file", "wrote 12 bytes")
            ))
        )
        RunCheckpointer.save(dir, CheckpointData("conv-42", "the goal", 7, 123L, msgs))
        val cp = RunCheckpointer.load(dir, "conv-42")
        assertNotNull(cp)
        assertEquals("the goal", cp!!.goal)
        assertEquals(7, cp.cycle)
        assertEquals(4, cp.messages.size)
        assertEquals("call-1", (cp.messages[2].parts[1] as LPart.ToolCallPart).id)
        assertEquals("wrote 12 bytes", (cp.messages[3].parts[0] as LPart.ToolResultPart).text)
        // clear → gone (a cleared checkpoint means "no crash")
        RunCheckpointer.clear(dir, "conv-42")
        assertNull(RunCheckpointer.load(dir, "conv-42"))
        // weird conv ids are filename-sanitized, no path escape
        RunCheckpointer.save(dir, CheckpointData("../../etc/passwd", "g", 1, 1L, msgs))
        assertNotNull(RunCheckpointer.load(dir, "../../etc/passwd"))
    }

    // ---------------- ScheduleLogic.activeHoursOk (OpenClaw heartbeat) ----------------

    private fun at(h: Int, m: Int): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    @Test
    fun activeHoursWindowGatesHeartbeats() {
        assertTrue(ScheduleLogic.activeHoursOk(null, at(3, 0)))            // always
        assertTrue(ScheduleLogic.activeHoursOk("", at(3, 0)))
        assertTrue(ScheduleLogic.activeHoursOk("09:00-22:00", at(15, 30))) // inside
        assertFalse(ScheduleLogic.activeHoursOk("09:00-22:00", at(23, 10))) // outside
        assertFalse(ScheduleLogic.activeHoursOk("09:00-22:00", at(7, 59)))
        // overnight window wraps midnight
        assertTrue(ScheduleLogic.activeHoursOk("22:00-06:00", at(23, 30)))
        assertTrue(ScheduleLogic.activeHoursOk("22:00-06:00", at(5, 0)))
        assertFalse(ScheduleLogic.activeHoursOk("22:00-06:00", at(12, 0)))
        // malformed never blocks (fail-open, the task still runs)
        assertTrue(ScheduleLogic.activeHoursOk("whenever", at(3, 0)))
    }

    // ---------------- tool registration ----------------

    @Test
    fun synthesisToolsAreRegisteredWithValidSchemas() {
        val names = builtInToolSpecs().map { it.name }.toSet()
        listOf(
            "knowledge_add", "knowledge_search", "knowledge_list", "knowledge_forget", "team_run"
        ).forEach { assertTrue("missing tool $it", names.contains(it)) }
        // strict-parse every new schema (same guarantee as ToolsSpecTest)
        val strict = Json { }
        builtInToolSpecs().filter {
            it.name in setOf("knowledge_add", "knowledge_search", "knowledge_list", "knowledge_forget", "team_run")
        }.forEach { spec ->
            strict.parseToJsonElement(spec.parametersJson) // throws on invalid
            assertTrue(spec.description.isNotBlank())
        }
    }
}
