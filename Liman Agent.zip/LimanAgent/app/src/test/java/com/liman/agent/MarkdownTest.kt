package com.liman.agent

import com.liman.agent.ui.MarkdownParser
import com.liman.agent.ui.MdBlock
import com.liman.agent.ui.MdSpan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * MarkdownParser — chat messages must render real markdown, never raw
 * `*text*` / backticks in the UI.
 */
class MarkdownTest {

    @Test
    fun `bold italic and code are parsed`() {
        val spans = MarkdownParser.parseInline("mix **bold** and *ital* and `code` end")
        assertEquals(
            listOf(
                MdSpan.Plain("mix "),
                MdSpan.Bold("bold"),
                MdSpan.Plain(" and "),
                MdSpan.Italic("ital"),
                MdSpan.Plain(" and "),
                MdSpan.Code("code"),
                MdSpan.Plain(" end")
            ),
            spans
        )
    }

    @Test
    fun `single asterisks stay literal when unmatched`() {
        val spans = MarkdownParser.parseInline("5 * 3 = 15")
        assertEquals(listOf<MdSpan>(MdSpan.Plain("5 * 3 = 15")), spans)
    }

    @Test
    fun `link parsing`() {
        val spans = MarkdownParser.parseInline("see [docs](https://example.com) now")
        assertTrue(spans.any { it is MdSpan.Link && it.url == "https://example.com" && it.text == "docs" })
    }

    @Test
    fun `strike parsing`() {
        val spans = MarkdownParser.parseInline("no ~~wrong~~ yes")
        assertTrue(spans.any { it is MdSpan.Strike && it.text == "wrong" })
    }

    @Test
    fun `code fence becomes a block with language`() {
        val blocks = MarkdownParser.parse("before\n```kotlin\nval x = 1\n```\nafter")
        val code = blocks.filterIsInstance<MdBlock.CodeBlock>().first()
        assertEquals("kotlin", code.lang)
        assertEquals("val x = 1", code.code)
        assertTrue(blocks.first() is MdBlock.Paragraph)
    }

    @Test
    fun `headings levels`() {
        val blocks = MarkdownParser.parse("# Big\n## Smaller\n### Small")
        assertEquals(3, blocks.size)
        assertTrue(blocks[0] is MdBlock.Heading && (blocks[0] as MdBlock.Heading).level == 1)
    }

    @Test
    fun `bullet and ordered lists`() {
        val blocks = MarkdownParser.parse("- one\n- two\n\n1. first\n2. second")
        assertEquals(2, blocks.size)
        val b = blocks[0] as MdBlock.BulletList
        assertEquals(2, b.items.size)
        val o = blocks[1] as MdBlock.OrderedList
        assertEquals(2, o.items.size)
    }

    @Test
    fun `quote block`() {
        val blocks = MarkdownParser.parse("> quoted line\n> more")
        val q = blocks[0] as MdBlock.Quote
        assertTrue(q.inline.isNotEmpty())
    }

    @Test
    fun `table parsing`() {
        val blocks = MarkdownParser.parse("| a | b |\n|---|---|\n| 1 | 2 |")
        val t = blocks[0] as MdBlock.Table
        assertEquals(listOf("a", "b"), t.header)
        assertEquals(listOf("1", "2"), t.rows[0])
    }

    @Test
    fun `horizontal rule`() {
        val blocks = MarkdownParser.parse("para\n\n---\n\npara2")
        assertTrue(blocks.any { it is MdBlock.Rule })
    }

    @Test
    fun `bold inside list item`() {
        val blocks = MarkdownParser.parse("- **key**: value")
        val b = blocks[0] as MdBlock.BulletList
        val spans = b.items[0]
        assertTrue(spans.any { it is MdSpan.Bold && it.text == "key" })
    }

    @Test
    fun `plain text with no markdown survives intact`() {
        val spans = MarkdownParser.parseInline("hello world 100%")
        assertEquals(listOf<MdSpan>(MdSpan.Plain("hello world 100%")), spans)
    }

    @Test
    fun `nested emphasis is conservative not broken`() {
        // unmatched marker → literal
        val spans = MarkdownParser.parseInline("a * b ** c")
        assertTrue(spans.all { it is MdSpan.Plain })
    }

    // ---------------- v2.31 additions ----------------

    @Test
    fun `highlight spans are parsed`() {
        val spans = MarkdownParser.parseInline("before ==the key== after")
        val hl = spans.filterIsInstance<MdSpan.Highlight>()
        assertEquals(1, hl.size)
        assertEquals("the key", hl[0].text)
    }

    @Test
    fun `unmatched equals stay literal`() {
        val spans = MarkdownParser.parseInline("a == b == c")
        assertTrue(spans.filterIsInstance<MdSpan.Highlight>().isEmpty())
    }

    @Test
    fun `task list block is parsed`() {
        val blocks = MarkdownParser.parse("- [ ] first\n- [x] second\n- plain bullet")
        val tl = blocks.filterIsInstance<MdBlock.TaskList>()
        assertEquals(1, tl.size)
        assertEquals(2, tl[0].items.size)
        assertFalse(tl[0].items[0].checked)
        assertTrue(tl[0].items[1].checked)
        // plain bullet after the list is its own block
        assertEquals(1, blocks.filterIsInstance<MdBlock.BulletList>().size)
    }

    @Test
    fun `heading inline can carry highlight`() {
        val blocks = MarkdownParser.parse("## Title with ==marked== word")
        val h = blocks.filterIsInstance<MdBlock.Heading>()[0]
        assertEquals(2, h.level)
        assertTrue(h.inline.any { it is MdSpan.Highlight })
    }
}
