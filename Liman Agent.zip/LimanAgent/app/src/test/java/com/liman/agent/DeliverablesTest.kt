package com.liman.agent

import com.liman.agent.agent.Deliverables
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** v2.36 — DELIVERABLES: produced files become downloadable chips. */
class DeliverablesTest {

    private fun tmpWs(): File =
        File(System.getProperty("java.io.tmpdir"), "liman-dlv-${System.currentTimeMillis()}-${(0..99999).random()}")
            .apply { mkdirs() }

    @Test
    fun newDeliverableFilesAreCollected() {
        val ws = tmpWs()
        val before = Deliverables.inventory(ws)
        File(ws, "report.docx").writeText("doc")
        File(ws, "build/app.zip").apply { parentFile.mkdirs() }.writeText("zip")
        val arts = Deliverables.collect(ws, before, ws)   // ws == its own root here
        assertEquals(setOf("report.docx", "build/app.zip"), arts.map { it.path }.toSet())
        assertEquals("app.zip", arts.first { it.name == "app.zip" }.name)
    }

    @Test
    fun oldFilesAreNotReattached() {
        val ws = tmpWs()
        File(ws, "old.pdf").writeText("x")
        val before = Deliverables.inventory(ws)
        Thread.sleep(50)
        assertEquals(0, Deliverables.collect(ws, before, ws.parentFile).size)
    }

    @Test
    fun modifiedFilesAreReattached() {
        val ws = tmpWs()
        val f = File(ws, "chart.svg")
        f.writeText("v1")
        val before = Deliverables.inventory(ws)
        Thread.sleep(60)
        f.writeText("v2")
        val arts = Deliverables.collect(ws, before, ws.parentFile)
        assertEquals(1, arts.size)
        assertEquals("chart.svg", arts[0].name)
    }

    @Test
    fun hiddenAndInternalPathsAreExcluded() {
        val ws = tmpWs()
        val before = Deliverables.inventory(ws)
        File(ws, ".liman-lessons.md").writeText("x")
        File(ws, "journal/day.md").apply { parentFile.mkdirs() }.writeText("x")
        File(ws, "node_modules/pkg/index.js").apply { parentFile.mkdirs() }.writeText("x")
        File(ws, ".secrets.json").writeText("x")
        assertEquals(0, Deliverables.collect(ws, before, ws.parentFile).size)
    }

    @Test
    fun nonDeliverableExtensionsIgnored() {
        val ws = tmpWs()
        val before = Deliverables.inventory(ws)
        File(ws, "binary.dat").writeText("x")
        File(ws, "noext").writeText("x")
        assertEquals(0, Deliverables.collect(ws, before, ws.parentFile).size)
    }

    @Test
    fun cappedAtEightNewestFirst() {
        val ws = tmpWs()
        val before = Deliverables.inventory(ws)
        (1..12).forEach { i ->
            File(ws, "f%02d.png".format(i)).writeText("x")
            Thread.sleep(15)
        }
        val arts = Deliverables.collect(ws, before, ws.parentFile)
        assertEquals(8, arts.size)
        assertEquals("f12.png", arts[0].name)   // newest first
        assertEquals("f05.png", arts[7].name)
    }

    @Test
    fun chatWorkspacePathsAreRelativeToRoot() {
        val root = tmpWs()
        val chat = File(root, "chats/task-1").apply { mkdirs() }
        val before = Deliverables.inventory(chat)
        File(chat, "out.apk").writeText("x")
        val arts = Deliverables.collect(chat, before, root)
        assertEquals("chats/task-1/out.apk", arts[0].path)
    }
}
