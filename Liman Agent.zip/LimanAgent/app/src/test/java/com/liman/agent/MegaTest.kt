package com.liman.agent

import com.liman.agent.agent.MissionTask
import com.liman.agent.agent.MissionTracker
import com.liman.agent.agent.ScheduleLogic
import com.liman.agent.agent.Secrets
import com.liman.agent.agent.SubagentBrief
import com.liman.agent.agent.Trash
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.util.Calendar

/**
 * v2.16.0 — MEGA AGENT mechanisms (adopted from the ORION MEGA spec).
 * Pins: secret redaction in the UI, backup-before-destructive, mission
 * decomposition checklists, subagent role briefs, and schedule due-math.
 */
class MegaTest {

    // ---------- secrets redaction ----------

    @Test
    fun redactsApiKeysAndBearerTokens() {
        val raw = """{"url":"https://api.cloudflare.com/x","headers":{"Authorization":"Bearer sk-abc123def456ghi789jkl012"}}"""
        val out = Secrets.redact(raw)
        assertFalse("raw token must not survive", out.contains("sk-abc123def456ghi789jkl012"))
        assertTrue(out.contains("Bearer"))
        assertTrue(out.contains("redacted"))
    }

    @Test
    fun redactsGithubAndOpaqueTokens() {
        val r = Secrets.redact("token ghp_16CharactersPlus123456")
        assertFalse("github token must not survive", r.contains("ghp_16CharactersPlus123456"))
        assertTrue(r.contains("redacted"))
        val blob = "A1b2C3d4E5f6G7h8I9j0K1l2M3n4O5p6Q7r8S9t0U1v2W3" // 46 opaque chars
        val out = Secrets.redact("key=$blob")
        assertFalse(out.contains(blob))
        assertTrue(out.contains("redacted"))
    }

    @Test
    fun keepsNormalTextIntact() {
        val normal = "Deployed worker my-api to https://api.example.com/v1/accounts/123/workers"
        assertEquals(normal, Secrets.redact(normal))
    }

    // ---------- backup-before-destructive ----------

    @get:Rule
    val tmp = TemporaryFolder()

    @Test
    fun deleteBackupPreservesContent() {
        val ws = tmp.newFolder("ws")
        val f = File(ws, "important.js").apply { writeText("export default 42;") }
        val backup = Trash.backup(f, ws)
        assertNotNull(backup)
        assertTrue(backup!!.exists())
        assertEquals("export default 42;", backup.readText())
        assertTrue(backup.path.contains(".trash"))
        // original untouched by the backup itself
        assertTrue(f.exists())
    }

    @Test
    fun backupOfMissingFileIsNull() {
        val ws = tmp.newFolder("ws2")
        assertNull(Trash.backup(File(ws, "nope.txt"), ws))
    }

    // ---------- mission tracker ----------

    @Test
    fun missionChecklistRendersAndUpdates() {
        val m = MissionTracker()
        assertFalse(m.isPlanned())
        m.plan(
            "Deploy echo bot",
            listOf(
                MissionTask("T1", "scaffold worker", "node --check exit 0"),
                MissionTask("T2", "deploy", "curl URL → 200"),
                MissionTask("T3", "verify reply", "echo round-trip <2s")
            )
        )
        val plan = m.render()
        assertTrue(plan.contains("MISSION: Deploy echo bot — 0/3 done"))
        assertTrue(plan.contains("⬜ T1 scaffold worker"))
        assertTrue(plan.contains("[✓: node --check exit 0]"))

        assertTrue(m.update("T1", "done"))
        assertTrue(m.update("T2", "in_progress"))
        val mid = m.render()
        assertTrue(mid.contains("1/3 done"))
        assertTrue(mid.contains("✅ T1"))
        assertTrue(mid.contains("▶️ T2"))
        assertFalse("unknown id rejected", m.update("T9", "done"))
        assertEquals(3, m.tasks.size)
    }

    // ---------- subagent briefs ----------

    @Test
    fun briefCarriesRoleContractAndCriteria() {
        val b = SubagentBrief.build(
            role = "deployer",
            goal = "deploy runs/t1 to Cloudflare",
            context = "wrangler.toml in runs/t1",
            constraints = listOf("use \$CF_API_TOKEN from env, never print it"),
            acceptanceCriteria = listOf("wrangler whoami exit 0", "*.workers.dev URL printed", "curl URL → 200")
        )
        assertTrue(b.contains("deployer-subagent"))
        assertTrue(b.contains("ROLE: Run deployment procedures"))
        assertTrue(b.contains("GOAL: deploy runs/t1 to Cloudflare"))
        assertTrue(b.contains("never print it"))
        assertTrue(b.contains("ACCEPTANCE CRITERIA"))
        assertTrue(b.contains("curl URL → 200"))
        assertTrue(b.contains("Result / Evidence / Side effects / Blockers"))
    }

    @Test
    fun unknownRoleFallsBackToBuilder() {
        val b = SubagentBrief.build("wizard", "do X", "", emptyList(), emptyList())
        assertTrue(b.contains("builder-subagent"))
        assertNull(SubagentBrief.roleLine("nonexistent"))
        assertNotNull(SubagentBrief.roleLine("Verifier"))
    }

    // ---------- prompt right-sizing for weak models ----------

    @Test
    fun weakModelsGetTheCompactPrompt() {
        assertTrue(com.liman.agent.agent.PromptSizing.compactFor("gemini-2.0-flash-lite"))
        assertTrue(com.liman.agent.agent.PromptSizing.compactFor("gpt-4o-mini"))
        assertTrue(com.liman.agent.agent.PromptSizing.compactFor("llama-3.1-8b-instruct"))
        assertTrue(com.liman.agent.agent.PromptSizing.compactFor("Muse-Spark-Free"))
        assertTrue(com.liman.agent.agent.PromptSizing.compactFor("qwen2.5:3b"))
    }

    @Test
    fun strongModelsKeepTheFullPrompt() {
        assertFalse(com.liman.agent.agent.PromptSizing.compactFor("gemini-2.5-pro"))
        assertFalse(com.liman.agent.agent.PromptSizing.compactFor("gemini-2.0-flash"))
        assertFalse(com.liman.agent.agent.PromptSizing.compactFor("gpt-4o"))
        assertFalse(com.liman.agent.agent.PromptSizing.compactFor("deepseek-chat"))
        assertFalse(com.liman.agent.agent.PromptSizing.compactFor("claude-sonnet-4"))
    }

    // ---------- schedule math (the cron engine) ----------

    private fun at(hour: Int, minute: Int, dayOffset: Int = 0): Long =
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            add(Calendar.DAY_OF_YEAR, dayOffset)
        }.timeInMillis

    @Test
    fun dailyTaskDueAfterTargetTimeWhenNotRunToday() {
        val now = at(10, 0)
        val ranYesterday = at(8, 0, dayOffset = -1)
        assertTrue("due: past 08:00, last run yesterday", ScheduleLogic.isDue("08:00", 0, ranYesterday, now))
        val ranToday = at(8, 30)
        assertFalse("not due: already ran today", ScheduleLogic.isDue("08:00", 0, ranToday, now))
    }

    @Test
    fun dailyTaskNotDueBeforeTargetTime() {
        val now = at(7, 0)
        val ranYesterday = at(8, 0, dayOffset = -1)
        assertFalse("before 08:00", ScheduleLogic.isDue("08:00", 0, ranYesterday, now))
    }

    @Test
    fun intervalTaskDueAfterNHours() {
        val now = at(15, 0)
        val threeHoursAgo = now - 3 * 3_600_000L
        assertTrue("3h elapsed, every 2h", ScheduleLogic.isDue("", 2, threeHoursAgo, now))
        val oneHourAgo = now - 3_600_000L
        assertFalse("only 1h elapsed", ScheduleLogic.isDue("", 2, oneHourAgo, now))
    }

    @Test
    fun invalidTimeIsNeverDue() {
        assertFalse(ScheduleLogic.isDue("25:99", 0, 0, at(10, 0)))
        assertFalse(ScheduleLogic.isDue("abc", 0, 0, at(10, 0)))
        assertNull(ScheduleLogic.parseHm("8:5"))
        assertEquals(8 to 5, ScheduleLogic.parseHm("08:05"))
    }
}
