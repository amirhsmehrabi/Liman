package com.liman.agent

import com.liman.agent.agent.TermuxBridge
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.17.0 — THE TERMUX BRIDGE.
 *
 * "Can Liman run npm code or connect to Termux?" — with this bridge the
 * agent executes REAL commands in the user's Termux (RUN_COMMAND intent)
 * and gets full stdout back via Liman's local router. These tests pin the
 * transport: wrapper command shape and the script/result round-trip.
 */
class TermuxBridgeTest {

    @Test
    fun wrapperIsPureBashWithZeroDependencies() {
        val cmd = TermuxBridge.wrapperCommand(port = 20129, id = "tx123")
        // v2: NO curl dependency (curl is not in the Termux bootstrap — the v1
        // bridge died silently because of it). Pure bash /dev/tcp instead.
        assertFalse("wrapper must not require curl", cmd.contains("curl"))
        assertTrue("bash /dev/tcp to the local router (port as $1)", cmd.contains("/dev/tcp/127.0.0.1/\$1"))
        // id + port travel as arguments ($1/$2 via `set --`)
        assertTrue("ports/ids passed as args", cmd.contains("set -- 20129 tx123"))
        assertTrue("fetches the script", cmd.contains("GET /termux/script/%s"))
        assertTrue("runs with stderr merged", cmd.contains("| bash 2>&1"))
        assertTrue("POSTs the result back", cmd.contains("POST /termux/result/%s"))
        assertTrue("sends Content-Length", cmd.contains("Content-Length"))
    }

    @Test
    fun selfTestUsesThePingProbe() {
        val t = TermuxBridge.selfTest(20129)
        assertTrue(t.contains("/dev/tcp/127.0.0.1/\$1"))
        assertTrue(t.contains("/termux/script/%s"))
        assertTrue("ping id passed as arg", t.contains("set -- 20129 ping"))
        assertFalse(t.contains("curl"))
    }

    @Test
    fun scriptResultRoundTripWorks() {
        TermuxBridge.putScript("rt1", "echo hello")
        assertEquals("echo hello", TermuxBridge.takeScript("rt1"))
        // second take is gone (single-serving)
        assertNull(TermuxBridge.takeScript("rt1"))

        TermuxBridge.putResult("rt1", "hello\n")
        assertEquals("hello\n", TermuxBridge.peekResult("rt1"))
        // consumed on read
        assertNull(TermuxBridge.peekResult("rt1"))
    }

    @Test
    fun awaitResultReturnsNullOnTimeout() {
        // no result was ever posted for this id
        val out = runBlocking { TermuxBridge.awaitResult("never-posted", 400) }
        assertNull(out)
    }

    @Test
    fun awaitResultPicksUpLateResult() = runBlocking {
        val id = "late1"
        TermuxBridge.putScript(id, "sleep 0.3; echo done")
        // simulate Termux posting the result ~300ms in
        val poster = Thread {
            Thread.sleep(300)
            TermuxBridge.putResult(id, "done")
        }
        poster.start()
        val out = TermuxBridge.awaitResult(id, 3000)
        poster.join()
        assertEquals("done", out)
    }

    @Test
    fun constantsMatchTermuxContract() {
        assertEquals("com.termux", TermuxBridge.TERMUX_PACKAGE)
        assertEquals("com.termux.permission.RUN_COMMAND", TermuxBridge.RUN_COMMAND_PERMISSION)
        assertEquals("/data/data/com.termux/files/usr/bin/bash", TermuxBridge.TERMUX_BASH)
        // wrapper must run under bash -c with the router URLs in it (checked in wrapperCommandFetchesScriptAndPostsResultBack)
        assertFalse(TermuxBridge.wrapperCommand(20129, "x").contains("sudo"))
    }
}
