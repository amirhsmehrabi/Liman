package com.liman.agent

import com.liman.agent.agent.ArgsNormalizer
import com.liman.agent.agent.NativeBuilder
import com.liman.agent.agent.TaskHeuristics
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

/**
 * v2.24.1 — THE RELIABILITY PATCH.
 *
 * User-reported bugs this suite locks down:
 *  1. models wrapping tool args in {"arguments":{…}} → "Missing 'name'/'command'/'action'"
 *  2. native_apk setup timing out as "No response from Termux" (now a background job + polling)
 *  3. simple tasks burning planning/review cycles
 */
class ArgsNormalizerTest {

    private fun obj(s: String): JsonObject = Json.parseToJsonElement(s).jsonObject

    // ---------------------------------------------------------------- normalizer

    @Test fun unwrapsSingleWrapperLayer() {
        for (key in listOf("arguments", "parameters", "params", "args", "tool_input", "tool_arguments", "function")) {
            val r = ArgsNormalizer.normalize(obj("""{"$key":{"command":"ls -la"}}"""))
            assertEquals("ls -la", (r.args["command"] as? kotlinx.serialization.json.JsonPrimitive)?.content)
            assertTrue(r.fixedNote != null)
        }
    }

    @Test fun unwrapsNestedWrapperLayers() {
        val r = ArgsNormalizer.normalize(obj("""{"arguments":{"parameters":{"name":"a.md","content":"hi"}}}"""))
        assertEquals("a.md", (r.args["name"] as? kotlinx.serialization.json.JsonPrimitive)?.content)
        assertEquals("hi", (r.args["content"] as? kotlinx.serialization.json.JsonPrimitive)?.content)
        assertEquals(2, r.args.size)
    }

    @Test fun parsesStringEncodedArguments() {
        val r = ArgsNormalizer.normalize(obj("""{"arguments":"{\"command\":\"pwd\"}"}"""))
        assertEquals("pwd", (r.args["command"] as? kotlinx.serialization.json.JsonPrimitive)?.content)
    }

    @Test fun parsesLoneJsonStringArgument() {
        val r = ArgsNormalizer.normalize(obj("""{"raw":"{\"name\":\"x.md\"}"}"""))
        assertEquals("x.md", (r.args["name"] as? kotlinx.serialization.json.JsonPrimitive)?.content)
    }

    @Test fun flatArgsPassThroughUntouched() {
        val src = """{"name":"report.md","content":"# h1\nbody"}"""
        val r = ArgsNormalizer.normalize(obj(src))
        assertNull(r.fixedNote)
        assertEquals(obj(src), r.args)
    }

    @Test fun nonJsonWrapperStringIsKeptAsValue() {
        // "input" is a legit argument whose value is plain prose, not JSON — must survive
        val r = ArgsNormalizer.normalize(obj("""{"input":"hello world"}"""))
        assertNull(r.fixedNote)
        assertEquals("hello world", (r.args["input"] as? kotlinx.serialization.json.JsonPrimitive)?.content)
    }

    @Test fun innerOverridesOuterOnMerge() {
        val r = ArgsNormalizer.normalize(obj("""{"arguments":{"name":"inner.md"},"extra":true}"""))
        assertEquals("inner.md", (r.args["name"] as? kotlinx.serialization.json.JsonPrimitive)?.content)
        assertEquals("true", (r.args["extra"] as? kotlinx.serialization.json.JsonPrimitive)?.content)
    }

    @Test fun wrapperDepthIsCapped() {
        // 4 layers deep → unwraps at most 3; no infinite loop, still returns an object
        val r = ArgsNormalizer.normalize(obj("""{"args":{"args":{"args":{"args":{"x":1}}}}}"""))
        assertTrue(r.args.isNotEmpty())
    }

    // ---------------------------------------------------------------- missing-arg teacher

    @Test fun missingArgShowsKeysAndFlatExample() {
        val msg = ArgsNormalizer.missingArg("write_file", "content", obj("""{"filename":"a.md"}"""), """{"name":"a.md","content":"text"}""")
        assertTrue(msg.contains("Missing 'content' for write_file"))
        assertTrue(msg.contains("filename"))
        assertTrue(msg.contains("FLAT"))
        assertTrue(msg.contains("Do NOT nest"))
    }

    @Test fun missingArgHandlesEmptyArgs() {
        val msg = ArgsNormalizer.missingArg("termux_run", "command", obj("{}"), """{"command":"ls"}""")
        assertTrue(msg.contains("(none"))
    }

    // ---------------------------------------------------------------- simple-task heuristics

    @Test fun shortSingleActionPromptsAreSimple() {
        assertTrue(TaskHeuristics.isSimpleTask("write a md file report of our chat"))
        assertTrue(TaskHeuristics.isSimpleTask("read data.json and tell me the total"))
        assertTrue(TaskHeuristics.isSimpleTask("delete log.txt"))
    }

    @Test fun longPromptsAreNotSimple() {
        val long = (1..60).joinToString(" ") { "word$it" }
        assertTrue(long.length > 260)
        assertFalse(TaskHeuristics.isSimpleTask(long))
    }

    @Test fun multiStepMarkersForcePlanning() {
        assertFalse(TaskHeuristics.isSimpleTask("research and compare rust vs zig for performance"))
        assertFalse(TaskHeuristics.isSimpleTask("build a habit tracker project with scheduling"))
    }

    @Test fun appAndApkAsksNeverTakeTheFastPath() {
        assertFalse(TaskHeuristics.isSimpleTask("build an app for my notes"))
        assertFalse(TaskHeuristics.isSimpleTask("make an apk of that"))
        assertFalse(TaskHeuristics.isSimpleTask("automate my morning report"))
    }

    @Test fun singleMarkerWithoutAppWordStaysSimple() {
        // "analyze" alone in a short one-shot ask is still a light task
        assertTrue(TaskHeuristics.isSimpleTask("analyze this sentence for typos"))
    }

    // ---------------------------------------------------------------- native job wrap + polling

    @Test fun jobWrapBase64PayloadDecodesToTrappedScript() {
        val wrapped = NativeBuilder.jobWrap("echo hello")
        assertTrue(wrapped.contains("LIMAN_JOB_LAUNCHED"))
        assertTrue(wrapped.contains("base64 -d > ~/liman-native/job.sh"))
        assertTrue(wrapped.contains("nohup bash ~/liman-native/job.sh"))
        // extract the base64 blob and decode it: trap + payload must be inside
        val b64 = Regex("'([A-Za-z0-9+/=]+)'").find(wrapped)!!.groupValues[1]
        val decoded = String(Base64.getDecoder().decode(b64))
        val d = '$' // literal shell dollar in the assertion below
        assertTrue(decoded.startsWith("set -e"))
        assertTrue(decoded.contains("trap 'echo LIMAN_JOB_EXIT_${d}? >> ~/liman-native/job.log' EXIT"))
        assertTrue(decoded.contains("echo hello"))
        // the wrap must NOT leak Kotlin template artifacts
        assertFalse(decoded.contains("\${d}"))
    }

    @Test fun pollScriptTailsLogAndReportsDoneOrRunning() {
        val s = NativeBuilder.pollScript()
        assertTrue(s.contains("tail -c 3000 ~/liman-native/job.log"))
        assertTrue(s.contains("LIMAN_JOB_EXIT_"))
        assertTrue(s.contains("LIMAN_JOB_DONE"))
        assertTrue(s.contains("LIMAN_JOB_RUNNING"))
    }

    @Test fun jobOutcomeDetectsExitMarkerAndCode() {
        val (done1, code1, _) = NativeBuilder.jobOutcome("compiling...\nLIMAN_BUILD_OK 1234 abc\nLIMAN_JOB_EXIT_0")
        assertTrue(done1); assertEquals(0, code1)
        val (done2, code2, _) = NativeBuilder.jobOutcome("ouch\nLIMAN_JOB_EXIT_2")
        assertTrue(done2); assertEquals(2, code2)
        val (done3, _, _) = NativeBuilder.jobOutcome("still compiling")
        assertFalse(done3)
        // success marker alone (belt & braces if the trap somehow missed)
        val (done4, _, _) = NativeBuilder.jobOutcome("LIMAN_NATIVE_SETUP_OK")
        assertTrue(done4)
    }

    @Test fun jobOutcomeTakesLastExitMarker() {
        val (done, code, _) = NativeBuilder.jobOutcome("LIMAN_JOB_EXIT_0\nsomething\nLIMAN_JOB_EXIT_1")
        assertTrue(done); assertEquals(1, code)
    }
}
