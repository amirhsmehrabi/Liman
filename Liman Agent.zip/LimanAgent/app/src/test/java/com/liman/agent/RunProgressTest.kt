package com.liman.agent

import com.liman.agent.agent.RunProgress
import com.liman.agent.llm.ToolCallData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v2.34 — THE PROGRESS AUDITOR: repetition / stall / chatter detection that
 *  forces the agent to act differently or ask the user immediately. */
class RunProgressTest {

    private fun call(name: String, args: String = "{}") = ToolCallData(id = "c1", name = name, argsJson = args)

    @Test fun `identical repeated calls are detected after two cycles`() {
        val p = RunProgress()
        val r1 = p.record(1, listOf(call("read_file", """{"name":"a.txt"}""")), "")
        assertFalse("first occurrence is new", r1.repeatedAll)
        p.record(2, listOf(call("read_file", """{"name":"a.txt"}""")), "")
        val r3 = p.record(3, listOf(call("read_file", """{"name":"a.txt"}""")), "")
        assertTrue("third identical call = repeating", r3.repeatedAll && p.isRepeating)
        assertTrue("directive fires", p.needsDirective(12, 3))
        assertTrue("directive demands ask_user",
            p.directive(12, 3).contains("ask_user") && p.directive(12, 3).contains("REPEATING"))
    }

    @Test fun `different args are not repeats`() {
        val p = RunProgress()
        p.record(1, listOf(call("read_file", """{"name":"a.txt"}""")), "")
        val r2 = p.record(2, listOf(call("read_file", """{"name":"b.txt"}""")), "")
        assertFalse(r2.repeatedAll)
        assertFalse(p.isRepeating)
    }

    @Test fun `read-only cycles stall the run`() {
        val p = RunProgress()
        p.record(1, listOf(call("list_files")), "")
        p.record(2, listOf(call("search_code", """{"pattern":"x"}""")), "")
        p.record(3, listOf(call("repo_map")), "")
        assertTrue("3 cycles without mutation = stalled", p.isStalled)
        val d = p.directive(12, 3)
        assertTrue(d.contains("state-changing") || d.contains("execution is overdue"))
    }

    @Test fun `a mutating call resets the stall counter`() {
        val p = RunProgress()
        p.record(1, listOf(call("list_files")), "")
        p.record(2, listOf(call("read_file", """{"name":"a"}""")), "")
        p.record(3, listOf(call("write_file", """{"name":"a","content":"x"}""")), "")
        assertFalse(p.isStalled)
        assertEquals(1, p.record(3, listOf(call("write_file")), "").mutating)
    }

    @Test fun `long prose with no tools is chatter`() {
        val p = RunProgress()
        val essay = "x".repeat(1500)
        p.record(1, emptyList(), essay)
        p.record(2, emptyList(), essay)
        assertTrue(p.isChatty)
        assertTrue(p.directive(12, 2).contains("writing long prose"))
    }

    @Test fun `directives are capped at three per run`() {
        val p = RunProgress()
        repeat(5) { c ->
            p.record(c + 1, listOf(call("read_file", """{"name":"same"}""")), "")
            if (p.needsDirective(12, c + 1)) p.directive(12, c + 1)
        }
        assertEquals("max 3 injections", 3, p.directivesUsed)
        assertFalse(p.needsDirective(12, 5))
    }

    @Test fun `cycle budget pressure fires near the cap without mutation`() {
        val p = RunProgress()
        // healthy acting cycles — no directive
        (1..7).forEach { c ->
            p.record(c, listOf(call("write_file", """{"name":"f$c"}""")), "")
            if (p.needsDirective(10, c)) p.directive(10, c)
        }
        // two idle cycles at 80% of budget → converge-now pressure
        p.record(8, listOf(call("list_files")), "")
        p.record(9, listOf(call("list_files")), "")
        assertTrue("budget pressure near cap", p.needsDirective(10, 9))
        assertTrue(p.directive(10, 9).contains("CYCLE BUDGET"))
    }

    @Test fun `mutating tool list covers the state changers`() {
        val p = RunProgress()
        assertTrue("write_file mutates", "write_file" in p.mutatingTools)
        assertTrue("http_request mutates", "http_request" in p.mutatingTools)
        assertFalse("read_file does not", "read_file" in p.mutatingTools)
        assertFalse("search_code does not", "search_code" in p.mutatingTools)
    }
}
