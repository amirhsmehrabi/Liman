package com.liman.agent

import com.liman.agent.data.PriceBook
import com.liman.agent.data.UsageStore
import com.liman.agent.data.fmtUsd
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/**
 * v2.15.0 — CREDIT METER.
 *
 * The user needs to control credit spend themselves: "show how much credit I
 * used at all and in each combo and each provider and each model". These
 * tests pin the data layer: cost estimation (never guessed for unknown
 * models), aggregation per provider/model/chat/day, persistence, and
 * readable USD formatting for tiny amounts.
 */
class UsageTest {

    // ---------- PriceBook ----------

    @Test
    fun knownModelsArePriced() {
        assertEquals(0.10, PriceBook.priceFor("gemini-2.0-flash")!!.inPer1M, 1e-9)
        assertEquals(2.50, PriceBook.priceFor("gpt-4o")!!.inPer1M, 1e-9)
        assertEquals(0.15, PriceBook.priceFor("gpt-4o-mini")!!.inPer1M, 1e-9)
        assertEquals(3.0, PriceBook.priceFor("claude-sonnet-4-20250514")!!.inPer1M, 1e-9)
        assertEquals(0.27, PriceBook.priceFor("deepseek-chat")!!.inPer1M, 1e-9)
        // models/ prefix and case must not matter
        assertEquals(0.10, PriceBook.priceFor("models/Gemini-2.0-Flash")!!.inPer1M, 1e-9)
    }

    @Test
    fun freeAndUnknownModelsAreNeverGuessed() {
        assertEquals(0.0, PriceBook.priceFor("llama-3.3-70b:free")!!.inPer1M, 1e-9)
        assertNull(PriceBook.priceFor("totally-unknown-model"))
        assertNull(PriceBook.costMicroUsd("totally-unknown-model", 1000, 1000))
    }

    @Test
    fun costMathIsExact() {
        // 1M input tokens of gemini-2.0-flash = $0.10 = 100_000 micro-USD
        assertEquals(100_000L, PriceBook.costMicroUsd("gemini-2.0-flash", 1_000_000, 0))
        // 500k in + 1M out of gpt-4o = 0.5*2.50 + 1*10 = $11.25
        assertEquals(11_250_000L, PriceBook.costMicroUsd("gpt-4o", 500_000, 1_000_000))
        // free model → $0
        assertEquals(0L, PriceBook.costMicroUsd("llama-3.3-70b:free", 123_456, 654_321))
    }

    // ---------- UsageStore aggregation + persistence ----------

    @get:Rule
    val tmp = TemporaryFolder()

    private fun store() = UsageStore(tmp.newFile())

    @Test
    fun recordsAggregatePerProviderModelChatAndDay() {
        val s = store()
        s.record("chat1", "Deploy worker", "Gemini", "gemini-2.0-flash", 10_000, 2_000)
        s.record("chat1", "Deploy worker", "Gemini", "gemini-2.0-flash", 30_000, 0)
        s.record("chat2", "Other task", "DeepSeek", "deepseek-chat", 100_000, 50_000)

        val st = s.state.value
        assertEquals(3, st.total.requests)
        assertEquals(140_000L, st.total.inTok)
        assertEquals(52_000L, st.total.outTok)
        // 40k in + 2k out of 2.0-flash = 0.1*0.04 + 0.4*0.002 = $0.0048
        assertEquals(4_800L, st.byProvider["Gemini"]!!.costMicroUsd)
        // deepseek: 0.1*0.27 + 0.05*1.10 = $0.082
        assertEquals(82_000L, st.byProvider["DeepSeek"]!!.costMicroUsd)
        assertTrue(st.byModel.containsKey("Gemini|gemini-2.0-flash"))
        assertEquals(2, st.byChat["chat1"]!!.requests)
        assertEquals(1, st.byChat["chat2"]!!.requests)
        assertEquals("Deploy worker", st.chatTitles["chat1"])
        assertEquals(3, st.byDay.values.sumOf { it.requests })
        // totals reconcile
        assertEquals(
            st.byProvider.values.sumOf { it.costMicroUsd },
            st.total.costMicroUsd
        )
    }

    @Test
    fun unknownModelCostsZeroButCounts() {
        val s = store()
        s.record("c", "t", "MyLocal", "custom-model-7b", 5_000, 5_000)
        val st = s.state.value
        assertEquals(1, st.total.requests)
        assertEquals(0L, st.total.costMicroUsd)
        assertEquals(10_000L, st.total.inTok + st.total.outTok)
    }

    @Test
    fun persistsAcrossReload() {
        val f = tmp.newFile()
        val s1 = UsageStore(f)
        s1.record("chat1", "Title", "Gemini", "gemini-2.0-flash", 10_000, 2_000)
        val s2 = UsageStore(f) // fresh instance reads the same file
        assertEquals(1, s2.state.value.total.requests)
        // 10k in × $0.10 + 2k out × $0.40 = $0.0018
        assertEquals(1_800L, s2.state.value.total.costMicroUsd)
        assertEquals("Title", s2.state.value.chatTitles["chat1"])
    }

    @Test
    fun resetClearsEverything() {
        val s = store()
        s.record("chat1", "T", "P", "m", 1, 1)
        s.reset()
        assertEquals(0L, s.state.value.total.requests)
        assertTrue(s.state.value.byProvider.isEmpty())
    }

    // ---------- formatting ----------

    @Test
    fun fmtUsdIsReadableAtTinyScales() {
        assertEquals("$0", fmtUsd(0))
        assertEquals("$0.0048", fmtUsd(4_800))
        assertEquals("$0.082", fmtUsd(82_000))
        assertEquals("$1.2345", fmtUsd(1_234_500))
        assertEquals("$19", fmtUsd(19_000_000))
    }
}
