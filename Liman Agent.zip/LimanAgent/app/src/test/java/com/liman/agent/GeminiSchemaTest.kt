package com.liman.agent

import com.liman.agent.llm.GeminiSchema
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * GeminiSchema — the fix for "Invalid JSON payload received. Unknown name …":
 * tool schemas are rewritten into Gemini's accepted subset.
 */
class GeminiSchemaTest {

    private fun sanitize(json: String): JsonObject =
        GeminiSchema.sanitize(Json.parseToJsonElement(json) as JsonObject)

    @Test
    fun `unsupported keys are stripped`() {
        val out = sanitize(
            """{"type":"object","title":"T","default":{},"additionalProperties":false,
               "properties":{"path":{"type":"string","minLength":1,"pattern":"^x"}},
               "required":["path"]}"""
        )
        val s = out.toString()
        assertFalse(s.contains("additionalProperties"))
        assertFalse(s.contains("${'$'}schema"))
        assertFalse(s.contains("default"))
        assertFalse(s.contains("title"))
        assertTrue(out.containsKey("type"))
        val props = out["properties"] as JsonObject
        val path = props["path"] as JsonObject
        assertEquals("string", (path["type"] as kotlinx.serialization.json.JsonPrimitive).content)
        assertFalse(path.containsKey("minLength"))
    }

    @Test
    fun `openai-style nullable type arrays collapse`() {
        val out = sanitize("""{"type":["string","null"],"description":"x"}""")
        assertEquals("string", (out["type"] as kotlinx.serialization.json.JsonPrimitive).content)
    }

    @Test
    fun `property without type gets a default type`() {
        val out = sanitize("""{"type":"object","properties":{"a":{"description":"no type"}}}""")
        val a = (out["properties"] as JsonObject)["a"] as JsonObject
        assertEquals("string", (a["type"] as kotlinx.serialization.json.JsonPrimitive).content)
    }

    @Test
    fun `arrays get sanitized items`() {
        val out = sanitize(
            """{"type":"array","items":{"type":"object","properties":{
               "n":{"type":["integer","null"]}},"additionalProperties":false}}"""
        )
        val items = out["items"] as JsonObject
        val props = items["properties"] as JsonObject
        val n = props["n"] as JsonObject
        assertEquals("integer", (n["type"] as kotlinx.serialization.json.JsonPrimitive).content)
        assertFalse(items.containsKey("additionalProperties"))
    }

    @Test
    fun `type inference when missing`() {
        val out = sanitize("""{"properties":{"a":{"type":"string"}}}""")
        assertEquals("object", (out["type"] as kotlinx.serialization.json.JsonPrimitive).content)
        val arr = sanitize("""{"items":{"type":"string"}}""")
        assertEquals("array", (arr["type"] as kotlinx.serialization.json.JsonPrimitive).content)
    }

    @Test
    fun `already-clean schema passes through semantically`() {
        val out = sanitize(
            """{"type":"object","properties":{"q":{"type":"string","description":"query"},
               "n":{"type":"integer"}},"required":["q"]}"""
        )
        val props = out["properties"] as JsonObject
        assertEquals(2, props.size)
        assertTrue(out.containsKey("required"))
    }
}
