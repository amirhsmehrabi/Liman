package com.liman.agent

import com.liman.agent.agent.parseSkillMarkdown
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SkillsParserTest {

    @Test
    fun parsesFrontmatter() {
        val md = """
            ---
            name: pdf-report-writer
            description: Writes polished PDF reports from data
            ---
            # Instructions
            Always include a title page.
        """.trimIndent()
        val (name, desc, body) = parseSkillMarkdown(md)
        assertEquals("pdf-report-writer", name)
        assertEquals("Writes polished PDF reports from data", desc)
        assertTrue(body.contains("Always include a title page."))
        assertTrue(!body.contains("name:"))
    }

    @Test
    fun parsesQuotedFrontmatter() {
        val md = "---\nname: \"web scraper\"\ndescription: 'scrapes pages'\n---\nDo the thing."
        val (name, desc, body) = parseSkillMarkdown(md)
        assertEquals("web scraper", name)
        assertEquals("scrapes pages", desc)
        assertTrue(body.contains("Do the thing."))
    }

    @Test
    fun plainMarkdownFallsBackToEmptyMeta() {
        val md = "# Just instructions\nNo frontmatter here."
        val (name, desc, body) = parseSkillMarkdown(md)
        assertEquals("", name)
        assertEquals("", desc)
        assertTrue(body.contains("Just instructions"))
    }

    @Test
    fun dashDividerAtStartIsTolerated() {
        val md = "Title\n\n---\n\nBody text"
        val (_, _, body) = parseSkillMarkdown(md)
        assertTrue(body.isNotBlank())
    }
}
