package com.liman.agent

import com.liman.agent.agent.builtInToolSpecs
import com.liman.agent.llm.safeSchema
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Regression test for the v2.1 bug: the http_request spec contained
 * unescaped quotes in a description, making parametersJson invalid JSON —
 * which broke EVERY provider request ("Unexpected JSON token at offset 225:
 * Expected end of the object or comma at path: $").
 */
class ToolsSpecTest {

    /** Strict JSON parser: no leniency — exactly what a picky API would see. */
    private val strict = Json { }

    @Test
    fun allBuiltInSpecsAreStrictValidJson() {
        val specs = builtInToolSpecs()
        assertTrue("expected the built-in tool list to be non-empty", specs.isNotEmpty())
        specs.forEach { spec ->
            try {
                val parsed = strict.parseToJsonElement(spec.parametersJson).jsonObject
                assertTrue(
                    "spec ${spec.name}: root must be an object",
                    parsed.containsKey("type") || parsed.containsKey("properties")
                )
            } catch (e: Exception) {
                throw AssertionError(
                    "Tool '${spec.name}' has an INVALID parametersJson schema: ${e.message}"
                )
            }
        }
    }

    @Test
    fun toolNamesAreUnique() {
        val names = builtInToolSpecs().map { it.name }
        assertEquals("tool names must be unique", names.size, names.distinct().size)
    }

    @Test
    fun everySpecHasNameAndDescription() {
        builtInToolSpecs().forEach {
            assertTrue("empty name", it.name.isNotBlank())
            assertTrue("empty description for ${it.name}", it.description.isNotBlank())
        }
    }

    @Test
    fun safeSchemaFallsBackOnInvalidJson() {
        val broken = """{"type":"object","description":"oops {"unescaped":"quotes"}"}"""
        val safe = safeSchema(broken)
        assertTrue(safe is JsonObject)
        // fallback schema: type=object, properties={}
        assertEquals("object", (safe as JsonObject)["type"]?.let { (it as kotlinx.serialization.json.JsonPrimitive).content })
        assertTrue((safe["properties"] as? JsonObject)?.isEmpty() == true)
    }

    @Test
    fun safeSchemaPassesValidJsonThrough() {
        val valid = """{"type":"object","properties":{"url":{"type":"string"}}}"""
        val safe = safeSchema(valid)
        assertTrue((safe as JsonObject)["properties"] is JsonObject)
    }
}
