package com.liman.agent

import com.liman.agent.llm.RouterEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RouterEngine pure logic — RTK token saver behavior (the 9Router-style
 * compression applied to tool outputs passing through the local gateway).
 */
class RouterLogicTest {

    @Test
    fun `short text passes untouched`() {
        val t = "hello world"
        assertEquals(t, RouterEngine.rtk(t, "tool"))
    }

    @Test
    fun `ansi escapes are stripped always`() {
        val t = "\u001B[31mred text\u001B[0m"
        assertEquals("red text", RouterEngine.rtk(t, "assistant"))
    }

    @Test
    fun `long tool output is compressed head plus tail`() {
        val t = buildString { repeat(400) { appendLine("line $it of the tool output") } }
        val out = RouterEngine.rtk(t, "tool")
        assertTrue(out.length < t.length / 2)
        assertTrue(out.contains("RTK"))
        assertTrue(out.startsWith("line 0"))
        assertTrue(out.contains("line 399"))
    }

    @Test
    fun `assistant output is never compressed`() {
        val t = buildString { repeat(400) { appendLine("answer line $it") } }
        val out = RouterEngine.rtk(t, "assistant")
        assertEquals(t, out)
    }

    @Test
    fun `user long text is compressed too`() {
        val t = "x".repeat(5000)
        val out = RouterEngine.rtk(t, "user")
        assertTrue(out.length < 3000)
        assertTrue(out.contains("RTK"))
    }

    @Test
    fun `collapsed blank runs`() {
        val t = "a\n\n\n\n\nb"
        assertEquals("a\n\nb", RouterEngine.rtk(t, "tool"))
        assertFalse(RouterEngine.rtk(t, "tool").contains("\n\n\n"))
    }
}
