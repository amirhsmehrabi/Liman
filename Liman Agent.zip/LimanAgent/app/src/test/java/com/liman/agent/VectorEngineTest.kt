package com.liman.agent

import com.liman.agent.agent.VectorEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v2.31 — Creative Vector Engine: recipes + slop detector + validator. */
class VectorEngineTest {

    @Test fun `all recipes run and emit valid svg`() {
        VectorEngine.recipeIds().forEach { id ->
            val r = VectorEngine.runRecipe(id, mapOf("seed" to "42", "values" to "4,8,15,16,23"))
            assertNotNull("recipe $id returned null", r)
            val svg = r!!.svg
            assertTrue("$id missing svg root", svg.contains("<svg"))
            assertTrue("$id missing viewBox", svg.contains("viewBox=\""))
            assertTrue("$id must not use raw filters", !svg.contains("<filter"))
            assertTrue("$id meta comment missing", svg.contains("_meta"))
            // determinism: same seed → identical output
            val r2 = VectorEngine.runRecipe(id, mapOf("seed" to "42", "values" to "4,8,15,16,23"))
            assertEquals("$id not reproducible", svg, r2!!.svg)
        }
    }

    @Test fun `different seeds give different art`() {
        val a = VectorEngine.runRecipe("pattern/truchet", mapOf("seed" to "1"))!!
        val b = VectorEngine.runRecipe("pattern/truchet", mapOf("seed" to "2"))!!
        assertNotEquals(a.svg, b.svg)
    }

    @Test fun `charts take real data`() {
        val bar = VectorEngine.runRecipe("data/chart-bar", mapOf("values" to "5,10,7"))!!
        assertTrue(bar.svg.contains("fill"))
        val line = VectorEngine.runRecipe("data/chart-line", mapOf("values" to "1,2,3,2"))!!
        assertTrue(line.svg.contains("stroke"))
        val donut = VectorEngine.runRecipe("data/chart-donut", mapOf("values" to "30,70"))!!
        assertTrue(donut.svg.contains("A"))
        assertEquals(null, VectorEngine.runRecipe("data/chart-bar", mapOf("values" to "1")))
    }

    @Test fun `precision is capped at two decimals`() {
        val r = VectorEngine.runRecipe("shape/superformula", mapOf("m" to "7", "n1" to "0.3", "n2" to "0.5", "n3" to "0.7"))!!
        assertTrue("3-decimal coordinates leaked", Regex("""\d+\.\d{3,}""").findAll(r.svg.replace("_meta", "")).count() == 0)
    }

    // ---------------- slop detector ----------------

    @Test fun `cliche palette is flagged`() {
        val slop = "<svg viewBox=\"0 0 100 100\"><rect fill=\"#6366F1\"/><rect fill=\"#8B5CF6\"/><rect fill=\"#EC4899\"/></svg>"
        val r = VectorEngine.slopScore(slop)
        assertTrue(r.hits.any { it.rule == "palette_cliche" })
        assertEquals("slop", r.verdict)
    }

    @Test fun `blob background is flagged`() {
        val slop = "<svg viewBox=\"0 0 800 600\"><ellipse filter=\"blur(60px)\"/><ellipse filter=\"blur(70px)\"/></svg>"
        val r = VectorEngine.slopScore(slop)
        assertTrue(r.hits.any { it.rule == "blob_bg" })
    }

    @Test fun `hand-emitted precision noise is flagged`() {
        val noisy = StringBuilder("<svg viewBox=\"0 0 24 24\"><path d=\"")
        repeat(40) { noisy.append("M12.123456 3.098765 L13.234567 4.198765 ") }
        noisy.append("\"/></svg>")
        val r = VectorEngine.slopScore(noisy.toString())
        assertTrue(r.hits.any { it.rule == "precision_noise" || it.rule == "viewbox_fit" })
    }

    @Test fun `script in svg is a blocking hit`() {
        val evil = "<svg viewBox=\"0 0 10 10\"><script>alert(1)</script><path d=\"M1 1\"/></svg>"
        val r = VectorEngine.slopScore(evil)
        assertTrue(r.hits.any { it.rule == "security" && it.severity == "block" })
        assertEquals("slop", r.verdict)
    }

    @Test fun `a clean recipe icon scores clean`() {
        val r = VectorEngine.runRecipe("shape/superformula", mapOf("m" to "6", "n1" to "1"))!!
        val report = VectorEngine.slopScore(r.svg)
        assertTrue("clean recipe flagged: ${report.hits}", report.verdict == "clean" || report.verdict == "minor")
        assertTrue(report.score < 20)
    }

    @Test fun `report text carries fixes and next action`() {
        val r = VectorEngine.slopScore("<svg viewBox=\"0 0 10 10\"><rect fill=\"#6366F1\"/><rect fill=\"#8B5CF6\"/></svg>")
        val txt = VectorEngine.slopReportText(r)
        assertTrue(txt.contains("SLOP SCORE"))
        assertTrue(txt.contains("fix:"))
        assertTrue(txt.contains("next:"))
    }

    // ---------------- validator ----------------

    @Test fun `validator catches malformed path data`() {
        val bad = "<svg viewBox=\"0 0 24 24\"><path d=\"M1 2 C 3\"/></svg>"
        val v = VectorEngine.validate(bad)
        assertTrue(!v.ok)
        assertTrue(v.errors.any { it.contains("C") && it.contains("args") })
    }

    @Test fun `validator catches zero-radius arc as warning`() {
        val v = VectorEngine.validate("<svg viewBox=\"0 0 24 24\"><path d=\"M0 0 A0 0 0 0 1 5 5\"/></svg>")
        assertTrue(v.warnings.any { it.contains("zero radius") })
    }

    @Test fun `validator android-vd bans text and filters`() {
        val svg = "<svg viewBox=\"0 0 24 24\"><text>hi</text></svg>"
        val v = VectorEngine.validate(svg, "android-vd")
        assertTrue(v.errors.any { it.contains("text") })
        val v2 = VectorEngine.validate("<svg viewBox=\"0 0 24 24\"><filter id=\"f\"/></svg>", "android-vd")
        assertTrue(v2.errors.any { it.contains("filter") })
    }

    @Test fun `validator accepts recipe output`() {
        val r = VectorEngine.runRecipe("shape/blob-organic", mapOf("seed" to "9"))!!
        val v = VectorEngine.validate(r.svg)
        assertTrue(v.errors.isEmpty())
    }

    @Test fun `sanitize strips dangerous svg`() {
        assertEquals(null, VectorEngine.sanitize("<svg><script>x</script></svg>"))
        assertEquals(null, VectorEngine.sanitize("<svg onload=\"x()\">"))
        val clean = VectorEngine.sanitize("<svg xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M0 0\"/></svg>")
        assertTrue(clean != null && clean.contains("<path"))
    }

    @Test fun `protocol and direction contract exist`() {
        assertTrue(VectorEngine.protocol().contains("INTENT"))
        assertTrue(VectorEngine.protocol().contains("RULE 0"))
        assertTrue(VectorEngine.directionContract().contains("four questions", ignoreCase = true))
        assertTrue(VectorEngine.directionContract().contains("motif"))
    }
}
