package com.liman.agent

import com.liman.agent.agent.HeroMode
import com.liman.agent.agent.TextToolCalls
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.14.0 — HERO MODE.
 *
 * The user's report: "I asked it to use my Cloudflare tokens and put workers
 * on my account; it said OK I WILL — and nothing happened." The loop accepted
 * all-talk replies as the final answer. These tests pin the two fixes:
 * force-action detection (never accept announced-intent / advice-only
 * replies on command tasks) and text-protocol tool-call rescue for models
 * that write calls as JSON instead of native function calls.
 */
class HeroModeTest {

    private val cfTask =
        "use my cloudflare tokens and connect to my account and write some workers and put them there"

    // ---------- the exact reported failure ----------

    @Test
    fun announcedActionIsRejected() {
        val reply = "Ok! I will now connect to your Cloudflare account and deploy the workers for you."
        assertTrue(HeroMode.shouldForceAction(reply, cfTask, toolsCalledSoFar = 0, cycle = 1))
    }

    @Test
    fun announcedActionIsRejectedEvenAfterEarlierTools() {
        // mid-run stall: it did step 1, then announced step 2 and stopped
        val reply = "I've listed your zones. Now I will write the worker script and deploy it."
        assertTrue(HeroMode.shouldForceAction(reply, cfTask, toolsCalledSoFar = 3, cycle = 5))
    }

    @Test
    fun lazyFinishSummaryIsRejected() {
        val summary = "Sure — I will set up the worker for you and upload it to your account."
        assertTrue(HeroMode.shouldForceAction(summary, cfTask, toolsCalledSoFar = 0, cycle = 1))
    }

    // ---------- advice / homework for the user ----------

    @Test
    fun adviceInsteadOfActionIsRejected() {
        val reply = "You should go to dash.cloudflare.com, open Workers & Pages and click Create. " +
            "Step 1: log in to your account. Step 2: paste the code."
        assertTrue(HeroMode.shouldForceAction(reply, cfTask, toolsCalledSoFar = 0, cycle = 1))
    }

    @Test
    fun persianAdviceIsRejected() {
        val reply = "شما باید خودت به داشبورد کلادفلر بروی و روی دکمه Create Worker کلیک کنی تا وارکر ساخته شود."
        assertTrue(HeroMode.shouldForceAction(reply, cfTask, toolsCalledSoFar = 0, cycle = 1))
    }

    @Test
    fun persianAnnouncementIsRejected() {
        val reply = "باشه، الان حساب کلادفلر تو را وصل می‌کنم و وارکرها را می‌سازم."
        assertTrue(HeroMode.shouldForceAction(reply, cfTask, toolsCalledSoFar = 0, cycle = 1))
    }

    // ---------- legitimate replies must finish normally ----------

    @Test
    fun honestSummaryWithProofIsAccepted() {
        val reply = "Done. I deployed the worker 'my-api' (PUT /workers/scripts/my-api → 200), " +
            "then verified GET https://my-api.workers.dev returns 'hello' (HTTP 200). Script saved at worker.js."
        assertFalse(HeroMode.shouldForceAction(reply, cfTask, toolsCalledSoFar = 4, cycle = 6))
    }

    @Test
    fun questionToUserIsAccepted() {
        val reply = "Which Cloudflare token should I use — the Account API token or the Global API key?"
        assertFalse(HeroMode.shouldForceAction(reply, cfTask, toolsCalledSoFar = 0, cycle = 1))
    }

    @Test
    fun persianQuestionIsAccepted() {
        val reply = "کدام توکن کلادفلر را استفاده کنم؟"
        assertFalse(HeroMode.shouldForceAction(reply, cfTask, toolsCalledSoFar = 0, cycle = 1))
    }

    @Test
    fun pureAnswerToNonTaskQuestionIsAccepted() {
        // no command verbs in the request → never force
        val reply = "The capital of Iran is Tehran."
        assertFalse(HeroMode.shouldForceAction(reply, "what is the capital of iran?", toolsCalledSoFar = 0, cycle = 1))
    }

    @Test
    fun explanationWallOnCommandTaskIsRejected() {
        // "it just generates" — 0 tools, first cycle, a wall of prose on a command task
        val wall = buildString {
            append("A Cloudflare Worker is a serverless compute platform. ")
            repeat(30) { append("It runs JavaScript at the edge of Cloudflare's network near your users. ") }
        }
        assertTrue(HeroMode.shouldForceAction(wall, cfTask, toolsCalledSoFar = 0, cycle = 1))
    }

    @Test
    fun pureWritingTaskIsNotTrappedForever() {
        // "write a story" → model returns the story with no tools; that's
        // legitimate. Cycle 2+ (after one honest chance) must accept it.
        val story = "Once upon a time in a quiet harbor town, there lived a small orange boat named Liman. " +
            "Every morning it carried fresh bread to the island. " +
            "The villagers loved Liman because it never gave up, even in storms. THE END."
        assertFalse(HeroMode.shouldForceAction(story, "write me a short story", toolsCalledSoFar = 0, cycle = 2))
    }

    // ---------- nudge text ----------

    @Test
    fun nudgeTellsModelHowToActuallyAct() {
        val n = HeroMode.nudge(1)
        assertTrue(n.contains("http_request"))
        assertTrue(n.contains("Cloudflare"))     // concrete deploy example
        assertTrue(n.contains("run_code"))
        assertTrue(n.contains("ask_user"))
        assertTrue(n.contains("verify") || n.contains("VERIFY"))
    }
}

class TextToolCallsTest {

    private val known = setOf("http_request", "write_file", "run_code", "finish", "ask_user")

    @Test
    fun rescuesFencedOpenAiStyleCall() {
        val text = """
            I'll fetch your Cloudflare account details now.
            ```json
            {"name": "http_request", "arguments": {"url": "https://api.cloudflare.com/client/v4/user/tokens/verify", "method": "GET", "headers": {"Authorization": "Bearer xyz"}}}
            ```
        """.trimIndent()
        val calls = TextToolCalls.parse(text, known)
        assertEquals(1, calls.size)
        assertEquals("http_request", calls[0].first)
        assertTrue(calls[0].second.contains("api.cloudflare.com"))
    }

    @Test
    fun rescuesActionStyleCall() {
        val text = """Let me check: {"http_request": {"url": "https://example.com/api", "method": "POST"}} ok?"""
        val calls = TextToolCalls.parse(text, known)
        assertEquals(1, calls.size)
        assertEquals("http_request", calls[0].first)
        assertTrue(calls[0].second.contains("example.com"))
    }

    @Test
    fun rescuesArgsAsJsonString() {
        val text = """{"tool": "write_file", "args": "{\"name\": \"worker.js\", \"content\": \"export default {}\"}"}"""
        val calls = TextToolCalls.parse(text, known)
        assertEquals(1, calls.size)
        assertEquals("write_file", calls[0].first)
        assertTrue(calls[0].second.contains("worker.js"))
    }

    @Test
    fun unknownToolIsIgnored() {
        val text = """{"name": "delete_everything", "arguments": {"x": 1}}"""
        assertTrue(TextToolCalls.parse(text, known).isEmpty())
    }

    @Test
    fun plainDataJsonIsNotExecuted() {
        // JSON shown as DATA (unknown keys, no tool name) must never run
        val text = """The API returned {"result": {"url": "https://example.com", "status": "ok"}} as expected."""
        assertTrue(TextToolCalls.parse(text, known).isEmpty())
    }

    @Test
    fun noJsonIsEmpty() {
        assertTrue(TextToolCalls.parse("I will deploy it right away, trust me!", known).isEmpty())
    }

    @Test
    fun multipleBlocksAreAllRescued() {
        val text = """
            First save the script:
            ```json
            {"name": "write_file", "arguments": {"name": "w.js", "content": "x"}}
            ```
            Then deploy it:
            ```json
            {"name": "http_request", "arguments": {"url": "https://api.cloudflare.com/deploy", "method": "PUT"}}
            ```
        """.trimIndent()
        val calls = TextToolCalls.parse(text, known)
        assertEquals(2, calls.size)
        assertEquals("write_file", calls[0].first)
        assertEquals("http_request", calls[1].first)
    }

    @Test
    fun unbalancedJsonDoesNotHangOrCrash() {
        val text = """{"name": "http_request", "arguments": {"url": "https://x""""
        assertTrue(TextToolCalls.parse(text, known).isEmpty())
    }
}
