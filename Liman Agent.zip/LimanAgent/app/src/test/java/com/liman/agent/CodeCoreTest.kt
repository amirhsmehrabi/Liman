package com.liman.agent

import com.liman.agent.agent.CodeCore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/** v2.32 — THE CODING AGENT CORE: search, repo map, patch, snapshots,
 *  web sessions, code checks — the six engines that make Liman a real coder. */
class CodeCoreTest {

    @get:Rule
    val tmp = TemporaryFolder()

    private fun proj(): File {
        val root = tmp.newFolder("proj")
        File(root, "node_modules/junk.js").apply { parentFile.mkdirs(); writeText("login here\n") }
        File(root, "src").mkdirs()
        File(root, "src/Auth.kt").writeText(
            "package p\nimport kotlinx.serialization.json.Json\n" +
                "class AuthService(val api: String) {\n" +
                "  fun login(user: String): String = api + user\n" +
                "  fun logout() = Unit\n" +
                "}\n"
        )
        File(root, "src/main.py").writeText(
            "def login(user):\n    return user\n\nclass Session:\n    pass\n"
        )
        File(root, "src/util.js").writeText("function login() { return 1 }\nconst x = 2;\n")
        File(root, "README.md").writeText("# proj\nDocs mention login too.\n")
        return root
    }

    // ---------------- search_code ----------------

    @Test fun `search finds matches with file and line and skips junk dirs`() {
        val hits = CodeCore.search(proj(), "log(in|out)")
        val files = hits.map { it.file }.toSet()
        assertTrue("finds src files", files.containsAll(listOf("src/Auth.kt", "src/main.py", "src/util.js", "README.md")))
        assertFalse("node_modules skipped", files.any { it.startsWith("node_modules") })
        assertTrue("1-based lines", hits.first().line >= 1)
    }

    @Test fun `search honors the glob filter`() {
        val hits = CodeCore.search(proj(), "login", glob = "*.kt")
        assertEquals(listOf("src/Auth.kt"), hits.map { it.file }.toSet().toList())
    }

    @Test fun `search context lines surround the hit`() {
        val hits = CodeCore.search(proj(), "Docs mention", contextLines = 1)
        assertEquals(1, hits.size)
        assertTrue("context included", hits[0].context.size >= 1)
    }

    // ---------------- repo_map ----------------

    @Test fun `repo map lists files with symbols and languages`() {
        val map = CodeCore.repoMap(proj())
        assertTrue("kt file present", map.contains("src/Auth.kt"))
        assertTrue("py file present", map.contains("src/main.py"))
        assertTrue("class symbol with line", map.contains("class AuthService") && map.contains("(L"))
        assertTrue("function symbol", map.contains("fn login"))
        assertTrue("language tag", map.contains("[kotlin"))
        assertTrue("python defs too", map.contains("def login") || map.contains("fn login") && map.contains("[python"))
    }

    @Test fun `repo map ranks referenced files above orphans`() {
        // README references nothing; Auth.kt is imported/mentioned by ranking heuristics —
        // at minimum the ranked section exists and mentions files by name.
        val map = CodeCore.repoMap(proj())
        assertTrue("has a ranking header", map.contains("REPO MAP") && map.contains("importance"))
    }

    @Test fun `repo map caps files and never crashes on empty dir`() {
        val empty = tmp.newFolder("empty")
        val map = CodeCore.repoMap(empty)
        assertTrue(map.isNotBlank())
    }

    // ---------------- patch ----------------

    @Test fun `patch applies multiple ops across files atomically with report`() {
        val root = proj()
        val results = CodeCore.applyPatch(
            root,
            listOf(
                CodeCore.PatchOp("src/Auth.kt", "fun login(user: String): String = api + user", "fun signIn(user: String): String = api + user", false),
                CodeCore.PatchOp("src/util.js", "function login()", "function signin()", false)
            )
        )
        assertTrue("both ops ok", results.all { it.error == null })
        val auth = File(root, "src/Auth.kt").readText()
        assertTrue(auth.contains("signIn"))
        assertFalse(auth.contains("fun login(user"))
        assertTrue(File(root, "src/util.js").readText().contains("function signin()"))
        assertTrue("report lists files", CodeCore.patchReport(results).contains("src/Auth.kt"))
    }

    @Test fun `patch is all-or-first and reports not-found honestly`() {
        val root = proj()
        val results = CodeCore.applyPatch(
            root,
            listOf(CodeCore.PatchOp("src/Auth.kt", "Unit", "DONE", all = true))
        )
        assertEquals(1, results.size)
        assertTrue(results[0].applied >= 1)
        // now a missing find
        val miss = CodeCore.applyPatch(root, listOf(CodeCore.PatchOp("src/Auth.kt", "NO_SUCH_TOKEN", "x", false)))
        assertTrue("missing find is an error", miss[0].error != null)
        // outside sandbox rejected
        val escape = CodeCore.applyPatch(root, listOf(CodeCore.PatchOp("../outside.txt", "a", "b", false)))
        assertTrue("sandbox escape blocked", escape[0].error != null)
    }

    // ---------------- snapshots ----------------

    @Test fun `snapshot create diff restore round trip`() {
        val root = proj()
        val (name, count) = CodeCore.Snapshots.create(root, "baseline")
        assertTrue("snapshot named", name.isNotBlank())
        assertTrue("files captured", count >= 4)

        // mutate the tree
        File(root, "src/Auth.kt").writeText("changed content\n")
        File(root, "src/NEW.md").writeText("new file\n")
        File(root, "README.md").delete()

        val diff = CodeCore.Snapshots.diff(root, name)
        assertTrue("diff sees modification", diff.contains("Auth.kt"))
        assertTrue("diff sees addition", diff.contains("NEW.md"))
        assertTrue("diff sees deletion", diff.contains("README.md"))

        val report = CodeCore.Snapshots.restore(root, name)
        assertTrue("restore reports success", report.lowercase().contains("restored"))
        assertEquals("content back to baseline", "changed content\n" != File(root, "src/Auth.kt").readText(), true)
        assertTrue("file restored", File(root, "README.md").exists())
        assertFalse("added file removed", File(root, "src/NEW.md").exists())
        // restore made its own safety snapshot
        assertTrue("pre-restore backup exists", CodeCore.Snapshots.list(root).any { it != name })
    }

    @Test fun `snapshot list is newest first and excludes snapshot dir from captures`() {
        val root = proj()
        val (n1, c1) = CodeCore.Snapshots.create(root, "first")
        val (n2, _) = CodeCore.Snapshots.create(root, "second")
        val list = CodeCore.Snapshots.list(root)
        assertTrue("newest first", list.indexOf(n2) < list.indexOf(n1))
        val (_, c3) = CodeCore.Snapshots.create(root, "third")
        assertEquals("snapshot dir not self-captured", c1, c3)
    }

    // ---------------- web sessions ----------------

    @Test fun `web sessions record cookies parse and rebuild cookie header`() {
        val ws = tmp.newFolder("ws")
        CodeCore.WebSessions.clear(null)
        CodeCore.WebSessions.record(
            "site", "https://example.com/login",
            listOf("sid=abc123; Path=/; HttpOnly", "theme=dark; Max-Age=3600")
        )
        CodeCore.WebSessions.save(ws)

        // fresh load from disk (persistence proof)
        CodeCore.WebSessions.clear(null)
        CodeCore.WebSessions.load(ws)
        assertEquals(listOf("site"), CodeCore.WebSessions.list())
        val header = CodeCore.WebSessions.cookieHeader("site", "https://example.com/api/data")
        assertTrue("cookie name=value pair kept", header.contains("sid=abc123"))
        assertTrue("second cookie kept", header.contains("theme=dark"))
        assertFalse("no cookie artifacts", header.contains("Path=") || header.contains("HttpOnly"))
    }

    @Test fun `web sessions clear one or all`() {
        val ws = tmp.newFolder("ws2")
        CodeCore.WebSessions.clear(null)
        CodeCore.WebSessions.record("a", "https://a.com/", listOf("x=1"))
        CodeCore.WebSessions.record("b", "https://b.com/", listOf("y=2"))
        CodeCore.WebSessions.clear("a")
        assertEquals(listOf("b"), CodeCore.WebSessions.list())
        CodeCore.WebSessions.clear(null)
        assertTrue(CodeCore.WebSessions.list().isEmpty())
    }

    // ---------------- code_check ----------------

    @Test fun `structural check catches unbalanced braces and strings`() {
        val problems = CodeCore.CodeCheck.structuralCheck("fun a() { if (x) { return 1 }")
        assertTrue("missing brace caught", problems.any { it.contains("brace") || it.contains("{") })
        val ok = CodeCore.CodeCheck.structuralCheck("fun a() { if (x) { return 1 } } // done")
        assertTrue("balanced code passes", ok.isEmpty())
        val strBad = CodeCore.CodeCheck.structuralCheck("val s = \"unterminated")
        assertTrue("unterminated string caught", strBad.isNotEmpty())
    }

    @Test fun `json check validates and reports errors`() {
        assertNullish(CodeCore.CodeCheck.jsonCheck("""{"a": 1}"""), true)
        assertNullish(CodeCore.CodeCheck.jsonCheck("""{"a": }"""), false)
    }

    @Test fun `python indent check catches inconsistent tabs`() {
        val bad = "def f():\n\tif x:\n        return 1\n"
        assertTrue(CodeCore.CodeCheck.pythonIndentCheck(bad).isNotEmpty())
        val ok = "def f():\n    if x:\n        return 1\n"
        assertTrue(CodeCore.CodeCheck.pythonIndentCheck(ok).isEmpty())
    }

    private fun assertNullish(msg: String?, shouldBeNull: Boolean) {
        if (shouldBeNull) assertEquals(null, msg)
        else assertTrue("expected an error message", msg != null)
    }
}
