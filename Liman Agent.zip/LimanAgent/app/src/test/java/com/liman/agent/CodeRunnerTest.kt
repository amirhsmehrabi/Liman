package com.liman.agent

import com.liman.agent.agent.JsSandbox
import com.liman.agent.agent.NpmLite
import com.liman.agent.agent.OnlineRunner
import com.liman.agent.agent.ShellRunner
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.GZIPOutputStream

/**
 * v2.13 code-runner engines, verified LIVE:
 *  - JsSandbox: plain JS, npm require() against the real registry
 *  - ShellRunner: the real static busybox shipped in jniLibs (x86_64 runs on
 *    this JVM host too — it is fully static)
 *  - OnlineRunner: real paiza.io call (python3) — skipped when offline
 *  - NpmLite.TarReader: crafted .tgz round-trip (no network)
 */
class CodeRunnerTest {

    private fun ws(): File = createTempDir()

    // ---------------- TarReader (offline) ----------------

    @Test
    fun tarReaderExtractsUstarWithPaxAndLongNames() {
        fun header(name: String, size: Int, type: Int): ByteArray {
            val h = ByteArray(512)
            name.toByteArray().copyInto(h, 0)
            size.toString(8).padStart(11, '0').toByteArray().copyInto(h, 124)
            h[156] = type.toByte()          // '0' = file
            h[148] = 0; h[149] = 0; h[150] = 0; h[151] = 0   // fake checksum → ok
            return h
        }
        fun tar(entries: List<Pair<String, String>>): ByteArray {
            val out = ByteArrayOutputStream()
            for ((name, content) in entries) {
                out.write(header(name, content.length, '0'.code))
                val data = content.toByteArray()
                out.write(data)
                repeat((512 - data.size % 512) % 512) { out.write(0) }
            }
            repeat(1024) { out.write(0) }
            return out.toByteArray()
        }
        val gz = ByteArrayOutputStream().let {
            GZIPOutputStream(it).use { g -> g.write(tar(listOf(
                "package/package.json" to """{"name":"x","main":"lib/a.js"}""",
                "package/lib/a.js" to "module.exports = 41;",
                "package/skipme.node" to "binary junk"
            ))) }
            it.toByteArray()
        }

        val outDir = createTempDir()
        NpmLite.TarReader.extract(
            gzip = gz, outDir = outDir, stripPrefix = "package/",
            maxFileBytes = 1_000_000, maxTotalBytes = 2_000_000, maxFiles = 100
        )
        assertTrue(File(outDir, "package.json").isFile)
        assertEquals("module.exports = 41;", File(outDir, "lib/a.js").readText())
        assertFalse(".node blobs must be skipped", File(outDir, "skipme.node").exists())
    }

    // ---------------- JsSandbox ----------------

    @Test
    fun jsBasicsAndTimersWork() {
        val out = JsSandbox.run(
            """
            var acc = 0;
            for (var i = 1; i <= 4; i++) acc += i;
            print('sum=' + acc);
            setTimeout(function(){ print('tick1'); }, 0);
            setTimeout(function(){ print('tick2'); }, 10);
            print('sync-done');
            """.trimIndent(), 10_000
        )
        assertTrue(out.contains("sum=10"))
        assertTrue(out.contains("sync-done"))
        assertTrue("timers must drain after main script, got: [$out]", out.contains("tick1") && out.contains("tick2"))
    }

    @Test
    fun jsInfiniteLoopTimesOut() {
        val t0 = System.currentTimeMillis()
        val out = JsSandbox.run("while(true){}", 2_000)
        val dt = System.currentTimeMillis() - t0
        assertTrue(out.contains("timed out"))
        assertTrue("timeout must actually stop the script (took ${dt}ms)", dt < 15_000)
    }

    @Test
    fun jsProcessExitStopsScript() {
        val out = JsSandbox.run(
            """
            print('before');
            process.exit(3);
            print('never');
            """.trimIndent(), 5_000
        )
        assertTrue(out.contains("before"))
        assertTrue(out.contains("process.exit(3)"))
        assertFalse("code after exit must not run", out.contains("never"))
    }

    @Test
    fun jsNpmRequireDownloadsAndRunsRealPackage() {
        // LIVE test — downloads is-even (tiny, pure JS) from registry.npmjs.org
        val reachable = try {
            java.net.URL("https://registry.npmjs.org/is-even/latest")
                .openStream().use { it.read() > 0 }
        } catch (e: Exception) {
            false
        }
        assumeTrue("no network — skipping live npm test", reachable)

        val ws = ws()
        val out = JsSandbox.run(
            """
            var isEven = require('is-even');
            print('isEven(42)=' + isEven(42));
            print('isEven(7)=' + isEven(7));
            var pad = require('left-pad');
            print('pad=' + pad('ab', 5));
            """.trimIndent(), 60_000, ws
        )
        assertTrue("expected isEven(42)=true, got: $out", out.contains("isEven(42)=true"))
        assertTrue("expected isEven(7)=false, got: $out", out.contains("isEven(7)=false"))
        assertTrue("expected left-pad result, got: $out", out.contains("pad=   ab"))
        // disk cache must exist for the second require to be instant
        assertTrue(File(ws, ".liman/npm").isDirectory)
    }

    // ---------------- ShellRunner (real busybox) ----------------

    private fun busybox(): File {
        val bb = File("src/main/jniLibs/x86_64/libbusybox.so")
        assumeTrue("x86_64 busybox not present", bb.isFile)
        bb.setExecutable(true, false)
        return bb
    }

    @Test
    fun shellRunsPipesAndStdin() {
        val r = ShellRunner.run(
            script = "echo 'n=6*7' | awk -F= '{print \$1, \$2}' ; printf 'b\\na\\n' | sort ; read line; echo \"got=\$line\"",
            cwd = ws(),
            timeoutMs = 10_000,
            stdin = "hello-stdin",
            busybox = busybox()
        )
        assertEquals("shell result: $r", 0, r.exitCode)
        assertTrue(r.stdout.contains("n 6*7"))
        assertTrue(r.stdout.contains("a"))
        assertTrue("stdin must reach the script", r.stdout.contains("got=hello-stdin"))
        assertTrue(r.shell, r.shell.contains("busybox"))
    }

    @Test
    fun shellCanWriteAndReadWorkspaceFiles() {
        val dir = ws()
        val r = ShellRunner.run(
            script = "echo 'hello' > out.txt && wc -c < out.txt && cat out.txt",
            cwd = dir,
            timeoutMs = 10_000,
            busybox = busybox()
        )
        assertEquals("shell result: $r", 0, r.exitCode)
        assertTrue(File(dir, "out.txt").readText().contains("hello"))
        assertTrue(r.stdout.contains("hello"))
    }

    @Test
    fun shellTimeoutKillsScript() {
        val t0 = System.currentTimeMillis()
        val r = ShellRunner.run(
            script = "sleep 30; echo never",
            cwd = ws(),
            timeoutMs = 2_000,
            busybox = busybox()
        )
        val dt = System.currentTimeMillis() - t0
        assertTrue("shell result: $r", r.timedOut)
        assertTrue("kill must be fast (took ${dt}ms)", dt < 10_000)
        assertFalse(r.stdout.contains("never"))
    }

    // ---------------- OnlineRunner (live paiza) ----------------

    @Test
    fun onlinePythonRunsOnPaiza() {
        val reachable = try {
            java.net.URL("https://api.paiza.io/runners/create")
                .openConnection().let { it.connectTimeout = 5000; it as java.net.HttpURLConnection; it.requestMethod = "GET"; it.responseCode in 200..499 }
        } catch (e: Exception) {
            false
        }
        assumeTrue("no network — skipping live online-runner test", reachable)

        val r = OnlineRunner.run(
            "python", "import sys\nprint('py-works', 6*7)\nsys.stderr.write('warn-line')\n",
            "", 60
        )
        assertEquals("paiza python exit must be 0: $r", 0, r.exitCode)
        assertTrue(r.stdout.contains("py-works 42"))
        assertTrue(r.stderr.contains("warn-line"))
    }

    @Test
    fun onlineUnsupportedLanguageFailsClearly() {
        try {
            OnlineRunner.run("cobol", "DISPLAY 'X'.", "", 30)
            throw AssertionError("cobol must be rejected")
        } catch (e: OnlineRunner.RunException) {
            assertTrue(e.message!!.contains("unsupported language"))
        }
    }
}
