package com.liman.agent

import com.liman.agent.data.ComboConfig
import com.liman.agent.data.ComboMode
import com.liman.agent.data.ProviderConfig
import com.liman.agent.data.ProviderKind
import com.liman.agent.llm.ROUTER_DASHBOARD_HTML
import com.liman.agent.llm.maskKey
import com.liman.agent.llm.routerStatusJson
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 9Router dashboard — status payload + masking + the self-contained page.
 */
class RouterDashboardTest {

    private fun status(
        providers: List<ProviderConfig> = emptyList(),
        combo: ComboConfig = ComboConfig(),
        models: List<String> = listOf("auto", "free"),
        log: List<String> = emptyList(),
        reveal: Boolean = false,
        running: Boolean = true
    ): String = routerStatusJson(
        running = running, port = 20128, lan = false, lanUrl = null,
        enabled = true, requests = 7, uptimeMs = 65_000,
        providers = providers, combo = combo,
        comboNames = { id -> "name-of-" + id },
        models = models, log = log, revealKeys = reveal
    )

    @Test
    fun `api keys are masked by default`() {
        val p = ProviderConfig(id = "p1", name = "OpenRouter", kind = ProviderKind.OPENAI_COMPATIBLE, apiKey = "sk-1234567890abcdef")
        val json = status(providers = listOf(p))
        assertFalse(json.contains("sk-1234567890abcdef"))
        assertTrue(json.contains("••••"))
        assertTrue(json.contains("sk-1"))
    }

    @Test
    fun `reveal flag shows full keys`() {
        val p = ProviderConfig(id = "p1", name = "OpenRouter", kind = ProviderKind.OPENAI_COMPATIBLE, apiKey = "sk-1234567890abcdef")
        val json = status(providers = listOf(p), reveal = true)
        assertTrue(json.contains("sk-1234567890abcdef"))
    }

    @Test
    fun `masking rules`() {
        assertEquals("", maskKey(""))
        assertEquals("local", maskKey("local"))
        assertEquals("••••••", maskKey("abc"))
        assertTrue(maskKey("sk-1234567890abcdef").startsWith("sk-1"))
        assertTrue(maskKey("sk-1234567890abcdef").endsWith("def"))
    }

    @Test
    fun `providers serialize with identity and routing fields`() {
        val p = ProviderConfig(
            id = "p9", name = "Poe web", kind = ProviderKind.WEB_CHAT,
            baseUrl = "https://poe.com", model = "auto", enabled = true
        )
        val json = status(providers = listOf(p))
        assertTrue(json.contains("Poe web"))
        assertTrue(json.contains("WEB_CHAT"))
        assertTrue(json.contains("https://poe.com"))
        assertTrue(json.contains("\"free\":true"))
    }

    @Test
    fun `combo carries mode retries and member names`() {
        val c = ComboConfig(providerIds = listOf("a", "b"), mode = ComboMode.ROUND_ROBIN, retriesPerProvider = 3, cooldownMs = 15_000)
        val json = status(combo = c)
        assertTrue(json.contains("ROUND_ROBIN"))
        assertTrue(json.contains("name-of-a"))
        assertTrue(json.contains("name-of-b"))
        assertTrue(json.contains("\"retriesPerProvider\":3"))
    }

    @Test
    fun `models and log lines are included`() {
        val json = status(models = listOf("auto", "free", "gpt-x"), log = listOf("router up", "req 1"))
        assertTrue(json.contains("gpt-x"))
        assertTrue(json.contains("router up"))
        assertTrue(json.contains("\"requests\":7"))
    }

    @Test
    fun `running state reflected`() {
        assertFalse(status(running = true).contains("\"running\":false"))
        assertTrue(status(running = false).contains("\"running\":false"))
    }

    @Test
    fun `dashboard page is self-contained and wired to the apis`() {
        val h = ROUTER_DASHBOARD_HTML
        assertTrue(h.contains("/api/status"))
        assertTrue(h.contains("/api/state"))
        assertTrue(h.contains("/api/providers/"))
        assertTrue(h.contains("/api/combo"))
        assertTrue(h.contains("/api/test"))
        assertTrue(h.contains("/v1/chat/completions"))
        // no external resources — must render offline inside any browser
        assertFalse(h.contains("<script src="))
        assertFalse(h.contains("<link"))
        assertFalse(h.contains("https://cdn"))
        // no dollar signs would have broken the Kotlin raw string
        assertFalse(h.contains("$"))
    }
}
