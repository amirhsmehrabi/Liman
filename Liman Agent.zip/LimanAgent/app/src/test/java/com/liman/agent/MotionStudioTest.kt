package com.liman.agent

import com.liman.agent.agent.MotionKit
import com.liman.agent.agent.MotionRecorder
import com.liman.agent.agent.MotionStudio
import com.liman.agent.agent.builtInToolSpecs
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/**
 * v2.24.0 — STORY MOTION STUDIO (video-shotcraft integration).
 * Pure-logic tests: the deterministic runtime contract, the scaffold,
 * the handbook doctrine, the export gate, the recorder math, and the
 * RGB→YUV conversion used by the H.264 encoder.
 */
class MotionStudioTest {

    @get:Rule
    val tmp = TemporaryFolder()

    // ---------------- MotionKit runtime ----------------

    @Test
    fun runtimeIsDeterministicAndComplete() {
        val js = MotionKit.RUNTIME
        // export contract the recorder depends on
        assertTrue(js.contains("window.__limanSeek"))
        assertTrue(js.contains("window.__limanReady"))
        assertTrue(js.contains("window.__limanDuration"))
        // determinism law: the runtime itself ships the seeded PRNG…
        assertTrue(js.contains("mulberry32"))
        // …and never touches non-deterministic sources itself
        assertFalse("Math.random forbidden", js.contains("Math.random"))
        assertFalse("Date.now forbidden", js.contains("Date.now"))
        // the tuned vocabulary from the repo
        listOf("outCubic", "outExpo", "outBack", "dampedSettle", "blurSlide", "wordStagger",
            "typewriter", "mulberry32", "prog", "stagger", "camera").forEach {
            assertTrue("runtime misses $it", js.contains(it))
        }
        // no JS template literals (keeps Kotlin raw-string interpolation safe)
        assertFalse("no JS template literals", js.contains("`"))
    }

    // ---------------- scaffold ----------------

    @Test
    fun scaffoldIsPublishableHtmlWithTheContract() {
        val html = MotionKit.scaffoldHtml("My Promo <evil>", "fast cut, 3 shots", 12)
        assertTrue(html.startsWith("<!DOCTYPE html>"))
        assertTrue(html.contains("<title>My Promo"))
        assertTrue("title injection escaped", !html.contains("<title>My Promo <evil>"))
        assertTrue(html.contains("mk.duration = 12"))
        // self-contained: runtime inline, no external resources
        assertTrue(html.contains("var MotionKit"))
        assertFalse("no external scripts", html.contains("src=\"http"))
        assertFalse("no CDNs", html.contains("cdn."))
        // fixed 1920x1080 stage + fit-to-window preview
        assertTrue(html.contains("width:1920px"))
        assertTrue(html.contains("height:1080px"))
        assertTrue(html.contains("__limanFit"))
        // autoplay preview + deterministic seek both present
        assertTrue(html.contains("mk.play(true)"))
        assertTrue(html.contains("COMPOSE_HERE"))
    }

    // ---------------- studio: projects + handbook ----------------

    @Test
    fun projectScaffoldAndHandbook() {
        val ws = tmp.newFolder()
        val dir = MotionStudio.create(ws, "Liman Launch Promo", "product launch teaser", 15)
        assertEquals("liman-launch-promo", dir.name)
        assertTrue(File(dir, "motion.html").exists())
        val board = File(dir, "storyboard.md").readText()
        assertTrue(board.contains("Energy") || board.contains("energy") || board.contains("STUDIO.md"))
        assertTrue(board.contains("| # | shot |"))
        // shared handbook created once at the root
        val hb = File(MotionStudio.motionRoot(ws), "STUDIO.md")
        assertTrue(hb.exists())
        val handbook = hb.readText()
        // the distilled doctrine
        assertTrue(handbook.contains("video-shotcraft"))
        assertTrue("energy arc present", handbook.contains("Energy arc"))
        assertTrue("R1 hold rule", handbook.contains("R1"))
        assertTrue("Q4 glint law", handbook.contains("Q4"))
        assertTrue("P4 one-protagonist law", handbook.contains("P4"))
        assertTrue("signature recipes", handbook.contains("brand-ink-open") && handbook.contains("deck-deal-flyin"))
        assertTrue("three-piece entrance", handbook.contains("three-piece"))
        assertTrue("determinism law", handbook.contains("mulberry32"))
        assertTrue("credit + license", handbook.contains("Apache-2.0"))
        // create again → same project reused, handbook not duplicated
        val dir2 = MotionStudio.create(ws, "Liman Launch Promo", "x", 10)
        assertEquals(dir.absolutePath, dir2.absolutePath)
        // second project lists
        MotionStudio.create(ws, "Second Piece", "y", 8)
        assertEquals(2, MotionStudio.projects(ws).size)
        assertEquals("liman-launch-promo", MotionStudio.findProject(ws, "liman launch promo")?.name)
    }

    // ---------------- export gate (the determinism law) ----------------

    @Test
    fun exportReadinessGate() {
        val good = MotionKit.scaffoldHtml("ok", "b", 10)
        assertNull(MotionStudio.exportReadiness(good))
        assertTrue(MotionStudio.exportReadiness(good.replace("__limanSeek", "seek"))!!.contains("export contract"))
        assertTrue(MotionStudio.exportReadiness(good + "var x = Math.random();")!!.contains("Math.random"))
        assertTrue(MotionStudio.exportReadiness(good + "var t = Date.now();")!!.contains("Date.now"))
        assertTrue(MotionStudio.exportReadiness(good.replace("mk.duration = 10", "var d = 10"))!!.contains("mk.duration"))
    }

    // ---------------- recorder math ----------------

    @Test
    fun recorderFrameMath() {
        assertEquals(360, MotionRecorder.frameCount(12.0, 30))
        assertEquals(1, MotionRecorder.frameCount(0.02, 30))
        assertEquals(300, MotionRecorder.frameCount(10.0, 30))
        assertEquals(0L, MotionRecorder.presentationUs(0, 30))
        assertEquals(33_333L, MotionRecorder.presentationUs(1, 30))
        assertEquals(1_000_000L, MotionRecorder.presentationUs(30, 30))
        assertEquals(14_000_000, MotionRecorder.bitrateFor(1920, 1080, 30))
        assertEquals(8_000_000, MotionRecorder.bitrateFor(1280, 720, 30))
        assertTrue(MotionRecorder.bitrateFor(1920, 1080, 60) > 14_000_000)
    }

    @Test
    fun rgbToYuv601Sanity() {
        // black → Y=16 (limited range), white → Y=235
        assertEquals(16, MotionRecorder.rgbToYuv601(0, 0, 0)[0])
        assertEquals(235, MotionRecorder.rgbToYuv601(255, 255, 255)[0])
        // pure gray keeps neutral chroma (u≈v≈128)
        val gray = MotionRecorder.rgbToYuv601(128, 128, 128)
        assertEquals(128, gray[1])
        assertEquals(128, gray[2])
        // red has strong V (Cr), blue strong U (Cb)
        val red = MotionRecorder.rgbToYuv601(255, 0, 0)
        val blue = MotionRecorder.rgbToYuv601(0, 0, 255)
        assertTrue(red[2] > 160)
        assertTrue(blue[1] > 160)
        // values always in range
        for (r in intArrayOf(0, 37, 128, 200, 255))
            for (g in intArrayOf(0, 90, 160, 255))
                for (b in intArrayOf(0, 45, 210, 255)) {
                    val yuv = MotionRecorder.rgbToYuv601(r, g, b)
                    yuv.forEach { assertTrue(it in 0..255) }
                }
    }

    // ---------------- planning brief ----------------

    @Test
    fun planningBriefCarriesTheDoctrine() {
        val brief = MotionStudio.planningBrief()
        assertTrue(brief.contains("ENERGY ARC"))
        assertTrue(brief.contains("Brand open"))
        assertTrue(brief.contains("HOLDS >= 1s"))
        assertTrue(brief.contains("one technique"))
        assertTrue(brief.contains("CO-CREATE"))
        assertTrue(brief.contains("deterministic"))
        assertTrue(brief.contains("VERIFY"))
    }

    // ---------------- tool registration ----------------

    @Test
    fun motionToolRegisteredWithValidSchema() {
        val spec = builtInToolSpecs().firstOrNull { it.name == "motion" }
        assertNotNull(spec)
        Json { }.parseToJsonElement(spec!!.parametersJson)
        assertTrue(spec.description.contains("video-shotcraft"))
        assertTrue(spec.description.contains("MP4"))
    }
}
