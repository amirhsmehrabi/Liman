package com.liman.agent

import com.liman.agent.agent.OfficeExtractors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class OfficeExtractorsTest {

    private fun makeZip(path: File, entries: Map<String, String>) {
        ZipOutputStream(path.outputStream().buffered()).use { zos ->
            entries.forEach { (name, content) ->
                zos.putNextEntry(ZipEntry(name))
                zos.write(content.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }
    }

    @Test
    fun docxExtraction() {
        val f = File.createTempFile("test", ".docx")
        makeZip(
            f,
            mapOf(
                "word/document.xml" to """
                    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
                    <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
                      <w:body>
                        <w:p><w:r><w:t>Hello </w:t></w:r><w:r><w:t>Liman</w:t></w:r></w:p>
                        <w:p><w:r><w:t>Second line</w:t></w:r></w:p>
                        <w:p><w:r><w:tab/><w:t>tabbed</w:t></w:r></w:p>
                      </w:body>
                    </w:document>
                """.trimIndent()
            )
        )
        val text = OfficeExtractors.docx(f)
        assertTrue(text.contains("Hello Liman"))
        assertTrue(text.contains("Second line"))
        assertTrue(text.contains("\ttabbed"))
        f.delete()
    }

    @Test
    fun xlsxExtraction() {
        val f = File.createTempFile("test", ".xlsx")
        makeZip(
            f,
            mapOf(
                "[Content_Types].xml" to "<Types/>",
                "xl/sharedStrings.xml" to """
                    <sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
                      <si><t>Hello</t></si>
                      <si><r><t>Wor</t></r><r><t>ld</t></r></si>
                    </sst>
                """.trimIndent(),
                "xl/workbook.xml" to """
                    <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
                               xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
                      <sheets>
                        <sheet name="Data" sheetId="1" r:id="rId1"/>
                      </sheets>
                    </workbook>
                """.trimIndent(),
                "xl/_rels/workbook.xml.rels" to """
                    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                      <Relationship Id="rId1" Target="worksheets/sheet1.xml"/>
                    </Relationships>
                """.trimIndent(),
                "xl/worksheets/sheet1.xml" to """
                    <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
                      <sheetData>
                        <row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row>
                        <row r="2"><c r="A2"><v>10</v></c><c r="B2"><v>20</v></c></row>
                      </sheetData>
                    </worksheet>
                """.trimIndent()
            )
        )
        val text = OfficeExtractors.xlsx(f)
        assertTrue(text.contains("Sheet: Data"))
        assertTrue(text.contains("Hello,World"))
        assertTrue(text.contains("10,20"))
        f.delete()
    }

    @Test
    fun htmlStripping() {
        val html = """
            <html><head><style>body{color:red}</style></head>
            <body><script>alert(1)</script>
            <h1>Title &amp; more</h1><p>First &lt;para&gt;</p><p>Second</p>
            </body></html>
        """.trimIndent()
        val text = OfficeExtractors.htmlToText(html)
        assertTrue(text.contains("Title & more"))
        assertTrue(text.contains("First <para>"))
        assertTrue(text.contains("Second"))
        assertTrue(!text.contains("alert"))
        assertTrue(!text.contains("color:red"))
    }

    @Test
    fun pptxExtraction() {
        val f = File.createTempFile("test", ".pptx")
        makeZip(
            f,
            mapOf(
                "ppt/slides/slide1.xml" to """
                    <p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
                           xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
                      <p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>Slide one text</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld>
                    </p:sld>
                """.trimIndent(),
                "ppt/slides/slide2.xml" to """
                    <p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
                           xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">
                      <p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>Slide two</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld>
                    </p:sld>
                """.trimIndent()
            )
        )
        val text = OfficeExtractors.pptx(f)
        assertTrue(text.contains("Slide 1"))
        assertTrue(text.contains("Slide one text"))
        assertTrue(text.contains("Slide two"))
        f.delete()
    }

    @Test
    fun zipListingAndEntry() {
        val f = File.createTempFile("test", ".zip")
        makeZip(f, mapOf("a.txt" to "content A", "b.json" to "{\"x\":1}"))
        val listing = OfficeExtractors.zipListing(f)
        assertTrue(listing.contains("a.txt"))
        assertEquals("{\"x\":1}", OfficeExtractors.zipEntryText(f, "b.json").trim())
        f.delete()
    }
}
