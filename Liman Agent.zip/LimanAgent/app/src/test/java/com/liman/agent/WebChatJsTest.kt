package com.liman.agent

import com.liman.agent.llm.WebChatProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mozilla.javascript.Context
import org.mozilla.javascript.ContextFactory
import org.mozilla.javascript.Scriptable

/**
 * v2.13.2 web-chat bridge tests — these EXECUTE the injected scripts against
 * a minimal fake DOM in Rhino, not just parse them.
 *
 * The real DeepSeek failure (user-reported): send=NO_SEND because DeepSeek's
 * send control is a div[role="button"][aria-disabled], NOT a <button> — and
 * typing produced no trusted input event so the site never enabled Send.
 * The first test reproduces that exact page and pins the fix.
 */
class WebChatJsTest {

    // ---------------- mini DOM harness (runs INSIDE Rhino) ----------------

    private val harness = """
var H = { clicks: [], dispatched: [], activeEl: null};
function Rect(l,t,w,h){ this.left=l; this.top=t; this.width=w; this.height=h; this.right=l+w; this.bottom=t+h; }
function El(spec){
  this.tagName=(spec.tag||'DIV').toUpperCase();
  this.attrs=spec.attrs||{};
  this.className=spec.cls||'';
  this.id=spec.id||'';
  this._rect=spec.rect||new Rect(0,0,0,0);
  this.value=spec.value;
  this.textContent=spec.text||'';
  this.innerText=spec.text||'';
  this.disabled=!!spec.disabled;
  var self=this;
  this.getBoundingClientRect=function(){ return self._rect; };
  this.getAttribute=function(k){ return self.attrs.hasOwnProperty(k)?self.attrs[k]:null; };
  this.focus=function(){ H.activeEl=this; };
  this.select=function(){ this._selAll=true; };
  this.click=function(){ H.clicks.push(self.id||self.className||self.tagName); };
  this.dispatchEvent=function(e){ H.dispatched.push((self.id||self.className||self.tagName)+':'+e.type); };
  this.closest=function(){ return null; };
  this.querySelector=function(){ return null; };
  this.querySelectorAll=function(){ return []; };
}
var ALL=[];
function matchAttr(el,tok){
  var inner=tok.slice(1,-1);
  var iFlag=/ i$/.test(inner); if(iFlag) inner=inner.slice(0,-2);
  var m=/^([a-zA-Z0-9-]+)(\*?=)?("[^"]*"|'[^']*')?$/.exec(inner);
  if(!m) return false;
  var name=m[1], op=m[2]||null, val=m[3]?m[3].slice(1,-1):null;
  var actual = name==='class' ? String(el.className||'') :
                name==='id'    ? String(el.id||'') :
                (el.getAttribute(name)===null ? null : String(el.getAttribute(name)));
  if(op===null) return actual!==null;
  if(actual===null) return false;
  if(iFlag){ actual=actual.toLowerCase(); val=String(val).toLowerCase(); }
  if(op==='*=') return actual.indexOf(val)>=0;
  return actual===val;
}
function matchesSimple(el,simple){
  var m=/^([a-zA-Z0-9]*)((?:\[[^\]]*\])*)$/.exec(simple);
  if(!m) return false;
  var tag=(m[1]||'').toLowerCase();
  if(tag && el.tagName.toLowerCase()!==tag) return false;
  var toks=m[2].match(/\[[^\]]*\]/g)||[];
  for(var i=0;i<toks.length;i++){ if(!matchAttr(el,toks[i])) return false; }
  return true;
}
function qsa(sel){
  var parts=sel.split(','), out=[];
  for(var i=0;i<ALL.length;i++){
    for(var j=0;j<parts.length;j++){
      var last=parts[j].trim().split(' ').pop();
      if(matchesSimple(ALL[i],last)){ out.push(ALL[i]); break; }
    }
  }
  return out;
}
var document={
  querySelector:function(sel){ var r=qsa(sel); return r.length?r[0]:null; },
  querySelectorAll:function(sel){ return qsa(sel); },
  body:{ innerText:'hello there this is the page body text 1234567890' },
  documentElement:{},
  execCommand:function(cmd,ui,text){
    var el=H.activeEl; if(!el) return false;
    if(cmd==='insertText'){ if(el._selAll){ el.value=text; el._selAll=false; } else { el.value=(el.value||'')+text; } H.dispatched.push('TRUSTED-input-on:'+(el.id||el.className)); return true; }
    if(cmd==='selectAll'){ el._selAll=true; return true; }
    return false;
  }
};
var getComputedStyle=function(){ return {visibility:'visible',display:'block',cursor:'pointer'}; };
function Event(t,o){ this.type=t; }
function KeyboardEvent(t,o){ this.type=t; }
function MouseEvent(t,o){ this.type=t; }
var innerHeight=1000;
var location={ href:'https://chat.deepseek.com/a/chat/s/abc123' };
var window={ __limanCap:{changes:7,lastChangeAt:Date.now()-400},
             HTMLTextAreaElement:{prototype:{}}, HTMLInputElement:{prototype:{}} };
""".trim()

    /** builds a fresh fake-DOM scope and evaluates the script built by [js] in it */
    private fun runInDom(vararg elements: ElSpec, js: () -> String): Pair<Any?, Scriptable> {
        val setup = StringBuilder(harness).append("\nALL=[")
        elements.forEach { spec ->
            val attrs = spec.attrs.entries.joinToString(",") { "'${it.key}':'${it.value.replace("'", "\\'")}'" }
            val value = spec.value?.let { "'${it.replace("'", "\\'").replace("\n", "\\n")}'" } ?: "undefined"
            setup.append(
                "new El({tag:'${spec.tag}',id:'${spec.id}',cls:'${spec.cls}',attrs:{$attrs}," +
                    "rect:new Rect(${spec.l},${spec.t},${spec.w},${spec.h}),value:$value,text:'${spec.text}'}),"
            )
        }
        setup.append("];")
        val factory = ContextFactory()
        return factory.call { cx ->
            cx.setOptimizationLevel(-1)
            cx.setClassShutter { false }
            val scope = cx.initStandardObjects()
            cx.evaluateString(scope, setup.toString(), "dom", 1, null)
            val result = cx.evaluateString(scope, js(), "script", 1, null)
            Pair(result, scope)
        }
    }

    data class ElSpec(
        val tag: String = "div",
        val id: String = "",
        val cls: String = "",
        val attrs: Map<String, String> = emptyMap(),
        val l: Int = 0, val t: Int = 0, val w: Int = 0, val h: Int = 0,
        val value: String? = null,
        val text: String = ""
    )

    private fun ALL(scope: Scriptable): List<Scriptable> {
        val arr = scope.get("ALL", scope) as org.mozilla.javascript.NativeArray
        return (0 until arr.getLength().toInt()).map { arr.get(it, arr) as Scriptable }
    }

    private fun clicks(scope: Scriptable): List<String> {
        val arr = scope.get("H", scope) as org.mozilla.javascript.Scriptable
        val c = arr.get("clicks", arr) as org.mozilla.javascript.NativeArray
        return (0 until c.getLength().toInt()).map { c.get(it, c).toString() }
    }

    private fun dispatched(scope: Scriptable): List<String> {
        val arr = scope.get("H", scope) as org.mozilla.javascript.Scriptable
        val d = arr.get("dispatched", arr) as org.mozilla.javascript.NativeArray
        return (0 until d.getLength().toInt()).map { d.get(it, d).toString() }
    }

    // ---------------- THE DeepSeek regression (user's exact bug) ----------------

    @Test
    fun deepseekSendClicksRoleButtonNotButtonTag() {
        val (result, scope) = runInDom(
            // DeepSeek composer: #chat-input textarea + div[role=button] send at the
            // right end + DeepThink toggle at the left. NO <button> elements at all.
            ElSpec(tag = "textarea", id = "chat-input", l = 10, t = 800, w = 700, h = 90),
            ElSpec(
                tag = "div", id = "ds-send",
                attrs = mapOf("role" to "button", "aria-disabled" to "false"),
                l = 660, t = 845, w = 44, h = 44
            ),
            ElSpec(
                tag = "div", id = "ds-deepthink",
                attrs = mapOf("role" to "button", "aria-disabled" to "false"),
                l = 20, t = 850, w = 60, h = 40
            )
        ) { WebChatProvider.sendJs(null) }

        assertEquals("SENT", result)
        val clicked = clicks(scope)
        assertTrue("the div[role=button] send must be clicked, got: $clicked", clicked.contains("ds-send"))
        assertFalse("the left-side DeepThink toggle must NOT be clicked", clicked.contains("ds-deepthink"))
    }

    @Test
    fun typingUsesTrustedExecCommandPath() {
        val (result, scope) = runInDom(
            ElSpec(tag = "textarea", id = "chat-input", l = 10, t = 800, w = 700, h = 90, value = "")
        ) { WebChatProvider.typeJs(null, "Reply with exactly: OK") }

        assertEquals("TYPED", result)
        val el = ALL(scope)[0]
        assertEquals("Reply with exactly: OK", el.get("value", el).toString())
        val d = dispatched(scope)
        assertTrue(
            "execCommand must fire (simulated) trusted input, dispatched: $d",
            d.any { it.startsWith("TRUSTED-input-on:") }
        )
        assertFalse("no synthetic input needed when execCommand works", d.any { it.endsWith(":input") })
    }

    @Test
    fun typingFallsBackToNativeSetterWhenExecCommandMissing() {
        // page without execCommand (undefined) → native setter + synthetic events
        val factory = ContextFactory()
        var result: Any? = null
        var scope: Scriptable? = null
        factory.call { cx ->
            cx.setOptimizationLevel(-1)
            cx.setClassShutter { false }
            val sc = cx.initStandardObjects()
            val setup = harness + "\nALL=[new El({tag:'textarea',id:'chat-input'," +
                "rect:new Rect(10,800,700,90),value:''})];\ndocument.execCommand=undefined;"
            cx.evaluateString(sc, setup, "dom", 1, null)
            result = cx.evaluateString(sc, WebChatProvider.typeJs(null, "hi there"), "script", 1, null)
            scope = sc
        }
        assertEquals("TYPED", result)
        val el = ALL(scope!!)[0]
        assertEquals("hi there", el.get("value", el).toString())
        assertTrue(
            "synthetic input event must be dispatched as fallback",
            dispatched(scope!!).any { it == "chat-input:input" }
        )
    }

    @Test
    fun standardButtonPageStillWorks() {
        val (result, scope) = runInDom(
            ElSpec(tag = "textarea", id = "prompt", l = 10, t = 800, w = 600, h = 80),
            ElSpec(
                tag = "button", id = "sendbtn",
                attrs = mapOf("aria-label" to "Send message"),
                l = 620, t = 810, w = 40, h = 40
            )
        ) { WebChatProvider.sendJs(null) }
        assertEquals("SENT", result)
        assertTrue(clicks(scope).contains("sendbtn"))
    }

    @Test
    fun pollJsReportsSixFieldsAndCorrectInputState() {
        val prompt = "Reply with exactly: OK"
        val (result, _) = runInDom(
            ElSpec(tag = "textarea", id = "chat-input", l = 10, t = 800, w = 700, h = 90, value = prompt),
            ElSpec(
                tag = "div", id = "ans", cls = "ds-markdown--block",
                attrs = mapOf("role" to "button"), l = 10, t = 100, w = 700, h = 300,
                text = "This is the assistant answer text that is long enough to count."
            )
        ) { WebChatProvider.pollJs(null) }
        val fields = result.toString().split('|')
        assertEquals("six fields expected: $fields", 6, fields.size)
        assertTrue("ds-markdown must be counted (got ${fields[0]})", fields[0].toInt() >= 1)
        assertEquals("inputState must read the chat input", prompt.length, fields[3].toInt())
    }

    @Test
    fun extractFindsDeepseekAnswer() {
        val (result, _) = runInDom(
            ElSpec(tag = "textarea", id = "chat-input", l = 10, t = 800, w = 700, h = 90),
            ElSpec(
                tag = "div", id = "ans", cls = "ds-markdown--block",
                l = 10, t = 100, w = 700, h = 300,
                text = "The answer to your question is forty-two."
            )
        ) { WebChatProvider.extractJs(null, "Reply with exactly") }
        assertEquals("The answer to your question is forty-two.", result)
    }

    // ---------------- syntax validation (all scripts) ----------------

    private fun assertJsParses(name: String, js: String) {
        val error = try {
            val factory = ContextFactory()
            factory.call { cx ->
                cx.setOptimizationLevel(-1)
                cx.setClassShutter { false }
                cx.evaluateString(cx.initStandardObjects(), js, name, 1, null)
                null
            }
        } catch (t: Throwable) {
            t.message ?: t.javaClass.simpleName
        }
        assertTrue(
            "generated JS '$name' does not parse: $error",
            error == null || error.contains("is not defined") || error.contains("ReferenceError")
        )
    }

    @Test
    fun allInjectedScriptsParse() {
        assertJsParses("typeJs", WebChatProvider.typeJs(null, "hello 'world' \n line2"))
        assertJsParses("typeJs-custom", WebChatProvider.typeJs("#my-input", "x"))
        assertJsParses("sendJs", WebChatProvider.sendJs(null))
        assertJsParses("sendJs-custom", WebChatProvider.sendJs("button.go"))
        assertJsParses("enterJs", WebChatProvider.enterJs(null))
        assertJsParses("armJs", WebChatProvider.armJs())
        assertJsParses("pollJs", WebChatProvider.pollJs(null))
        assertJsParses("extractJs", WebChatProvider.extractJs(null, "my prompt prefix"))
    }

    // ---------------- escaping ----------------

    @Test
    fun promptWithQuotesAndNewlinesCannotBreakTheScript() {
        val tricky = "it's a \"test\"\nwith \\ backslash and 'quotes'"
        val js = WebChatProvider.typeJs(null, tricky)
        val literal = js.substringAfter("var text='").substringBefore("';")
        assertFalse("raw newline leaked into JS literal", literal.contains('\n'))
        assertJsParses("tricky-prompt", js)
    }

    @Test
    fun decodeJsHandlesQuotedAndNull() {
        assertEquals(null, com.liman.agent.llm.decodeJs(null))
        assertEquals(null, com.liman.agent.llm.decodeJs("null"))
        assertEquals("line1\nline2", com.liman.agent.llm.decodeJs("\"line1\\nline2\""))
        assertEquals("say \"hi\"", com.liman.agent.llm.decodeJs("\"say \\\"hi\\\"\""))
    }
}
