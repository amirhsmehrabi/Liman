package com.liman.agent

import com.liman.agent.agent.DiagLog
import com.liman.agent.agent.HeroMode
import com.liman.agent.agent.TermuxHeal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * v2.28.0 — DOCTOR'S LOG + CYCLE-BUG FIX + TERMUX SELF-HEAL.
 */
class DiagAndHealTest {

    @Before fun reset() = DiagLog.clear()

    // ================= the "hi → 4 cycles" bug (HeroMode conversational guard)

    @Test fun pureConversationNeverForcedToAct() {
        // "hi" → friendly reply with a conversational closer → COMPLETE, not a failure
        val reply = "Hey! Great to hear from you. Let me know if you need anything else 😊"
        assertFalse(
            HeroMode.shouldForceAction(reply, "hi", toolsCalledSoFar = 0, cycle = 1)
        )
        assertFalse(
            HeroMode.shouldForceAction("Sure, I can help with that!", "what can you do?", 0, 1)
        )
        assertFalse(
            HeroMode.shouldForceAction("خواهش می‌کنم! اگر سوال دیگری داشتی بپرس", "ممنون", 0, 1)
        )
    }

    @Test fun realAnnouncementsStillRejectedOnCommandTasks() {
        // command task + announced action → still forced to act
        assertTrue(
            HeroMode.shouldForceAction(
                "Okay! I will now deploy the worker to Cloudflare.",
                "deploy my worker to cloudflare", 0, 1
            )
        )
        assertTrue(
            HeroMode.shouldForceAction(
                "Let me create the file for you…",
                "create a file called notes.txt", 0, 1
            )
        )
        // Persian future-tense announcement on a command task
        assertTrue(
            HeroMode.shouldForceAction(
                "حتماً، الان انجام می‌دهم و نتیجه را می‌فرستم.",
                "این کار را انجام بده", 0, 1
            )
        )
    }

    @Test fun midRunAnnouncementsAfterToolsStillRejected() {
        // tools already ran, model announces MORE instead of finishing → nudged
        assertTrue(
            HeroMode.shouldForceAction(
                "File written. Now I will configure the router next.",
                "set up my router", toolsCalledSoFar = 3, cycle = 2
            )
        )
    }

    @Test fun politeClosersAfterRealWorkAreAccepted() {
        // finished the work, polite closer → done, not nudged
        assertFalse(
            HeroMode.shouldForceAction(
                "Done — notes.txt is created and verified. Let me know if you want changes!",
                "create a file called notes.txt", 3, 2
            )
        )
    }

    // ================= termux dependency self-heal

    @Test fun missingBinaryDiagnosedAndMapped() {
        val f = TermuxHeal.diagnose("bash: jq: command not found")
        assertNotNull(f)
        assertEquals("missing-binary", f!!.kind)
        assertEquals("jq", f.missing)
        assertEquals("pkg install -y jq", f.installCommand)

        // missing reports the BINARY; the pkg it maps to rides in installCommand
        val py = TermuxHeal.diagnose("sh: python3: not found")!!
        assertEquals("python3", py.missing)
        assertEquals("pkg install -y python", py.installCommand)
        assertEquals("npm", TermuxHeal.diagnose("npm: command not found")!!.missing)
        assertEquals("pkg install -y nodejs", TermuxHeal.diagnose("npm: command not found")!!.installCommand)
        assertEquals("cargo", TermuxHeal.diagnose("cargo: command not found")!!.missing)
        assertEquals("pkg install -y rust", TermuxHeal.diagnose("cargo: command not found")!!.installCommand)
        // zsh format — name at the END
        assertEquals("jq", TermuxHeal.diagnose("zsh:1: command not found: jq")!!.missing)
    }

    @Test fun missingPythonModuleDiagnosed() {
        val f = TermuxHeal.diagnose("Traceback (most recent call last):\nModuleNotFoundError: No module named 'requests'")
        assertNotNull(f)
        assertEquals("missing-python-module", f!!.kind)
        assertEquals("requests", f.missing)
        assertTrue(f.installCommand.contains("pip install"))
    }

    @Test fun healthyOutputNotDiagnosed() {
        assertNull(TermuxHeal.diagnose("total 4\n-rw-r--r-- 1 u0 u0 1024 Sep 15 notes.txt"))
        assertNull(TermuxHeal.diagnose("Hello world"))
        // stdlib modules are NOT installable — no false fix
        assertNull(TermuxHeal.diagnose("ModuleNotFoundError: No module named 'os'"))
    }

    @Test fun healReportTeaches() {
        val r = TermuxHeal.healReport(TermuxHeal.Fix("missing-binary", "jq", "pkg install -y jq"), "1 2 3")
        assertTrue(r.contains("SELF-HEAL"))
        assertTrue(r.contains("pkg install -y jq"))
        assertTrue(r.contains("Remember"))
    }

    // ================= the Doctor's Log

    @Test fun logRingBufferCapsAndClears() {
        repeat(900) { DiagLog.log("t", "event $it") }
        assertEquals(DiagLog.MAX_EVENTS, DiagLog.snapshot().size)
        DiagLog.clear()
        assertEquals(0, DiagLog.snapshot().size)
    }

    @Test fun markdownReportContainsTheStory() {
        DiagLog.log("agent", "run start — goal: build a website")
        DiagLog.warn("hero", "nudge 1/2 — all-talk reply rejected")
        DiagLog.error("termux", "bridge failure: No response from Termux")
        val md = DiagLog.toMarkdown()
        assertTrue(md.contains("# Liman diagnostic report"))
        assertTrue(md.contains("run start"))
        assertTrue(md.contains("nudge 1/2"))
        assertTrue(md.contains("bridge failure"))
        assertTrue(md.contains("## Errors and warnings only"))
        assertTrue(md.contains("`termux`"))
    }

    @Test fun longMessagesAreTrimmed() {
        DiagLog.log("tool", "x".repeat(5_000))
        val e = DiagLog.snapshot().last()
        assertTrue(e.msg.length <= DiagLog.MAX_MSG)
    }
}
