package com.liman.agent

import com.liman.agent.agent.NineRouter
import com.liman.agent.agent.builtInToolSpecs
import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v2.25.1 — 9ROUTER, CLOUD EDITION.
 *
 * The Termux install path is retired; the user's 9Router runs at
 * https://9router-production-5f97a.up.railway.app/ and Liman connects to it
 * like any OpenAI-compatible provider — fetching COMBOS (owned_by "combo"
 * in /v1/models, listed first by the server) instead of plain models.
 */
class NineRouterTest {

    // ---------------- URL derivation ----------------

    @Test fun defaultBaseIsTheUsersServer() {
        assertEquals("https://9router-production-5f97a.up.railway.app/v1", NineRouter.DEFAULT_BASE)
    }

    @Test fun originOfHandlesBaseShapes() {
        val origin = "https://9router-production-5f97a.up.railway.app"
        assertEquals(origin, NineRouter.originOf("https://9router-production-5f97a.up.railway.app/v1"))
        assertEquals(origin, NineRouter.originOf("https://9router-production-5f97a.up.railway.app/"))
        assertEquals(origin, NineRouter.originOf("https://9router-production-5f97a.up.railway.app/v1/models?x=1"))
        assertEquals(origin, NineRouter.originOf(origin))
        assertEquals("http://127.0.0.1:20128", NineRouter.originOf("http://127.0.0.1:20128/v1"))
    }

    @Test fun dashboardUrlIsOriginPlusDashboard() {
        assertEquals(
            "https://9router-production-5f97a.up.railway.app/dashboard",
            NineRouter.dashboardUrl("https://9router-production-5f97a.up.railway.app/v1")
        )
        assertEquals(
            "https://9router-production-5f97a.up.railway.app/dashboard",
            NineRouter.dashboardUrl("https://9router-production-5f97a.up.railway.app/")
        )
    }

    @Test fun normalizeBaseAppendsV1AndStripsTails() {
        val b = "https://9router-production-5f97a.up.railway.app"
        assertEquals("$b/v1", NineRouter.normalizeBase(b))
        assertEquals("$b/v1", NineRouter.normalizeBase("$b/"))
        assertEquals("$b/v1", NineRouter.normalizeBase("$b/v1"))
        assertEquals("$b/v1", NineRouter.normalizeBase("$b/v1/"))
        assertEquals("$b/v1", NineRouter.normalizeBase("$b/v1/chat/completions"))
        assertEquals("$b/v1", NineRouter.normalizeBase("$b/v1/models"))
        // empty → the user's default server
        assertEquals(NineRouter.DEFAULT_BASE, NineRouter.normalizeBase("   "))
    }

    // ---------------- catalog: COMBOS first ----------------

    @Test fun parseCatalogSeparatesCombosFromModels() {
        // the real server shape (src/app/api/v1/models/route.js): combos are
        // pushed FIRST with owned_by "combo"; plain models carry a provider alias
        val json = """{"object":"list","data":[
            {"id":"my-fusion","object":"model","owned_by":"combo"},
            {"id":"night-shift","object":"model","owned_by":"combo"},
            {"id":"kr/claude-sonnet-4.5","object":"model","owned_by":"kr"},
            {"id":"oc/glm-5","object":"model","owned_by":"oc"}
        ]}"""
        val cat = NineRouter.parseCatalog(json)
        assertEquals(listOf("my-fusion", "night-shift"), cat.combos)
        assertEquals(listOf("kr/claude-sonnet-4.5", "oc/glm-5"), cat.models)
        assertEquals(4, cat.total)
        // combos come first in the unified picker list
        assertEquals("my-fusion", cat.all().first())
    }

    @Test fun parseCatalogSurvivesGarbageAndEmpties() {
        assertTrue(NineRouter.parseCatalog("not json").combos.isEmpty())
        assertTrue(NineRouter.parseCatalog("""{"data":[]}""").total == 0)
        assertTrue(NineRouter.parseCatalog("").total == 0)
        // entries without ids are skipped, not crashed on
        val cat = NineRouter.parseCatalog("""{"data":[{"owned_by":"combo"},{"id":"x","owned_by":"combo"}]}""")
        assertEquals(listOf("x"), cat.combos)
    }

    // ---------------- tool registration ----------------

    @Test fun nineRouterToolIsRegisteredWithComboActions() {
        val spec = builtInToolSpecs().firstOrNull { it.name == "nine_router" }
        assertNotNull(spec)
        assertTrue(spec!!.description.contains("combos"))
        Json.parseToJsonElement(spec.parametersJson) // strict-valid schema
        assertTrue(spec.parametersJson.contains("combos"))
        assertTrue(spec.parametersJson.contains("connect"))
        // the Termux-era actions are gone
        assertFalse(spec.description.contains("Termux"))
        assertFalse(spec.parametersJson.contains("setup"))
        assertFalse(spec.parametersJson.contains("scaffold"))
    }
}
