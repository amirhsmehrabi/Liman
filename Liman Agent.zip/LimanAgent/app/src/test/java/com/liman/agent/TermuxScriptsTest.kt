package com.liman.agent

import com.liman.agent.agent.TermuxScripts
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v2.36 — TERMUX CODE RUNNER: any language, real local toolchains. */
class TermuxScriptsTest {

    @Test
    fun pythonScriptHasHeredocProbeAndExitMarker() {
        val script = TermuxScripts.runCodeScript("python", "print('hi')", "")
        assertNotNull(script)
        script!!
        assertTrue(script.contains("cat > 'main.py' <<'${TermuxScripts.EOF}'"))
        assertTrue(script.contains("print('hi')"))
        assertTrue(script.contains("pkg install -y python"))
        assertTrue(script.contains("main.py"))
        assertTrue(script.contains("echo \"${TermuxScripts.EXIT}\$?\""))
        assertTrue(script.contains("CI=1"))                       // non-interactive hardening
        assertTrue(script.contains("DEBIAN_FRONTEND=noninteractive"))
        assertTrue(script.contains("agent-workspace"))
    }

    @Test
    fun stdinIsPipedSingleQuoteSafe() {
        val script = TermuxScripts.runCodeScript("python", "x = input()", "it's 5")
        assertNotNull(script)
        assertTrue(script!!.contains("printf '%s' 'it'\\''s 5' |"))
    }

    @Test
    fun delimiterCollisionFallsBackToNull() {
        assertNull(TermuxScripts.runCodeScript("python", "x = '''${TermuxScripts.EOF}'''", ""))
    }

    @Test
    fun unsupportedLanguageIsNull() {
        assertNull(TermuxScripts.runCodeScript("cobol", "DISPLAY 'X'.", ""))
    }

    @Test
    fun allSupportedLanguagesBuildScripts() {
        TermuxScripts.supportedLanguages().split(",").map { it.trim() }.forEach { lang ->
            assertNotNull("no runner for $lang", TermuxScripts.runCodeScript(lang, "// x", ""))
        }
    }

    @Test
    fun cCompilesThenRuns() {
        val script = TermuxScripts.runCodeScript("c", "int main(){}", "")
        assertTrue(script!!.contains("clang main.c -o main.bin && ./main.bin"))
    }

    @Test
    fun javaUsesSingleFileLauncher() {
        val script = TermuxScripts.runCodeScript("java", "class A{}", "")
        assertTrue(script!!.contains("java main.java"))
        assertTrue(script.contains("openjdk-17"))
    }

    @Test
    fun parseExitSplitsBodyAndCode() {
        val out = "hello\nworld\n${TermuxScripts.EXIT}0"
        val (body, code) = TermuxScripts.parseExit(out)
        assertEquals("hello\nworld", body)
        assertEquals(0, code)
    }

    @Test
    fun parseExitNonZero() {
        val out = "boom\n${TermuxScripts.EXIT}127"
        val (body, code) = TermuxScripts.parseExit(out)
        assertEquals("boom", body)
        assertEquals(127, code)
    }

    @Test
    fun parseExitMissingMarkerMeansFailure() {
        val (body, code) = TermuxScripts.parseExit("partial output")
        assertEquals(1, code)
        assertTrue(body.contains("partial"))
    }

    @Test
    fun ansiCodesAreStripped() {
        val dirty = "\u001B[32mOK\u001B[0m done"
        assertEquals("OK done", TermuxScripts.stripAnsi(dirty))
        val clean = TermuxScripts.parseExit("\u001B[1;34mstep\u001B[0m\n${TermuxScripts.EXIT}0")
        assertEquals("step", clean.first)
    }

    @Test
    fun runnerListMatchesGuideLanguages() {
        assertTrue(TermuxScripts.supportedLanguages().contains("python"))
        assertTrue(TermuxScripts.supportedLanguages().contains("typescript"))
        assertTrue(TermuxScripts.supportedLanguages().contains("kotlin"))
        assertFalse(TermuxScripts.supportedLanguages().contains("cobol"))
    }
}
