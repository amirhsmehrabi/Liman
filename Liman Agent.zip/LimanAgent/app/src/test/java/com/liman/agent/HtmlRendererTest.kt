package com.liman.agent

import com.liman.agent.agent.HtmlRenderer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

/** Path-traversal protection for the render_html file server. */
class HtmlRendererTest {

    @get:Rule
    val tmp = TemporaryFolder()

    @Test
    fun resolvesFilesWithinBase() {
        val base = tmp.newFolder("app")
        val css = tmp.newFile("app/style.css")
        val f = HtmlRenderer.resolveWithin(base, "style.css")
        assertNotNull(f)
        assertEquals(css.canonicalFile, f)
    }

    @Test
    fun resolvesNestedPaths() {
        val base = tmp.newFolder("app2")
        tmp.newFolder("app2", "js")
        val js = tmp.newFile("app2/js/main.js")
        assertEquals(js.canonicalFile, HtmlRenderer.resolveWithin(base, "js/main.js"))
        assertEquals(js.canonicalFile, HtmlRenderer.resolveWithin(base, "/js/main.js"))
    }

    @Test
    fun blocksTraversalEscape() {
        val base = tmp.newFolder("app3")
        tmp.newFile("outside.txt")
        assertNull(HtmlRenderer.resolveWithin(base, "../outside.txt"))
        assertNull(HtmlRenderer.resolveWithin(base, "js/../../outside.txt"))
        assertNull(HtmlRenderer.resolveWithin(base, ""))
        assertNull(HtmlRenderer.resolveWithin(base, "/"))
    }

    @Test
    fun mimeMappingCoversWebTypes() {
        assertEquals("text/html", HtmlRenderer.mimeFor("index.html"))
        assertEquals("text/javascript", HtmlRenderer.mimeFor("app.JS"))
        assertEquals("image/png", HtmlRenderer.mimeFor("logo.png"))
        assertEquals("font/woff2", HtmlRenderer.mimeFor("f.woff2"))
        assertEquals("application/octet-stream", HtmlRenderer.mimeFor("data.bin"))
    }
}
