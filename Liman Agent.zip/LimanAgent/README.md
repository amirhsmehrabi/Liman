# ⚓ Liman Agent

**An autonomous AI agent that lives on your Android phone.**

Liman Agent brings the agentic power of tools like Claude Code, Google Antigravity or
Nous Research's Hermes to Android — as a real, native app you can carry in your pocket.
It plans, uses tools, reads your files, searches the web, computes, writes results,
**checks its own work**, and **never gives up when an AI provider fails**.

> **v2.36.0 — DELIVERABLES · AI TASK NAMES · PLAN-FREE EXECUTION · TERMUX EVERYTHING (from the three guides):**
> - **PLAN/BUILD SECTION REMOVED:** the Plan⇄Build toggle, the plan-mode tool gate, the roadmap accept/edit flow and the pre-run "Planning…" pass are all gone — the agent plans by DOING (mission checklist card still tracks multi-step work live). Fewer modes, fewer wasted cycles.
> - **DELIVERABLES EMBEDDED IN THE ANSWER:** every file a run creates or modifies (zip, docx, pdf, svg, apk, xlsx, images, audio, video, csv, code…) is automatically attached to the final message as a 📎 card — tap **Save** → straight into Downloads/Liman (MediaStore on Android 10+), or **Share** via the Android share sheet. No more digging through the workspace.
> - **AI TASK NAMING:** conversation titles are never the raw first prompt anymore. The instant placeholder is a clean 2-3 word heuristic; right after the first run, one cheap LLM call names the task creatively ("Harbor Dashboard", "Neon Shop") in the task's own language. **Rename any task from the landing view** (✏️ button).
> - **TERMUX BRIDGE, FIXED & SUPERCHARGED:** `run_code` now runs python, node, typescript, c, cpp, go, rust, ruby, php, perl, lua, R, java AND kotlin in the user's REAL Termux (source embedded via heredoc into ~/agent-workspace, missing interpreters AUTO-INSTALLED via `pkg install -y`, exit code parsed back) and falls back to the free online runner when Termux is absent. Every bridge command is now non-interactive-hardened (CI=1, DEBIAN_FRONTEND=noninteractive, no pagers, stdin closed — commands can never hang waiting for a keypress), ANSI color codes are stripped, output >20k is truncated in-context with the FULL log saved to a workspace file, and diagnostics gained the Android 12+ phantom-process-killer fix (`adb shell device_config put activity_manager max_phantom_processes 2147483647`).
> - **GUIDE AUDIT (the three markdowns):** mapped every feature — memory/skills/RAG/subagents/crews/MCP ✓ (already strong), persistent shell sessions → non-interactive bridge + self-heal + doctor ✓, AGENTS.md/.liman-lessons.md project memory ✓, checkpoints/kill-switch/audit-log ✓, multi-provider failover ✓, accessibility phone-control ✓. The gaps this release closes: local polyglot execution, non-interactive hardening, output offloading, deliverable hand-off, and ceremony removal (stop-when-answered doctrine).
> - Tests: **388/388** (+26: TaskTitles heuristic/clean/Persian, Deliverables diff/exclusions/cap/root-paths, TermuxScripts heredoc/probe/exit-parse/ANSI/collision-fallback/all-languages; −1 obsolete planModeGate test).

> **v2.35.0 — THE SELF-HEALING CORE (salvage · finish gates · cross-run learning):**
> - **XML TOOL-CALL SALVAGE (the production incident, fixed):** when a model wrote REAL tool calls as Claude-style XML markup (`<function_calls><invoke name="run_js"><parameter name="code">…` — with a broken wrapper closer), the old JSON-only rescue couldn't parse it: the raw markup leaked into the chat as garbage and the run ended with nothing executed. The salvage engine now parses BOTH shapes — JSON objects AND XML markup (tolerant to stray closers like `</design_tokens>`, missing wrappers, unquoted attrs, XML entities) — executes the calls for real, and **scrubs the markup from the visible reply**.
> - **FORMAT-REPAIR COACHING:** markup that can't be parsed (invented tool names, broken shape) no longer ends the run as garbage text — the model gets a blunt format-correction turn naming the invalid tools, the closest real ones, and the valid tool list, then re-issues the calls (max 2 coachings/run).
> - **FAILURE-NARRATIVE REJECTION:** "Short, honest answer: No — nothing was built yet. Attempt 1 crashed… nothing to show" essays are now detected as a stall shape and REJECTED as final answers on do-tasks (with the all-talk nudge budget raised to 3).
> - **FINISH GATE:** calling `finish` after only read-only calls on a do-task gets REJECTED (max 2×) with a demand for one mutating action or the single unblocking `ask_user` — research-without-delivery is no longer an acceptable ending.
> - **CROSS-RUN LEARNING (Hermes loop):** every failed/spinning run auto-writes a one-line lesson (goal, failure shape, prescription) into `workspace/.liman-lessons.md` — the file the system prompt already injects into every run. The same mistake never burns a full run twice.
> - **RUN LEDGER + PERFORMANCE AUDIT (every 15 runs):** each run is one line in `filesDir/agent-run-ledger.tsv`; on every 15th run Liman grades itself in-chat (success rate, spin-outs, avg tool calls, blunt advice) — Hermes-style periodic self-audit.
> - **PROMPT DOCTRINE — TOOL CALL FORMAT LAW + ANSWER HYGIENE:** tool calls only through native function-calling (JSON object fallback specified); final answers report OUTCOMES only — no attempt ledgers, no cycle counts, no raw markup, no self-flagellation essays. Both full and compact prompt variants.
> - Tests: **362/362** (+21: XML salvage with the exact production incident, redaction, unknown-tool reporting, entity unescaping, failure-narrative rejection, finish-gate prerequisites, lesson file cap/format, ledger 15-run audit cadence).

> **v2.34.0 — SMART CORE · FLUID CANVAS EVERYWHERE · PERMANENT CODE LOG:**
> - **THE PROGRESS AUDITOR (super-smart core):** the user's complaint — *"multiple cycles without progress, it writes and writes without doing the tasks, and it must ask for help whenever that makes the way faster"* — is now detected and broken by machinery, not politeness. Every cycle is audited (`RunProgress`): **REPEAT** (identical tool calls executing again), **STALL** (3+ cycles with zero state-changing calls), **CHATTER** (>900 chars of prose with <2 tool calls), and **CYCLE-BUDGET pressure** (near the cap without delivering). When any shape persists, a blunt directive is injected into the conversation: *act differently NOW or call `ask_user` for the one missing piece — asking is the fast path* (max 3 per run). Every audit line lands in the Doctor's Log.
> - **SPEED LAW + ASK-EARLY LAW (prompt doctrine, full + compact variants):** between tool calls the agent writes at most 2 short sentences — the final answer is the only prose. If a single user answer (password, preference, location, choice) would save ≥2 cycles of guessing, it must `ask_user` IMMEDIATELY with options. Repeating an identical tool call is banned.
> - **FLUID CANVAS THEME — THE WHOLE APP:** the accepted HTML design is now the app-wide skin: deep-navy `#060B16` canvas, sky→indigo `#38BDF8→#818CF8` signature gradient (send button, rails, hairline progress), blue-tinted glass surfaces, emerald semantic accents — dark AND light palettes rebuilt; every screen (chat, conversations, settings, skills, automations, credits, log) re-skinned through the one Material scheme. The chat backdrop got the **living nebula blobs** (two slow-drifting blue radials, reduced-motion aware).
> - **PERMANENT CODE LOG (never cleaned, multiple files):** every event in the app now ALSO persists to disk as a debugging code log: `logs/diag-YYYY-MM-DD.log` (everything), `logs/errors-YYYY-MM-DD.log` (warn+error fast lane), `logs/crash-<ts>.log` (full uncaught-exception stacks via an installed crash handler). Daily rotation = multiple files; lines capped; a low-priority daemon thread writes them; the Log screen shows the file inventory. Nothing is ever auto-deleted.
> - Tests: **341/341** (+8 RunProgressTest: repeat/stall/chatter detection, budget pressure, directive cap, mutating-tool classification).

> **v2.32.5 → v2.33.0 — THE FLUID CANVAS (design overhaul, from the v5 mockup):**
> - **CHAIN ANSWERS:** tool calls no longer render as chunky cards — every call is a **node on a quiet left rail** (mono tool label · ms · one-line result, tap to expand args/result). Consecutive rows stack into one continuous chain that reads like a live build log; failures turn their node red.
> - **STEERING (typed mid-run):** the composer stays open while the agent works — typing + send becomes a **STEER chip** (tertiary dashed pill, cancelable with ✕) that **auto-fires the moment the run finishes**. The input field is never disabled again; the send button morphs **➤ send → 🧭 steer → ⏹ stop → ✓** depending on run state.
> - **CONTEXTUAL LIVE PREVIEW PANE:** a docked pane that appears **only for coding tasks** — every `render_html` screenshot updates it live (check the front right in the chat) and `dev_server` fills its URL row (breathing live dot · mono URL · ✕ dismiss). Non-coding tasks keep the chat perfectly clean.
> - **HAIRLINE RUN PROGRESS:** the big run-status card is now a **2dp traveling gradient wave** (2026-style) + one slim phase pill (dots · phase · elapsed · stop) — the run is visible without eating the chat.
> - **MINIMAL BUBBLES:** user bubbles dropped the always-on timestamp (long-press still copies); quieter translucent fill.
> - Same 60-tool engine underneath — pure UI-surface overhaul. Tests: **333/333**.

> **v2.32.0 — THE CODING AGENT CORE: “explodes the terminal” + the EXPERT OPERATOR code:**
> - **RESEARCH:** audited what makes the 2026 terminal agents strong (Claude Code, Codex CLI, Cursor, Aider, OpenHands, SWE-agent, OpenCode, Cline, Gemini CLI, Goose) and ported the load-bearing abstractions into a real native app — no WebView shell.
> - **REPO MAP (aider's killer feature):** new `repo_map` tool — a compact, **ranked** map of any project (files, languages, LOC, imports, definition symbols with line numbers, ordered by references) so the agent navigates a big codebase without reading every file. 7 languages (Kotlin/Java/JS/TS/Python/HTML/CSS).
> - **RIPGREP-LITE `search_code`:** regex content search across the whole workspace — file:line hits with context lines, glob filters, junk dirs skipped. “Where is X used/defined?” is now one call.
> - **SURGICAL `patch` + MINI-VCS `snapshot`:** multi-file find/replace batches in ONE atomic call with per-op reports — and every patch auto-snapshots first. `snapshot create/list/diff/restore` gives git-less undo (restore even pre-snapshots the current state, so undo is itself undoable; files added after the snapshot are cleaned up on restore).
> - **`code_check` VERIFY GATE:** deterministic syntax checks — real JS parse via the on-device engine, JSON parse, brace/paren/string balance, Python indent sanity. The system prompt now forbids claiming code is done without checks + actually running it.
> - **WEB SESSIONS (the login killer-feature):** `http_request {session:'name'}` now carries a **persistent cookie jar** (.liman/sessions.json) — GET the form, grab the CSRF token, POST credentials, stay logged in across calls. List/clear built in. This makes the API-first route for “register me on this site” real.
> - **DEV SERVER + DOCTOR:** `termux_run {action:'dev_server'}` serves any workspace folder over HTTP via the local router (`/preview/`, phone + LAN URLs, correct MIME types) for instant live preview; `{action:'doctor'}` probes the whole Termux toolchain (node/python/pip/git/gcc/make/ffmpeg… + free disk) and suggests the exact `pkg install` line.
> - **BROWSER BRIDGE:** `device {action:'open_url'}` opens any URL in Chrome — then the `ui` tool (a11y snapshot → tap → type) drives the real page. The last rung of the web ladder before asking a human.
> - **EXPERT OPERATOR CODE (in the prompt):** a strict route ladder for acting on the user's accounts: **1 documented API → 2 undocumented API (network calls, /api/ routes, RSS, oEmbed) → 3 session login → 4 real browser automation → 5 human (only OTP/CAPTCHA/nowhere-existing passwords/payments)**. “Blocked ≠ impossible — it's a puzzle”; ≥3 alternative routes must be enumerated before any surrender; a blocker report needs evidence + the one missing key. Never fake success.
> - **CRAFT LAW (in the prompt):** repo-first navigation, test-first building, the verify gate, patch/snapshot surgery discipline, and “ship it — a live dev server beats a folder of files.”
> - **LESSONS (failure memory):** the same tool failing the same way twice auto-appends to `.liman-lessons.md` (read at every run start) — the mistake is never repeated in a later session.
> - **PROJECT CONVENTIONS:** `PROJECT.md` / `AGENTS.md` in a workspace are honored like law (the Codex-CLI convention), and `.liman-lessons.md` is surfaced in the environment block.
> - Tests: **333/333** (+15 CodeCoreTest: search/glob/context, repo-map symbols+ranking, patch atomicity+sandbox, snapshot create-diff-restore round trip incl. stray-file cleanup, web-session cookie jar persistence, structural/JSON/Python checks).

> **v2.31.0 — PLAN/BUILD, PER-CHAT WORKSPACES, MODEL SWITCHER & THE CREATIVE VECTOR ENGINE (Volume 3):**
> - **PLAN ⇄ BUILD MODE:** an animated segmented control at the top of every chat. In **Plan** the agent is the architect — the harness *blocks* mutating tools (deterministic gate, not a polite request) while it discusses options and researches; in **Build** it executes as always.
> - **ROADMAPS (the plan-mode deliverable):** the agent proposes a to-do list that renders as a card with **✓ Accept & build** / **Edit** buttons — edit it as plain text (one task per line), accept it, and the chat **auto-switches to Build and starts executing**. Every mission now shows as a **live checklist card** with an animated progress bar: ✅ done · ⏳ in progress · ⬜ pending — you always see which part is finished.
> - **QUICK MODEL/PROVIDER SWITCH:** tap the ⚡ model chip under the title → bottom sheet with every provider **and every model** (incl. free pools); one tap switches the combo. "All providers (failover)" is one tap away.
> - **PER-CHAT WORKSPACES:** every new chat gets its own file folder — one task's outputs never clutter another. The workspace sheet shows only this chat's files, and the new **＋** menu offers *Upload from storage* or *Browse all workspaces* (any file anywhere copies into the current chat and attaches). Legacy chats and scheduled missions keep the shared root (campaign state survives).
> - **SKILL LEARNING LAW:** after any substantial task (≥6 mutations) the `finish` tool now *refuses once* until the agent saves what it learned as a skill (Telegram/Bale bot wiring, API flows, build patterns…) — future runs start faster and cheaper. Second finish passes, so nothing deadlocks.
> - **RICH ANSWERS:** the markdown renderer got the treatment — big bold H1/H2 with accent underline, `==highlight==` marks for the key takeaway, task-list checkboxes, tables, code blocks; the system prompt now mandates structured, emoji-scannable, no-wall-of-text formatting.
> - **MINIMAL ANIMATIONS:** sliding mode indicator, animated roadmap progress, spring entrances (already there) — the UI moves like a product now.
> - **CRON + SUBAGENTS HARDENED:** the WorkManager periodic now uses `UPDATE` policy (worker code refreshes across app upgrades — the #1 "cron died after update" cause), a Settings row guides you through the **battery-optimization exemption** that makes schedules survive Doze, subagents **inherit the parent's workspace**, run under a 12-cycle focus cap, and report duration.
> - **CREATIVE VECTOR ENGINE (Volume 3 absorbed):** new `vector_studio` tool — **RULE 0: never freehand path data.** RETRIEVE real icons (Iconify API, sanitized + license ledger), GENERATE via **17 seeded deterministic recipes** (wave-divider, scallop, blob-organic, superformula, topo-lines, truchet, low-poly, grain, charts, identicon…), then pass two gates: a structural **validator** (path-data math, budgets, android-vd compatibility) and the **Slop Detector** (score 0–100: cliché palettes, blob backgrounds, precision noise, viewbox fit, security… every hit with a fix + nextAction; <20 and no high-severity hit or you don't ship). Plus the full **DIRECTION.md contract** (subject-derived motifs, locked palette, forbidden list, one bold thing) that kills rocket/lightbulb/purple-gradient defaults.
> - Tests: **318/318** (+29: VectorEngineTest 16, PlanAndRoadmapTest 5, WorkspaceTest 4, Markdown +4).

> **v2.30.0 — THE APP FACTORY & UI CRAFT (Engineering Blueprint Volume 2):**
> - **DESIGN SYSTEM KERNEL:** `design_tokens` tool — the token law (compose tokens, never raw hex/px), 5 complete design presets (swiss-minimal, soft-material, dark-terminal, neo-brutalist, glass-aurora) with light+dark token sets, 9 layout archetypes, and one-click generation: `tokens.css` + `kit.css` (component vocabulary with full state coverage) for web targets, `colors.xml` + `dimens.xml` for native scaffolds. One source of truth → web prototypes and native apps look identical.
> - **DETERMINISTIC UI LINT, STATIC:** `render_html` now also lints the source — raw hex outside token definitions, off-scale spacing, font budget (>2 families), missing viewport meta, CDN dependencies, missing `prefers-color-scheme`, `<img>` without alt, lorem ipsum, `alert()`/`confirm()`, emoji-as-icon, `!important` sprawl, 300 KB single-file budget. Every finding ships with a fix.
> - **DETERMINISTIC UI LINT, LIVE DOM:** every render runs an in-WebView audit script and reports tap targets <44px (with the offending elements), horizontal overflow, WCAG contrast failures (computed styles, with ratios), h1 count and alt coverage — objective quality gates the model must clear before calling anything "done".
> - **VECTOR-FIRST ASSETS:** `svg_icon` tool — 35 embedded stroke icons (24px grammar), the icon spec (viewBox/stroke/monochrome/adaptive 108dp·66dp safe zone), and a pure-Kotlin **SVG→VectorDrawable converter** (circle/rect/line/polyline→path, stroke attrs mapped, unsupported features like filters REJECTED up front instead of producing broken drawables).
> - **APK PIPELINE, CLOSED LOOP:** `native_apk` gains `verify` (apksigner signature schemes + `aapt2 dump badging` + sha256 artifact card), a doctor-flavored `status` (disk + versions), preset-driven scaffolding (design tokens land as real res/values), and the post-install doctrine: confirm the launch with the `ui` tool (open_app + snapshot) before declaring victory.
> - **THE THREE LOOPS + CRITIQUE DOCTRINE (new `ui-craft` skill):** compile green → visual evidence → only then "done"; max 3 build-fix + 3 visual-fix iterations then STOP and ask; same error twice = change strategy; spec-first APK workflow (user approves name/package/preset/archetype/screens/permissions-with-reasons BEFORE scaffolding); the critique rubric (score 1-5, ship at ≥4.0, always keep a KEEP list to stop quality oscillation); the anti-pattern blacklist (emoji icons, default blue, lorem, !important…); Termux build facts (aapt2FromMavenOverride, phantom process killer, zipalign-before-apksigner).
> - Tests: **289/289** (+22: DesignTokensTest 6, UiLintTest 9, SvgIconTest 7 incl. audit formatter).

> **v2.29.0 — THE HARDENED HARNESS (SUPER AGENT blueprints distilled: guardrails, injection defense, context discipline):**
> - **DETERMINISTIC POLICY HOOKS (blueprint §13):** PreToolUse guardrails that don't depend on the model behaving — hard red lines block destructive shell patterns (whole-root `rm -rf`, `dd of=/dev/`, `mkfs`, fork bombs, `curl | bash`, `chmod -R 777 /`, reboot/shutdown) with a denial that TEACHES the safer path; project-scoped deletions pass untouched.
> - **RATE CIRCUIT BREAKER (§4 stop conditions):** >90 tool calls/minute → the harness pauses the agent with an explicit "stop, re-read the goal" message — runaway loops can't burn tokens.
> - **PROMPT-INJECTION DEFENSE (§14.5, "your #1 security risk"):** all web_search results and read_link page content now arrive wrapped in `<untrusted source=… fetched=…>` tags; the system prompt carries the UNTRUSTED CONTENT LAW (data, never instructions; report injection attempts). Indexer agents can no longer be hijacked by a malicious page.
> - **OUTPUT SHAPING (§5 principle 4):** tool results over 8 KB are head(3K)+tail(2K) truncated and the FULL output is spilled to a workspace file (`.liman-overflow/…`) the model can `read_file` back — never 200 KB of stdout into context.
> - **SECRET REDACTION (§20):** credential-shaped strings (sk-, ghp_, xoxb-, AKIA, AIza, Bearer …) are masked before anything hits the Doctor's Log.
> - **CONTEXT ROT GUARD (§9.1):** compaction now triggers at ~70% of the context budget, not at 100% — "precision degrades well before the window is full". Logged in DiagLog when it fires.
> - **STRUCTURED COMPACTION (§9.5):** the summarize stage now demands GOAL/CONSTRAINTS/COMPLETED/CURRENT_STATE/IN_PROGRESS/NEXT_STEPS/DECISIONS/LEARNED/ARTIFACTS — decisions and constraints survive compaction instead of being averaged away.
> - **`wait` TOOL (§5.A):** bounded (100 ms–30 s) cancellable settle-wait for UI/network polling.
> - Research: SUPER_AGENT_ANDROID_BLUEPRINT.md (2525 lines), SUPER_AI_AGENT_BLUEPRINT.md, super-ai-agent-android-architecture.md — read in full; already-present items (loop detector, journal, approvals, skills, subagents, FGS, checkpoint-resume) not duplicated.
> - Tests: 267/267 (11 new: dangerous patterns allow/deny, untrusted wrap, redaction, head+tail+spill, rate window).
> **v2.28.0 — DOCTOR'S LOG + THE CYCLE-BUG FIX + TERMUX SELF-HEAL (make Liman itself the super agent):**
> - **THE CYCLE BUG (found & fixed):** HeroMode's "all talk, no action" detector matched conversational closers ("let me know if…", "sure, I can…", Persian می‌کنم) and REJECTED friendly replies to simple chats — injecting "ACT NOW" nudges that forced tool calls and cycle-after-cycle on "hi". Now: a **conversational guard** (no command verb in the ask + no tools yet = a chat reply is a COMPLETE answer, never nudged) + announcement regexes tightened to require real action verbs. Real announcements on command tasks are still rejected as before.
> - **DOCTOR'S LOG (the Log button):** a 📋 button in the chat top bar opens the backend log — every agent run (goal, cycles, provider/model, tokens), every tool call (ok/FAILED + ms + result head), hero nudges, compactions, ceilings, cron fires, and all bridge errors, in a capped in-memory ring. **Export .md** writes a full diagnostic report (device, version, session stats, full event timeline, errors-only section) you can attach when reporting a problem.
> - **TERMUX DEPENDENCY SELF-HEAL:** `command not found` / `ModuleNotFoundError` no longer dead-end a run — the bridge diagnoses the missing binary/module (bash/sh/zsh formats), auto-runs `pkg install`/`pip install` ONCE, retries the command, and reports what it did. Binary→pkg map covers python, pip, node/npm, git, ffmpeg, jq, cargo, clang, ssh, tmux…
> - **SIMPLICITY DOCTRINE in the system prompt:** match effort to the ask — pure conversation gets direct short replies with ZERO tools; simple tasks get the fewest steps; code is minimal and runnable; prefer a one-line shell command over writing a program.
> - Tests: 256/256 (11 new: conversational guard, announcement regression, self-heal diagnosis incl. zsh, heal report, log ring/markdown/trim).
> **v2.27.0 — THE SUPER AGENT PACK (5-repo research distilled: perception, anti-fragility, ceilings, variables, slash, knotwork style):**
> - **UI tool got EYES (droidclaw × agent-device):** `ui snapshot` dumps the current screen as a compact, ref-addressable list (`@e3 [button] "Add"`) from the accessibility tree — interactive elements only, 60-cap, token-efficient; `ui tap` accepts refs from the latest snapshot. The system prompt now teaches the full perception→act→verify loop.
> - **Anti-fragility guard (droidclaw's five):** STUCK (screen unchanged across 3 snapshots → change approach), REPETITION (same target 3+ times → stop and re-snapshot), DRIFT (5 navigation-only actions → interact instead of wandering). Hints are appended to tool results in real time; drift outranks repetition for nav-only sequences.
> - **Run token ceiling (knotwork):** whole-run-tree budget (default 400k, Settings → Agent, 0 = off). A looping automation cannot quietly burn tokens — the run pauses with an explicit `run_ceiling` note instead of looking broken.
> - **Prompt variables (knotwork):** scheduled tasks render `\$DATE $TIME $WEEKDAY $LANG $DEVICE $MODEL $BATTERY $USER` fresh on every fire — "brief me at $TIME" resolves the actual time, never a stale date.
> - **Slash commands (openclaude):** `/stop`, `/new`, `/clear`, `/help` act client-side in the composer; unknown slashes pass through to the agent.
> - **knotwork design system:** layered surface ramp (S0–S4 blue-tinted), LOCKED signal hues (success/warn/error — never re-themed), tonal chat-bubble pairs (user bubble is a tinted container, not a gradient), asymmetric knotwork bubble geometry (16/16/4/16 mirrored), Today/Yesterday date chips, tonal send affordance. Share-target, 3-stage auto-compact and archive were audited — already present.
> - Research: unitedbyai/droidclaw, Gitlawb/openclaude, opencode-ai/opencode, callstack/agent-device, alexeyw/knotwork (READMEs + design tokens read in full).
> - Tests: 245/245 (11 new: refs, kinds, signatures, stuck, repetition, drift, variables, ceiling math).
> **v2.26.0 — DEBUG-IT-YOURSELF BUILDS + BLUE THEME + TRUE RTL (user-reported bugs from real phone use):** Three live bugs + two design asks, all fixed.
> - **Bug 1 — mission "unknown task id 'probe'":** models invent task ids. `MissionTracker.resolveTaskId()` now resolves exact → case-insensitive → 1-based index ("2", "#2", "task 2") → goal-text → id-fragment; unknown ids return a TEACHING error that lists the valid ids plus the current plan (one-retry recovery). The mission tool also accepts `taskId|task_id|id|task` aliases and an `update` action.
> - **Bug 2 — native_apk builds failing on classic Kotlin gotchas** (both real logs from the user's phone): (1) `actual type is 'Long', but 'Int' was expected` — hex literals >= 0x80000000 are Long in Kotlin but Android color APIs take Int; (2) `obj::prop.isInitialized` is illegal for another object's property. New **`NativeBuilder.buildHints()`** scans failed build logs for these signatures and appends targeted `[FIX HINT]` paragraphs (exact code patterns to write), and **`cleanJobLog()`** strips the LIMAN_JOB_EXIT/DONE plumbing lines so the agent sees only real errors. The SystemPrompt native_apk doctrine now teaches both gotchas up front. Result: the agent repairs generated Kotlin in ONE rebuild instead of guessing.
> - **Bug 3 — English words misplaced inside Persian paragraphs:** RTL was decided for the WHOLE message (one Persian paragraph + one English/code-heavy message → everything LTR → broken bidi). `Markdown.kt` now detects Persian **per block** (headings, paragraphs, bullet/ordered items, quotes each get their own direction via an Rtl layout wrap + full-width fill), so a Persian paragraph renders right-to-left with English words flowing in the right places, while the English paragraph right below stays LTR. Code blocks stay always-LTR.
> - **Theme → blue:** the "Signal" palette's mint primary became **azure** (dark: 0xFF8FC1FF primary + navy containers + blue-tinted neutrals; light: 0xFF2563EB primary) — rails, pulses, chips, input accents all follow. Semantic success/warn keep their green/apricot meaning.
> - **Interface polish (minimal):** airier message rhythm (10dp gaps, 14/12 padding), softer asymmetric bubble corners (20/20/6/20 user, 8/20/20/20 assistant with a gentler hairline), crisper input-bar border, more present suggestion chips.
> - **Tests: 254/254 green** (14 new: mission fuzzy resolution incl. index/goal/id-fragment + teaching-error data + update-through-fuzzy; build hints for Long/Int, ::isInitialized, jansi noise, dedup, clean-log; per-block Persian detection on the user's exact mixed-paragraph case).
> **v2.25.1 — 9ROUTER GOES CLOUD (Termux path retired, combos-first provider):** The user's verdict: *"doesn't work, forget it — I made it on another server"* (their own 9Router deployment at **https://9router-production-5f97a.up.railway.app/**). Everything Termux-install is removed; the integration now connects to the user's server like any OpenAI-compatible provider — with COMBOS as first-class citizens.
> - **Probed the live server first**: `/api/health` → `{"ok":true}` · `/v1/models` → requires `Authorization: Bearer <key>` · `/api/combos` → dashboard-session only (NOT the API key), so combos are read from `/v1/models` instead — where the 9Router source (`src/app/api/v1/models/route.js`) pushes them FIRST with `owned_by:"combo"` and the combo's NAME as the id.
> - **`agent/NineRouter.kt` rewritten (cloud edition)**: URL derivation (`originOf`/`dashboardUrl` — the dashboard button opens `<origin>/dashboard` in Chrome), `normalizeBase` (pasting just the server link auto-appends `/v1`; strips `/models`, `/chat/completions`, trailing slashes), `parseCatalog` (splits the `/v1/models` answer into **combos** vs **plain models**, combos first), `fetchCatalog` + `isUp` health probe, and `ensureProvider` (create-or-update the "9Router (my server)" provider — default endpoint baked in).
> - **Provider editor (Settings → Providers → 9Router)** — exactly as asked: **"Open 9Router dashboard in Chrome"** button (the user's link), the standard Base URL + API key fields like every other provider, and the fetch button is now **"Check key & fetch my combos"** — it lists the server's combos first (⚡ combo badge, tap to use as the model) followed by plain models; a blank model auto-picks the first combo. The preset's default base URL is the user's Railway deployment.
> - **`nine_router` tool reworked** to the cloud actions: `status` · `open` (dashboard in Chrome) · `combos` (the user's combo list — the preferred models) · `models` · `connect {api_key, model}` (verifies the key against `/v1/models` before saving; auto-defaults the model to the first combo). SystemPrompt doctrine updated to match; the Termux-era actions are gone.
> - **Tests: 240/240 green** (NineRouter suite rewritten for the cloud contracts: URL derivation incl. bare-origin → `/v1`, dashboard derivation, catalog parsing with `owned_by:"combo"` separation + garbage tolerance, tool-spec assertions that the combo actions exist and the Termux actions are gone).
> - Honest scope: endpoint shapes were verified against the user's live server and the 9Router source; the key-authenticated fetch (`/v1/models` with the user's real key) is the one path that could not be exercised here (no valid key in this sandbox) — first in-app "Check key & fetch my combos" is the real test.
> **v2.25.0 — THE REAL 9ROUTIER ON THIS PHONE (Termux bridge + provider + combos):** The user's directive: *"now that I installed termux, I wanna run 9router and use it on my liman, the real 9router… the liman must use the termux bridge and run 9router and add a button link in liman to open 9router and then everytime I open liman and ask for setup 9router it make it and send the local url to open in chrome and then make api key in dashboard of 9router and with using api key and endpoint of 9router open combos… then add a new provider part for 9router that get endpoint link and api key and reach combos models providers and others"* — delivered against the real repo ([decolua/9router](https://github.com/decolua/9router), MIT, 28.7k★: npm `9router`, 40+ providers, free tiers, OAuth, combos with fallback/round-robin/fusion, RTK token saver).
> - **`agent/NineRouter.kt`** — the whole lifecycle, distilled from the repo's README + CLI: status probe (node / CLI / server / data dir), one-time install (`pkg install -y nodejs-lts` + `npm install -g 9router`) run as a **v2.24.1 background job** (base64 payload + EXIT trap + polling — the install takes minutes and must not hang the bridge), daemon start (`nohup setsid 9router --port 20128 --no-browser --skip-update`, detached — a server never exits so it is deliberately NOT an exit-marker job), self-safe stop (`pkill -f '9r[o]uter'` — the bracket pattern can't match its own script), HTTP health polling from Liman itself (same device → 127.0.0.1 works), `/v1/models` listing (combos included — they are model ids), and `ensureProvider` (create-or-update the Liman provider entry).
> - **`nine_router` tool** — actions: `status` · `setup` (**the one-ask flow**: bridge check → install if missing → start → wait for health → **auto-opens the dashboard in the browser** and returns the local URL) · `start` / `stop` · `open` (button-equivalent for the agent) · `models` (live model ids incl. combos) · `connect {endpoint, api_key, model}` (verifies the key against `/v1/models` BEFORE saving, then upserts the provider — argument-alias tolerant per v2.24.1).
> - **Settings → 9Router (the real one)** — the dedicated provider part: endpoint field (default `http://127.0.0.1:20128/v1`), API-key field, model field, live ●/○ server status, **"Setup & start in Termux"** (runs the full flow with progress), **"Open 9Router dashboard in browser"** (the button link), **"Test & save as Liman provider"** (probes the endpoint with the key, lists the live models, saves — first model auto-picked when blank). Once saved it is a normal enabled provider: **it joins any combo** (failover / round-robin / race), and 9router's own combos/combo models work inside it as model ids.
> - **Port layout honored**: 20128 = the REAL 9router (reserved since v2.10.1), 20129 = Liman's own mini-router — both can run side by side. The `9router` provider preset's hint now points to the automatic flow instead of the old manual `~/9router.sh`. SystemPrompt doctrine + TOOLS table teach the agent the setup→key→connect sequence, and "setup 9router" stays a least-cycles task (one tool call, no planning ceremony).
> - **Tests: 244/244 green** (11 new: URL builders, script contracts — npm install of the real package, headless detached daemon flags, no-exit-marker assertion for the server job, self-safe pkill pattern proof, jobWrap decode round-trip, OpenAI-shaped model parsing incl. combo ids + garbage tolerance, tool registration + schema validity, least-cycles phrasing, missing-arg teacher).
> - Honest scope: the Termux-side scripts follow the repo's documented install/run interface (`npm install -g 9router`, `--port/--no-browser/--skip-update`, dashboard `/dashboard`, API `/v1`) but could not be executed against a real phone in this sandbox — first on-device `setup 9router` is the real test. Credit: 9Router by decolua (MIT).
> **v2.24.1 — THE RELIABILITY PATCH (argument unwrapping, background Termux jobs, least-cycles agent):** The user reported three real-world bugs from live use with free models; all three diagnosed from the actual chat logs and fixed at the root.
> - **Bug 1 — "Missing 'name'/'command'/'action'" on most tool calls.** Root cause (confirmed in logs): models often wrap tool arguments in an extra layer — `{"arguments":{"command":"ls"}}` instead of `{"command":"ls"}` — so strict tools saw no keys. New **`agent/ArgsNormalizer.kt`**: every tool call is normalized before dispatch — unwraps `arguments/parameters/params/args/input/tool_input/tool_arguments/function_call/function` wrappers (≤3 layers, inner wins on merge), parses string-encoded JSON args, and never touches flat or legitimately-named arguments. Plus alias tolerance everywhere: files accept `name|path|file|filename`, content `content|text|data`, commands `command|cmd|script|command_line`, actions `action|action_name|op`. And when an arg is truly missing, the error now TEACHES: it shows exactly which keys arrived + a flat-argument example, so even a weak model recovers in one retry.
> - **Bug 2 — `native_apk setup` dying as "No response from Termux".** Root cause: a multi-minute install (pkg + 65 MB download) sent over one bridge call that outlived the timeout. New **background-job mode in `NativeBuilder`**: `jobWrap()` ships the whole script base64-encoded (zero quoting hazards), runs it under `nohup` with an `EXIT` trap that always writes `LIMAN_JOB_EXIT_<code>` to the job log (even mid-script aborts), then the agent polls a 3000-byte log tail every ~15 s — launch call ≤90 s, setup budget 20 min, build 15 min, and a timeout returns a "still running, check later" hint instead of hanging.
> - **Bug 3 — simple tasks burning full planning + review cycles** ("write an md report of our chat" ran an 8-step plan). New `TaskHeuristics.isSimpleTask()`: short prompts with no multi-step markers skip planning entirely, and light tasks (≤3 tool calls) skip the self-review round. Word-boundary guarded so "happy" ≠ "app". SystemPrompt gained the **LEAST-CYCLES doctrine**: one tool call + finish for simple asks, flat arguments always.
> - **Tests: 233/233 green** (19 new: wrapper unwrapping incl. nested/string-encoded/no-false-positives, merge precedence, depth cap, missing-arg teacher, simple-task heuristics incl. app/apk/automation edge cases, jobWrap base64+trap decode proof, poll script contract, job outcome parsing).
> - Honest scope: the argument normalizer, heuristics and gating are fully unit-verified, but the Termux background-job path (nohup + trap + polling) follows the standard pattern and could not be exercised against a real phone in this sandbox — first on-device `native_apk setup` + `build` is the real test.
> **v2.24.0 — STORY MOTION STUDIO (video-shotcraft integration):** The user's directive: *"read this repo carefully and add it to Liman… I make story motion a lot… best prompt engineering to make story motion or motion graphics using this repo… need the final html or code publish + mp4 high quality export"* — delivered. Liman gained a full cinematic motion studio distilled from **[Vincentwei1021/video-shotcraft](https://github.com/Vincentwei1021/video-shotcraft)** (Apache-2.0, 8.3k★ — 157 shot recipe cards, the promo energy arc, 27 case-law aesthetic rules, an 8-stage pipeline).
> - **`agent/MotionKit.kt` — the deterministic runtime**: a self-contained HTML/CSS/JS motion engine inlined into every project (so each motion.html is independently publishable and plays in any browser). Determinism law enforced: seeded mulberry32 randomness only, `Math.random()`/`Date.now()` forbidden; export contract `__limanSeek`/`__limanReady`/`__limanDuration`; tuned vocabulary from the repo (outCubic/outExpo/outBack/dampedSettle, the entrance three-piece y+blur+opacity on ONE ease, word stagger, typewriter, 2.5D camera). **Verified by real execution in Node**: deterministic seek, clamping, easings, PRNG seeds, typewriter, the export contract — all pass.
> - **`agent/MotionStudio.kt` — the prompt engineering**: planning brief (3 modes: FAST / CREATIVE-autonomous / CO-CREATE), the energy-arc slot table (brand open 8-12% LOW → single hero 12-15% → feature climb 55-65% alternating → launch finale PEAK + breathing cards), the case-law rulebook (R1 land-and-hold ≥1s, R2 speed=acceleration, Q4 no group glints, Q5 one hero, Q8 launch group photo, Q1 real screenshots for real pages…), a distilled shot catalog across all 10 categories (brand-ink-open, spotlight-hero-card, deck-deal-flyin, blur-slide, orbit-ring-title-open, before-after-slider-scrub, ai-stream-response, outro-group-photo-launch…), and the full handbook written to `workspace/motion/STUDIO.md`.
> - **`agent/MotionRecorder.kt` — high-quality MP4 export, fully on-device**: renders the deterministic timeline frame-by-frame through the phone's own WebView (software raster → ARGB bitmap) → BT.601 YUV420 conversion → MediaCodec H.264 (1920×1080 @30fps, ~14 Mbps, bit-exact presentation timestamps) → MediaMuxer MP4. No Termux, no ffmpeg, no cloud.
> - **`motion` tool**: `plan` (the doctrine) | `create` (project scaffold: motion.html + storyboard.md + handbook) | `list` | `export` (determinism gate → frame-perfect MP4 + progress notifications). SystemPrompt doctrine added: story motion requests follow the studio pipeline and always deliver BOTH the publishable HTML and the MP4.
> - **Tests: 214/214 green** (8 new: runtime contract + determinism law, scaffold publishability, handbook doctrine, export gate, recorder frame math + RGB→YUV sanity, tool registration) + the real-Node execution proof above.
> - Honest scope: the MP4 recorder (WebView+MediaCodec) follows the canonical Android pattern but could not be executed in this sandbox (no device) — first on-device export is the real test; the runtime, scaffold, doctrine and gate are fully verified. Credit: video-shotcraft by Vincent Wei (Apache-2.0); shot vocabulary and rules are his — distilled with credit inside the handbook.

> **v2.23.0 — SUPER AGENT (the 20-feature mega-update + the GitHub Research Engine):** The user's directive: *"add all of these… lets make Liman SUPPPPER AGENT"* — plus a new first-class capability: **when facing any task or coding project, Liman now researches GitHub FIRST** — searching repositories by title/README, diving deep into the best repo's code (README → file tree → individual files), and adapting/running what it finds. That's now doctrine #1 in the system prompt for building.
> - **`github` tool (Research Engine)**: search (queries + language filter), research (composite: search + auto-fetch top-3 READMEs), readme / tree / file deep-dive. Free without a token (60 req/hr); `github {action:'token'}` stores a PAT privately for 5000/hr. License honesty built into the doctrine (credit repos; MIT/Apache fine, GPL asks the user).
> - **Semantic memory**: memory_recall now BM25-ranks saved memories AND past conversations by meaning ("what did we decide about X?" now finds it) — zero keys, fully offline.
> - **Journal + Morning Briefing**: Liman writes its own day-book (workspace/journal/YYYY-MM-DD.md); `briefing write` aggregates journal + missions + watcher changes + notification pulse + urgent items; a daily 08:30 briefing mission seeds itself — the agent now INITIATES.
> - **Web watchers (`watch`)**: monitor any URL, extract text or a regex capture group, report only CHANGES (+notify +journal). Pair with schedules — price drops, visa slots, exam results.
> - **Context triggers (`trigger`)**: charging_on/off, battery_low/ok, screen_on/off, wifi_on/off, boot — each runs a full headless agent cycle with cooldown spam-guards. Dynamic receivers + BOOT_COMPLETED; `survival` installs the Termux boot kit (wake-lock + crond, Termux:Boot app required).
> - **Notification digest (`digest`)**: groups NOTIF lines by app, flags urgent via user regexes, delivers windowed digests — additive (Android can't suppress others' notifications; honest in-tool).
> - **Self-improvement (`evolve`)**: retrospection over recent missions (tool stats, failures, goals, skills, journal) → the agent drafts skills and corrections with user approval, never silently.
> - **Plugin packs (`pack`)**: export/import whole setups (skills + pipelines + triggers + watchers) as one zip (workspace/packs/).
> - **Local brain (`local_ai`)**: llama.cpp inside Termux serving an OpenAI-compatible endpoint on 127.0.0.1:8085 (Qwen2.5-0.5B/1.5B Q4 GGUF) — zero API keys, offline, private; add as a provider or first hop of a combo. Honest: a 0.5B model is light-text work only.
> - **On-device OCR (`ocr`)**: tesseract in Termux over the bridge (base64 image transfer, like the APK factory) — no APK bloat, ~40 languages.
> - **Reachability**: Quick Settings tile, system-assistant intent (long-press home → Liman), device location action (termux-location, powers geofencing-lite pipelines; needs Termux:API).
> - Already present from earlier versions and confirmed during the audit: voice input+TTS, Telegram gateway, knowledge RAG, team/squads, profile, demo recorder (macro recording), share-sheet.
> - **Tests: 206/206 green** (20 new SuperAgentTest cases: GitHub URL/parse/rate-limit, BM25 ranking, journal/briefing, watcher extraction/diff/store, trigger mapping/cooldown, digest parse/window, evolve stats, pack roundtrip, local-brain/OCR scripts, tool registration).

> **v2.22.0 — THE NATIVE APK FACTORY (real Kotlin, compiled on this phone):** The flagship upgrade the user demanded: *"I don't need that old HTML-to-APK! I need a real application with a real native language."* — delivered. The new `native_apk` tool scaffolds a REAL Kotlin Android project (actual `MainActivity.kt` sources, `AndroidManifest.xml`, `res/` — framework APIs only, no Gradle) and then **compiles it on-device via the Termux toolchain**: `kotlinc → d8 (dx fallback) → aapt2 link → zip → zipalign → apksigner`. The result is a genuine, signed, installable APK of the agent's own Kotlin code — not a WebView shell.
> - **New `agent/NativeBuilder.kt`**: project scaffolding (package validation, `slugify`, programmatic-UI MainActivity template), one-time Termux setup script (`pkg install openjdk-17 kotlin aapt2 apksigner dx zip unzip curl` + official Google `android.jar` API 33 + debug keystore), environment probe, the verified 6-step build script (project files travel TO Termux base64-embedded; APK returns in md5-verified 256 KB base64 chunks over the bridge, 6 MB ceiling).
> - **Pipeline verified end-to-end before shipping**: the exact scaffold template + exact script shape ran through real kotlinc 2.0.21 + d8 + aapt2 + zipalign + apksigner on the same android.jar URL the phone uses → 1.38 MB signed APK; the reassembled chunked transfer was byte-identical with matching md5 and a verified signature. (Sandbox verification; on-device compilation runs in the user's Termux — the setup step is one-time, ~265 MB.)
> - **Tools**: `native_apk` with `status | setup | scaffold | build`; builds notify the user; `build_apk` (WebView shell) stays as the honest offline fallback. SystemPrompt doctrine updated: native-first for app requests.
> - Deliberate choices: API 33 platform (Termux's aapt2 breaks on SDK 35+ jars), openjdk-17 + d8 (JDK 21/dx incompatibilities), `javac` fallback if a project has only Java sources, `zipalign` skipped gracefully if absent (v2 signing tolerates it).
> - Tests: **186/186 green** (10 new `NativeBuilderTest` cases: scaffold shape, package rules, pipeline-command pinning with escape checks, setup/probe scripts, chunk roundtrip with md5 tamper detection, build-marker parsing, transfer caps).

> **v2.21.0 — THE AUTOMATION LAYER (demonstration → automation, self-forged
> tools, pipelines, storage doctor):** the Termux-Liman bridge got the
> "make it real" stack. **UI bridge** (new `ui` tool + accessibility service,
> enable once in Settings → Accessibility): `record_start/stop` captures a
> DEMONSTRATION — every screen, tap, typed text and scroll logged as a
> readable procedure the agent distills (what happened, why, which parts are
> variables) and then automates or replays; plus `tap/type/scroll/back/home/
> open_app` actions to drive apps with NO API (Instagram, Bale, …) — the last
> missing piece of cross-platform pipelines. **Tool forge** (`tool_forge`):
> the agent BUILDS NEW TOOLS at runtime — sandboxed JS (always available,
> smoke-tested before registration) or real Termux python (base64-embedded,
> stdin/stdout JSON contract) — registered instantly, persisted in
> workspace/tools/, auto-loaded every future run: "make a tool that extracts
> the numbers from these PDF reports" now literally works. **Automations**
> (`automation` tool + new Automations screen ⚡): standing pipelines —
> trigger (daily / every 15+ min / manual, activeHours respected) + ordered
> STEPS (fetch / transform / filter / dedupe / output / notify) where
> transform is the universal AI node (translate, summarize, rewrite,
> classify) — synced onto the scheduler, running unattended with state files
> so nothing repeats; "＋ New automation: describe it once" builds it. Sub-hour
> `everyMinutes` missions enable true watchtowers ("monitor until
> registration opens → notify"). **Storage doctor** (`storage_scan` /
> `storage_clean`): intelligent triage of granted folders into SAFE /
> REVIEW / KEEP with reclaimable bytes — and cleanup is ALWAYS undoable:
> quarantine-to-vault + manifest + one-command restore. The system prompt
> gained the MAKE-IT-REAL doctrine (idea → questions → build → verify → save
> skill → automate/package) and QA-testing ethics (own/authorized targets
> only, never mass-account-creation or anti-abuse evasion).

> **v2.20.0 — THE SYNTHESIS (framework best-of breed):** the 8 top open-source
> agent frameworks were studied and their core capabilities ported into Liman.
> **Run checkpointing + crash resume (LangGraph)** — after every cycle the
> full run state (goal + transcript) is snapshotted to disk; if Android kills
> the app mid-run, the chat shows an "⚡ Interrupted run recovered" banner and
> RESUME continues from the exact cycle that died, with an explicit
> do-not-redo-work instruction. Normal exits clear the checkpoint, so a
> surviving file always means "crashed mid-run". **Private library — on-device
> agentic RAG (Agno + RAGFlow)** — knowledge_add ingests documents (recursive
> paragraph-respecting chunking, ~15% overlap), knowledge_search runs
> MULTI-QUERY BM25 retrieval (2-4 phrasings scored independently, merged
> across docs) with exact doc#chunk citations; zero external embedding APIs —
> fully offline and free. System prompt doctrine: search the library FIRST,
> web only fills gaps. **Crew orchestration (CrewAI + AutoGen + Agno)** — the
> new team_run tool dispatches a full crew in one call: roles
> (role/goal/backstory) + tasks with expected outputs; process = sequential
> (outputs chain as context, CrewAI-style), broadcast (parallel independent
> evaluation, Agno) or hierarchical (a manager subagent plans the delegation
> order); AutoGen termination conditions: a worker replying "TERMINATE:
> reason" ends the run, plus hard task caps. **Heartbeat discipline
> (OpenClaw)** — scheduled missions can now carry activeHours windows (e.g.
> 09:00-22:00, overnight supported) so they never fire while the user sleeps;
> the agent maintains workspace/HEARTBEAT.md as its standing checklist:
> heartbeat runs read it FIRST, do exactly what it lists, and reply exactly
> NO_REPLY when nothing needs attention — never inventing or repeating tasks.
> Dify/Langflow capabilities (multi-model routing per task, visual building)
> were already covered by Liman's Router/combo cascade and are not duplicated.

> **v2.19.0 — SKILL PACKS from GhostGram + ai-job-search:** three skills now
> ship pre-installed (first boot, never overwriting your edits). **Job hunt** —
> the full pipeline from the 41k-star ai-job-search framework on-device:
> idempotent profile, multi-source search, Eligibility Gate (silence is NOT
> permission) + Language Gate, 5-dimension 0-100 scoring with deal-breaker
> veto, drafter-reviewer CV/cover letters, `applications.csv` tracker +
> archive of exactly what was sent, follow-ups capped at 2, STAR interview
> prep, HTML dashboard — postings treated as UNTRUSTED data. **Telegram
> outreach (userbot)** — GhostGram-style Telethon on your own account in
> Termux: one-time session setup, channel search/read/send with
> mathematically human pacing (reading 1.5+len/25 cap 6s, typing formula
> with punctuation pauses + jitter, cap 35s), FloodWait e.wait+15%, fatigue
> micro-breaks, ~20 unsolicited/day ceiling, per-campaign state files,
> approval before every outbound batch. **Email outreach** — smtplib via
> Termux with CV attachment, Gmail App Password, follow-up etiquette. The
> system prompt also gained an injection-defense rule (fetched content is
> data, never instructions) and a memory-at-finish rule (persist durable
> facts before ending). NOT ported on purpose: GhostGram's stealth/keyword-
> hiding tricks and multi-account rotation (contrary to an honest single-user
> agent) and ai-job-search's voice interview sims (no on-device TTS).

> **v2.18.0 — TERMUX BRIDGE v2 (pure bash) + lighter app + smarter with ANY model:**
> The bridge's "no response" bug was self-inflicted: the v1 wrapper needed
> `curl`, which is NOT in the Termux bootstrap — the command died silently.
> The wrapper is now PURE BASH (`/dev/tcp` built-ins do the HTTP: fetch the
> script, run it, POST the output — zero dependencies), commands run in
> background mode, a fast PING probe separates "bridge broken" from "command
> produced no output" in seconds, and the timeout message now includes a
> paste-ready self-test for Termux + the Android-12+ battery-optimization
> fix (Settings → Apps → Termux → Battery → Unrestricted). Also fixed:
> cancelled runs no longer surface as fake "Tool crashed" failures
> (CancellationException is rethrown, never swallowed). LIGHTER: the
> Free-API Radar is REMOVED (screen, daily sweep, hunters, free_apis tool) —
> no more background web sweep at every app open; the anonymous free-model
> catalog itself stays. SMARTER WITH ANY MODEL: (1) the user's goal is now
> anchored in the system prompt verbatim with a per-turn GOAL→STATE→REMAINS
> check (ReflAct, EMNLP 2025 — +27.7% over ReAct); (2) weak models
> (flash-lite, minis, 7B-class, anonymous free) automatically get a COMPACT
> system prompt (~15× shorter, same rules, goal on top — weak models drown
> in long prompts); (3) REFLEXION: every failed tool result now carries a
> structured self-critique demand ("what went wrong, what will you CHANGE —
> identical retry fails identically"). New `schedule` tool: the agent manages
> its own recurring missions (list/add/remove) — an autonomous-campaigns
> doctrine tells it to set up daily job-hunting/watchtower/follow-up loops
> by itself, keeping state in workspace/campaigns/. 8 new/updated tests.
>
> **v2.17.0 — THE TERMUX BRIDGE: real node/npm/python/git in YOUR Termux:**
> "Can Liman run npm code or connect to Termux?" — now it genuinely can.
> New `termux_run` tool: the agent sends a real bash command into the
> user's Termux via the `com.termux.RUN_COMMAND` intent (the same mechanism
> Tasker uses) and gets full stdout/stderr back. Transport rides Liman's
> own local router: Termux fetches the script at
> `127.0.0.1:PORT/termux/script/{id}` (`curl | bash`), runs it in a real
> bash (workdir ~), and POSTs the output to `/termux/result/{id}`; the tool
> awaits and returns it. That unlocks REAL node + `npm install`, python,
> git, ssh, ffmpeg — the user's whole Termux toolbox — driven by the agent,
> on-device. One-time setup (surfaced in Settings → 🐚 Termux bridge with a
> status panel and a Grant-permission button, and auto-relayed by the tool
> itself when missing): Termux installed (F-Droid), `pkg install curl`,
> `allow-external-apps = true` in `~/.termux/termux.properties`,
> `termux-reload-settings`, grant RUN_COMMAND. npm support also already
> worked before this (pure-JS `require()` on-device + Node.js 20 on the
> online runner) — the bridge adds the REAL thing with native modules.
> 5 new tests (wrapper command shape, script/result round-trip, late-result
> await, Termux intent constants).
>
> **v2.16.0 — MEGA AGENT (the ORION doctrine):** the maximal-autonomy
> upgrade. New COGNITIVE ENGINE in the system prompt: pre-action gate
> (define the EXPECTED proving output BEFORE running anything),
> hypothesis-driven debugging (read the literal error → ≥2 hypotheses → one
> discriminating test, one variable at a time), the ROUTE-CHANGE LADDER
> (RETRY → RE-TOOL → RE-STRUCTURE → RE-PLATFORM → RE-SCOPE, with side-doors:
> RSS/sitemap/oEmbed/mobile-API), PRE-MORTEM before deploys, ANNOUNCE-then-DO
> for irreversible effects, human-only facts (OTP/QR/passwords — ask
> instantly, everything else route around), PROVEN/LIKELY/GUESSED confidence
> labels + an evidence table in every final answer, and "a task where you
> learned nothing is a failed task". New TOOLS: `mission` (MISSION CONTROL —
> decompose into tasks with machine-checkable acceptance criteria, checklist
> checkpoints, T-FINAL re-verifies everything), `skill_create` (SKILL FORGE —
> distill every non-trivial success into a reusable skill; competence
> compounds), `device` (PHONE BRIDGE — battery, clipboard, vibrate,
> notifications). Subagents gained ROLES (scout/architect/builder/runner/
> verifier/deployer/auditor) + constraints + acceptance-criteria brief
> contracts. New ⏰ CRON ENGINE (Settings → Scheduled missions): any prompt
> runs daily at HH:MM or every N hours as a full headless agent cycle
> (WorkManager, survives app close) — daily briefings, watchtowers that
> notify on change, weekly self-doctor, any recurring job; results land as
> their own conversation + notification. Safety teeth: backup-before-
> destructive (deletes/overwrites snapshot to workspace/.trash first) and
> SECRETS REDACTION — API tokens are masked in the chat UI (the model keeps
> the real values; the screen never shows them). 12 new tests.
>
> **v2.15.0 — CREDIT METER: a live dashboard of everything you spend:**
> "I NEED to know how much credit I use for each chat and each provider to
> control it myself." Every model call Liman makes is now recorded — tokens
> in/out, request count and an ESTIMATED USD cost from a built-in price
> table (Gemini, GPT, Claude, DeepSeek…; free-tier & unknown models are
> counted in tokens only — never a made-up dollar number). The new
> 💳 Credits & Usage screen (top bar of the conversations list) shows it
> all LIVE while the agent runs: total estimated spend + today, a 14-day
> cost-per-day bar chart, breakdown per PROVIDER (proportional cost bars),
> per MODEL (with each model's price or "free"/"unknown" tag), per COMBO
> (every provider in the current combo and its usage), and per CHAT (top
> spenders with titles) — plus a reset button to wipe history. Subagent and
> reviewer calls are attributed to the parent chat, so a run's true cost is
> never hidden. Usage persists across restarts (usage.json).
>
> **v2.14.0 — HERO MODE: the agent EXECUTES instead of narrating:**
> The #1 complaint: "I asked it to use my Cloudflare tokens and put workers
> on my account — it said OK I WILL, and nothing happened." Root cause: the
> agent loop accepted a text-only reply as the FINAL answer, so a model that
> narrates its plan ("ok, I will connect…") ended the run with zero actions.
> Three fixes: (1) **Force-action detection** — replies that announce future
> actions ("I will…", "let me…", Persian "می‌کنم/خواهم کرد…"), hand the work
> to the user ("you should go to…", step-by-step instructions), or answer a
> command task with a wall of explanation are REJECTED as final answers;
> the loop injects an EXECUTION MODE nudge (max 2 per run, questions and
> honest tool-backed summaries always finish normally) that tells the model
> exactly how to act with its tools — including a concrete Cloudflare
> Workers deploy example (PUT the script to api.cloudflare.com with the
> user's token); a lazy `finish` call gets the same treatment (rejected with
> a tool result so history stays protocol-valid). (2) **Text-protocol tool
> call rescue** — free-tier models often WRITE the tool call as JSON in text
> instead of native function calls; those are now parsed (OpenAI-style,
> action-style, args-as-string) and EXECUTED, with unknown tool names and
> data-JSON ignored for safety. (3) **Executor persona** — system prompt
> rule 0: "EXECUTE, DON'T ADVISE — you are the user's hands, not their
> consultant", plus http_request (tool + prompt) now explicitly framed as
> YOUR HANDS ON THE OUTSIDE WORLD: call any API with the user's tokens as
> headers to deploy, upload, send, configure — then verify and prove it.
> Pinned by 21 new tests reproducing the exact reported Cloudflare failure
> (English + Persian), lazy finishes, advice-detection, Q&A/proof
> non-traps, and every text-call rescue shape.
>
> **v2.13.3 — Gemini free-tier 429s handled (quota-aware retry + pacing):**
> "You exceeded your current quota" after ONE message is not a bug in your
> key — the Gemini free tier enforces **per-minute** (≈5–15 RPM) AND
> **per-day** request caps, and Liman is an agent: a single user message can
> mean many model calls (one per tool round-trip), so a naive chat-style
> retry loop burns the whole minute-window in seconds and then spins
> uselessly. Fixes: (1) Gemini 429 responses are now parsed properly — the
> server's `RetryInfo.retryDelay` (e.g. `26s`) and `QuotaFailure`
> violations (`PerDay` vs `PerMinute`) are extracted, and the user sees a
> clean one-line explanation instead of a raw JSON dump; (2) the provider
> keeps a per-provider cooldown, so follow-up calls in the agent loop WAIT
> out the server-supplied delay instead of hammering (which would keep
> resetting the window); (3) the agent's resilience loop retries with the
> server's hint (6–150 s) for per-minute limits — with a note that it will
> auto-continue — and is HONEST about the daily cap: waiting won't help
> until ~midnight Pacific, so it suggests adding a second provider or a
> `flash` model (free-tier flash limits are much higher than pro);
> (4) image-generation errors get the same clean parsing. Pinned by new
> unit tests using real Gemini 429 bodies (PerMinute with 26 s delay,
> PerDay, fractional 1.5 s delay, garbage body, non-quota 400).
>
> **v2.13.2 — DeepSeek web-chat REALLY fixed (send button + trusted typing):**
> the v2.13.1 diagnostics revealed the true failure: `send=NO_SEND, DOM
> events=0` — DeepSeek's send control is **not a `<button>`** but a
> `div[role="button"][aria-disabled]` (confirmed against real DeepSeek
> userscripts), so the old scanner never found it and nothing was ever
> clicked. Fixes: (1) send discovery now scans `[role="button"]` elements
> too and picks the rightmost enabled one in the chat input's row — the
> DeepSeek pattern — while keeping all classic button strategies;
> (2) typing now uses `execCommand('insertText')` FIRST (a real, trusted
> input event — what React composers actually enable Send on) with
> verification and the native-setter fallback; (3) input/poll/enter all
> agree on WHICH element is the chat input (was: poll read the last
> textarea on the page — the ghost `input=8` reading). The injected
> scripts are now EXECUTED in unit tests against a fake DOM in Rhino,
> including a regression test that reproduces the exact DeepSeek composer
> (textarea #chat-input + div[role=button] send + DeepThink toggle) and
> asserts the right control gets clicked.
>
> **v2.13.1 — web-chat bridge fixed for real sites (DeepSeek et al.):**
> "Test connection" on chat.deepseek.com failed with "no new answer
> appeared within 45 s" even though login and send worked — the answer
> DETECTION only knew ChatGPT-style DOM selectors and was blind to
> DeepSeek's `ds-markdown` blocks. Detection is now three-layered and
> site-independent: (1) selector count (ChatGPT/Gemini/Claude/Poe/DeepSeek
> + custom), (2) whole-document text growth beyond the typed prompt,
> (3) "input cleared + ≥5 post-send DOM mutations" via a MutationObserver
> (catches even the tiny 'OK' test reply). Plus: the send is verified
> (readback that the prompt actually landed in the input), a rescue
> re-send if the text still sits in the input after 5 s, a 20 s
> wait-for-input that detects logged-out sessions with a clear "open the
> login browser again" message, 60 s answer window, and every timeout now
> carries a diagnostics line (typed? sent? DOM bytes changed? events?
> page URL?) so the next failure is debuggable from the error alone.
> All injected scripts are unit-checked to be valid JavaScript (Rhino
> parse test) with locked selector coverage and prompt-escaping tests.
>
> **v2.13.0 — MEGA AGENT: run real code IN the app.** New `run_code` tool
> + upgraded `run_js`. Liman can now write and RUN actual programs like a
> developer: **bash runs on-device in a real shell** (embedded static busybox
> — 378 applets: awk, sed, grep, tar, wget, find, sort, bc…, shipped as
> native libs, applet-symlinked at first use; scripts run with cwd = the
> workspace, so they can process the user's files), **js runs on-device with
> npm**: `require('lodash')` downloads pure-JS packages from
> registry.npmjs.org, untars them (hand-written ustar/pax reader), caches
> them in the workspace and evaluates them inside the same security sandbox
> (CommonJS wrapper, mini event loop with setTimeout/setInterval, process/
> Buffer stubs). Everything else — **python, c, c++, java, go, rust, ruby,
> php, perl, typescript, kotlin, swift, scala, r, haskell** — runs on free
> NO-KEY online runners (paiza.io primary — every language live-verified —
> with wandbox.org fallback), with stdin support and clear failure hints.
> Engine auto-selection with explicit override (`engine: device|online`).
> All engines are covered by live unit tests (real npm downloads, the real
> busybox binary executing pipes/stdin/timeouts, a real paiza.io run).
>
> **v2.12.2 — generated APKs install again (Android 10 / OEM ROM fix):** apps
> built by the on-device `build_apk` tool reported "There was a problem
> parsing the package" on some Android 10 arm64 OEM ROMs. Root cause: the old
> zip writer streamed entries with *data descriptors* (zero sizes/CRC in local
> headers) — stock Android tolerates that, several OEM installers don't. The
> zip is now written deterministically like aapt2 does: real CRC + sizes in
> every local header, no data descriptors, 4-byte aligned entries
> (`zipalign -c 4` clean). JAR (v1) signing was also added on top of v2 —
> MANIFEST.MF + CERT.SF (SHA-256, 72-byte folding) + hand-built PKCS#7
> CERT.RSA, no BouncyCastle — so the APK carries both schemes (v1 verified
> by apksigner for its SDK range, v2 for Android 7.0+). Every build is
> self-verified by unit tests: no 0x0008 flags, local==central headers,
> alignment, META-INF present, and the reference toolchain (apksigner,
> zipalign, aapt) passes on a generated sample.
>
> **v2.12.1 — Web-to-API login browser fixed:** pressing "Open & log in" no
> longer shows a dead black page. Root causes found and fixed: OAuth popups
> ("Login with Google") were created invisible (off-screen WebView) — they
> are now attached and fully visible on top of the page; the browser area is
> a real white surface (no black void while pages load); live progress bar +
> page title + status line; load failures show a readable error card with
> Retry / Open-in-Chrome; system Back now closes the popup → goes back in
> history → then closes the dialog; cookies are flushed on close so the
> web-chat automation really picks the session up; force-dark and system
> font-scaling can no longer break the page.
>
> **v2.12 — the Free API Hunter:** Liman now FINDS and CHECKS free AI APIs by
> itself, daily. It searches X, Reddit, YouTube, GitHub and the web (rotating
> query sets), extracts candidate base URLs, then LIVE-VERIFIES every one —
> models list + a tiny chat request through an anonymous auth ladder, with a
> Responses-API fallback and patient 429 retries. Only verified rows are
> reported, exactly as needed: **name · base URL · where to sign up · works
> with no key? · models · latency**. No article links, no hearsay. Results
> live in the Radar's "🛰️ Free API hunter" table (tap a base URL to copy,
> "sign up ↗" opens the site), in `workspace/free-api-report.md`, and in the
> new `free_apis` tool — just ask Liman "which free APIs work today?" Known
> free tiers (OpenCode Zen, OpenRouter, Groq, Gemini, GitHub Models, Mistral,
> Cerebras, NVIDIA, SambaNova, Together, llm7, HuggingFace) are re-checked
> every hunt, so dead services are reported dead, never copied stale.
>
> **v2.11 — Free models with NO key, growing inside the app:** a native anonymous
> free provider (OpenCode Zen — Muse Spark 1.2/1.3 contributor-free) that needs
> **no API key, no account, no Termux, no cloud** — it works the moment the app is
> installed. Plus a **self-updating Free Catalog**: Liman pulls OpenCode's live model
> list and the models.dev community catalog (the same source 9Router syncs from),
> adds new `-free` models to the picker automatically, health-checks the channel,
> and flags dead ones. Deep-researched free landscape (Sept 2026): MiMo Code Free
> was sunset by Xiaomi on 2026-07-26 (the app knows and reports it); llm7's
> "unused" token now requires a key; DuckDuckGo AI is challenge-walled. All
> findings live in the Radar's new "🎁 Free models — no key" card, which also has
> the manual "Sync & health-check" button. Anonymous free = a shared public pool:
> Liman retries busy moments automatically with backoff and says so honestly.
>
> **v2.8 — the local router + Gemini hardening:** run a 9Router-compatible gateway
> **on the phone itself** — an OpenAI-compatible endpoint at `http://127.0.0.1:20128/v1`
> with free-first tiered routing, auto-fallback, RTK token saver and multi-account
> rotation, no server needed; plus a root fix for Gemini's "Invalid JSON payload
> received. Unknown name …" errors (every tool schema is now rewritten into Gemini's
> accepted subset, blank parts and non-object args can never reach the API).
>
> **v2.7 — "Quiet Intelligence" + Web-to-API:** real Markdown rendering in every
> message (code blocks with copy buttons), a new web-chat provider kind that drives ANY
> website chatbot (ChatGPT / Gemini web) as a provider — no API key, real browser session,
> hard to block; a self-healing provider engine (dead models are dropped for the run, image
> rejections auto-strip images and continue, malformed payloads trigger an adaptive retry
> ladder — the agent progresses no matter what); copy-any-message actions; and the chat
> screen rebuilt to the Quiet Intelligence spec: graphite + luminous mint palette, an
> animated "soft aperture" identity that reacts to real AI states, editorial answers,
> send⇄stop morph, smart auto-follow scrolling with jump-to-latest, aurora welcome,
> reduced-motion support.
>
> **v2.6 — the Midnight Bento redesign:** a complete new UI — dark-navy bento design,
> Vazirmatn typeface, Persian/RTL answers, English ⇄ فارسی app language switch, minimal
> Material Symbols icons (no more emojis), in-app HTML viewer, real Android file access
> (SAF), an autonomous skill/MCP hunter, a persistent user profile, a permissions
> manager, free-model auto-combos with search & badges, vision-aware model routing, a
> built-in model-guide skill, and JSON repair for marathon tool-heavy runs.
> Details in **"What's new"** below.

---

## Why it's not "just a chatbot"

| Capability | Simple chatbot app | Liman Agent |
|---|---|---|
| Answers questions | ✅ | ✅ |
| Decides *how* to reach a goal (plan → act → observe) | ❌ | ✅ cycle engine |
| Uses tools (files, web, code, memory, images) | ❌ | ✅ 16 sandboxed tools |
| Reads PDF / Word / Excel / PPT / EPUB / HTML / images / video | ❌ (paste text only) | ✅ native file ingestion |
| Runs precise computation | ❌ | ✅ calculator + sandboxed JS engine |
| Remembers facts across conversations | ❌ | ✅ long-term memory |
| Asks you clarifying questions mid-task | ❌ | ✅ `ask_user` tool |
| Reviews and grades its own work | ❌ | ✅ self-review (report or iterate) |
| Survives provider outages / rate limits | ❌ request fails | ✅ combo failover / round-robin / race |
| Works with many providers incl. free Gemini key or a local Ollama | usually one vendor | ✅ any OpenAI-compatible + Gemini + Claude |
| Generates images | ❌ | ✅ Gemini / OpenAI image models |
| Builds installable Android apps (APK) — on the phone | ❌ | ✅ `build_apk` (signed v2 APK, no build tools needed) |
| Verifies its own work by running + LOOKING at it | ❌ | ✅ mandatory BUILD → VERIFY → REVIEW → FIX loop with `render_html` screenshots |

## The Liman cycle

```
        ┌──────────────────────────────────────────────┐
        │                                              │
   ORIENT ──► PLAN ──► ┌─ THINK ──► ACT ──► OBSERVE ─┐ │
  (context)  (1 cheap   │  (model)  (tools,  (results)│ │
             plan pass) └──────────── loop ───────────┘ │
        │                                              │
        ▼                                              ▼
   VERIFY ──► FINISH        (loop-detection & context compaction
  (self-review)  (summary)   keep the loop efficient)
```

* **Loop detection** — identical repeated tool calls trigger a nudge, then a stop.
* **Context compaction** — 3 stages: truncate big tool outputs → drop old media → model-summarized history.
* **Provider combo** — every LLM call (including planning and review) goes through the combo chain.

## Providers

| Preset | Needs | Notes |
|---|---|---|
| **Google Gemini** | API key only | Free tier: [aistudio.google.com/apikey](https://aistudio.google.com/apikey) |
| OpenAI | API key | base URL fixed |
| Anthropic Claude | API key only | native Messages API |
| OpenRouter | API key | hundreds of models |
| Groq | API key | very fast inference |
| DeepSeek | API key | |
| Ollama (local) | nothing | run `ollama serve` in Termux, base URL `http://127.0.0.1:11434/v1` |
| LM Studio (local) | nothing | enable the local server |
| Custom | base URL + key + model | any OpenAI-compatible endpoint (vLLM, llama.cpp, …) |

### Combo modes

* 🛟 **Failover** — try providers in order; retry with backoff on transient errors (429/5xx/network); switch to the next provider on failure. Failed providers cool down and go to the back of the line.
* ⇄ **Round-robin** — rotate the starting provider each request (spreads load/quota).
* ⚡ **Race** — query every provider at once, first success wins (lowest latency, burns tokens).

## The toolbox

| Tool | What it does |
|---|---|
| `list_files`, `read_file` | workspace-aware file reading (see formats below) |
| `write_file`, `append_file`, `edit_file`, `delete_file` | create/modify/delete files in the sandboxed workspace |
| `http_request` | GET/POST/PUT/PATCH/DELETE anything; binary responses saved to workspace, images attached as vision |
| `web_search` | DuckDuckGo → Bing → Wikipedia fallback chain, no API key |
| `run_js` | sandboxed JavaScript (Rhino): no network, no Java access, instruction/time limits |
| `calculator` | exact math (arbitrary expressions, trig, logs…) |
| `memory_save` / `memory_recall` | persistent long-term memory across conversations |
| `image_generate` | generate images (Gemini or OpenAI-compatible image endpoint), saved + attached |
| `build_apk` | **package an HTML/CSS/JS app into a real signed installable APK — on-device** |
| `render_html` | **self-verification eyes**: renders your HTML app in a real browser engine, attaches a screenshot for the vision model + JS console errors + JS probe — the agent literally looks at what it built |
| `ask_user` | mid-task clarifying question with suggested answers |
| `datetime` | current date/time/timezone |
| `finish` | end the task with a summary |

Risky tools (`write_file`, `http_request`, `image_generate`, …) can require a tap-to-approve
dialog; read-only tools run instantly. "Always allow" per tool, or full YOLO mode, in Settings.

## File support

| Format | How it's understood |
|---|---|
| Images (png/jpg/webp/gif/bmp/heic) | downscaled & sent as vision input |
| PDF | pages rendered to images (via Android PdfRenderer) — works even with scanned PDFs |
| Video (mp4/mkv/mov/webm/…) | metadata + 4 sampled frames as vision |
| Audio | duration + note (transcription not built in) |
| Word .docx | full text extraction (runs XML parsing) |
| Excel .xlsx | per-sheet CSV extraction incl. shared strings |
| PowerPoint .pptx | per-slide text |
| EPUB | chapter text |
| HTML | cleaned text (scripts/styles stripped, entities decoded) |
| ZIP/JAR/APK | entry listing + member extraction |
| Text/code/json/csv/… | direct |

Everything is sandboxed to the app's internal `workspace/` folder — the agent cannot touch
the rest of your device. Share files from any app straight into Liman with the Android share
sheet. Voice input (speech recognizer) and spoken answers (TTS) included.

## Build & install

Requirements: **Android Studio** (Ladybug or newer) or a local JDK 17 + Android SDK 35.

**Android Studio:** open this folder, let Gradle sync, press ▶ Run.

**Command line:**

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
adb install app/build/outputs/apk/debug/app-debug.apk
```

Release build: `./gradlew assembleRelease` (add your signing config in `app/build.gradle.kts`).

- `minSdk 26` (Android 8.0) · `targetSdk 35`
- Permissions: **INTERNET only**. No storage permission — files come in via the system
  file picker / share sheet (SAF).

## Quick start

1. Install & open → **Settings → Providers → Add provider**.
2. Pick **Google Gemini**, paste a free key from aistudio.google.com/apikey, tap
   **Test connection**, then **Save**.
3. *(Optional but recommended)* add a second provider (e.g. Groq) and arrange a combo:
   **Settings → Combo → Failover**.
4. Back on the main screen: **New task**. Try:
   - *"Search the web for 3 reviews of the Pixel 10, then write a markdown summary file."*
   - Attach an Excel file: *"Analyze the data and compute per-region totals with run_js."*
   - *"Generate an image of a cat astronaut, then critique it honestly."*

## Security notes

- All agent file operations are confined to the app's internal workspace (path-traversal checked).
- `run_js` uses Rhino with a ClassShutter that denies **all** Java class access + time/instruction caps.
- `http_request` is http(s) only, size-capped; cleartext HTTP is allowed so local LLMs
  (Ollama/LM Studio in Termux or LAN) work — tighten `res/xml/network_security.xml` if you don't need that.
- API keys are stored in the app's private storage (`filesDir`) and never leave the device
  except to your chosen provider endpoints.
- Tool results and conversation history stay local (JSON files in `filesDir/conversations`).

## Project layout

```
app/src/main/java/com/liman/agent/
├── LimanApplication.kt, MainActivity.kt    app entry, share-intent handling
├── data/        models, presets, JSON stores (providers/combo/settings/memory/conversations)
├── llm/         Types, Http+SSE, OpenAiProvider, GeminiProvider, AnthropicProvider,
│                ComboProvider (failover / round-robin / race)
├── agent/       Agent (cycle engine: plan→act→observe→verify), Tools (16 tools),
│                SystemPrompt, Files (docx/xlsx/pptx/epub/html/zip), AndroidFiles
│                (pdf/video/image ingestion), WebSearch (DDG→Bing→Wikipedia),
│                Calculator, JsSandbox
├── ui/          Compose UI: chat, conversations, settings, components, view model
└── util/        helpers
app/src/test/    unit tests: calculator, office extractors, combo failover/race logic
```

## Troubleshooting

- **401/403** — wrong API key. **404** — wrong model name (check the provider's model list).
- **429** — rate limit: that's exactly what the combo is for; add a second provider.
- Empty answers from a local model — it may not support function calling; use a model that does.
- Gemini image generation requires an image-capable model (default `gemini-2.5-flash-image`).
- Web search may be rate-limited on some networks; the agent automatically falls through the engine chain.

## Roadmap ideas

## What's new

### v2.10.1 — the REAL 9Router on Android (Termux) + port handover

- **Researched + ran the real 9Router** (npm `9router` v0.5.69, github.com/decolua/9router) end-to-end: install, server boot on Node 22 with built-in `node:sqlite`, dashboard login + session, API-key creation, `/v1/models` (625 models), chat-completions routing, model catalog (1189 models / 21 providers).
- **Android fixes found + shipped in `9router-android/`**: `install-9router-android.sh` one-shot Termux installer (platform shim for "Unsupported platform: android", sql-wasm.wasm restore, xdg-open→termux-open-url shim, node:sqlite driver selection, INITIAL_PASSWORD, wake-lock, Termux:Boot autostart) + `9Router-Android-Guide.md` (free-tier access path: Kiro/iFlow/Qwen/OpenCode/OpenRouter/NVIDIA/Gemini/Cloudflare + OAuth subscriptions).
- **Port handover:** the real 9Router owns **20128**; Liman's mini-router moved to **20129** (one-shot migration rewrites settings + existing Liman-Router provider URLs). `RouterServer.start` now falls back to the next free port if one is taken, so both routers can run side by side.
- New provider preset **"9Router (the real one · Termux)"** → `http://127.0.0.1:20128/v1`, model `auto`, paste the `sk-…` key from the 9Router dashboard.

## v2.10 — 9Router dashboard + Google login fix + contrast & copiable errors

- **The 9Router now has a full web dashboard.** Open **http://127.0.0.1:20128/** in any browser on the phone (Settings → Local router → *Open 9Router dashboard in browser*). It shows and controls everything: router on/off, LAN toggle, every provider (name, kind, link, model, **API key masked/reveal + inline editing**, enable switch, free/paid badge), the combo (mode / retries / cooldown / members), all routes with a **live test button**, copy-ready endpoints + curl examples, and a live request log. Self-contained page — no internet needed.
- **Router enabled & auto-run.** v2.10 force-enables the router once (one-shot latch) and it boots with the app; fresh installs default to ON. The dashboard button also boots it on demand.
- **Restart-safe server.** The socket pool is recreated on start, so toggling LAN / restarting from the dashboard no longer leaves a dead executor behind. Request counter + uptime + LAN URL (Wi-Fi IP) surfaced in status.
- **Web2API Google login fixed.** The in-app login WebView now keeps **every** http(s) navigation inside the app (before, "Login with Google" escaped to Chrome and the session never came back — stuck pending). OAuth popups / `target=_blank` windows are funneled back into the same WebView, the UA's webview token is stripped so Google accepts the login, and the header shows **✓ Logged in** once the session cookie lands.
- **Sent messages are now deep blue.** User bubbles + send button use a dark blue gradient (#2F6FE4 → #1B4FD1) with light ink — much stronger contrast against the dark canvas. The mint→cyan signal gradient stays on the rail/accents.
- **Errors are copiable.** Tap any error (or warning) note → copy chip → full text on the clipboard. Failed tool cards show a copy chip with `tool + args + result` — paste it to the developer as a log.

## v2.9 — "Signal" full redesign (2026 evolved minimalism)

The whole app re-skinned around one idea: **a single signal gradient (mint → cyan) on a deep blue-graphite canvas.**

- **New palette** (`ui/theme/Theme.kt`): Canvas `#0D1117`, Surface `#161D26`, SurfaceHi `#1E2732`, Mint `#9EE8C7` (primary), Cyan `#6EC9F9` (secondary), Apricot `#F0BFA5` (tertiary), Ink `#EFF3F0` / InkDim `#A8B3AC`. Light theme: forest-mint `#12855F` on `#F5F8F6`.
- **Answers now live in bubbles** — soft tonal rounded bubbles (6·20·20·20 radii) with markdown rendered inside, not editorial bare text.
- **Bubbles are linked** by a 2dp **gradient rail** on the left of every assistant run: a bright mint→cyan pulse travels **down and back** ("go and back") while Liman is thinking/streaming, and settles to a quiet static gradient when resting. `GradientRail` respects reduced-motion.
- **Tap-to-copy on every message**: tap any bubble (user or assistant) → a small **copy chip springs in** next to it; tap the chip → text copied, chip flips to ✓ *Copied* and auto-hides. Long-press copy still works.
- **User bubbles** use the signal gradient fill with dark ink text — the only strong color in the chat, so answers stay readable.
- **Streaming bubble** shows the growing answer inside the same tonal bubble with a blinking cursor; the rail pulses while it grows.
- **Gradient send button** (mint→cyan circle, scale+rotate microinteraction), top bars blend with the canvas.
- `LimanDesignPreview.html` in the release zip — a self-contained HTML mockup of the new chat (same palette, radii and motion timings) so the design can be reviewed without installing.

## v2.8 — 9Router on your phone + the Gemini fix
- **Local router (9Router-compatible)** — a real HTTP gateway built into the app and running on the phone: `http://127.0.0.1:20128/v1` (9Router's own port). OpenAI-compatible `/v1/models` + `/v1/chat/completions` (plain and SSE streaming) that any app or CLI on the device can call — and Liman itself can use it as a provider (one-tap "Add router as Liman provider"). Implements 9Router's architecture natively: **free-first tiered fallback** (web chats, `:free` pools, Gemini free-tier keys first, paid after), **RTK token saver** (tool outputs passing through are compressed — ANSI stripped, head+tail kept; 20-40% token savings), **multi-account rotation** across duplicate providers, **format translation** (OpenAI requests → Gemini/Claude/OpenAI-compatible/web-chat backends), and combo health tracking so failing models are skipped. Special models: `auto` (all routes, free-first) · `free` (free routes only) · exact model names. Settings → Local router: run toggle, port, auto-start with the app, LAN exposure (0.0.0.0) for other devices on your Wi-Fi.
- **Gemini "Unknown name" fix** — the root cause: Gemini's function-declaration schemas accept only a strict JSON-Schema subset, and any extra key (`additionalProperties`, `$schema`, `default`, OpenAI-style `["type","null"]` arrays, properties without a type…) kills the whole request with `400 Invalid JSON payload received`. Every tool schema is now sanitized recursively into the accepted subset; blank text parts are filtered; non-object function arguments are wrapped. 6 new unit tests cover the sanitizer, 6 more cover the router's RTK compressor.


### v2.7 — Quiet Intelligence + the web-to-API bridge
- **Markdown rendering** — messages render real markdown: headings, **bold**, *italic*, `code`, fenced code blocks with language label + copy button, lists, quotes, tables, links, ~~strike~~. No more raw `*text*`. (13 new unit tests cover the parser.)
- **Web-to-API providers** — new provider kind "Web chat": point it at any website chatbot (chatgpt.com, gemini.google.com, Poe, DeepSeek, your company's internal bot…). Liman drives the site in a real WebView with your logged-in session: types into the site's input, presses its send button, watches the DOM and returns the fresh answer as a normal LLM response. No API key. Uses a real browser fingerprint + persistent cookies + natural delays (hard to block), one request at a time. Login once via Settings → Open & log in. Optional CSS selector overrides when a site's DOM changes. Honest limits: no tool calling, no image input (auto-degrades to text).
- **Self-healing provider engine** — wrong model names (HTTP 404) mark that handle dead for the whole run instead of retrying forever; "invalid JSON payload" 400s trigger an adaptive ladder (strip images → trim history → ask without tools) before giving up; when no provider accepts images the agent posts a note and continues text-only; a hard failure now ends with a graceful partial summary (files produced so far) instead of a dead stop.
- **Copy any message** — assistant answers get a quiet Copy action row; user messages copy on long-press; code blocks have their own copy buttons.
- **Quiet Intelligence chat screen** (per the master design brief) — graphite `#101315` canvas with tonal layering, luminous mint `#B9F5D0` accent, warm apricot secondary; editorial assistant answers (no more fat bubbles) with a small animated "soft aperture" identity mark whose motion maps to real states (idle = still, thinking = slow turn, streaming = quiet); user bubbles at 85% width with long-press copy; the composer is the signature component: 28dp rounded, 5-line limit, send⇄stop morph inside stable bounds; smart scrolling (auto-follow only while you're at the bottom, jump-to-latest pill when you scroll up); aurora light-field welcome screen (disabled under reduced motion); selectable text everywhere; motion tokens follow the spring research consensus (settle 300/30, pop 500/25, entrance 350/28 — transform & opacity only).


### v2.6 — Midnight Bento redesign + autonomy wave
- **Complete UI reskin** — dark navy "Midnight Bento" design language: tonal rounded cards (22–26dp), floating pill input, soft indigo accent, cyan/amber support colors, fixed brand scheme (no wallpaper re-theming), spring physics everywhere (press, morph, entrance, streaming). Inspired by the clean minimal AI-chat patterns of 2026.
- **Vazirmatn font app-wide** and **Persian RTL rendering** — answers in Persian automatically flow right-to-left with proper bidi layout; the whole UI mirrors when the app language is فارسی.
- **App language switch** — Settings → Language: System / English / فارسی (Vazirmatn renders both beautifully).
- **Minimal icon set** — every tool, button and card now uses Material Symbols vectors (53 icons); emoji stickers are gone.
- **In-app HTML viewer** — tapping a workspace .html file opens it inside Liman (offline WebView with sibling css/js/assets), no external browser needed.
- **Real Android file access** — Settings → Storage access: grant folders (SAF); the agent gets `storage_list` / `storage_read` / `storage_write` tools to browse, read and edit your actual device files inside the granted roots.
- **Autonomous skill & MCP hunting** — the system prompt now instructs the agent to decide by itself when a skill is needed, search the internet for one, install and use it — and to find + connect MCP servers on its own via the new `mcp_connect` tool (runtime tools, optional persistence).
- **Persistent user profile** — `profile_update` stores durable facts about you (job, favorites, how you like answers); facts are injected into every future prompt and shown/editable in Settings → User profile.
- **Permissions manager** — Settings → Permissions: per-tool Always allow / Ask / Deny (code, file writes, deletions, HTTP, images, subagents, storage writes, MCP).
- **JSON repair for marathon runs** — truncated/malformed tool arguments are auto-repaired (prefix-truncate + balance) so long high-volume tool-call sessions no longer stall.
- **Free-model auto-combo** — model lists mark FREE and VISION models; a search field filters them; the "use all free models" switch expands a provider into an auto-failover combo across every free model (OpenRouter's `:free` fleet).
- **Vision-aware smart routing** — when a message carries images, the combo reorders so vision-capable models run first.
- **Built-in model-guide skill** — which model suits which task, cost tiers, quality heuristics, combo recipes; auto-installed and consultable by the agent.
- **Parallel tool calls capped (12/turn)** — giant batches no longer starve the dispatcher.
 in v2

### ✈️ Telegram gateway
Turn Liman into your private Telegram bot (like Hermes' multi-platform gateways):
get a token from **@BotFather**, paste it in Settings → Telegram, then send the
pairing code (`/start XXXXXX`) to your bot from Telegram. The gateway runs as a
foreground service, runs **full agent cycles** per message, supports `/new`,
`/status`, forwards `ask_user` questions to the chat (reply within 10 min), and
stores every remote conversation inside the app. Pairing means strangers can't
burn your API keys. Optional auto-approve for remote tool use.

### 🔌 MCP connector (Model Context Protocol)
Add any MCP server with an HTTP endpoint (URL + optional bearer token). Liman
performs `initialize` → `tools/list` and every remote tool becomes a first-class
tool named `mcp_<server>_<tool>` (readOnly-annotated tools are auto-safe).
`tools/call` supports text AND image results (images are attached for vision).
Handles both plain-JSON and SSE-framed responses and session headers.

### 🎯 Skills — the self-improvement layer
Skills are `SKILL.md` folders (Claude Code / Hermes compatible format: YAML
frontmatter + instructions). Three ways they make Liman smarter over time:
- **Auto-loading:** before every task a router call checks the installed skill
  catalog against your prompt and injects the relevant skills automatically.
- **On demand:** `use_skill` loads any skill; the system prompt lists the catalog.
- **Internet discovery:** `search_skills` searches the web + the
  `anthropics/skills` GitHub registry for new skills, and `install_skill` adds
  them (with your approval). The Skills screen also offers manual search/URL
  import/file import/an in-app skill editor.

### 🤖 Subagents
`spawn_subagent` runs a nested Liman with its own cycle, tools and conversation
on a self-contained objective — **spawn several in one turn and they run in
parallel**. Each subagent's transcript is saved as its own conversation
(`🤖 …`) so you can audit exactly what happened. Approvals/questions forward
to the parent UI.

### 🔗 read_link — read anything on the web
`read_link` fetches a URL and extracts readable text (title + HTML→text, JSON,
plain). If the page needs JavaScript or extraction is too thin, it renders the
**whole page in an offscreen WebView** and attaches a full-height screenshot
(scaled for vision) so the model literally *looks* at the page.

### 🧠 Creativity engine
Settings → Agent behavior → Creativity: **Standard / Balanced / Creative / Genius**.
Creative generates multiple approaches and picks the most promising; Genius adds
first-principles decomposition, inversion ("how would this fail?"), cross-domain
analogies, per-cycle self-challenge.

### 📡 Free API radar
A dedicated screen (🔔 in the top bar) that sweeps the web — search engines +
the live OpenRouter catalog — for **free LLM API keys, tiers, credits and
giveaways**, plus models that are free on OpenRouter *right now*. It re-checks
about once a day when you open the app and flags new finds until you've seen
them. Results include direct links to claim/use them.

### 🔎 Live provider model catalog
Provider setup now has "Check key & list available models": it verifies the key
and endpoint, then fetches the **real model list** from the API
(`/v1/models`, Gemini `v1beta/models`, Anthropic `/v1/models`) so you tap to
pick a model instead of typing IDs.

### 🛡 Never-give-up engine + live heartbeat (v2.3)
- **Provider/network failures no longer stop the run.** Every LLM call is
  wrapped in a resilient retry loop: connectivity-aware backoff (8s → 45s,
  up to 15 minutes) that **resumes automatically** once the network or the
  provider is back. "Context too long" errors trigger auto-compaction and a
  retry. A one-time note in the chat explains what failed; the run continues.
- **Live status bar** while the agent works: pulsing dot (green = active,
  amber = waiting), current phase ("Thinking · cycle 4", "Acting · 3 tools",
  "📴 Network offline — waiting for connection…", "⏸ Waiting for your
  approval"), elapsed time and seconds since the last activity — so you always
  know whether Liman is working, waiting on you, or waiting on the network.
- **Visible thinking**: the system prompt now requires the model to open every
  turn with one short line about what it's doing and why, and to state how it
  will work around any error — no more silent tool calls.
- **Cycle timeline**: slim CYCLE dividers between agent cycles.
- **Material You**: on Android 12+ the whole UI follows your wallpaper
  colors; older devices keep the Liman teal palette.

### 📦 On-device APK builder (v2.4)
Ask Liman for *“build me a … app and give me the APK”* and it delivers a real,
**signed, installable .apk** — assembled entirely on your phone, with no
Android Studio, no aapt2, no gradle, no internet build service:

- The agent writes your app as a self-contained **HTML/CSS/JS bundle**
  (`index.html` entry point), tests the logic with `run_js`, then calls
  `build_apk`.
- Liman generates the **binary AndroidManifest.xml from scratch** (pure-Kotlin
  AXML writer), bundles a pre-compiled WebView shell `classes.dex`, packs the
  ZIP, and signs it with **APK Signature Scheme v2** (its own RSA key, same
  idea as a debug key) — all in milliseconds on-device.
- The APK is saved to `workspace/generated/`. Open the 📁 workspace sheet,
  tap the APK → **📦 Install** (Android will ask once to allow Liman to
  install unknown apps). Apps run full-screen in a WebView with JavaScript,
  localStorage and INTERNET permission; installable on Android 7.0+.
- Verified against Google's own reference tooling during development:
  `aapt2 dump badging` and `apksigner verify` both pass on generated APKs,
  and tampering with a single byte invalidates the signature.
- **Honest scope**: this builds *WebView* apps (HTML/CSS/JS). Apps needing
  native Android code, NDK libraries or Play Services cannot be produced
  on-device — a phone has no Java/Kotlin compiler or resource compiler.

### 🔁 Self-verification loop + eyes (v2.5)
Liman no longer *hopes* its output works — it **proves** it:

- **New tool `render_html`** — the agent's eyes. Renders any workspace HTML
  file (sibling css/js/assets served automatically) in a real browser engine,
  attaches the screenshot **as vision input**, reports JavaScript console
  errors/warnings, and can run a **JS probe** (e.g.
  `document.querySelectorAll('li').length`) to assert behavior.
- **Mandatory BUILD → VERIFY → REVIEW → FIX loop** baked into the system
  prompt: apps/pages must be screenshotted and studied after every change
  until the screenshot proves they work; logic checked with `run_js`;
  produced files re-read and totals re-computed; links verified with
  `read_link`; APKs only built after `render_html` passes on the same files.
  Up to ~5 verify-fix rounds, then an honest report of what was verified
  and how.
- **Open files in-app**: the 📁 workspace sheet file menu now has
  **📂 Open** — opens any workspace file (PDF, image, video, audio, text,
  HTML…) in the best matching app, plus **📦 Install** for APKs.

### ✨ Material 3 Expressive UI (2026) (v2.5)
- **Spring physics everywhere**: cards, buttons and messages respond with
  springy scale/press feedback (overshoot + bounce) instead of instant
  state flips — hand-rolled on stable Compose APIs.
- **Morphing motion**: new messages and tool cards slide in with spring
  overshoot; the live status bar's phase text morphs between states
  (slide + fade) and switches to a **three-dot wave** indicator when active.
- **Animated typing indicator**: wave dots while the model thinks.
- **Send button**: colored circle that squishes and twists on press;
  **Stop button** pulses while the agent runs.
- **Empty state**: gently bobbing ⚓ hero with staggered, springy
  suggestion cards.
- **Gradient user bubbles** (primary → tertiary), animated toast snackbar.

---

audio transcription · browser automation · scheduled (cron) tasks · per-provider cost tracking ·
sub-agents · MCP-style plugin tools.
