# Building Liman Agent in Android Studio

This is the complete, self-contained source of **Liman Agent v2.36.0** — a real
native Kotlin/Compose Android app (no WebView shell). Everything needed to
open, build and run it is in this folder.

## Requirements

| Tool | Version |
|---|---|
| Android Studio | Ladybug (2024.2.1) or newer |
| JDK | 17 (bundled with Android Studio — nothing to install) |
| Android SDK | Platform 35 + Build-Tools 35.0.0 (Android Studio auto-installs on sync) |
| Device | Android 8.0+ (minSdk 26), phone or emulator |

## Open & run (2 minutes)

1. **Unzip** this folder anywhere.
2. In Android Studio: **File → Open…** and select the unzipped `LimanAgent` folder.
3. Let Gradle **sync** finish (first sync downloads dependencies — needs internet).
4. Press **Run ▶** with a device or emulator connected.

That's it — `local.properties` is intentionally NOT included; Android Studio
creates it automatically with your own SDK path.

## Build an APK from the command line

```bash
./gradlew assembleDebug          # → app/build/outputs/apk/debug/app-debug.apk
./gradlew testDebugUnitTest      # full test suite (388 tests)
```

(Windows: use `gradlew.bat`.)

## Notes

- **Signing:** debug builds are auto-signed and installable. For a release
  build, generate your own keystore and wire it into `app/build.gradle.kts`
  (`signingConfigs`).
- **Gradle memory:** `gradle.properties` is tuned for a low-memory build
  environment (`-Xmx560m`, single worker). On a normal dev machine you can
  raise `-Xmx` (e.g. `-Xmx2g`) and remove `org.gradle.workers.max=1` /
  `org.gradle.parallel=false` for faster builds — the project builds fine
  either way.
- **First app start:** add a provider in Settings → Providers (Gemini needs
  just a free API key from aistudio.google.com/apikey). Everything else —
  skills, memory, automations, the agent loop — works out of the box.
- **Full power mode (optional):** install the Termux app (F-Droid build) and
  grant the Termux bridge permission in Liman's settings — this unlocks real
  local python/node/go/rust/… execution, git, npm and the whole Linux
  toolbox on-device.
- **Architecture:** single `:app` module, pure Kotlin + Jetpack Compose +
  Material 3, kotlinx.serialization, no NDK. See `README.md` for the full
  feature documentation.
