# Hermes Agent (Nous Research) × Liman — Feasibility Research (2026-09-15)

Question: can Liman's Termux bridge auto-install Hermes, run it on demand, and render
its chat inside the Liman chat screen?

## Verdict: YES — feasible, with a "Tier 2" caveat. ~80% of the vision is a clean v1.

## Facts verified (official docs + CLI reference)

**Termux is an officially supported install target (Tier 2 = best-effort):**
- One-liner auto-detects Termux: `curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash`
- On Termux the installer: uses `pkg` for system deps (git, python, nodejs, ripgrep, ffmpeg, build tools),
  creates a stdlib venv (`python -m venv` — NOT uv, because uv's pythons are glibc binaries),
  exports ANDROID_API_LEVEL, tries `.[termux-all]` extra → falls back `.[termux]` → base install,
  links `hermes` into `$PREFIX/bin`.
- Tested Termux bundle includes: CLI, cron, PTY/background terminal support,
  Telegram gateway (best-effort), MCP, Honcho memory, ACP support.
- Known blockers on Android: voice (faster-whisper → ctranslate2 has no Android wheels);
  browser + WhatsApp experimental (via node agent-browser).
- Build failures possible: some Python deps compile from source → needs
  `pkg install clang rust make pkg-config libffi openssl`; can be SLOW on a phone.
- constraints-termux.txt pins known-good versions.
- Data lives in `~/.hermes/` (survives across runs).

**Headless/programmatic mode exists — the bridge key:**
- `hermes chat -q "..."` — one-shot non-interactive prompt.
- `-Q / --quiet` — programmatic mode: suppresses banner/spinner/tool previews → clean stdout.
- `--resume <session>` / `--continue [name]` — session continuity → MULTI-TURN across one-shots.
- `--source <tag>` — documented as: "Use `tool` for third-party integrations that should
  not appear in user session lists" — designed for exactly our use case.
- `--image <path>`, `--max-turns <N>` (default 90), `--yolo` (bypass approvals — we should NOT default to this),
  `--checkpoints`, `--ignore-user-config`, `--safe-mode`.
- `hermes doctor` — built-in self-check (agent-device-style). `hermes version`.
- Slash commands inside REPL: /model /tools /skills /background /status /sessions /title …

**Model providers:**
- Custom OpenAI-compatible endpoint supported: `~/.hermes/.env` with
  `OPENAI_API_KEY` + `OPENAI_BASE_URL`, or config.yaml `model: {provider: custom, base_url: ...}`.
  → **the user's 9router server (combos!) can power Hermes for free.**
- Nous Portal (`hermes setup --portal`): 300+ models + Tool Gateway via one subscription, no keys.
- Also OpenRouter/DeepSeek/Kimi/Gemini/etc. Requires 64k+ context models (local phone
  inference NOT realistic — 70B needs 16GB+ VRAM per docs).

**Gateway API server option (v2 streaming):**
- hermes-webui project routes chat through a Hermes Gateway API server
  (HERMES_WEBUI_CHAT_BACKEND=gateway) — i.e. Hermes can expose an HTTP chat API.
  On Android, loopback (127.0.0.1) IS shared between apps → Liman could POST directly
  to a Termux-hosted Hermes API server for real streaming + persistent process.

## Proposed Liman architecture

**v1 — one-shot bridge (simple, robust):**
1. `HermesBridge` (new, agent-side): `status()` (hermes version/doctor parse),
   `install()` (pkg prereqs → curl installer → doctor, streamed into job log),
   `configure(env)` (write ~/.hermes/.env — 9router base URL + key).
2. Conversation flag `engine = "hermes"`: ChatViewModel diverts send() →
   `hermes chat -q -Q --source liman --resume <conv-id-mapped-session> "msg"`.
3. stdout tailed incrementally (existing job-log tailing) → AssistantEntry/ToolEntry-style
   cards; keep knots (user goal = "talk to Hermes").
4. Auto-(re)install check on opening a Hermes conversation: missing → guided install card.
5. Safety: no --yolo by default; approvals surfaced as notes; Liman's headless-risky law respected.

**v2 — gateway server bridge (real streaming, persistent session):**
- Start `hermes` gateway/API server on 127.0.0.1:port via bridge, Liman POSTs chat turns.

## Risks (honest)
- Tier 2: upstream commits can break Termux path anytime (constraints file mitigates).
- First install can take long (source compiles: rust/maturin/jiter) or fail on some phones.
- Per-turn latency: Python process spawn ≈ 2–6 s on phones + model latency; no true token
  streaming in v1 (log-tail pseudo-streaming instead).
- 64k-context model required → cloud (9router combos / Nous Portal / OpenRouter key);
  local Ollama on phone unrealistic.
- Storage: venv + repo ≈ 1–2 GB in Termux.
- Tool-approval UX in one-shot mode needs a defined policy.

## Synergies
- Liman agent ITSELF performs the install via termux_run (agent installs its guest agent).
- 9router combos power Hermes → zero extra accounts, free.
- Hermes skills/memory/cron enrich Liman; Liman UI (markdown, tool cards, date chips) renders it.
- Both sides speak MCP.
