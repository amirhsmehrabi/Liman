# Liman — MEGA FEATURES BACKLOG (2026-09-16, post-v2.29.0)

Vision/screen question + 20 candidate mega features for discussion. Research base:
SUPER_AGENT blueprints, OpenClaw/QwenPaw/mobile-use/OpenGUI landscape, Liman internals.

## VISION & SCREEN ACCESS — THE ANSWER
YES, 3 paths, best first:
1. **AccessibilityService.takeScreenshot()** (API 30+): silent, no consent dialog,
   needs `android:canTakeScreenshot="true"` in the service XML. Liman's DemoService
   already exists → add flag + capture → downscale (long edge ≤1024, JPEG q80) →
   LPart.Media attachment → vision-capable combo model (Gemini flash works free).
   FLAG_SECURE windows (banking) return ERROR_TAKE_SCREENSHOT_SECURE_WINDOW → detect
   + degrade to a11y tree + tell the user honestly.
2. **MediaProjection** (API 21+): full-screen incl. more contexts, but needs a
   user-consent dialog each session (hard Android boundary).
3. **Tree-first**: keep the a11y snapshot as the cheap default (3-5× cheaper than
   vision); vision only when tree is empty (games/canvas/WebView) or for visual
   verification. droidclaw's vision-fallback doctrine.
Pair with **set-of-marks**: draw numbered boxes on the downscaled screenshot for
clickable nodes (@m3 refs) → coordinates grounded across DPIs.
Pipeline pieces Liman ALREADY has: a11y service ✓, image attachments → media parts ✓,
vision providers via combos ✓, UiGuard anti-fragility ✓.

## THE 20 MEGA FEATURES (each: what / Liman fit / effort S-M-H)

### Perception & Device
1. **👁 Vision Mode** — screen screenshot → vision model → set-of-marks refs; vision
   fallback when tree empty; visual verification after actions. Fit: DemoService + media
   parts. Effort: M. THE capability jump.
2. **🔔 Notification Brain** — NotificationListenerService: read/dismiss/reply;
   notification-triggered automations ("when an X email lands, summarize"); daily
   digest flow. Fit: new service + triggers store (exists). Effort: M.
3. **🌐 In-App Browser Agent** — controllable WebView: navigate/click/fill/screenshot
   any site (JS-heavy/anti-bot). Fit: render_html already renders+screenshots WebView;
   generalize to arbitrary URLs + click/fill via JS injection. Effort: M.
4. **📍 Location & Sensor Triggers** — geofences ("at gym → log workout"), battery/
   charging/step conditions in automations. Fit: Scheduler + trigger system exist.
   Effort: M.
5. **🎙 Audio Scene Understanding** — on-device sound events (doorbell, baby crying,
   music ID) → automations. Creative/differentiating. Effort: H.

### Execution & Power
6. **🖥 Persistent Shell Sessions (PTY)** — session_id-addressable bash sessions in
   Termux: cd, venvs, ssh, long builds survive between calls; process registry +
   kill. Fixes the #1 Termux pitfall (fresh shell each call). Effort: M-H.
7. **🎬 Record→Replay Flows** — upgrade the existing demo recorder into parameterized
   replayable automations (tree+vision adaptive replay, variables like $CONTACT),
   one-tap flow tiles + QS. droidclaw "workflows". Effort: H (but recorder exists).
8. **⚡ Parallel Tool Fan-out** — read-only tools execute concurrently in one cycle
   (3× read_file + snapshot). Latency win. Effort: S-M.
9. **🧠 Big/Small Brain Router** — auto-route: flash-lite for reads/simple steps,
   pro model for planning/hard code; per-decision cost meter. Fit: combos exist.
   Effort: M.
10. **🏥 Watchdog Daemon** — Termux:Boot auto-start, phantom-killer bypass, bridge
    self-heal + health pings; "phone as reliable server". Fit: TermuxBridge +
    DiagLog. Effort: S-M.

### Reach & Channels (the OpenClaw lesson: 362k★ = channels + skills + self-host)
11. **💬 Telegram/WhatsApp Gateway** — talk to YOUR phone agent from anywhere:
    send tasks, get approvals, receive digests over chat. Remote control of the
    phone agent. Fit: RouterServer exists as transport pattern; Telegram Bot API
    is trivial HTTP. Effort: M. (OpenClaw proved the demand.)
12. **📲 Phone-as-MCP-Server** — expose ui/files/notifications/sensors as MCP tools
    over LAN → control your phone FROM Claude Desktop / VS Code. Liman becomes
    computer-use hardware for desktop agents. Fit: RouterServer + mcp layer exist.
    Effort: M. Uniquely possible for Liman.
13. **🫧 Floating Bubble** — overlay mini-chat over any app + "act on what I'm
    looking at" (bubble → snapshot → act). System-wide assistant feel. Effort: M.
14. **👥 Companion Nodes** — desktop/second-phone peers sharing camera/screen/tools
    (OpenClaw "Nodes" pattern). Effort: H.

### Memory & Intelligence
15. **🧠 Embedding Memory RAG** — episodic recall across ALL past conversations,
    auto-curation, provenance tags. Fit: SemanticMemory store exists (keyword);
    add embeddings (API or on-device). Effort: M.
16. **🤖 Self-Evolving Skill Loop** — auto-draft a skill after every hard task
    (skill_create exists!) + "what I learned this week" digest; user approves.
    Hermes-style self-improvement. Effort: S-M.
17. **🧪 Eval Harness + Trace Replay** — 20 golden tasks (in-app dev mode), run
    history with screenshot timeline; regression gates before shipping. Effort: M.
18. **🔀 Conversation Forking + Recipes** — branch any chat at any message; save
    flows as reusable $variable templates library. Fit: PromptVars exists.
    Effort: S-M.

### UX & Trust
19. **🗂 Auto-Snapshots + Diff Cards + Trash** — every write_file/edit snapshotted;
    red/green diff cards in UI; trash folder + "undo last change". Effort: S-M.
20. **🎛 Autonomy Dial + Permissions Dashboard** — one-tap mode (read-only → ask →
    auto → full) + review/revoke learned permissions. Effort: S-M.

## RECOMMENDED BUILD ORDER (impact × feasibility for THIS codebase)
Wave 1 (biggest jumps): 1 Vision, 2 Notifications, 6 Persistent Shell.
Wave 2 (reach): 11 Telegram Gateway, 7 Replay Flows, 13 Bubble.
Wave 3 (depth): 15 Memory RAG, 9 Router, 19 Snapshots, 20 Dial.
Wave 4 (frontier): 12 Phone-as-MCP, 3 Browser, 17 Evals, rest.

## RESEARCH NOTES (2026-09)
- OpenClaw (ex-Clawdbot, ~362k★): self-hosted gateway, 20+ chat channels, 5.4k+
  community skills, Nodes = companion devices exposing camera/screen. Lesson:
  channels + skills + self-host = the winning shape. No slick mobile app — Liman's slot.
- QwenPaw (AgentScope): 3-layer memory, self-evolving knowledge base (ReMe), local
  2B-9B agent models, kernel sandbox + tool guard. Lesson: memory depth + safety.
- mobile-use (minitap): natural-language phone control, data scraping from any app
  → JSON. Lesson: "scrape any app into JSON" is a killer tool shape.
- OpenGUI (1.8k★): phone-use GUI agent framework (see/plan/operate).
- TopoClaw: cross-device Android+Windows GUI agent, "proactive assistant".
- Security notes: a11y takeScreenshot is silent (no indicator) — powers vision;
  FLAG_SECURE blocks screenshots but NOT the a11y tree (banking trojan technique —
  we use the tree legitimately, and must detect FLAG_SECURE and be honest).
